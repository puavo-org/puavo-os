/**
 * Convert Integer to Big Endian Value
 * @param intValue
 * @returns {Int8Array}
 */
function convert_int_into_bytes_big_endian(intValue) {
  var result = new Int8Array(4);
  result[3] = 0xff & intValue;
  result[2] = 0xff & (intValue >> 8);
  result[1] = 0xff & (intValue >> 16);
  result[0] = 0xff & (intValue >> 24);

  return result;

}

/**
 * Convert 4Bytes Big Endian arrays to Integer
 * @param byte1
 * @param byte2
 * @param byte3
 * @param byte4
 * @returns
 */
function convert_bytes_big_endian_into_int(byte1, byte2, byte3, byte4) {
  var firstByte = 0xff & byte1;
  var secondByte = 0xff & byte2;
  var thirdByte = 0xff & byte3;
  var fourthByte = 0xff & byte4;
  var result = ((firstByte << 24) | (secondByte << 16) | (thirdByte << 8) | fourthByte) & 0xFFFFFFFF;
  return result
}

/**
 * Covert String to bytes arrays
 * @param str
 * @returns {Array}
 */
function convert_str_into_bytes(str) {
  var bytes = [];
  for (var i = 0; i < str.length; ++i) {
    bytes.push(str.charCodeAt(i));
  }

  return bytes;
}

/**
 * Covert String to bytes arrays
 * @param array
 * @returns {String}
 */
function convert_bytes_array_into_str(array) {
  var result = "";
  for (var i = 0; i < array.length; i++) {
    result += String.fromCharCode(array[i]);
  }

  return result;
}

/**
 * Conver String to bytes arrays with UTF-8 Decode
 * @param arrayBuffer
 * @returns {String}
 */
function convert_bytes_array_into_str_utf8(arrayBuffer) {
  var result = "";
  var i = 0;
  var c = 0;
  var c1 = 0;
  var c2 = 0;

  var data = new Uint8Array(arrayBuffer);

  // If we have a BOM skip it
  if (data.length >= 3 && data[0] === 0xef && data[1] === 0xbb && data[2] === 0xbf) {
    i = 3;
  }

  while (i < data.length) {
    c = data[i];

    if (c < 128) {
      result += String.fromCharCode(c);
      i++;
    } else if (c > 191 && c < 224) {
      if (i + 1 >= data.length) {
        throw "UTF-8 Decode failed. Two byte character was truncated.";
      }
      c2 = data[i + 1];
      result += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
      i += 2;
    } else {
      if (i + 2 >= data.length) {
        throw "UTF-8 Decode failed. Multi byte character was truncated.";
      }
      c2 = data[i + 1];
      c3 = data[i + 2];
      result += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
      i += 3;
    }
  }
  return result;
}

/**
 * Covert array bytes to base64
 * @param bytes
 * @returns
 */
function covert_array_into_Base64(bytes) {
  var binary = ''
  var len = bytes.byteLength;
  for (var i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return window.btoa(binary);
}

/**
 * Get Chromebook display width
 * @returns {Number}
 */
function getScreenDisplayWidth(cb) {
  //	var width = 1920;
  var width;
  chrome.system.display.getInfo(function (displayInfo) {
    for (var i = 0; i < displayInfo.length; i++) {
      var disObject = displayInfo[i];
      if (disObject.isPrimary) {
        width = disObject.bounds.width;
      }
    }
    cb(width);
  });
  console.log("Screen Widht = " + width);
  return width;
}

/**
 * Get Chromebook height
 * @returns {Number}
 */
function getScreenDisplayHeight(cb) {
  //	var height = 1080;
  var height;
  chrome.system.display.getInfo(function (displayInfo) {
    for (var i = 0; i < displayInfo.length; i++) {
      var disObject = displayInfo[i];
      if (disObject.isPrimary) {
        height = disObject.bounds.height;
      }
    }
    cb(height);
  });
  console.log("Screen Height = " + height);
  return height;
}

/**
 * Get Youtube URL
 * @param url
 * @returns
 */
function getYoutubeId(url, type) {
  var result = "";
  if (type == 1) {
    //https://www.youtube.com/watch?v=ElJxUVJ8blw&feature=youtu.be
    result = url.substring(32, 43);
  } else if (type == 2) {
    result = url.substring(17, 28);
    //https://youtu.be/ElJxUVJ8blw
  } else if (type == 3) {
    //https://m.youtube.com/watch?v=ElJxUVJ8blw
    result = url.substring(30, 41);
  }
  return result;
}

function getVotingAnswer(type) {
  var result = "";
  switch (type) {
  case 1:
    result = "TRUE";
    break;
  case 2:
    result = "FALSE";
    break;
  case 5:
    result = "A";
    break;
  case 6:
    result = "B";
    break;
  case 7:
    result = "C";
    break;
  case 8:
    result = "D";
    break;
  case 9:
    result = "E";
    break;
  }

  return result;
}


function getStreamingSecond(firstByte, secondByte) {
  var c = 0xff & firstByte;
  var d = 0xff & secondByte;
  var result = (c << 8 | d) & 0xffffffff;
  return result;
}

function transferToHHMMSS(timeValue) {
  var sec_num = parseInt(timeValue, 10);
  var hours = Math.floor(sec_num / 3600);
  var minutes = Math.floor((sec_num - (hours * 3600)) / 60);
  var seconds = sec_num - (hours * 3600) - (minutes * 60);

  if (hours < 10) {
    hours = "0" + hours;
  }
  if (minutes < 10) {
    minutes = "0" + minutes;
  }
  if (seconds < 10) {
    seconds = "0" + seconds;
  }
  var time = hours + ':' + minutes + ':' + seconds;
  return time;
}

function getSendNameById(uid) {
  for (var i = 0; i < user_list.length; i++) {
    console.log(user_list);
    var user = user_list[i];
    if (user.uid == uid) {
      return user.label;
    }
  }
}

function amIHost(uid) {
  for (var i = 0; i < user_list.length; i++) {
    var user = user_list[i];
    if (user.uid == uid) {
      return user.isHost;
    }
  }
}

function getHostName() {
  for (var i = 0; i < user_list.length; i++) {
    var user = user_list[i];
    if (user.isHost) {
      return user.label;
    }
  }
}

function b64toBlob(b64Data, contentType, sliceSize) {
  contentType = contentType || '';
  sliceSize = sliceSize || 512;

  var byteCharacters = atob(b64Data);
  var byteArrays = [];

  for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
    var slice = byteCharacters.slice(offset, offset + sliceSize);

    var byteNumbers = new Array(slice.length);
    for (var i = 0; i < slice.length; i++) {
      byteNumbers[i] = slice.charCodeAt(i);
    }

    var byteArray = new Uint8Array(byteNumbers);

    byteArrays.push(byteArray);
  }

  var blob = new Blob(byteArrays, {
    type: contentType
  });

  return blob;
}

function getUserData(uid) {
  for (var i = 0; i < user_list.length; i++) {
    var user = user_list[i];
    if (user.uid == uid) {
      return user;
    }
  }
}

function isMoreThanTwoUser() {
  var count = 0;
  for (var i = 0 ; i < user_list.length; i++) {
    var user = user_list[i];
    if (user.online) {
      if (user.os_type >= 12 && user.os_type <=16) {
        //Ignore google cast and airplay
      } else {
        count++;
      }
    }
  }

  if (count > 1) {
    return true;
  } else {
    return false;
  }
}

function getOnlineUserCounts() {
  var count = 0;
  for (var i = 0 ; i < user_list.length; i++) {
    var user = user_list[i];
    if (user.online) {
      if (user.os_type >= 12 && user.os_type <=16) {
        //Ignore google cast and airplay
      } else {
        count++;
      }
    }
  }

  return count;
}

function getCurrentDaySeconds() {
  var dt = new Date();
  var secs = dt.getSeconds() + (60 * dt.getMinutes()) + (60 * 60 * dt.getHours());
  return secs;
}

function getFilenameByCurrentTime() {
  var thisTime = new Date();
  var month;
  var date;
  var hour;
  var minute;
  var second;
  if (thisTime.getMonth() + 1 < 10) {
    month = "0" + (thisTime.getMonth() + 1);
  } else {
    month = thisTime.getMonth() + 1;
  }
  if (thisTime.getDate() < 10) {
    date = "0" + (thisTime.getDate());
  } else {
    date = thisTime.getDate();
  }
  if (thisTime.getHours() < 10) {
    hour = "0" + (thisTime.getHours());
  } else {
    hour = thisTime.getHours();
  }
  if (thisTime.getMinutes() < 10) {
    minute = "0" + (thisTime.getMinutes());
  } else {
    minute = thisTime.getMinutes();
  }
  if (thisTime.getSeconds() < 10) {
    second = "0" + (thisTime.getSeconds());
  } else {
    second = thisTime.getSeconds();
  }

  return thisTime.getFullYear() + "-" + month + "-" + date + "_" + hour + "-" + minute + "-" + second + ".jpg";
}

function getOS(os) {
  switch (os) {
  case "win":
    return OS_DEV_TYPE.OS_CHROME_APP_ON_WIN;
  case "mac":
    return OS_DEV_TYPE.OS_CHROME_APP_ON_MAC;
  case "cros":
    return OS_DEV_TYPE.OS_CHROME_APP;
  default:
    return OS_DEV_TYPE.OS_CHROME_APP;
  }
}

function utf8_encode(argString) {
  //  discuss at: http://phpjs.org/functions/utf8_encode/
  // original by: Webtoolkit.info (http://www.webtoolkit.info/)
  // improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
  // improved by: sowberry
  // improved by: Jack
  // improved by: Yves Sucaet
  // improved by: kirilloid
  // bugfixed by: Onno Marsman
  // bugfixed by: Onno Marsman
  // bugfixed by: Ulrich
  // bugfixed by: Rafal Kukawski
  // bugfixed by: kirilloid
  //   example 1: utf8_encode('Kevin van Zonneveld');
  //   returns 1: 'Kevin van Zonneveld'

  if (argString === null || typeof argString === 'undefined') {
    return '';
  }

  var string = (argString + ''); // .replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  var utftext = '',
    start, end, stringl = 0;

  start = end = 0;
  stringl = string.length;
  for (var n = 0; n < stringl; n++) {
    var c1 = string.charCodeAt(n);
    var enc = null;

    if (c1 < 128) {
      end++;
    } else if (c1 > 127 && c1 < 2048) {
      enc = String.fromCharCode(
        (c1 >> 6) | 192, (c1 & 63) | 128
      );
    } else if ((c1 & 0xF800) != 0xD800) {
      enc = String.fromCharCode(
        (c1 >> 12) | 224, ((c1 >> 6) & 63) | 128, (c1 & 63) | 128
      );
    } else { // surrogate pairs
      if ((c1 & 0xFC00) != 0xD800) {
        throw new RangeError('Unmatched trail surrogate at ' + n);
      }
      var c2 = string.charCodeAt(++n);
      if ((c2 & 0xFC00) != 0xDC00) {
        throw new RangeError('Unmatched lead surrogate at ' + (n - 1));
      }
      c1 = ((c1 & 0x3FF) << 10) + (c2 & 0x3FF) + 0x10000;
      enc = String.fromCharCode(
        (c1 >> 18) | 240, ((c1 >> 12) & 63) | 128, ((c1 >> 6) & 63) | 128, (c1 & 63) | 128
      );
    }
    if (enc !== null) {
      if (end > start) {
        utftext += string.slice(start, end);
      }
      utftext += enc;
      start = end = n + 1;
    }
  }

  if (end > start) {
    utftext += string.slice(start, stringl);
  }

  return utftext;
}

function parseYoutubeText(inputValue) {
  var start = inputValue.indexOf('&title');
  if (start === -1) {
    return "error";
  }

  var result1 = inputValue.substring(start + 7, inputValue.length);
  var end = result1.indexOf('&');
  var result2 = result1.substring(0, end).replace(/\+/g, " ");
  return result2;
}

function checkIfFilenameTooLong(filename, username) {
  if (filename.length > 256) {
    var start1 = username.length;
    var result1 = filename.substring(start1 + 1, filename.length);
    console.log(result1.length);
    return username + "_" + filename;
  } else {
    return filename;
  }
}

function getOSDeviceNameByType(os_type) {
  var device = "";
  if (os_type === OS_DEV_TYPE.OS_WINDOWS_PC) {
    device = "Win PC";
  } else if (os_type == OS_DEV_TYPE.OS_MAC_PC) {
    device = "Mac PC";
  } else if (os_type == OS_DEV_TYPE.OS_LINUX_PC) {
    device = "LINUX_PC";
  } else if (os_type == OS_DEV_TYPE.OS_UNIX_PC) {
    device = "UNIX_PC";
  } else if (os_type == OS_DEV_TYPE.OS_ANDROID_TABLET) {
    device = "Android Pad";
  } else if (os_type == OS_DEV_TYPE.OS_ANDROID_PHONE) {
    device = "Android Phone";
  } else if (os_type == OS_DEV_TYPE.OS_IOS_IPAD) {
    device = "iPad";
  } else if (os_type == OS_DEV_TYPE.OS_IOS_PHONE) {
    device = "iPhone";
  } else if (os_type == OS_DEV_TYPE.OS_CHROME_APP) {
    device = "Chromebook";
  } else if (os_type == OS_DEV_TYPE.OS_CHROME_APP_ON_WIN) {
    device = "Chrome on Win";
  } else if (os_type == OS_DEV_TYPE.OS_CHROME_APP_ON_MAC) {
    device = "Chrome on Mac";
  } else if (os_type == OS_DEV_TYPE.OS_AIRPLAY) {
    device = "Airplay";
  } else if (os_type == OS_DEV_TYPE.OS_GOOGLE_CAST) {
    device = "Google Cast";
  } else if (os_type == OS_DEV_TYPE.OS_HDMI_IN) {
    device = "HDMI IN";
  } else if (os_type == OS_DEV_TYPE.OS_WINDOWS_PC_LITE) {
    device = "Win PC Lite";
  } else if (os_type == OS_DEV_TYPE.OS_MAC_PC_LITE) {
    device = "Mac PC Lite";
  } else if (os_type == OS_DEV_TYPE.OS_IOS_IPAD_LITE) {
    device = "iPad Lite";
  } else if (os_type == OS_DEV_TYPE.OS_IOS_PHONE_LITE) {
    device = "iPhone Lite";
  } else if (os_type == OS_DEV_TYPE.OS_ANDROID_TABLET_LITE) {
    device = "Android Pad Lite";
  } else if (os_type == OS_DEV_TYPE.OS_ANDROID_PHONE_LITE) {
    device = "Android Phone Cast";
  } else if (os_type == OS_DEV_TYPE.OS_LINUX_PC_LITE) {
    device = "Linux";
  } else if (os_type == OS_DEV_TYPE.OS_UNIX_PC_LITE) {
    device = "Unix";
  } else if (os_type == OS_DEV_TYPE.OS_MIRACAST) {
    device = "Miracast";
  } else {
    device = "";
  }

  return device;
}

function amIPresenter(uid) {
  for (var i = 0; i < user_list.length; i++) {
    var user = user_list[i];
    if (user.uid == uid && user.panel >= 0) {
      return true;
    }
  }
  return false;
}

function getUserListStatus() {
  var result = RVA_PLAY_STATUS.PENDING_ALL;
  for (var i = 0; i < user_list.length; i++) {
    var user = user_list[i];
    if (user.panel === 0 && user.os_type < 5) {
      result = RVA_PLAY_STATUS.FULL_VIDEO;
      break;
    } else if (user.panel === 0 && user.os_type > 4) {
      result = RVA_PLAY_STATUS.FULL_IMAGE;
      break;
    } else if (user.panel > 0) {
      result = RVA_PLAY_STATUS.SPLIT_IMAGE;
      break;
    }
  }

  return result;
}

/**
 * Convert Integer to Two Bytes Big Endian Value
 * @param intValue
 * @returns {Int8Array}
 */
function convertIntegerTwoBytes(intValue) {
  var result = new Int8Array(2);
  result[1] = 0xff & intValue;
  result[0] = 0xff & (intValue >> 8);

  return result;

}

function convertPositionToArray(data) {
  var result = [];
  for (var i = 0; i < data.length; i++) {
    result.push(convertIntegerTwoBytes(data[i].x)[0]);
    result.push(convertIntegerTwoBytes(data[i].x)[1]);
    result.push(convertIntegerTwoBytes(data[i].y)[0]);
    result.push(convertIntegerTwoBytes(data[i].y)[1]);
  }
  console.log(result);
  return result;
}

function randomString(length, chars) {
  var mask = '';
  if (chars.indexOf('a') > -1) mask += 'abcdefghijklmnopqrstuvwxyz';
  if (chars.indexOf('A') > -1) mask += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  if (chars.indexOf('#') > -1) mask += '0123456789';
  if (chars.indexOf('!') > -1) mask += '~`!@#$%^&*()_+-={}[]:";\'<>?,./|\\';
  var result = '';
  for (var i = length; i > 0; --i) result += mask[Math.floor(Math.random() * mask.length)];
  return result;
}

function isNoOneMirroring() {
  var result = true;
  for (var i = 0; i < user_list.length; i++) {
    var user = user_list[i];
    if (user.panel >= 0) {
      result = false;
      break;
    }
  }

  return result;
}

function isHostOnline() {
  for (var i = 0 ; i < user_list.length; i++) {
    var user = user_list[i];
    if (user.online && user.isHost) {
      return true;
    }
  }

  return false;
}
function isUserOnList(uid) {
  for (var i = 0; i < user_list.length; i++) {
    var user = user_list[i];
    if (user.uid == uid) {
      return true;
    }
  }
  return false;
}
