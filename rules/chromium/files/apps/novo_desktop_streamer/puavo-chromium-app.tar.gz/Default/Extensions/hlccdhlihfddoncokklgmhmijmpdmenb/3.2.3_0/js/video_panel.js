function onChooseFolder(entry) {
  chrome.runtime.getBackgroundPage(function(bg) {
    window.bg = bg;
    window.entry = entry.filesystem.root;
    bg.entry = entry.filesystem.root;
    bg.haveentry(entry.filesystem.root);
 	});
  fileName = entry.name;
}

var type;
var fileName;

var main = chrome.app.window.get("main").contentWindow;

function isSupportNewVideoPlay() {
  return main.supportNewVideoPlay;
}

function go() {
  var filePath = document.querySelector('#video_path');
  if (filePath.value.length > 42 && filePath.value.substring(0,32) == "https://www.youtube.com/watch?v=") {
    console.log("YoutubeStreaming");
    type = "youtube";
    main.sendYoutubeStreaming(filePath.value, 1);
  }else if (filePath.value.length > 17 && filePath.value.startsWith("https://youtu.be/")) {
    console.log("YoutubeStreaming");
    type = "youtube";
    main.sendYoutubeStreaming(filePath.value, 2);
  }
  else if (filePath.value.length > 40 && filePath.value.substring(0, 30) == "https://m.youtube.com/watch?v=") {
    console.log("YoutubeStreaming");
    type = "youtube";
    main.sendYoutubeStreaming(filePath.value, 3);
  }
  else if (filePath.value.startsWith("https://drive.google.com")) {
    console.log("Google drive streaming");
    type = "web";
    main.sendWebStreaming("web->"+getGooglDrvieURL(filePath.value));
  }
  else if (filePath.value.startsWith("https://www.dropbox.com")) {
    console.log("Dropbox streaming");
    type = "web";
    main.sendWebStreaming("web->"+getDropboxURL(filePath.value));
  }
  else if (filePath.value.startsWith("https://") || filePath.value.startsWith("http://")) {
    console.log("WebStreaming");
    type = "web";
    main.sendWebStreaming("web->"+filePath.value);
  }
  else if (filePath.value.length > 0) {
    console.log("LocalStreaming");
    type = "local";
    main.sendLocalStreaming(fileName);
  }
  else {
    console.log("Error filepath");
    sendVideoResult(-1, $.t("video.unreachableUrl"));  // error
  }
}

function close_video_panel() {
	main.close_video_panel();
}

function sendStreaming_STOP() {
    main.controlStreaming(type, PLAY_CMD.EXIT);
}

function sendStreaming_FOWARD() {
	main.controlStreaming(type, PLAY_CMD.FORWARD);
}

function sendStreaming_REVERSE() {
	main.controlStreaming(type, PLAY_CMD.REVERSE);
}

function sendStreaming_PAUSE() {
	main.controlStreaming(type, PLAY_CMD.PAUSE);
}

function sendStreaming_RESUME() {
	main.controlStreaming(type, PLAY_CMD.RESUME);
}

function sendStreamingPercentToRVA(percent) {
  main.sendStreamingPercentToRVA(percent);
}

function getFileType(filename) {
  //'wmv','mp4','mov','avi','3gp','3g2','mkv','mp3','AAC','wma'
  //var a = filename.substring(filename.length -3, filename.length);
  var a = filename.slice((filename.lastIndexOf(".") - 1 >>> 0) + 2).toLowerCase();
  if (a == 'wma' || a == 'aac' || a == 'mp3' || a == 'wav') {
    return "audio";
  }
  else {
    return "video";
  }
}

function getGooglDrvieURL(url) {
  var result = "";
  if (url.substring(0,33) === "https://drive.google.com/open?id=") {
    result = url.substring(33, url.length);
  }
  else if (url.substring(0,32) === "https://drive.google.com/file/d/") {
    var end = url.indexOf("/view");
    result = url.substring(32, end);
  }
  return "https://drive.google.com/uc?id="+result+"&export=open";
}

function getDropboxURL(url) {
  return url.replace("dl=0", "dl=1");
}
