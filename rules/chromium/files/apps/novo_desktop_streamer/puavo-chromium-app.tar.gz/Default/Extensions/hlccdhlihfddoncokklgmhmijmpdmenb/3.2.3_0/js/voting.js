var voting;

$(document).ready(function () {
  var language = 'en-US'; //'zh-TW';//en-US  
  translate(chrome.i18n.getUILanguage());

  voting = $("#voting-page").votingPanel();

  $(".icon-minimize").off().click(function () {
    chrome.app.window.current().minimize();
  });

  $(".icon-fullscreen").off().click(function () {
    ($(this).hasClass('onMax')) ? runRestore(): runMax();
  });

  $(".icon-close").off().click(function () {
    chrome.app.window.current().hide();
  });

  $("#font-func .bigger").click(function () {
    //$("#q-content").css("font-size", "bigger");
    var fontSize = parseInt($("#q-content").css("font-size")) + 2;
    $("#q-content").css("font-size", fontSize);
    $("#q-content span").css("font-size", fontSize);
  });
  $("#font-func .smaller").click(function () {
    //$("#q-content").css("font-size", "bigger");
    var fontSize = parseInt($("#q-content").css("font-size")) - 2;
    $("#q-content").css("font-size", fontSize);
    $("#q-content span").css("font-size", fontSize);
  });

  $("#font-func .bigger").click(function () {

  });


  (chrome.app.window.current().isMaximized()) ? onMax(): onUnmaximize();
  chrome.app.window.current().onMaximized.addListener(onMax);
  chrome.app.window.current().onRestored.addListener(winOnRestore);

  
});

function createQuestion(votingObject) {
  voting.votingPanel("createQuestion", votingObject.question);

  // Restore answer, result
  if (typeof votingObject.studentClickAnswer != "undefined") {
    $('*[value="' + votingObject.studentClickAnswer + '"]').trigger("click").addClass("checked");
  }
  if (typeof votingObject.studentAnswerSubmited != "undefined") {
    if (votingObject.question.type != 6) {
      var compare = (votingObject.studentClickAnswer == votingObject.studentSubmitAnswer);
      voting.votingPanel("submitAnswerResult", votingObject.studentAnswerSubmited, ((compare) ? votingObject.studentAnswerSubmitedMsg : ''));
    } else {
      if (votingObject.studentAnswerSubmited) {
        setUploading(votingObject.studentSubmitAnswer);
        voting.votingPanel("submitAnswerResult", votingObject.studentAnswerSubmited, votingObject.studentAnswerSubmitedMsg);
      }
    }
  }
  if (typeof votingObject.flag != "undefined") {
    voting.votingPanel("showAnswerResultDialog", votingObject.flag, votingObject.correctAnswer);
  }
  if (votingObject.stopVoting) {
    voting.votingPanel("stopAnswerQuestion");
  }
}

function runRestore() {
  //console.log('=========== runRestore ==========');
  chrome.app.window.current().restore();
}

function runMax() {
  //console.log('=========== runMax ==========');
  chrome.app.window.current().maximize();
}

function winOnRestore() {
  //console.log('==== winOnRestore ==========');
  (chrome.app.window.current().isMaximized()) ? onMax(): onUnmaximize();
}

function onMax() {
  //console.log('=========== onMax ==========');
  $(".icon-fullscreen").addClass('onMax');
  // "win32" for PC chrome app, the others for chrome book app
  var h = (navigator.platform.toLowerCase() == "win32") ? Math.min(screen.availHeight, $(window).height()) : screen.availHeight;
  $("#voting-page").width("100%").height(h);
  h = h - $("#taskbar").height();
  $("#main-content").height(h);
  tuningHeight();
}

function onUnmaximize() {
  //console.log('=========== onUnmaximize ==========');
  $(".icon-fullscreen").removeClass('onMax');
  var h = 620;
  $("#voting-page").width(820).height(h);
  h = h - $("#taskbar").height();
  $("#main-content").height(h);
  tuningHeight();

  var bound = chrome.app.window.current().getBounds();
  bound.width = $("#voting-page").width();
  bound.height = $("#voting-page").height();
  chrome.app.window.current().setBounds(bound);
}

function tuningHeight() {
  //console.log('=========== tuningHeight ==========');
  // reset height
  $("#q-content").css("height", "").css("max-height", "");
  $("#content").css("height", "");
  $("#right-content").css("height", "");

  var h = $("#voting-page").height() - $("#taskbar").height(),
    bottomHeight = 55,
    contentSetHeight = h - bottomHeight,
    contentHeight = $("#content").height();

  //console.log("contentHeight="+contentHeight, contentSetHeight, bottomHeight, 'h=' + h, $("#right-content").height());
  if (contentHeight + bottomHeight > h) {
    var maxHeight = contentSetHeight - $("#q-title").outerHeight(true) - $("#answers").outerHeight(true);
    $("#q-content").css("max-height", Math.floor(maxHeight - ($("#q-content").outerHeight(true) - $("#q-content").height())));
    //console.log($("#right-content").height(), $("#content").height(), contentHeight, contentSetHeight, $("#q-content").outerHeight(true), $("#answers").outerHeight(true));
  }
}