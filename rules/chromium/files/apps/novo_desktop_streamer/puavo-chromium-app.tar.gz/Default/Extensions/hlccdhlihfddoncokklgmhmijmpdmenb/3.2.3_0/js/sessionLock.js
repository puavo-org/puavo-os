function request_SESSION_LOCK() {
  console.log("REQUEST SESSION LOCK");
  send_CMD_SESSION_LOCK(SESSION_LOCK_UNLOCK_STATUS.REQUEST_TO_CREATE_SESSION);
}

function request_SESSION_UNLOCK() {
  console.log("REQUEST SESSION UNLOCK");
  send_CMD_SESSION_LOCK(SESSION_LOCK_UNLOCK_STATUS.REQUEST_TO_REMOVE_SESSION);
}

var isSessionLock = false;

function send_CMD_SESSION_LOCK(arg1) {
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.SESSION_LOCK_UNLOCK;
  buf[2] = client_id;
  buf[3] = arg1;

  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("SEND CMD SESSION LOCK SUCCESS");
    } else {
      console.log("SEND CMD SESSION LOCK FAIL");
    }
  });
}

function receive_CMD_SESSION_LOCK_UNLOCK(bValues, s_bytes) {
  console.log("Receive CMD SESSION LOCK UNLOCK");
  console.log("BEFORE LOCK", user_list);
  var state = bValues[s_bytes + 3];
  switch (state) {
    case SESSION_LOCK_UNLOCK_STATUS.CREATE_SESSION_SUCCESS:
      console.log("RECEIVE CREATE SESSION SUCCESS");
      isSessionLock = true;
      break;
    case SESSION_LOCK_UNLOCK_STATUS.REMOVE_SESSION_SUCCESS:
      console.log("RECEIVE REMOVE SESSION SUCCESS");
      isSessionLock = false;
      refreshUserListBySessionUnlock();
      break;
    case SESSION_LOCK_UNLOCK_STATUS.NO_PERMISSION:
      console.log("RECEIVE NO PERMISSION");
      break;
    case SESSION_LOCK_UNLOCK_STATUS.SESSION_LOCKED:
      console.log("RECEIVE SESSION LOCKED");
      isSessionLock = true;
      break;
    case SESSION_LOCK_UNLOCK_STATUS.SESSION_IS_OPEN:
      console.log("RECEIVE SESSION OPEN");
      isSessionLock = false;
      refreshUserListBySessionUnlock();
      refreshUserList(user_list);
      break;
  }
  updateSessionLock();

}

function send_CMD_SESSION_CLIENT_STATUS_REFRESH() {
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.SESSION_CLIENT_STATUS_REFRESH;
  buf[2] = client_id;
  buf[3] = 0;

  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("SEND CMD SESSION CLIENT STATUS REFRESH SUCCESS");
    } else {
      console.log("SEND CMD SESSION CLIENT STATUS REFRESH FAIL");
    }
  });
}

function receive_CMD_SESSION_CLIENT_STATUS_REFRESH(bValues, s_bytes) {
  console.log("Receive CMD SESSION CLIENT STATUS REFRESH");

  var user_id = bValues[s_bytes + 2];
  var state = bValues[s_bytes + 3];
  var device = bValues[s_bytes + 4];

  var j = 0;
  var length = bValues[s_bytes];
  var strBuf = new Uint8Array(bValues[s_bytes] - 5);
  for (var i = s_bytes + 5; i < length + s_bytes; i++) {
    strBuf[j] = bValues[i];
    j++;
  }
  var userName = convert_bytes_array_into_str(strBuf);

  console.log("User ID = " + user_id);
  console.log("STATE = " + state);
  console.log("OS_DEV_TYPE = " + device);
  console.log("User NAME = " + encodeURIComponent(userName));

  update_session_lock_userdata("Name", user_id, decodeURIComponent(escape(userName)), false, null, -1, false, true, device);
  //  check_state_case(user_id, CMD.CLIENT_STATUS_REFRESH, state);

  return length;

}

function update_session_lock_userdata(action, uid, label, isHost, device, panel, isMyself, online, os_type) {
  var user;
  if (os_type == OS_DEV_TYPE.OS_HDMI_IN) {
    user = new userdata(uid, label, false, null, panel, false, true, label, os_type);
    user_list.push(user);
    refreshUserList(user_list);
    return;
  }
  for (var i in user_list) {
    var update_user = user_list[i];

    if (update_user.label == label) {
      if (action == "Update") {
        user = new userdata(uid, label, false, null, panel, false, true, label, os_type);
      } else {
        user = new userdata(update_user.uid, update_user.label, false, null, update_user.panel, false, true, update_user.label, update_user.os_type);
      }
      break;
    }
  }
  if (typeof user != "undefined") {
    if (action == "Update") {
      user_list[i] = user;
    }
  } else {
    if (action == "REFRESH") {
      var host = false;
      if (uid == client_id) {
        host = true;
      }
      user = new userdata(uid, label, host, null, panel, isMyself, true, label, os_type);
    } else {
      user = new userdata("None", label, isHost, null, panel, isMyself, false, label, os_type);
    }
    user_list.push(user);
  }
  refreshUserList(user_list);

}

function refreshUserListBySessionUnlock() {
  for (var i in user_list) {
    var uData = user_list[i];
    if (uData.online == false) {
      console.log(uData);
      var r = user_list.indexOf(uData);
      if (r != -1) {
        user_list.splice(r, 1);
      }
    }
  }
}
