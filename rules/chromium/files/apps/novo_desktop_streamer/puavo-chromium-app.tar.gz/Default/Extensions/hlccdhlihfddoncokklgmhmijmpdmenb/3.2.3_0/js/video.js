var video;

$(document).ready(function() {
  var language = 'en-US'; //'zh-TW';//en-US
  translate(chrome.i18n.getUILanguage());

  video = $("#video-page").videoPanel();
  window.onload = function(){
    video.videoPanel("setRvaVersion", rvaVersion, rvaType);
  }
  checkResize();
});

function checkResize() {
  var bound = chrome.app.window.current().getBounds();
  bound.width = $("#video-page").width();
  bound.height = $("#video-page").height();
  chrome.app.window.current().setBounds(bound);
}

function sendVideoResult(code, message, data){
  switch(code) {
    case 3: // Not seekable
      video.videoPanel("videoNotSeekable");
      break;
    case 2:  // go playing width vedio info
      video.videoPanel("goPlaying", message, data);
      break;
    case 1:  // playing
      video.videoPanel("startPlaying", message);
      break;
    case 0:  // exit
      video.videoPanel("stopPlaying");
      break;
    default: // error
      video.videoPanel("sendError", message);
  }
}
