$.widget("custom.videoPanel", {
  // Default options
  options: {
    rvaType: 'EDU',  //EDU, NOVOCAST
    rvaVersion: 2.2,
    videoTotalSeconds: 0,  // video total seconds
    videoPlayPercentage: 0,
    notSeekable: false,
    localFileName: null,
    isPlaying: false,
    localStreaming: true,
  },
  _create: function() {
    var instance = this;

    $("#close-video-win").off().click(function() {
      chrome.app.window.current().close();
      // TODO: call luke
      close_video_panel();
    });

    $("#choose_file").off().click(function() {
      // TODO: call chrome fileSystem
      chrome.fileSystem.chooseEntry({
        type:'openFile',
        acceptsAllTypes: false,
        accepts: [{ mimeTypes: ['video/*,audio/*'], extensions: ['mp4','mov','mpg','avi','wmv', 'vob', '3gpp','3gp','3g2','mkv','mp3','wav','aac', 'wma'] }]},  // access type
        function(entry){
          if (chrome.runtime.lastError) {
            //console.log("cancel folder select");
          }
          else {
            if (entry.isFile) {
              onChooseFolder(entry);
           	  chrome.fileSystem.getDisplayPath(entry, function(displayPath) {
                $('#video_path').val(displayPath);
              });
              $('#video_path').addClass("disable").attr('readonly','readonly');
              $('#clear').addClass("enable");
              $('#paste').removeClass("enable");
              // MP3, AAC -- Audio files
              // Video files -- mp4, mov, mpg, avi, wmv, 3gpp, etc.
              var title = (getFileType(entry.name) == "audio") ? $.t("video.audioTitle") : $.t("video.title");
              $('.span2').text(title);
              $('title').text(title + ' | Novo');
              instance._enableSendVideo();
            }
            else {
          	  //console.log("cancel folder select");
            }
          }
        }
      );
    });

    instance._enableVideoPath();

    $('#clear').off().click(function(){
      $(this).removeClass("enable");
      $('#paste').addClass("enable");
      $('#video_path').val("").attr("title",$.t("video.videoPath")).off().removeAttr('readonly').removeClass("disable").focus();
      var title = $.t('video.title');
      $('.span2').text(title);
      instance._enableVideoPath();
      instance._disablePlayback();
    });

    $('#paste').off().click(function () {
      // console.log("Paste input or file...");
      $(this).removeClass("enable");
      $('#clear').addClass("enable");
      $('#video_path').focus();
      document.execCommand('paste');
    });

    $('#info').off().click(function(){
      $('#tooltip').toggleClass("show");
      return false;
    });


    $(document).click(function(){
      $('#tooltip').removeClass("show");
    });

  },
  setRvaVersion: function(version, rvaType){
    console.log("setRvaVersion...", version, rvaType);
    var instance = this;
    instance.options.rvaVersion = version;
    instance.options.rvaType = rvaType;

    // v1.5
    $('.content').removeClass("version16").addClass("version15");
    if (!isSupportNewVideoPlay()){
      $("#playback").removeClass().addClass("version15").empty()
        .append('<span id="video_backward"></span>')
        .append('<span id="video_play"></span>')
        .append('<span id="video_forward"></span>')
        .append('<span id="video_stop"></span>');
      checkResize();
      return;
    }

    // below is v1.6
    $('.content').removeClass("version15").addClass("version16");

    /*
    var moveTime = function() {
      if ($(this).hasClass("active")) {
        instance._setProgressBar();
        return false;
      }
      $(this).addClass("active");
      var red = $(this).slider("value");
      var percent = red / 100;
      instance.options.videoPlayPercentage = percent;
      instance._setProgressBar(percent);
      sendStreamingPercentToRVA(percent);
    }
    */

    // initialize prograss bar
    var prograssBar = $('<div id="points"></div>').slider({
      orientation: "horizontal",
      range: "min",
      min: 0,
      max: 100,
      value: 0,
      //stop: moveTime
      start: function( event, ui ) {
        $(this).addClass("onDrag");
        console.warn("[slider.start]", ui.value);
      },
      slide: function( event, ui ) {
        instance._setProgressBar(ui.value / 100);
        console.log("[slider.slide] Change point to ", ui.value);
      },
      stop: function( event, ui ) {
        $(this).slider("disable");
        var percentage = ui.value / 100;
        instance.options.videoPlayPercentage = percentage;
        instance._setProgressBar(percentage);
        sendStreamingPercentToRVA(percentage);
        //videoClipApi.sendStreamingPercentToRVA(percentage);
        $(this).removeClass("onDrag");
        console.debug("[slider.stop] Change point to percentage=", percentage);
      }
    }).slider("disable");

    $("#playback").removeClass().addClass("version16").empty()
      .append($('<span id="video_points"></span>')
                .append(prograssBar)
                .append('<div class="time"><span id="progressBarErrorMsg"></span><output id="nowTime">0:00</output> / <output id="totalTime">0:00</output></div>')
              )
      .append('<span id="video_play"></span>')
      .append('<span id="video_stop"></span>');

    checkResize();
  },
  goPlaying: function(message, data){
    console.log('[goPlaying] message, data=', message, data);
    if ($("#points").hasClass("onDrag")) {
      console.log('[startPlaying] Escape onDrag');
      return;
    }
    var instance = this;
    instance._enablePlayback();
    $("#video_play").addClass("pause");
    instance._enableFileName(message);
    instance.options.videoTotalSeconds = data.total;  // set video total time;
    instance.options.videoPlayPercentage = data.percent;

    if (instance.options.notSeekable === true) {
      this.disableProgressBar();
      $("#pointsErrorMsg").text($.t("video.videoNotSeekable"));
      return;
    }

    instance._setProgressBar(data.percent);
    //$("#points").removeClass("active");
    $("#points").slider("enable");
  },
  startPlaying: function(message){
    console.log('[startPlaying] message=', message);
    var instance = this;
    instance._enablePlayback();
    $("#video_play").addClass("pause");
    instance._enableFileName(message);
  },
  stopPlaying: function(){
    $("#video_stop").trigger("click");
  },
  sendError: function(message){
    var instance = this;
    instance._disablePlayback();
    instance._disableFileName();
    $("#errorMsg").text(message);
    $("#progressBarErrorMsg").text("");
    $("#video_path").focus();
    $(".path").addClass("error");
  },
  _enableVideoPath: function(){
    var instance = this;

    $("#video_path").off().change(function() {
      // enable play button
      ($(this).val().trim()!="")? instance._enableSendVideo() : instance._disablePlayback();
      instance.videoPathChanged();
    })
    .bind('input propertychange', function() {
      ($(this).val().trim()!="")? instance._enableSendVideo() : instance._disablePlayback();
      instance.videoPathChanged();
    });
  },
  removeErrorMsg: function removeErrorMsg(){
    $("#errorMsg").text('');
    $(".path").removeClass("error");
  },
  videoPathChanged: function videoPathChanged() {
    console.log("[videoPathChanged]...");
    var instance = this;
    video.videoPanel("removeErrorMsg");

    if ($("#video_path").val() == ""){
      instance._disablePlayback();
      $('#clear').removeClass("enable");
      $('#paste').addClass("enable");
    }
    else {
      instance._enableSendVideo();
      $('#clear').addClass("enable");
      $('#paste').removeClass("enable");
    }
  },
  _enableSendVideo: function() {
    var instance = this;
    this.options.notSeekable = false;
    $("#video_play").addClass("enable").off().click(function() {
      if ($("#video_path").val() == "") {
        $("#get_file").trigger("click");
        return false;
      }
      $(".path").removeClass("error");
      instance._enableLoading();
      instance._disablePlayback();
      // TODO: Send video
      go();
    });
  },
  _enableLoading: function() {
    this._hideBlock();
    $("#loading").show();
  },
  _enablePlayButton: function() {
    $("#video_play").addClass("enable").off().click(function() {
      if ($(this).hasClass("pause")) {
        $(this).removeClass("pause");
        // TODO: Pause when playing video
        sendStreaming_PAUSE();
      }
      else {
        $(this).addClass("pause");
        // TODO: Continue playing video
        sendStreaming_RESUME();
      }
    });
  },
  _enablePlayback: function() {
    var instance = this;
    $("#playback > span").off().addClass("enable");
    this._enablePlayButton();

    $("#video_stop").off().click(function() {
      if ($(this).hasClass("active")) {
        return false;
      }
      $(this).addClass("active");
      instance._doStop();
      // TODO: Stop
      sendStreaming_STOP();
    });

    // v1.5
    if (!isSupportNewVideoPlay()) {
      $("#video_backward").off().click(function() {
        if ($(this).hasClass("active")) {
          return false;
        }
        $(this).addClass("active");
        $(this).powerTimer({
          name: 'backwardTimer',
          delay: 3000,
          func: function() {
            $(this).removeClass("active");
          },
        });
        // TODO: Backward
        sendStreaming_REVERSE();
      });

      $("#video_forward").off().click(function() {
        if ($(this).hasClass("active")) {
          return false;
        }
        $(this).addClass("active");
        $(this).powerTimer({
          name: 'forwardTimer',
          delay: 3000,
          func: function() {
            $(this).removeClass("active");
          },
        });
        // TODO: Forward
        sendStreaming_FOWARD();
      });

      return;
    }

    // after v1.6
    $("#points").slider("value",0).slider("enable");

  },
  _disablePlayback: function() {
    $("#playback > span").off().removeClass();
    var instance = this;
    if (isSupportNewVideoPlay()) {
      instance.options.videoPlayPercentage = 0;
      instance.options.videoTotalSeconds = 0;
      instance._setProgressBar(0);
      instance.disableProgressBar();
      $("#pointsErrorMsg").empty();
      $("#progressBarErrorMsg").empty();
    }
  },
  _setProgressBar: function (percentage){
    var instance = this;
    var percent = (percentage)? percentage : instance.options.videoPlayPercentage;
    percent = Math.max(0, percent);
    percent = Math.min(1, percent);
    $("#points").slider("value", percent * 100);
    //console.log("_setProgressBar...", percent, percentage);
    // Update Time
    var totalTime = instance.options.videoTotalSeconds;  // total Seconds
    var nowTime = Math.floor(totalTime * percent);
    $('#nowTime').val(formatSecond(nowTime));
    $('#totalTime').val(formatSecond(totalTime));
    $("#progressBarErrorMsg").empty();
  },
  _doStop: function() {
    this._disableFileName();
    this._disablePlayback();
    this._enableSendVideo();
  },
  _enableFileName: function(content) {
    this._hideBlock();
    $(".file_name").show();
    $("#file_name").empty().append(content);
  },
  _disableFileName: function() {
    this._hideBlock();
    $(".path").show();
    $("#file_name").empty();
  },
  _hideBlock: function() {
    $(".content > div:not(#playback)").hide();
  },
  _destroy: function() {
    // events bound via _on are removed automatically
    // revert other modifications here
    // remove generated elements
    this.remove();
  },
  videoNotSeekable: function videoNotSeekable(){
    console.log('[videoNotSeekable] ...');
    this.options.notSeekable = true;
    this.disableProgressBar();
    $("#progressBarErrorMsg").text($.t("video.videoNotSeekable"));
  },
  disableProgressBar: function disableProgressBar(){
    var instance = this;
    instance.options.videoPlayPercentage = 0;
    instance.options.videoTotalSeconds = 0;

    $("#points").slider("value", 0).slider("disable");
    $("#video_points").off().removeClass();
    $('#nowTime').val(formatSecond(0));
    $('#totalTime').val(formatSecond(0));
  },
});

function formatSecond(secs) {         
  var hr = Math.floor(secs / 3600);
  var min = Math.floor((secs - (hr * 3600)) / 60).toString();
  var sec = parseInt( secs % 60).toString();
 
  if (min.length < 2 && hr > 0) { min = '0' + min; }
  if (sec.length < 2) { sec = '0' + sec; }
  hr = (hr > 0)?  hr+':' : '';
  return hr + min + ':' + sec;
}
