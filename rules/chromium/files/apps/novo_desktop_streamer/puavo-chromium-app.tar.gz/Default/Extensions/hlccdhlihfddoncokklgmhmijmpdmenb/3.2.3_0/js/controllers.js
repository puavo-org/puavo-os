function UserModel(item) {
  var self = this;
  self.uid = ko.observable(item.uid);
  self.osType = ko.observable(item.os_type);
  self.data = ko.observable(item);
  self.ishost = ko.computed(function() {
    return (self.data().isHost) ? "ishost" : "";
  });
  self.isMyself = ko.computed(function() {
    return (self.data().isMyself) ? "isMyself" : "";
  });
  self.showSnapshot = ko.computed(function() {
    return ((self.data().os_type >= OS_DEV_TYPE.OS_AIRPLAY && self.data().os_type <= OS_DEV_TYPE.OS_HDMI_IN) || self.data().os_type == OS_DEV_TYPE.OS_MIRACAST) ? "" : "showSnapshot";
  });
  self.label = ko.computed(function() {
    return self.data().label;
  });
  self.username = ko.computed(function() {
    return (self.data().isMyself)? $.t('login.myself', {usrname: self.data().label}) : self.data().label;
    //return (self.data().isMyself)? 'Myself ('+ self.data().label +')' : self.data().label;
  });
  self.panelcss = ko.computed(function() {
    var cssArray = {"-1": "", "0": "full-on", "1": "no1", "2": "no2", "3": "no3", "4": "no4"};
    return cssArray[self.data().panel];
  });
  self.panelimgsrc = ko.computed(function() {
    return presenterImgs[self.data().panel];
  });
  self.playing = ko.computed(function() {
    return (self.data().panel > -1) ? "playing" : "stop-play";
  });
  self.online = ko.computed(function() {
    return (self.data().online)? "online" : "offline";
  });
  self.loginTime = ko.observable(item.loginTime);
  self.isAirNote = ko.computed(function() {
    return (self.data().isAirNote) ? "isAirNote" : "";
    //return false;
  });
}

function UserViewModel(userList) {
  var self = this;

  // Data
  self.allusers = ko.observableArray($.map(userList, function(user) { return new UserModel(user) }));
  self.refresh = function(userList) {
    self.allusers($.map(userList, function(user) { return new UserModel(user) }));
    self.iamHost(false);
    self.hasHost(false);
    self.moderatorName($.t("info.noModerator"));
  }
  
  // Sort Key
  //self.rvaModal = ko.observable('B300');  // B100/C300/C400/B300/...
  self.rvaType = ko.observable('EDU');  // EDU/CORP/NOVOCAST/NOVOPROPLUS, default: EDU
  self.sortKey = ko.observable('name');  // name/time, default: name
  self.sortPeople = function(key, rvaType) {
    self.sortKey(key);
    self.rvaType(rvaType);
  }

  self.moderatorName = ko.observable("None");
  
  self.hasHost = ko.observable(false);
  self.hasHostClass = ko.computed(function() {
    return (self.hasHost()? 'has-host' : 'no-host');
  }, this);
  
  self.iamHost = ko.observable(false);
  self.iamHostClass = ko.computed(function() {
    return (self.iamHost()? 'iamhost ' : ' ');
  }, this);
  
  self.sessionStatus = ko.observable(false);
  self.updateSessionStatus = function(lock) {
    self.sessionStatus(lock);
  }
  
  self.groupMode = ko.observable(false);
  self.groupName = ko.observable("None");
  self.updateGroup = function(gMode, gName) {
    self.groupMode(gMode);
    self.groupName(gName);
  }
  
  // Display
  self.display = ko.observable(0);
  self.displayUsers = ko.computed(function() {
    var output = [];
    self.moderatorName();
    self.hasHost(false);
    self.iamHost(false);    
    ko.utils.arrayForEach(self.allusers(), function(user) {
      if (user.data().isHost){
        self.moderatorName(user.data().label);
        self.hasHost(true);
        (user.data().isMyself)? self.iamHost(true) : null;
      }
      if (self.display()==0) output.push(user);
      if (self.display()==1 && user.data().online) output.push(user);
      if (self.display()==2 && !user.data().online) output.push(user);
    });    
    
    return output.sort(function(left, right) {
      if (self.rvaType() == "CORP" && left.isMyself() != right.isMyself()) {
        return (left.isMyself() > right.isMyself() ? -1 : 1); 
      }
      if (left.ishost() != right.ishost()) {
        return (left.ishost() > right.ishost() ? -1 : 1); 
      }
      var key = self.sortKey();
      if (key=='name')
        return (left.label().toUpperCase() == right.label().toUpperCase()) ? 0 : (left.label().toUpperCase() < right.label().toUpperCase() ? -1 : 1); 
      if (key=='time')
        return (left.loginTime() == right.loginTime())? 0 : (left.loginTime() < right.loginTime() ? -1 : 1);
    });
  }, this);
  
  self.fullViewName = ko.computed(function() {
    var output = "";
    ko.utils.arrayForEach(self.allusers(), function(user) {
      if (user.data().panel===0)
        return output = user.data().label;
    });
    return output;
  }, this);
  self.splitViews = ko.computed(function() {
    var output = ["","","",""];
    ko.utils.arrayForEach(self.allusers(), function(user) {
      if (user.data().panel > 0)  output[user.data().panel-1]=user.data().label;
    });    
    return output;
  }, this);
  self.flexibleViews = ko.computed(function() {
    var output = [];
    ko.utils.arrayForEach(self.allusers(), function(user) {
      if (user.data().panel > -1)  output.push(user);
    });
    return output.sort(function(left, right) {
      return (left.data().panel < right.data().panel) ? -1 : 1;
    });
  }, this);  
  self.onlineCount = ko.computed(function(flag) {
    var output = 0;
    ko.utils.arrayForEach(self.allusers(), function(user) {
      if (user.data().online) output++;
    });
    return output;
  }, this);
  self.offlineCount = ko.computed(function(flag) {
    var output = 0;
    ko.utils.arrayForEach(self.allusers(), function(user) {
      if (!user.data().online) output++;
    });
    return output;
  }, this);
};