function initial_DATASOCKET() {
  if (typeof data_socketId === 'undefined') {
    chrome.sockets.tcp.create({
      persistent: false,
      bufferSize: 8192,
      name: "DataConnection"
    }, function(createInfo) {
      data_socketId = createInfo.socketId;
      chrome.sockets.tcp.connect(data_socketId, rvaIp, TCP_DATA_PORT, function(result) {
        if (result === 0) {
          isDataConnected = true;
          console.log("Data Connection Success -> Start Send Preload-01");
          sendNewDataPreloadOne();
        } else {
          console.log("Data Connection Fail");
        }
      });
    });
  } else {
    chrome.sockets.tcp.getInfo(data_socketId, function(socketInfo) {
      if (chrome.runtime.lastError) {
        console.log("No Data Connection Intial");
        chrome.sockets.tcp.create({
          persistent: false,
          bufferSize: 8192,
          name: "DataConnection"
        }, function(createInfo) {
          data_socketId = createInfo.socketId;
          chrome.sockets.tcp.connect(data_socketId, rvaIp, TCP_DATA_PORT, function(result) {
            if (result === 0) {
              isDataConnected = true;
              console.log("Data Connection Success -> Start Send Preload-01");
              sendNewDataPreloadOne();
            } else {
              console.log("Data Connection Fail");
            }
          });
        });
      } else {
        if (socketInfo.connected) {
          console.log("Data Connection Already connected");
          if (isImageSendingPause) {
            console.log("Streaming mode pause");
          } else {
            //sendNewDataPreloadOne();
            start_SENDING_IMAGE();
          }
        } else {
          chrome.sockets.tcp.create({
            persistent: false,
            bufferSize: 8192,
            name: "DataConnection"
          }, function(createInfo) {
            data_socketId = createInfo.socketId;
            chrome.sockets.tcp.connect(data_socketId, rvaIp, TCP_DATA_PORT, function(result) {
              if (result === 0) {
                isDataConnected = true;
                sendNewDataPreloadOne();
                console.log("Data Connection Success -> Start Send Preload-01");
              } else {
                console.log("Data Connection Fail");
              }
            });
          });
        }
      }
    });
  }
}

function sendNewDataPreloadOne() {
  var buf = new Uint8Array(12);
  buf[0] = client_id;
  buf[1] = 1;
  buf[2] = 1; //1 : JPG, 2 : PNG, 3: H264
  if (supportH264) {
    buf[2] = 3;
  }
  buf[3] = 0;
  buf[4] = 0;
  buf[5] = 0;
  buf[6] = 0;
  buf[7] = 0;
  buf[8] = 0;
  buf[9] = 0;
  buf[10] = 0;
  buf[11] = 0;
  chrome.sockets.tcp.send(data_socketId, buf.buffer, function(sendInfo) {
    if (chrome.runtime.lastError) {
      console.log("Send New DataConnection error");
    } else {
      if (supportH264) {
        console.log("Re Start");
        //sendNewDataPreloadTwo();
      } else {
        start_SENDING_IMAGE();
      }
    }
  });
}
