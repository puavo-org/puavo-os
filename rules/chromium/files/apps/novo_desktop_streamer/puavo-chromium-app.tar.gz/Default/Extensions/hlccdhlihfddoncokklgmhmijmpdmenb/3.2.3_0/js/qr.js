
var sessionInfoShow = false;
var rvaVersionValue = 0;
$(function() {
  var language = 'en-US'; //'zh-TW';//en-US
  translate(chrome.i18n.getUILanguage());
  sessionInfoShow = false;
  var bound = chrome.app.window.current().getBounds();
  bound.width = $("#qr-page").width();
  bound.height = $("#qr-page").height();
  chrome.app.window.current().setBounds(bound);

  $("#resizable").resizable({
    maxHeight: 400,
    maxWidth: 400,
    minHeight: 100,
    minWidth: 100,
    aspectRatio: 1 / 1,
    helper: "ui-resizable-helper"
  });

  $('#qr-close').click(function() {
    // chrome.app.window.get("main").contentWindow.send_CMD_CONNECT_SESSION_INFO();
    if (rvaVersionValue >= 2.2 && sessionInfoShow) {
      chrome.app.window.get("main").contentWindow.send_CMD_CONNECT_SESSION_INFO();
    }
    chrome.app.window.current().close();
  });

});

function displaySessionInfo(obj, rvaVersion) {
  console.log("displaySessionInfo", obj);
  rvaVersionValue = rvaVersion;
  var ul = $('#info-list');
  $('#qr-img').attr("src","data:image/png;base64,"+obj.qrImg);
  
  ul.empty();

  if (obj.deviceName != undefined && obj.deviceName != ""){
    ul.append($('<li><label class="device"></label><span>'+ obj.deviceName +'</span></li>'));
  }

  ul.append($('<li><label class="pin"></label><span class="yellow">' + obj.pinValue +'</span></li>'));
  
  if (obj.lan){
    ul.append($('<li><label class="lan"></label><span>' + obj.lan + '</span></li>'));
  }
  if (obj.usbLanIP && obj.usbLanIP != "0.0.0.0") {
    $(ul).append($('<li><label class="lan"></label><span>' + obj.usbLanIP + '</span></li>'));
  }
  
  if (obj.wifi && obj.wifi.ip!="0.0.0.0"){
    ul.append($('<li>')
              .append($('<label class="wifi">'))
              .append($('<span>').addClass("blue-line")
                      .append($('<div>').text(obj.wifi.ip))
                      .append($('<div>').text(obj.wifi.ssid).attr("id", "ssid"))));                          
  }
  
  $('#qr-rva-btn').hide();
  if (rvaVersion >= 2.2) {
    var clearText;
    function toggleRvaSessionInfo(){
      sessionInfoShow = !sessionInfoShow;
      console.info("call RVA to toggle session information...");
      chrome.app.window.get("main").contentWindow.send_CMD_CONNECT_SESSION_INFO();
      $('#qr-rva-btn').addClass('loading');
      $('#msg').empty();
      clearTimeout(clearText);
      window.setTimeout(function(){
        $('#qr-rva-btn').removeClass().off().one("click",toggleRvaSessionInfo);
        $('#msg').text($.t("info.sendRequest"));
        clearText = window.setTimeout(function(){
          $('#msg').empty();
        }, 5000);
      }, 2000);
    }
    (obj.isHost)? $('#qr-rva-btn').show().off().one("click",toggleRvaSessionInfo) : $('#qr-rva-btn').hide().off();
  }

}