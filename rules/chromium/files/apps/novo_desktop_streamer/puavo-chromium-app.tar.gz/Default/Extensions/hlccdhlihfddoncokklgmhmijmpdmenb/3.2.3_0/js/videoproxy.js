//RVA Streaming proxy port
var STREAMING_CONNECTION_PORT = 20130;
var isTCP_Server_Started = false;
var stream_ch1, stream_ch2, stream_ch3, stream_ch4, stream_ch5, stream_ch6, stream_ch7;
var tcp_ch1, tcp_ch2, tcp_ch3, tcp_ch4, tcp_ch5, tcp_ch6, tcp_ch7;

//Initial two connection to RVA Streaming proxy
function connect_to_rva_proxy() {
  chrome.sockets.tcp.create({persistent: true, name: "proxy1"}, function(createInfo) {
    stream_ch1 = createInfo.socketId;
    console.log("Stream_Ch1 = " + stream_ch1);
    chrome.sockets.tcp.connect(stream_ch1, rvaIp, STREAMING_CONNECTION_PORT, function(result) {
      if (result == 0) {
        console.log("Connect to RVA proxy 1 success -> Listen http request");
      } else {
        console.log("Connect to RVA proxy 1 fail");
      }
    });
  });
  chrome.sockets.tcp.create({persistent: true, name: "proxy2"}, function(createInfo) {
    stream_ch2 = createInfo.socketId;
    console.log("Stream_Ch = " + stream_ch2);
    chrome.sockets.tcp.connect(stream_ch2, rvaIp, STREAMING_CONNECTION_PORT, function(result) {
      if (result == 0) {
        console.log("Connect to RVA proxy 2 success -> Listen http request");
      } else {
        console.log("Connect to RVA proxy 2 fail");
      }
    });
  });
  if (support7SocketChannel) {
    chrome.sockets.tcp.create({persistent: true, name: "proxy3"}, function(createInfo) {
      stream_ch3 = createInfo.socketId;
      console.log("Stream_Ch3 = " + stream_ch3);
      chrome.sockets.tcp.connect(stream_ch3, rvaIp, STREAMING_CONNECTION_PORT, function(result) {
        if (result == 0) {
          console.log("Connect to RVA proxy 3 success -> Listen http request");
        } else {
          console.log("Connect to RVA proxy 3 fail");
        }
      });
    });
    chrome.sockets.tcp.create({persistent: true, name: "proxy4"}, function(createInfo) {
      stream_ch4 = createInfo.socketId;
      console.log("Stream_Ch4 = " + stream_ch4);
      chrome.sockets.tcp.connect(stream_ch4, rvaIp, STREAMING_CONNECTION_PORT, function(result) {
        if (result == 0) {
          console.log("Connect to RVA proxy 4 success -> Listen http request");
        } else {
          console.log("Connect to RVA proxy 4 fail");
        }
      });
    });
    chrome.sockets.tcp.create({persistent: true, name: "proxy5"}, function(createInfo) {
      stream_ch5 = createInfo.socketId;
      console.log("Stream_Ch5 = " + stream_ch5);
      chrome.sockets.tcp.connect(stream_ch5, rvaIp, STREAMING_CONNECTION_PORT, function(result) {
        if (result == 0) {
          console.log("Connect to RVA proxy 5 success -> Listen http request");
        } else {
          console.log("Connect to RVA proxy 5 fail");
        }
      });
    });
    chrome.sockets.tcp.create({persistent: true, name: "proxy6"}, function(createInfo) {
      stream_ch6 = createInfo.socketId;
      console.log("Stream_Ch6 = " + stream_ch6);
      chrome.sockets.tcp.connect(stream_ch6, rvaIp, STREAMING_CONNECTION_PORT, function(result) {
        if (result == 0) {
          console.log("Connect to RVA proxy 6 success -> Listen http request");
        } else {
          console.log("Connect to RVA proxy 6 fail");
        }
      });
    });
    chrome.sockets.tcp.create({persistent: true, name: "proxy7"}, function(createInfo) {
      stream_ch7 = createInfo.socketId;
      console.log("Stream_Ch7 = " + stream_ch7);
      chrome.sockets.tcp.connect(stream_ch7, rvaIp, STREAMING_CONNECTION_PORT, function(result) {
        if (result == 0) {
          console.log("Connect to RVA proxy 7 success -> Listen http request");
        } else {
          console.log("Connect to RVA proxy 7 fail");
        }
      });
    });
  }
}

function close_all_streaming_sockets() {
  last_data3 = -1;
  last_data4 = -1;
  skip_streaming_update = false;
  // Close TCP SERVER
  if (isTCP_Server_Started) {
    isTCP_Server_Started = false;
    close_local_tcp_server();
  }
  //DSA_PROXY ONE TO RVA_PROXY
  if (typeof stream_ch1 != 'undefined') {
    chrome.sockets.tcp.getInfo(stream_ch1, function(socketInfo) {
      if (socketInfo.connected) {
        chrome.sockets.tcp.close(stream_ch1, function(callback) {
          if (chrome.runtime.lastError) {

          }
        });
      }
    });
  }
  //DSA_PROXY TWO TO RVA_PROXY
  if (typeof stream_ch2 != 'undefined') {
    chrome.sockets.tcp.getInfo(stream_ch2, function(socketInfo) {
      if (socketInfo.connected) {
        chrome.sockets.tcp.close(stream_ch2, function(callback) {
          if (chrome.runtime.lastError) {

          }
        });
      }
    });
  }
  if (support7SocketChannel) {
    if (typeof stream_ch3 != 'undefined') {
      chrome.sockets.tcp.getInfo(stream_ch3, function(socketInfo) {
        if (socketInfo.connected) {
          chrome.sockets.tcp.close(stream_ch3, function(callback) {
            if (chrome.runtime.lastError) {

            }
          });
        }
      });
    }
    if (typeof stream_ch4 != 'undefined') {
      chrome.sockets.tcp.getInfo(stream_ch4, function(socketInfo) {
        if (socketInfo.connected) {
          chrome.sockets.tcp.close(stream_ch4, function(callback) {
            if (chrome.runtime.lastError) {

            }
          });
        }
      });
    }
    if (typeof stream_ch5 != 'undefined') {
      chrome.sockets.tcp.getInfo(stream_ch5, function(socketInfo) {
        if (socketInfo.connected) {
          chrome.sockets.tcp.close(stream_ch5, function(callback) {
            if (chrome.runtime.lastError) {

            }
          });
        }
      });
    }
    if (typeof stream_ch6 != 'undefined') {
      chrome.sockets.tcp.getInfo(stream_ch6, function(socketInfo) {
        if (socketInfo.connected) {
          chrome.sockets.tcp.close(stream_ch6, function(callback) {
            if (chrome.runtime.lastError) {

            }
          });
        }
      });
    }
    if (typeof stream_ch7 != 'undefined') {
      chrome.sockets.tcp.getInfo(stream_ch7, function(socketInfo) {
        if (socketInfo.connected) {
          chrome.sockets.tcp.close(stream_ch7, function(callback) {
            if (chrome.runtime.lastError) {

            }
          });
        }
      });
    }
  }
  //DSA_PROXY ONE to HTTP SERVER
  if (typeof tcp_ch1 != 'undefined') {
    chrome.sockets.tcp.getInfo(tcp_ch1, function(socketInfo) {
      if (socketInfo.connected) {
        chrome.sockets.tcp.close(tcp_ch1, function(callback) {
          if (chrome.runtime.lastError) {

          }
        });
      }
    });
  }
  //DSA_PROXY TWO to HTTP SERVER
  if (typeof tcp_ch2 != 'undefined') {
    chrome.sockets.tcp.getInfo(tcp_ch2, function(socketInfo) {
      if (socketInfo.connected) {
        chrome.sockets.tcp.close(tcp_ch2, function(callback) {
          if (chrome.runtime.lastError) {

          }
        });
      }
    });
  }
  if (support7SocketChannel) {
    if (typeof tcp_ch3 != 'undefined') {
      chrome.sockets.tcp.getInfo(tcp_ch3, function(socketInfo) {
        if (socketInfo.connected) {
          chrome.sockets.tcp.close(tcp_ch3, function(callback) {
            if (chrome.runtime.lastError) {

            }
          });
        }
      });
    }
    if (typeof tcp_ch4 != 'undefined') {
      chrome.sockets.tcp.getInfo(tcp_ch4, function(socketInfo) {
        if (socketInfo.connected) {
          chrome.sockets.tcp.close(tcp_ch4, function(callback) {
            if (chrome.runtime.lastError) {

            }
          });
        }
      });
    }
    if (typeof tcp_ch5 != 'undefined') {
      chrome.sockets.tcp.getInfo(tcp_ch5, function(socketInfo) {
        if (socketInfo.connected) {
          chrome.sockets.tcp.close(tcp_ch5, function(callback) {
            if (chrome.runtime.lastError) {

            }
          });
        }
      });
    }
    if (typeof tcp_ch6 != 'undefined') {
      chrome.sockets.tcp.getInfo(tcp_ch6, function(socketInfo) {
        if (socketInfo.connected) {
          chrome.sockets.tcp.close(tcp_ch6, function(callback) {
            if (chrome.runtime.lastError) {

            }
          });
        }
      });
    }
    if (typeof tcp_ch7 != 'undefined') {
      chrome.sockets.tcp.getInfo(tcp_ch7, function(socketInfo) {
        if (socketInfo.connected) {
          chrome.sockets.tcp.close(tcp_ch7, function(callback) {
            if (chrome.runtime.lastError) {

            }
          });
        }
      });
    }
  }
}

var streaming_channel = 1;

//Receive from RVA_PROXY from channel one.
function receive_streaming_message(receive_buffer) {
  streaming_channel = 1;
  chrome.sockets.tcp.create({persistent: true, name: "tcp1", bufferSize: 25000}, function(createInfo) {
    tcp_ch1 = createInfo.socketId;
    chrome.sockets.tcp.connect(tcp_ch1, "127.0.0.1", 9090, function(result) {
      if (result == 0) {
        console.log("Connect to TCP Server 1 Success -> Waiting");
        chrome.sockets.tcp.send(tcp_ch1, receive_buffer.buffer, function(sendInfo) {
          if (sendInfo.resultCode == 0) {
            console.log("Transfer RVA PORXY 1 to TCP SERVER Success");
          } else {
            console.log("Transfer RVA PORXY 1 to TCP SERVER Fail");
          }
        });
      } else {
        console.log("Connect to TCP Server Fail -> Close");
      }
    });
  });
}

//Receive from RVA_PROXY from channel two.
function receive_streaming_second_message(receive_buffer) {
  streaming_channel = 2;
  chrome.sockets.tcp.create({persistent: true, name: "tcp2", bufferSize: 25000}, function(createInfo) {
    tcp_ch2 = createInfo.socketId;
    chrome.sockets.tcp.connect(tcp_ch2, "127.0.0.1", 9090, function(result) {
      if (result == 0) {
        console.log("Connect to TCP Server 2 Success -> Waiting");
        chrome.sockets.tcp.send(tcp_ch2, receive_buffer.buffer, function(sendInfo) {
          if (sendInfo.resultCode == 0) {
            console.log("Transfer RVA PORXY 2 to TCP SERVER Success");
          } else {
            console.log("Transfer RVA PORXY 2 to TCP SERVER Fail");
          }
        });
      } else {
        console.log("Connect to TCP Server Fail -> Close");
      }
    });
  });
}
function receive_streaming_3_message(receive_buffer) {
  streaming_channel = 3;
  chrome.sockets.tcp.create({persistent: true, name: "tcp3", bufferSize: 25000}, function(createInfo) {
    tcp_ch3 = createInfo.socketId;
    chrome.sockets.tcp.connect(tcp_ch3, "127.0.0.1", 9090, function(result) {
      if (result == 0) {
        console.log("Connect to TCP Server 3 Success -> Waiting");
        chrome.sockets.tcp.send(tcp_ch3, receive_buffer.buffer, function(sendInfo) {
          if (sendInfo.resultCode == 0) {
            console.log("Transfer RVA PORXY 3 to TCP SERVER Success");
          } else {
            console.log("Transfer RVA PORXY 3 to TCP SERVER Fail");
          }
        });
      } else {
        console.log("Connect to TCP Server Fail -> Close");
      }
    });
  });
}
function receive_streaming_4_message(receive_buffer) {
  streaming_channel = 4;
  chrome.sockets.tcp.create({persistent: true, name: "tcp4", bufferSize: 25000}, function(createInfo) {
    tcp_ch4 = createInfo.socketId;
    chrome.sockets.tcp.connect(tcp_ch4, "127.0.0.1", 9090, function(result) {
      if (result == 0) {
        console.log("Connect to TCP Server 4 Success -> Waiting");
        chrome.sockets.tcp.send(tcp_ch4, receive_buffer.buffer, function(sendInfo) {
          if (sendInfo.resultCode == 0) {
            console.log("Transfer RVA PORXY 4 to TCP SERVER Success");
          } else {
            console.log("Transfer RVA PORXY 4 to TCP SERVER Fail");
          }
        });
      } else {
        console.log("Connect to TCP Server Fail -> Close");
      }
    });
  });
}
function receive_streaming_5_message(receive_buffer) {
  streaming_channel = 5;
  chrome.sockets.tcp.create({persistent: true, name: "tcp5", bufferSize: 25000}, function(createInfo) {
    tcp_ch5 = createInfo.socketId;
    chrome.sockets.tcp.connect(tcp_ch5, "127.0.0.1", 9090, function(result) {
      if (result == 0) {
        console.log("Connect to TCP Server 5 Success -> Waiting");
        chrome.sockets.tcp.send(tcp_ch5, receive_buffer.buffer, function(sendInfo) {
          if (sendInfo.resultCode == 0) {
            console.log("Transfer RVA PORXY 5 to TCP SERVER Success");
          } else {
            console.log("Transfer RVA PORXY 5 to TCP SERVER Fail");
          }
        });
      } else {
        console.log("Connect to TCP Server Fail -> Close");
      }
    });
  });
}
function receive_streaming_6_message(receive_buffer) {
  streaming_channel = 6;
  chrome.sockets.tcp.create({persistent: true, name: "tcp6", bufferSize: 25000}, function(createInfo) {
    tcp_ch6 = createInfo.socketId;
    chrome.sockets.tcp.connect(tcp_ch6, "127.0.0.1", 9090, function(result) {
      if (result == 0) {
        console.log("Connect to TCP Server 6 Success -> Waiting");
        chrome.sockets.tcp.send(tcp_ch6, receive_buffer.buffer, function(sendInfo) {
          if (sendInfo.resultCode == 0) {
            console.log("Transfer RVA PORXY 6 to TCP SERVER Success");
          } else {
            console.log("Transfer RVA PORXY 6 to TCP SERVER Fail");
          }
        });
      } else {
        console.log("Connect to TCP Server Fail -> Close");
      }
    });
  });
}
function receive_streaming_7_message(receive_buffer) {
  streaming_channel = 7;
  chrome.sockets.tcp.create({persistent: true, name: "tcp7", bufferSize: 25000}, function(createInfo) {
    tcp_ch7 = createInfo.socketId;
    chrome.sockets.tcp.connect(tcp_ch7, "127.0.0.1", 9090, function(result) {
      if (result == 0) {
        console.log("Connect to TCP Server 7 Success -> Waiting");
        chrome.sockets.tcp.send(tcp_ch7, receive_buffer.buffer, function(sendInfo) {
          if (sendInfo.resultCode == 0) {
            console.log("Transfer RVA PORXY 7 to TCP SERVER Success");
          } else {
            console.log("Transfer RVA PORXY 7 to TCP SERVER Fail");
          }
        });
      } else {
        console.log("Connect to TCP Server Fail -> Close");
      }
    });
  });
}



//Receive from HTTP SERVER to DSA_PROXY one
function receive_tcpServer(receive_buffer) {
  if (streaming_channel == 1) {
    chrome.sockets.tcp.getInfo(stream_ch1, function(socketInfo) {
      if (chrome.runtime.lastError) {
        return;
      }
      if (socketInfo.connected) {
        chrome.sockets.tcp.send(stream_ch1, receive_buffer.buffer, function(sendInfo) {
          if (chrome.runtime.lastError) {
            streaming_channel = 2;
          } else {
            if (sendInfo.resultCode == 0) {
              // console.log("Send Streaming From TCP to DSA Success");
            } else {
              console.log("Send Streaming From TCP 1 to DSA Fail");
              streaming_channel = 2;
            }
          }
        });
      }
    });
  }
}

//Receive from HTTP SERVER to DSA_PROXY two
function receive_second_tcpServer(receive_buffer) {
  if (streaming_channel == 2) {
    chrome.sockets.tcp.getInfo(stream_ch2, function(socketInfo) {
      if (chrome.runtime.lastError) {
        return;
      }
      if (socketInfo.connected) {
        chrome.sockets.tcp.send(stream_ch2, receive_buffer.buffer, function(sendInfo) {
          if (chrome.runtime.lastError) {
            if (support7SocketChannel) {
              streaming_channel = 3;
            } else {
              streaming_channel = 1;
            }
          } else {
            if (sendInfo.resultCode == 0) {
              // console.log("Send Streaming From TCP to DSA Success");
            } else {
              console.log("Send Streaming From TCP 2 to DSA Fail");
              if (support7SocketChannel) {
                streaming_channel = 3;
              } else {
                streaming_channel = 1;
              }
            }
          }
        });
      }
    });
  }
}
function receive_tcp3Server(receive_buffer) {
  if (streaming_channel == 3) {
    chrome.sockets.tcp.getInfo(stream_ch3, function(socketInfo) {
      if (chrome.runtime.lastError) {
        return;
      }
      if (socketInfo.connected) {
        chrome.sockets.tcp.send(stream_ch3, receive_buffer.buffer, function(sendInfo) {
          if (chrome.runtime.lastError) {
            streaming_channel = 4;
          } else {
            if (sendInfo.resultCode == 0) {
              // console.log("Send Streaming From TCP to DSA Success");
            } else {
              console.log("Send Streaming From TCP 3 to DSA Fail");
              streaming_channel = 4;
            }
          }
        });
      }
    });
  }
}
function receive_tcp4Server(receive_buffer) {
  if (streaming_channel == 4) {
    chrome.sockets.tcp.getInfo(stream_ch4, function(socketInfo) {
      if (chrome.runtime.lastError) {
        return;
      }
      if (socketInfo.connected) {
        chrome.sockets.tcp.send(stream_ch4, receive_buffer.buffer, function(sendInfo) {
          if (chrome.runtime.lastError) {
            streaming_channel = 5;
          } else {
            if (sendInfo.resultCode == 0) {
              // console.log("Send Streaming From TCP to DSA Success");
            } else {
              console.log("Send Streaming From TCP 4 to DSA Fail");
              streaming_channel = 5;
            }
          }
        });
      }
    });
  }
}
function receive_tcp5Server(receive_buffer) {
  if (streaming_channel == 5) {
    chrome.sockets.tcp.getInfo(stream_ch5, function(socketInfo) {
      if (chrome.runtime.lastError) {
        return;
      }
      if (socketInfo.connected) {
        chrome.sockets.tcp.send(stream_ch5, receive_buffer.buffer, function(sendInfo) {
          if (chrome.runtime.lastError) {
            streaming_channel = 6;
          } else {
            if (sendInfo.resultCode == 0) {
              // console.log("Send Streaming From TCP to DSA Success");
            } else {
              console.log("Send Streaming From TCP 5 to DSA Fail");
              streaming_channel = 6;
            }
          }
        });
      }
    });
  }
}
function receive_tcp6Server(receive_buffer) {
  if (streaming_channel == 6) {
    chrome.sockets.tcp.getInfo(stream_ch6, function(socketInfo) {
      if (chrome.runtime.lastError) {
        return;
      }
      if (socketInfo.connected) {
        chrome.sockets.tcp.send(stream_ch6, receive_buffer.buffer, function(sendInfo) {
          if (chrome.runtime.lastError) {
            streaming_channel = 7;
          } else {
            if (sendInfo.resultCode == 0) {
              // console.log("Send Streaming From TCP to DSA Success");
            } else {
              console.log("Send Streaming From TCP 6 to DSA Fail");
              streaming_channel = 7;
            }
          }
        });
      }
    });
  }
}
function receive_tcp7Server(receive_buffer) {
  if (streaming_channel == 7) {
    chrome.sockets.tcp.getInfo(stream_ch7, function(socketInfo) {
      if (chrome.runtime.lastError) {
        return;
      }
      if (socketInfo.connected) {
        chrome.sockets.tcp.send(stream_ch7, receive_buffer.buffer, function(sendInfo) {
          if (chrome.runtime.lastError) {
            streaming_channel = 1;
          } else {
            if (sendInfo.resultCode == 0) {
              // console.log("Send Streaming From TCP to DSA Success");
            } else {
              console.log("Send Streaming From TCP 7 to DSA Fail");
              streaming_channel = 1;
            }
          }
        });
      }
    });
  }
}

//DSA proxy one send connection request to rva proxy
function connection_one() {
  console.log("Reconnection DSA_1_Proxy <-----> RVA_Proxy");
  chrome.sockets.tcp.create({persistent: true, name: "proxy1", bufferSize: 25000}, function(createInfo) {
    stream_ch1 = createInfo.socketId;
    chrome.sockets.tcp.connect(stream_ch1, rvaIp, STREAMING_CONNECTION_PORT, function(result) {
      if (result == 0) {
        console.log("Connect to RVA proxy 1 success -> Listen http request");
      } else {
        console.log("Connect to RVA proxy 1 fail");
      }
    });
  });
}

//DSA proxy two send connection request to rva proxy
function connection_two() {
  console.log("Reconnection DSA_2_Proxy <-----> RVA_Proxy");
  chrome.sockets.tcp.create({persistent: true, name: "proxy2", bufferSize: 25000}, function(createInfo) {
    stream_ch2 = createInfo.socketId;
    chrome.sockets.tcp.connect(stream_ch2, rvaIp, STREAMING_CONNECTION_PORT, function(result) {
      if (result == 0) {
        console.log("Connect to RVA proxy 2 success -> Listen http request");
      } else {
        console.log("Connect to RVA proxy 2 fail");
      }
    });
  });
}
//DSA proxy two send connection request to rva proxy
function connection_three() {
  console.log("Reconnection DSA_3_Proxy <-----> RVA_Proxy");
  chrome.sockets.tcp.create({persistent: true, name: "proxy3", bufferSize: 25000}, function(createInfo) {
    stream_ch3 = createInfo.socketId;
    chrome.sockets.tcp.connect(stream_ch3, rvaIp, STREAMING_CONNECTION_PORT, function(result) {
      if (result == 0) {
        console.log("Connect to RVA proxy 3 success -> Listen http request");
      } else {
        console.log("Connect to RVA proxy 3 fail");
      }
    });
  });
}
//DSA proxy two send connection request to rva proxy
function connection_four() {
  console.log("Reconnection DSA_4_Proxy <-----> RVA_Proxy");
  chrome.sockets.tcp.create({persistent: true, name: "proxy4", bufferSize: 25000}, function(createInfo) {
    stream_ch4 = createInfo.socketId;
    chrome.sockets.tcp.connect(stream_ch4, rvaIp, STREAMING_CONNECTION_PORT, function(result) {
      if (result == 0) {
        console.log("Connect to RVA proxy 4 success -> Listen http request");
      } else {
        console.log("Connect to RVA proxy 4 fail");
      }
    });
  });
}
//DSA proxy two send connection request to rva proxy
function connection_five() {
  console.log("Reconnection DSA_5_Proxy <-----> RVA_Proxy");
  chrome.sockets.tcp.create({persistent: true, name: "proxy5", bufferSize: 25000}, function(createInfo) {
    stream_ch5 = createInfo.socketId;
    chrome.sockets.tcp.connect(stream_ch5, rvaIp, STREAMING_CONNECTION_PORT, function(result) {
      if (result == 0) {
        console.log("Connect to RVA proxy 5 success -> Listen http request");
      } else {
        console.log("Connect to RVA proxy 5 fail");
      }
    });
  });
}
//DSA proxy two send connection request to rva proxy
function connection_six() {
  console.log("Reconnection DSA_6_Proxy <-----> RVA_Proxy");
  chrome.sockets.tcp.create({persistent: true, name: "proxy6", bufferSize: 25000}, function(createInfo) {
    stream_ch6 = createInfo.socketId;
    chrome.sockets.tcp.connect(stream_ch6, rvaIp, STREAMING_CONNECTION_PORT, function(result) {
      if (result == 0) {
        console.log("Connect to RVA proxy 6 success -> Listen http request");
      } else {
        console.log("Connect to RVA proxy 6 fail");
      }
    });
  });
}
//DSA proxy two send connection request to rva proxy
function connection_seven() {
  console.log("Reconnection DSA_7_Proxy <-----> RVA_Proxy");
  chrome.sockets.tcp.create({persistent: true, name: "proxy7", bufferSize: 25000}, function(createInfo) {
    stream_ch7 = createInfo.socketId;
    chrome.sockets.tcp.connect(stream_ch7, rvaIp, STREAMING_CONNECTION_PORT, function(result) {
      if (result == 0) {
        console.log("Connect to RVA proxy 7 success -> Listen http request");
      } else {
        console.log("Connect to RVA proxy 7 fail");
      }
    });
  });
}
