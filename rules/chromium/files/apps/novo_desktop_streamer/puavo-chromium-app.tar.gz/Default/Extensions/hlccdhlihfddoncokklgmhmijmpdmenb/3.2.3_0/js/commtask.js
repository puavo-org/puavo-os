var MAXIUM_MSG_LENGTH = 200;
var SOFTWARE_VERSION = 1234;
var MINUM_MSG_LENGTH = 4;

var TCP_CONNECTION_PORT = 20121;
var TCP_DATA_PORT = 20123;
var TCP_REMOTE_DISPLAY_PORT = 20125;
var EXCHANGE_DATA_PORT = 20131;
var ANNOTATION_DATA_PORT = 20161;

var cmd_socketId;
var data_socketId;
var screenshot_socketId;
var exchange_data_socketId;
var annotation_data_socketId;

var clientName;
var rvaIP = "";
var isPIN = false;
var pinCode;
var client_id = 0;
var user_id = 0;
var state = 0;
var osDevType;
var screen_number = 0;
var image_value;
var ssid;
var isDataConnected = false;
var isScreenConnected = false;
var isCMDConnected = false;
var network_mode;
var dev_name;
var isPause = false;

var screenshot_userid = 0;
var isGroupMode;
var mainWindow;

var display_width = 0;
var display_height = 0;

var isSplitMode = false;
var lastImageTime;
var nextImageTime;

var isImageSendingPause = false;

var image_rate = "";

var data = {};

var lastRequestTime = 0;
var thisRequestTime = 0;

var nextUrlNumber = 0;
var urlList;

var file_progress_notification;

var conObject = {};
var qrObject = {};
var rvaType = "EDU";
var screen_width;
var screen_height;
var notificationOn;
var connection_uid = 999;
var isPinMandatory = false;
var isTesting = false;
var quality_rate = 0.8;
var last_data3 = -1;
var last_data4 = -1;

chrome.runtime.getBackgroundPage(function(backgroundPage) {

  chrome.system.display.getInfo(function (displayInfo) {
    for (var i = 0; i < displayInfo.length; i++) {
      var disObject = displayInfo[i];
      if (disObject.isPrimary) {
        if (disObject.bounds.width > 1920) {
          display_width = 1920;
        } else {
          display_width = disObject.bounds.width;
        }
        if (disObject.bounds.height > 1080) {
          display_height = 1080;
        } else {
          display_height = disObject.bounds.height;
        }
      }
    }
  });

  chrome.system.network.getNetworkInterfaces(function(callback) {
    var count = 1;
    for (var i = 0; i < callback.length; i++) {
      var networkInterfaces = callback[i];
      if (networkInterfaces.prefixLength === 64) {
        console.log(networkInterfaces.address);
        var netW = networkInterfaces.address;
        var netWork = netW.substring(netW.length - 4, netW.length);
        console.log("NETWORK ", netWork);
        connection_uid = parseInt(netWork, 16) / 2;
        console.log("Connection_UID ", connection_uid);
        break;
      }
    }
  });

  isFirstTeacherPriorityError = true;
});

function getStorageSettings() {
  var storageArray = ["client_name", "rva", "ip_list", "image_quality", "moderator_status", "moderator_password", "url_list", "notificationOn"];
  chrome.storage.local.get(storageArray, function(callback) {

    //display last login name
    data.client_name = (callback.client_name)? callback.client_name : "";

    //display last rva url
    data.rva_url = (callback.rva)? callback.rva : "";

    //display last screen-mirroring quality
    quality_rate = (callback.image_quality)? callback.image_quality : .8;
    data.imageQuality = quality_rate;

    //notification option
    notificationOn = (callback.notificationOn)? (callback.notificationOn == true) : false;
    data.notificationOn = notificationOn;

    //display connect as a moderator status
    isConnectAsModeratorChecked = (callback.moderator_status)? callback.moderator_status : false;
    data.moderator = isConnectAsModeratorChecked;

    //display connect as a moderator password
    moderatorPassword = (callback.moderator_password)? callback.moderator_password : "";
    data.moderatorPassword = moderatorPassword;

    setInitValue(data);

    //loading rva url address history
    if (callback.ip_list) {
      ip_list = [];
      var ip_datalist = callback.ip_list;
      for (var i = 0; i < ip_datalist.length; i++) {
        //for (var i = 0; i < 7; i++) {
        var ipObject = ip_datalist[i];
        add_ipdata(ipObject.value, ipObject.label, false, ipObject.username, ipObject.times, false);
      }
      refreshIPList(ip_list);
    }
    else {
      ip_list = [];
    }

    //get receive url history
    if (callback.url_list) {
      urlList = callback.url_list;
      if (urlList.length > 0) {
        nextUrlNumber = urlList[urlList.length - 1].pid;
      }
    }
    else {
      urlList = [];
    }
  });
  chrome.runtime.getPlatformInfo(function(info) {
    osDevType = info.os;
    if (osDevType === "win" || osDevType === "mac") {
      update_IP_LIST_with_Boardcast();
    }
  });
}

function initial_parameters() {

  image_value = "";
  isDataConnected = false;
  isScreenConnected = false;
  isCMDConnected = false;
  handle_buffer = [];
  data_exchange_handle_buffer = [];
  annotation_data_handle_buffer = [];
  times = 1;
  screenshot_times = 1;
  array_size = 0;
  scount = 0;
  screenBuf = null;
  try_times = 0;
  annotation_state = false;
  annotator_uid = 0;
  clearTimeout(cmd_keep_alive_timeout);
  clearTimeout(request_checkKeepAlive_timeout);
  if (need_reconnection) {
    // no reset
  } else {
    isPIN = false;
    client_id = 0;
    isGroupMode = false;
    group_list = [];
    user_list = [];
    groupName = $.t("info.noModerator"); // TODO: i18n
    rvaNumber = 1.4;
    nvc = "B380";
    isflexibleGUI = false;
    isflexibleGUIDnD = false;
    sessionInfoOn = false;
    supportVoting = 0;
    supportExchangeServer = false;
    supportURLSharing = false;
    supportSharingBigFile = false;
    supportLocalVideo = false;
    supportNewVideoPlay = false;
    isNVCMatching = false;
    supportFastSwitchScreen = false;
    supportFastImageSending = false;
    supportNewWifiLan = false;
    supportScreenWithdraw = false;
    isCorp = false;
    isSessionLock = false;
    supportSessionLock = false;
    supportAnnotation = false;
    supportTerminateUser = false;
    isNovoCast = false;
    isPinMandatory = false;
    isNewFileSharing = false;
    isSoftwareDecoder = false;
    isDataNeedPreload = false;
    isHideVoting = false;
    isSupportUsbLan = false;
    conObject = {};
    qrObject = {};
    isCastTW1 = false;
    isCastCN = false;
    supportH264 = false;
    isNewDataConnection = false;
    isSoftwareMatching = false;
    support7SocketChannel = false;

  }
  isPause = false;
  isSplitMode = false;
  isImageSendingPause = false;

  // Voting
  votingObject = new votingObj(false, null);
  isTesting = false;
  // 	streaming_isFirst = true;
  isFirstTeacherPriorityError = true;
  //File sharing data
  isFileDownloading = false;
  isReadyToSend = true;
  isClosingSendingFilepage = false;

  //Switch panel timeout
  lastRequestTime = 0;
  thisRequestTime = 0;
  last_data3 = -1;
  last_data4 = -1;
}

function connection_request() {
  document.getElementById("canvas").width = display_width;
  document.getElementById("canvas").height = display_height;

  var rva_url = document.querySelector('#rva_url');
  var client_name = document.querySelector('#client_name');

  if (client_name.value === "") {
    novo.novoconnect("showClientNameTooltip", $.t("login.nameRequired"));
  } else if (rva_url.value.length === 0) {
    messagePage($.t("login.ipInvalid")); // TODO: i18n
  } else {
    if (pending_request_id === null) {
      initial_ImageService();
    } else {
      connectToRVA(true);
    }
  }
}

// add offset socketId
var offset_socketId;

chrome.sockets.tcp.create({persistent: false, name: "OFF"}, function(createInfo) {
  offset_socketId = createInfo.socketId;
});

var connection_timeout;
function connectToRVA(flag) {
  if (flag) {
    var rva_url = document.querySelector('#rva_url');
    var client_name = document.querySelector('#client_name');
    rvaIp = rva_url.value.replace(/\s+/g, "");
    clientName = client_name.value;
    // new qr for above v1.4
    qr_ip = rvaIp;
    // storage client name
    chrome.storage.local.set({
      'client_name': clientName
    });
    // storage rva ip
    chrome.storage.local.set({
      'rva': rvaIp
    });
    //send timeout to check login 20s
    connection_timeout = setTimeout(request_timeout, 20000);
    chrome.sockets.tcp.create({
      persistent: false,
      bufferSize: 8192,
      name: "CMD"
    }, function(createInfo) {
      cmd_socketId = createInfo.socketId;
      chrome.sockets.tcp.connect(cmd_socketId, rvaIp, TCP_CONNECTION_PORT, function(result) {
        if (result === 0) {
          console.log("CMD Connection Success -> Initial ConnectionRequest");
          send_CMD_CONNECTION_REQUEST();
        } else {
          chrome.sockets.tcp.close(cmd_socketId);
          clearTimeout(connection_timeout);
          connection_fail($.t("login.connectFailMsg")); // TODO: i18n
        }
      });
    });
  } else {
    messagePage($.t("login.needAllowShareScreen")); // TODO: i18n
  }
}

function request_timeout() {
  connection_fail($.t("login.connectFailMsg")); // TODO: i18n
  chrome.sockets.tcp.close(cmd_socketId);
}

//Open connection to RVA with Image data
function openDataConnection() {
  if (isNewDataConnection) {
    initial_DATASOCKET();
  } else {
    initial_IMAGESOCKET();
  }
}

//Open connection to RVA with ScreenShot
function openScreenConnection(flag) {
  chrome.sockets.tcp.create({
    bufferSize: 8192,
    name: "Preview"
  }, function(createInfo) {
    screenshot_socketId = createInfo.socketId;
    chrome.sockets.tcp.connect(screenshot_socketId, rvaIp, TCP_REMOTE_DISPLAY_PORT, function(result) {
      if (result === 0) {
        isScreenConnected = true;
        console.log("Screen Connection Success -> Intial Screen Receiving");
        if (flag) {
          // receive screen request
          send_screenshot_image();
          console.log("Screen Connection Success -> Intial Screen Sending");
        }
      } else {
        console.log("Screen Connection Fail");
      }
    });
  });
}

//Close connection to RVA with ScreenShot
function closeScreenConnection() {
  isScreenConnected = false;
  chrome.sockets.tcp.close(screenshot_socketId);
}

//Close connection to RVA with Command
function closeCMDConnection() {
  console.log("Close CMD Connection");
  if (isDataConnected) {
    closeDataConnection();
  }
  chrome.sockets.tcp.disconnect(cmd_socketId);
  chrome.sockets.tcp.close(cmd_socketId);
  reset_Data_Exchange_Server_Status();
  //Check annotation window
  reset_Annotation_Server_Status();
  // set all parameters to default
  initial_parameters();
}

function closeDataConnection() {
  console.log("Close Data Connection");
  times = 1;
  isDataConnected = false;
  if (amIPresenter(client_id)) {
    chrome.sockets.tcp.close(data_socketId);
  }
}

function closeCMD_Socket() {
  chrome.sockets.tcp.disconnect(cmd_socketId);
  chrome.sockets.tcp.close(cmd_socketId);
}

function closeData_Socket() {
  chrome.sockets.tcp.disconnect(data_socketId);
  chrome.sockets.tcp.close(data_socketId);
}

//Initial connection to RVA with parameters
function send_CMD_CONNECTION_REQUEST() {
  console.log("send_CMD_CONNECTION_REQUEST");
  var length = 0;
  var buf = new Uint8Array(MAXIUM_MSG_LENGTH);

  for (var i = 0; i < MAXIUM_MSG_LENGTH; i++) {
    buf[i] = 0;
  }

  buf[1] = CMD.CM_CONNECTION_REQUEST; // message type
  var connection_uuid = convertIntegerTwoBytes(connection_uid);
  buf[2] = connection_uuid[0]; // client ID
  buf[3] = connection_uuid[1]; // state

  var dataPortArray = convert_int_into_bytes_big_endian(pinCode);

  buf[4] = dataPortArray[0];
  buf[5] = dataPortArray[1];
  buf[6] = dataPortArray[2];
  buf[7] = dataPortArray[3];

  var pversion = convert_int_into_bytes_big_endian(SOFTWARE_VERSION);
  buf[8] = pversion[0];
  buf[9] = pversion[1];
  buf[10] = pversion[2];
  buf[11] = pversion[3];

  if (osDevType === "win") {
    buf[12] = OS_DEV_TYPE.OS_CHROME_APP_ON_WIN; // Chrome run on PC
  } else if (osDevType === "mac") {
    buf[12] = OS_DEV_TYPE.OS_CHROME_APP_ON_MAC; // Chrome run on MAC
  } else {
    buf[12] = OS_DEV_TYPE.OS_CHROME_APP; // ChromeBook = 9
  }

  if (isPIN) {
    buf[13] = 1;
  } else {
    buf[13] = 0;
  }

  var width = convert_int_into_bytes_big_endian(display_width);
  buf[14] = width[0];
  buf[15] = width[1];
  buf[16] = width[2];
  buf[17] = width[3];

  var height = convert_int_into_bytes_big_endian(display_height);
  buf[18] = height[0];
  buf[19] = height[1];
  buf[20] = height[2];
  buf[21] = height[3];

  length = client_name.value.length;

  if (length > 0) {
    var data = convert_str_into_bytes(utf8_encode(client_name.value));
    length = data.length;

    for (var k = 0; k < length; k++) {
      buf[22 + k] = data[k];
    }
  }
  buf[0] = length + MINUM_MSG_LENGTH + 18;

  chrome.sockets.tcp.send(cmd_socketId, buf.buffer.slice(0, length + MINUM_MSG_LENGTH + 18), function(sendInfo) {
    if (sendInfo.resultCode === 0) {
      console.log("Connection Request Success");
    } else {
      console.log("Connection Request Fail");
    }
  });
}

var handle_buffer = [];

var data_exchange_handle_buffer = [];
var annotation_data_handle_buffer = [];

//Receive all socket data here
chrome.sockets.tcp.onReceive.addListener(function(info) {
  // check keep alive
  isBack = true;

  if (info.socketId == cmd_socketId) {
    // from CMD socket
    var receive_buffer = new Uint8Array(info.data);
    handle_buffer.push.apply(handle_buffer, receive_buffer);
    var slice_byte = 0;
    while (handle_buffer.length > 0) {
      slice_byte = receive_CMD_MESSAGE(handle_buffer, 0);
      if (slice_byte > handle_buffer.length) {
        console.log(handle_buffer);
        console.log("Need more data");
        break;
      } else {
        handle_buffer.splice(0, slice_byte);
      }
    }
  } else if (info.socketId == data_socketId) {
    // from DATA Socket
    if (!isImageSendingPause) {
      var receive_buffer = new Uint8Array(info.data);
      if (receive_buffer.length >= 2) {
        if (isSplitMode) { //split mode need to reduce rate
          nextImageTime = new Date().getTime();
          var range = 1000;
          if (supportFastImageSending) {
            range = 500;
          }
          if (nextImageTime - lastImageTime > range) {
            start_SENDING_IMAGE();
          } else {
            var nextTime = range - nextImageTime + lastImageTime;
            setTimeout(start_SENDING_IMAGE, nextTime);
          }
        } else {
          start_SENDING_IMAGE();
        }
      }
    }
  } else if (info.socketId == screenshot_socketId) {
    // from SCREEN Socket
    var receive_buffer = new Uint8Array(info.data);
    receive_screenshot_image(receive_buffer);
  } else if (info.socketId == exchange_data_socketId) {
    // from Data exchange server socket
    var receive_buffer = new Uint8Array(info.data);
    data_exchange_handle_buffer.push.apply(data_exchange_handle_buffer, receive_buffer);
    if (getDataNeedPacketSize(data_exchange_handle_buffer) > 8 && data_exchange_handle_buffer[4] === CMD.FILE_SHARING_DATA) {

      file_progress_notification.progress = Math.round(data_exchange_handle_buffer.length * 100 / getDataNeedPacketSize(data_exchange_handle_buffer));
      chrome.notifications.update("fileProgress", file_progress_notification);

    }
    var slice_byte = 0;
    while (data_exchange_handle_buffer.length >= getDataNeedPacketSize(data_exchange_handle_buffer)) {
      slice_byte = receive_DATA_EXCHANGE_SERVER(data_exchange_handle_buffer, 0);
      if (slice_byte > data_exchange_handle_buffer.length) {
        console.log(data_exchange_handle_buffer);
        console.log("Need more data exchange data");
        break;
      } else {
        data_exchange_handle_buffer.splice(0, slice_byte);
      }
      if (data_exchange_handle_buffer.length === 0) {
        break;
      }
    }
  } else if (info.socketId == annotation_data_socketId) {
    // from Data exchange server socket
    var receive_buffer = new Uint8Array(info.data);
    annotation_data_handle_buffer.push.apply(annotation_data_handle_buffer, receive_buffer);

    var slice_byte = 0;
    while (annotation_data_handle_buffer.length >= getDataNeedPacketSize(annotation_data_handle_buffer)) {
      slice_byte = receive_ANNOTATION_DATA_SERVER(annotation_data_handle_buffer, 0);
      if (slice_byte > annotation_data_handle_buffer.length) {
        console.log("Need more data annotation data");
        break;
      } else {
        annotation_data_handle_buffer.splice(0, slice_byte);
      }
      if (annotation_data_handle_buffer.length === 0) {
        break;
      }
    }
  } else if (info.socketId == stream_ch1) {
    var receive_buffer = new Uint8Array(info.data);
    receive_streaming_message(receive_buffer);
  } else if (info.socketId == stream_ch2) {

    var receive_buffer = new Uint8Array(info.data);
    receive_streaming_second_message(receive_buffer);
  } else if (info.socketId == stream_ch3) {
    var receive_buffer = new Uint8Array(info.data);
    receive_streaming_3_message(receive_buffer);
  } else if (info.socketId == stream_ch4) {
    var receive_buffer = new Uint8Array(info.data);
    receive_streaming_4_message(receive_buffer);
  } else if (info.socketId == stream_ch5) {
    var receive_buffer = new Uint8Array(info.data);
    receive_streaming_5_message(receive_buffer);
  } else if (info.socketId == stream_ch6) {
    var receive_buffer = new Uint8Array(info.data);
    receive_streaming_6_message(receive_buffer);
  } else if (info.socketId == stream_ch7) {
    var receive_buffer = new Uint8Array(info.data);
    receive_streaming_7_message(receive_buffer);
  } else if (info.socketId == tcp_ch1) {
    var receive_buffer = new Uint8Array(info.data);
    receive_tcpServer(receive_buffer);
  } else if (info.socketId == tcp_ch2) {
    var receive_buffer = new Uint8Array(info.data);
    receive_second_tcpServer(receive_buffer);
  } else if (info.socketId == tcp_ch3) {
    var receive_buffer = new Uint8Array(info.data);
    receive_tcp3Server(receive_buffer);
  } else if (info.socketId == tcp_ch4) {
    var receive_buffer = new Uint8Array(info.data);
    receive_tcp4Server(receive_buffer);
  } else if (info.socketId == tcp_ch5) {
    var receive_buffer = new Uint8Array(info.data);
    receive_tcp5Server(receive_buffer);
  } else if (info.socketId == tcp_ch6) {
    var receive_buffer = new Uint8Array(info.data);
    receive_tcp6Server(receive_buffer);
  } else if (info.socketId == tcp_ch7) {
    var receive_buffer = new Uint8Array(info.data);
    receive_tcp7Server(receive_buffer);
  }else if (info.socketId == voting_data_socket) {
    // from voting
    var receive_buffer = new Uint8Array(info.data);
    receiveVotingServer(receive_buffer);
  } else {
    console.log("Receive Wrong socket id = " + info.socketId);
    console.log("From HTTP SERVER");
  }
});

function getDataNeedPacketSize(rBuffer) {
  return convert_bytes_big_endian_into_int(rBuffer[0], rBuffer[1], rBuffer[2], rBuffer[3]);
}

//Handle all command message
function receive_CMD_MESSAGE(byteValues, startByte) {
  var msg_length = byteValues[startByte];
  var cmd = byteValues[startByte + 1];
  console.log("CMD ", cmd);

  switch (cmd) {
    case CMD.KEEP_ALIVE:
      receive_CMD_KEEP_ALIVE();
      break;
    case CMD.VIEWER_REQUEST:
      receive_CMD_VIEWER_REQUEST(byteValues, startByte);
      break;
    case CMD.MODERATOR_VIEWER_REQUEST:
      msg_length = receive_CMD_MODERATOR_VIEWER_REQUEST(byteValues, startByte);
      break;
    case CMD.MODERATOR_VIEWER_STATE_CHANGE:
      receive_CMD_MODERATOR_VIEWER_STATE_CHANGE(byteValues, startByte);
      break;
    case CMD.SCREEN_RESOLUTION:
      receive_CMD_SCREEN_RESOLUTION(byteValues, startByte);
      break;
    case CMD.NETWORK_MODE:
      receive_CMD_NETWORK_MODE(byteValues, startByte);
      break;
    case CMD.PIN_VALUE:
      receive_CMD_PIN_VALUE(byteValues, startByte);
      break;
    case CMD.RVA_EDUCATION:
      receive_CMD_RVA_EDUCATION(byteValues, startByte);
      break;
    case CMD.RVA_ENTERPRISE_V2:
      receive_CMD_RVA_ENTERPRISE_V2(byteValues, startByte);
      break;
    case CMD.DISPLAY_SETTING:
      receive_CMD_DISPLAY_SETTING(byteValues, startByte);
      break;
    case CMD.DISPLAY_LANGUAGE:
      console.log("Receive CMD DISPLAY_LANGUAGE");
      break;
    case CMD.RVA_VERSION:
      receive_CMD_RVA_VERSION(byteValues, startByte);
      break;
    case CMD.BSP_VERSION:
      receive_CMD_BSP_VERSION(byteValues, startByte);
      break;
    case CMD.NVC_MODEL:
      receive_CMD_NVC_MODEL(byteValues, startByte);
      break;
    case CMD.DEVICE_NAME:
      receive_CMD_DEVICE_NAME(byteValues, startByte);
      break;
    case CMD.PIN_REQUIRED:
      receive_CMD_PIN_REQUIRED();
      break;
    case CMD.PIN_NOT_REQUIRED:
      receive_CMD_PIN_NOT_REQUIRED();
      break;
    case CMD.UPLOAD_GROUP_DATA:
      msg_length = receive_CMD_UPLOAD_GROUP_DATA(byteValues, startByte);
      break;
    case CMD.QR_CODE_IMAGE:
      msg_length = receive_CMD_QR_CODE_IMAGE(byteValues, startByte);
      break;
    case CMD.CM_RECONNECTION_ALLOWED:
      receive_CMD_RECONNECTION_ALLOWED();
      break;
    case CMD.CM_CONNECTION_APPROVAL:
      receive_CMD_CONNECTION_APPROVAL(byteValues, startByte);
      break;
    case CMD.SPLIT_SCREEN_READY:
      receive_CMD_SPLIT_SCREEN_READY();
      break;
    case CMD.FULL_SCREEN_READY:
      receive_CMD_FULL_SCREEN_READY();
      break;
    case CMD.MODERATOR_BROADCAST_REQUEST:
      receive_CMD_MODERATOR_BROADCAST_REQUEST();
      break;
    case CMD.CM_RESET_RVA:
      receive_CMD_RESET_RVA();
      break;
    case CMD.CM_RESET_DEVICE:
      receive_CMD_RESET_DEVICE();
      break;
    case CMD.MODERATOR_REQUEST:
      receive_CMD_MODERATOR_REQUEST();
      break;
    case CMD.MODERATOR_APPROVED:
      receive_CMD_MODERATOR_APPROVED();
      break;
    case CMD.MODERATOR_DENIED:
      receive_CMD_MODERATOR_DENIED();
      break;
    case CMD.SCREENSHOT_REQUEST:
      receive_CMD_SCREENSHOT_REQUEST();
      break;
    case CMD.SCREENSHOT_RESPONSE:
      receive_CMD_SCREENSHOT_RESPONSE();
      break;
    case CMD.SCREEN_LOCK_UNLOCK: // pending not support Chromebook
      receive_CMD_SCREEN_LOCK_UNLOCK(byteValues);
      break;
    case CMD.CM_VIEWER_PAUSE:
      receive_CMD_VIEWER_PAUSE();
      break;
    case CMD.CM_VIEWER_RESUME:
      receive_CMD_VIEWER_RESUME();
      break;
    case CMD.VIEWER_RELEASE:
      receive_CMD_VIEWER_RELEASE();
      break;
    case CMD.VIEWER_APPROVED:
      receive_CMD_VIEWER_APPROVED(byteValues, startByte);
      break;
    case CMD.CM_VIEWER_STARTED:
      receive_CMD_VIEWER_STARTED();
      break;
    case CMD.REMOVE_REQUEST:
      receive_CMD_REMOVE_REQUEST(byteValues);
      break;
    case CMD.CM_INVALID_CMD:
      receive_CMD_INVALID_CMD(byteValues, startByte);
      break;
    case CMD.CLIENT_STATUS_REFRESH:
      msg_length = receive_CMD_CLIENT_STATUS_REFRESH(byteValues, startByte);
      break;
    case CMD.PLAY_VIDEO:
      receive_CMD_PLAY_VIDEO(byteValues);
      break;
    case CMD.PLAY_YOUTUBE:
      receive_CMD_PLAY_YOUTUBE(byteValues);
      break;
    case CMD.POLLING_VOTING:
      msg_length = receive_CMD_POLLING_VOTING(byteValues, startByte);
      break;
    case CMD.PREVIEW_DATA:
      receive_CMD_PREVIEW_DATA(byteValues, startByte);
      break;
    case CMD.POLLING_VOTING_V2:
      receive_CMD_POLLING_VOTING_V2(byteValues, startByte);
      break;
    case CMD.STREAMING_PLAY_TIME_UPDATE:
      receive_CMD_STREAMING_PLAY_TIME_UPDATE(byteValues, startByte);
      break;
    case CMD.REQUEST_TEACHER_PRIORITY:
      receive_CMD_REQUEST_TEACHER_PRIORITY(byteValues, startByte);
      break;
    case CMD.FILE_SHARING_DATA:
      receive_CMD_FILE_SHARING_DATA(byteValues, startByte);
      break;
    case CMD.URL_SHARING:
      msg_length = receive_CMD_URL_SHARING(byteValues, startByte);
      break;
    case CMD.BROADCAST_MSG:
      msg_length = receive_CMD_BROADCAST_MSG(byteValues, startByte);
      break;
    case CMD.RESPONDER:
      receive_CMD_RESPONDER(byteValues);
      break;
    case CMD.ANNOTATION:
      receive_CMD_ANNOTATION_REQUEST(byteValues, startByte);
      break;
    case CMD.REMOTE_CONTROL_CMD:
      receive_CMD_REMOTE_CONTROL_CMD(byteValues);
      break;
    case CMD.CLIENT_REMOVE:
      receive_CMD_CLIENT_REMOVE(byteValues, startByte);
      break;
    case CMD.SESSION_LOCK_UNLOCK:
      receive_CMD_SESSION_LOCK_UNLOCK(byteValues, startByte);
      break;
    case CMD.SESSION_CLIENT_STATUS_REFRESH:
      receive_CMD_SESSION_CLIENT_STATUS_REFRESH(byteValues, startByte);
      break;
    case CMD.CM_STATUS:
      receive_CMD_CM_STATUS(byteValues, startByte);
      break;
    case CMD.REQUEST_CANCELLED:
      receive_CMD_REQUEST_CANCELLED(byteValues, startByte);
      break;
    case CMD.SHARE_SYSTEM_BUSY:
      receive_CMD_ANNOTATION_SYSTEM_BUSY();
      break;
    case CMD.H264_VIDEO_CLIENT:
      receive_CMD_H264_VIDEO_CLIENT(byteValues, startByte);
      break;
    case CMD.NVC_EDITION_STRING:
      receive_CMD_NVC_EDITION_STRING(byteValues, startByte);
      break;
    default:
      receive_CMD_NOT_READY(byteValues, startByte);
  }

  return startByte + msg_length;
}

function receive_CMD_INVALID_CMD(bValues, s_bytes) {
  console.log("Receive CMD INVALID_CMD");
  var error_code = bValues[s_bytes + 3];
  switch (error_code) {
    case ERRORCODE.PIN_INVALID:
      receive_ERRORCODE_PIN_INVALID();
      break;
    case ERRORCODE.NAME_NOT_IN_GROUP:
      receive_ERRORCODE_NAME_NOT_IN_GROUP();
      break;
    case ERRORCODE.DUPLICATED_NAME_IN_GROUP:
      receive_ERRORCODE_DUPLICATED_NAME_IN_GROUP();
      break;
    case ERRORCODE.REACH_MAX_NUMBER_USERS:
      receive_ERRORCODE_REACH_MAX_NUMBER_USERS();
      break;
    case ERRORCODE.NOVOCAST_REACH_MAX_NUMBER_USERS:
      receive_ERRORCODE_NOVOCAST_REACH_MAX_NUMBER_USERS();
      break;
    default:
      console.log("Other Errorcode =" + error_code);
      console.log("[0]=" + bValues[s_bytes]);
      console.log("[1]=" + bValues[s_bytes + 1]);
      console.log("[2]=" + bValues[s_bytes + 2]);
      console.log("[3]=" + bValues[s_bytes + 3]);
  }
}

function receive_CMD_CM_STATUS(bValues, s_bytes) {
  console.log("Receive CMD CM STATUS");
  var state = bValues[s_bytes + 3];
  switch (state) {
    case STATUSCODE.CONNECTION_FAIL_SESSION_LOCKED:
      console.log("Receive CONNECTION FAIL SESSION LOCK");
      clearTimeout(connection_timeout);
      closeCMDConnection();
      failSessionLockLogin($.t("group.connectFailSessionLockedMsg")); // TODO: i18n
      break;
  }
}

function receive_ERRORCODE_PIN_INVALID() {
  console.log("Receive ERRORCODE PIN INVALID");
  clearTimeout(connection_timeout);
  closeCMDConnection();
  isPIN = true;
  //messagePage($.t("login.pinInvalid")); // TODO: i18n
  connection_fail_invalid_pincode();
}

function receive_ERRORCODE_NAME_NOT_IN_GROUP() {
  console.log("Receive ERROR NAME NOT IN GROUP");
  clearTimeout(connection_timeout);
  closeCMDConnection();
  novo.novoconnect("showClientNameTooltip", $.t("group.nameNotInGroup"));
}

function receive_ERRORCODE_DUPLICATED_NAME_IN_GROUP() {
  console.log("Receive ERROR DUPLICATED NAME IN GROUP");
  clearTimeout(connection_timeout);
  closeCMDConnection();
  novo.novoconnect("showClientNameTooltip", $.t("group.duplicateNameInGroup"));
}

function receive_ERRORCODE_REACH_MAX_NUMBER_USERS() {
  console.log("Receive ERROR REACH MAX NUMBER USERS");
  clearTimeout(connection_timeout);
  closeCMDConnection();
  messagePage($.t("login.connectionOverMsg")); // TODO: i18n
}

function receive_ERRORCODE_NOVOCAST_REACH_MAX_NUMBER_USERS() {
  console.log("Receive ERROR REACH MAX NUMBER USERS");
  clearTimeout(connection_timeout);
  closeCMDConnection();
  messagePage($.t("login.connectionOver2Msg")); // TODO: i18n
}

//RVA ask to close data connection
function receive_CMD_VIEWER_RELEASE() {
  console.log("Receive CMD VIEWER RELEASE");
  closeDataConnection();
}

//Received not supported command message
function receive_CMD_NOT_READY(bValues, s_bytes) {
  console.log("Receive CMD NOT READY");
  console.log("[0]=" + bValues[s_bytes]);
  console.log("[1]=" + bValues[s_bytes + 1]);
  console.log("[2]=" + bValues[s_bytes + 2]);
  console.log("[3]=" + bValues[s_bytes + 3]);
}

//Receive Group xml data
function receive_CMD_UPLOAD_GROUP_DATA(bValues, s_bytes) {
  console.log("Receive CMD UPLOAD GROUP DATA");
  var xml_length = convert_bytes_big_endian_into_int(bValues[s_bytes + 4], bValues[s_bytes + 5], bValues[s_bytes + 6], bValues[s_bytes + 7]);
  if (xml_length + 8 > bValues.length) {
    return xml_length + 8;
  } else {
    var j = 0;
    var length = xml_length + 8;
    var strBuf = new Uint8Array(xml_length);
    for (var i = 8 + s_bytes; i < length + s_bytes; i++) {
      strBuf[j] = bValues[i];
      j++;
    }
    var receive_xml = convert_bytes_array_into_str(strBuf);
    console.log(receive_xml);
    getGroupList(receive_xml);

    return length;
  }
}

var group_list = [];

function getGroupList(xml_str) {
  // replace spaces
  var no_space = xml_str.replace(/^\s+|\s+$/gm, '');
  var oParser = new DOMParser();
  var oDOM = oParser.parseFromString(no_space, "text/xml");

  var group = oDOM.getElementsByTagName("group")[0];
  for (var i = 0; i < group.childNodes.length; i++) {
    if (group.childNodes[i].tagName == "class") {
      groupName = group.childNodes[i].childNodes[0].nodeValue;
      groupName = decodeURIComponent(escape(groupName));
    } else if (group.childNodes[i].tagName == "teacher" || group.childNodes[i].tagName == "student") {
      var user = group.childNodes[i];
      var name = "";
      var device = "";
      for (var j = 0; j < user.childNodes.length; j++) {
        if (user.childNodes[j].tagName == "name") {
          if (typeof user.childNodes[j].childNodes[0] !== 'undefined') {
            name = user.childNodes[j].childNodes[0].nodeValue;
          }
        }
        if (user.childNodes[j].tagName == "device") {
          if (typeof user.childNodes[j].childNodes[0] !== 'undefined') {
            device = user.childNodes[j].childNodes[0].nodeValue;
          }
        }
      }
      if (name === "") {
        name = device;
      }
      if (device === "") {
        device = name;
      }

      group_list.push(decodeURIComponent(escape(name)), decodeURIComponent(escape(device)));
    } else {
      console.log("Ignore data");
    }
  }
}

//Received ask to be presenter
function receive_CMD_VIEWER_APPROVED(bValues, s_bytes) {
  console.log("Receive CMD VIEWER APPROVED");
  var userid = bValues[2];
  var location = bValues[3];
  //Response to RVA
  send_CMD_VIEWER_START(userid, location);
}

function send_CMD_VIEWER_START(userid, location) {
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.CM_VIEWER_START; // message type
  buf[2] = userid;
  buf[3] = location;
  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send send_CMD_VIEWER_START Success");
    } else {
      console.log("Send send_CMD_VIEWER_START Fail");
    }
  });
}

//Receive RVA record updating
function receive_CMD_MODERATOR_VIEWER_REQUEST(bValues, s_bytes) {
  //cancel request timeout
  send_request_timeout = false;

  var user_id = bValues[s_bytes + 2];
  var state = bValues[s_bytes + 3];
  var device = bValues[s_bytes + 4];

  var j = 0;
  var length = bValues[s_bytes];
  var strBuf = new Uint8Array(bValues[s_bytes] - 5);
  for (var i = s_bytes + 5; i < length + s_bytes; i++) {
    strBuf[j] = bValues[i];
    j++;
  }
  //var userName = convert_bytes_array_into_str(strBuf);
  var userName = convert_bytes_array_into_str_utf8(strBuf);


  console.log("Receive CMD MODERATOR_VIEWER_REQUEST");
  console.log("User ID = " + user_id);
  console.log("STATE = " + state);
  console.log("OS_DEV_TYPE = " + device);
  console.log("User NAME = " + userName);
  //insert into user_list
  //add_userdata("MODERATOR_REQUEST", user_id, decodeURIComponent(escape(userName)), false, null, -1, false, true, device);
  add_userdata("MODERATOR_REQUEST", user_id, userName, false, null, -1, false, true, device);
  //update user_list
  check_state_case(user_id, CMD.MODERATOR_VIEWER_REQUEST, state);

  return length;
}

function receive_CMD_QR_CODE_IMAGE(bValues, s_bytes) {
  console.log("Receive CMD QR_CODE_IMAGE");
  var image_data_size = convert_bytes_big_endian_into_int(bValues[s_bytes + 4], bValues[s_bytes + 5], bValues[s_bytes + 6], bValues[s_bytes + 7]);
  //image data = 8 ~ image_data_size
  var j = 0;
  var length = image_data_size + 8;
  var strBuf = new Uint8Array(image_data_size);
  for (var i = 8; i < length; i++) {
    strBuf[j] = bValues[i];
    j++;
  }
  image_value = covert_array_into_Base64(strBuf);
  img = covert_array_into_Base64(strBuf);

  // new qr
  qr_ImgURL = img;
  qrObject.qrImg = qr_ImgURL;

  return length;
}

var qr_ImgURL;
var qr_Pin;
var qr_pin_status = false;

//Receive PIN CODE from RVA
function receive_CMD_PIN_VALUE(bValues, s_bytes) {
  console.log("Receive CMD PIN_VALUE");
  var pin_number = convert_bytes_big_endian_into_int(bValues[s_bytes + 4], bValues[s_bytes + 5], bValues[s_bytes + 6], bValues[s_bytes + 7]);
  pinCode = pin_number;
  // new qr
  qr_Pin = pin_number;

  if (bValues[s_bytes + 3] == 1) {
    isPinMandatory = true;
  }

}

var qr_ip;
var qr_ssid;
var qr_lan;
var qr_usb;

function receive_CMD_NETWORK_MODE(bValues, s_bytes) {
  console.log("Receive CMD NETWORK_MODE");
  if (bValues[s_bytes + 3] == 0) {
    network_mode = 0; // Network mode
  } else if (bValues[s_bytes + 3] == 1) {
    network_mode = 1 // Hotspot mode
  } else {
    network_mode = 2; // Wifi turn off
  }

  //v1.5 support Dual IP address
  if (supportNewWifiLan) {
    // GET WIFI
    var ssid_length = bValues[4 + s_bytes];
    var strBuf = new Uint8Array(ssid_length);
    for (var i = 0; i < ssid_length; i++) {
      strBuf[i] = bValues[4 + i + 1 + s_bytes];
    }

    qr_ssid = convert_bytes_array_into_str(strBuf);
    console.log(qr_ssid);

    var wifi_ip_length = bValues[4 + s_bytes + 1 + ssid_length];
    var strBuf2 = new Uint8Array(wifi_ip_length);
    for (var i = 0; i < wifi_ip_length; i++) {
      strBuf2[i] = bValues[4 + i + 1 + ssid_length + 1 + s_bytes];
    }
    qr_ip = convert_bytes_array_into_str(strBuf2);

    var lan_ip_length = bValues[4 + s_bytes + 1 + ssid_length + 1 + wifi_ip_length];
    var strBuf3 = new Uint8Array(lan_ip_length);
    for (var i = 0; i < lan_ip_length; i++) {
      strBuf3[i] = bValues[4 + i + 1 + ssid_length + 1 + wifi_ip_length + 1 + s_bytes];
    }
    var strBuf3Result = convert_bytes_array_into_str(strBuf3);
    if (strBuf3Result != "0.0.0.0") {
      qr_lan = strBuf3Result;
    }

    if (isSupportUsbLan) {
      var usb_ip_length = bValues[4 + s_bytes + 1 + ssid_length + 1 + wifi_ip_length + 1 + lan_ip_length];
      var strBuf4 = new Uint8Array(usb_ip_length);
      for (var i = 0; i < usb_ip_length; i++) {
        strBuf4[i] = bValues[4 + i + 1 + ssid_length + 1 + wifi_ip_length + 1 + s_bytes + 1 + lan_ip_length];
      }
      var strBuf4Result = convert_bytes_array_into_str(strBuf4);
      if (strBuf4Result != "0.0.0.0") {
        qr_usb = strBuf4Result;
      }
    }
  } else {
    var j = 0;
    var length = bValues[s_bytes] + s_bytes;
    var strBuf = new Uint8Array(bValues[s_bytes] - 4);
    for (var i = s_bytes + 4; i < length; i++) {
      strBuf[j] = bValues[i];
      j++;
    }

    ssid = convert_bytes_array_into_str(strBuf);

    //Send to qrimage
    chrome.runtime.getBackgroundPage(function(backgroundPage) {
      backgroundPage.setSSID(ssid);
    });

    qr_ssid = ssid;
  }

  var wifi_object = {
    ip: qr_ip,
    ssid: qr_ssid
  };
  qrObject.pinStatus = qr_pin_status;
  qrObject.pinValue = qr_Pin;
  if (network_mode === 0 || network_mode == 1) {
    qrObject.wifi = wifi_object;
    qrObject.lan = qr_lan;
    if (isSupportUsbLan) {
      qrObject.usbLanIP = qr_usb;
    }
  } else if (network_mode === 2) {
    qrObject.lan = qr_lan;
    if (isSupportUsbLan) {
      qrObject.usbLanIP = qr_usb;
    }
  }
}

function receive_CMD_SCREEN_RESOLUTION(bValues, s_bytes) {
  console.log("Receive CMD SCREEN_RESOLUTION");
  screen_width = convert_bytes_big_endian_into_int(
    bValues[s_bytes + 4], bValues[s_bytes + 5], bValues[s_bytes + 6], bValues[s_bytes + 7]);
  screen_height = convert_bytes_big_endian_into_int(
    bValues[s_bytes + 8], bValues[s_bytes + 9], bValues[s_bytes + 10], bValues[s_bytes + 11]);
}

function receive_CMD_DEVICE_NAME(bValues, s_bytes) {
  console.log("Receive CMD DEVICE_NAME");
  var j = 0;
  var length = bValues[s_bytes] + s_bytes;
  dev_name = "";
  var strBuf = new Uint8Array(bValues[s_bytes] - 4);
  for (var i = s_bytes + 4; i < length; i++) {
    strBuf[j] = bValues[i];
    j++;
  }

  dev_name = decodeURIComponent(escape(convert_bytes_array_into_str(strBuf)));
  console.log("DEVICE NAME = " + dev_name);
}

function receive_CMD_DISPLAY_SETTING(bValues, s_bytes) {
  console.log("Receive CMD DISPLAY_SETTING");
}

function receive_CMD_PIN_NOT_REQUIRED() {
  console.log("Receive CMD PIN_NOT_REQUIRED");
  isPIN = false;

  qr_pin_status = false;
  qrObject.pinStatus = false;

  if (isCMDConnected) {
    //Refresh Connected Object
    conObject.pin_need = qr_pin_status;
    conObject.qrObj = qrObject;
    connected_initial(conObject);
  }
}

var image_path = "";
var ssid = "";
var pin = "";
var ipaddress = "";
var need_pin = false;

var groupName;

function refreshUserListByGroupList() {
  // update_userdata
  for (var i = 1; i < group_list.length; i = i + 2) {
    var pass = false;
    for (var j = 0; j < user_list.length; j++) {
      var update_user = user_list[j];
      if (update_user.label.toUpperCase().replace(/\s/g, "") == group_list[i].toUpperCase().replace(/\s/g, "")) {
        // update online = true;
        if (group_list[i - 1] != group_list[i]) {
          //Device = OS Type + (User's + Device name)
          var d_name = getOSDeviceNameByType(update_user.os_type) + " (" + group_list[i - 1] + "'s " + group_list[i] + ")";
          user = new userdata(update_user.uid, group_list[i - 1], update_user.isHost, d_name, update_user.panel, update_user.isMyself, true, group_list[i], update_user.os_type);
        } else {
          user = new userdata(update_user.uid, group_list[i - 1], update_user.isHost, null, update_user.panel, update_user.isMyself, true, group_list[i], update_user.os_type);
        }
        user_list[j] = user;
        pass = true;
        break;
      }
    }
    if (pass) {
      // already do update_user
    } else {
      // user is offline
      var user = new userdata("None", group_list[i - 1], false, "", -1, false, false, group_list[i], 0);
      user_list.push(user);
    }
  }
}

//Connect to RVA Success
function receive_CMD_CONNECTION_APPROVAL(bValues, s_bytes) {
  console.log("Receive CMD CONNECTION_APPROVAL");
  clearTimeout(connection_timeout);
  client_id = bValues[s_bytes + 2]; // This is real client_id from RVA

  //check if groupMode : true
  isGroupMode = false;
  var isOk = true;
  if (group_list.length > 0) {
    isGroupMode = true;
    // refreshUserList
    refreshUserListByGroupList();
    // 		}
  } else {
    groupName = $.t("info.noModerator");//Todo: i18n
  }

  if (!isSoftwareMatching) {
    doLogout();
    send_CMD_REMOVE_REQUEST();
    // UI Action
    messagePage($.t("upgrade.versionNotMatch")); //TODO: i18n
    return;
  }

  if (isNVCMatching) {
    //update iplist history
    add_ipdata(rvaIp, rvaIp + " (" + dev_name + ")", false, clientName, new Date().getTime(), true);
    chrome.storage.local.set({
      'ip_list': ip_list
    });
    refreshIPList(ip_list);
    isCMDConnected = true;
    //Start Keep Alive
    send_CMD_KEEP_ALIVE();
    if (isCorp) {
      doLogout();
      send_CMD_REMOVE_REQUEST();
      messagePage($.t("login.setToEducationVersion")); //TODO: i18n
    } else {
      if (supportSessionLock && isSessionLock) {
        send_CMD_SESSION_CLIENT_STATUS_REFRESH();
      }
      send_CMD_MODERATOR_VIEWER_REQUEST();
      //Send Connected Object to Molly
      doLogin(true);
      conObject.message = $.t("login.connected");
      conObject.ipaddress = rvaIp;
      conObject.pin_value = pinCode;
      conObject.qrsrc = image_value;
      conObject.pin_need = isPIN;
      conObject.ssid = ssid;
      conObject.groupMode = isGroupMode;
      conObject.groupName = groupName;
      conObject.rvaVersion = rvaNumber;
      conObject.rvaWidth = screen_width;
      conObject.rvaHeight = screen_height;
      qrObject.deviceName = dev_name;
      conObject.qrObj = qrObject;
      conObject.rvaType = rvaType;
      conObject.pin_mandatory = isPinMandatory;
      if (isGroupMode) {
        conObject.client_name = getSendNameById(client_id) + ",";
      } else {
        conObject.client_name = clientName + ",";
      }
      console.log(conObject);
      connected_initial(conObject);
    }
  } else {
    send_CMD_REMOVE_REQUEST();
    doLogout();

    // UI Action
    messagePage($.t("login.incompatible")); //TODO: i18n
  }

}

//RVA ask to be presenter
function receive_CMD_VIEWER_STARTED() {
  console.log("Receive CMD VIEWER STARTED");
  if (isDataConnected) {
    console.log("Data Connection is already initial");
  } else {
    isDataConnected = true;
    openDataConnection();
  }
}

function receive_CMD_MODERATOR_VIEWER_STATE_CHANGE(bValues, s_bytes) {
  console.log("Receive CMD MODERATOR VIEWER STATE CHANGE");
  var change_userId = bValues[s_bytes + 2];
  var change_state = bValues[s_bytes + 3];

  console.log("Userid = " + change_userId);
  console.log("State = " + change_state);

  check_state_case(change_userId, CMD.MODERATOR_VIEWER_STATE_CHANGE, change_state);
}

//Register to RVA
function send_CMD_MODERATOR_VIEWER_REQUEST() {
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.MODERATOR_VIEWER_REQUEST; // message type
  buf[2] = client_id;
  buf[3] = OS_DEV_TYPE.OS_CHROME_APP;

  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send CMD_MODERATOR_VIEWER_REQUEST Success");
    } else {
      console.log("Send CMD_MODERATOR_VIEWER_REQUEST Fail");
    }
  });
}

var request_checkKeepAlive_timeout;

function send_CMD_KEEP_ALIVE() {
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.KEEP_ALIVE; // message type
  buf[2] = 0;
  buf[3] = 0;

  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      //console.log("Send CMD_KEEP_ALIVE Success");
      isBack = false;
      request_checkKeepAlive_timeout = setTimeout(checkKeepAlive, 2000);
    } else {
      console.log("Send CMD_KEEP_ALIVE Fail");
    }
  });
}

function receive_CMD_CLIENT_STATUS_REFRESH(bValues, s_bytes) {

  send_request_timeout = false;

  var user_id = bValues[s_bytes + 2];
  var state = bValues[s_bytes + 3];
  var device = bValues[s_bytes + 4];

  var j = 0;
  var length = bValues[s_bytes];
  var strBuf = new Uint8Array(bValues[s_bytes] - 5);
  for (var i = s_bytes + 5; i < length + s_bytes; i++) {
    strBuf[j] = bValues[i];
    j++;
  }
  var userName = convert_bytes_array_into_str(strBuf);

  console.log("Receive CMD CLIENT_STATUS_REFRESH");
  console.log("User ID = " + user_id);
  console.log("STATE = " + state);
  console.log("OS_DEV_TYPE = " + device);
  console.log("User NAME = " + encodeURIComponent(userName));

  add_userdata("STATUS_REFRESH", user_id, decodeURIComponent(escape(userName)), false, null, -1, false, true, device);
  check_state_case(user_id, CMD.CLIENT_STATUS_REFRESH, state);

  return length;
}

function send_CMD_CLIENT_STATUS_REFRESH() {
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.CLIENT_STATUS_REFRESH;
  buf[2] = client_id;
  buf[3] = OS_DEV_TYPE.OS_CHROME_APP;

  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send CMD CLIENT STATUS REFRESH Success");
    } else {
      console.log("Send CMD CLIENT STATUS REFRESH Fail");
    }
  });
}

var isBack = false;
var novo_try;
var try_times = 0;
var request_try;

function checkKeepAlive() {
  if (isBack) {
    need_reconnection = false;
  } else {
    // No Receive Back
    if (try_times > 0) {
      openWaitingPageNoTimer($.t('login.reconnecting')); //TODO:i18n
      need_reconnection = true;
      printTime();
      closeCMDConnection();
      isNVCMatching = true;
      isSoftwareMatching = true;
      console.log("Close CMD and start reconnection");
      novo_try = setTimeout(checkConnectionTimeout, 20000);
      initial_reconnection();
    } else {
      console.log("Send keep alive again");
      printTime();
      try_times++;
      send_CMD_KEEP_ALIVE();
    }
  }
}

function initial_reconnection() {
  chrome.sockets.tcp.create({
    persistent: true,
    name: "CMD"
  }, function(createInfo) {
    cmd_socketId = createInfo.socketId;
    request_try = setInterval(retry_connection, 2500);
  });

}

function retry_connection() {
  if (need_reconnection) {
    chrome.sockets.tcp.connect(cmd_socketId, rvaIp, TCP_CONNECTION_PORT, function(result) {
      if (chrome.runtime.lastError) {
        console.log("Retry Reconnection");
      } else {
        if (result == 0) {
          console.log("CMD Connection Success -> Initial ReConnectionRequest");
          send_CMD_CONNECTION_REQUEST();
        } else {
          console.log("ReConnectionRequest Fail, wait for 2.5s");
        }
      }
    });
  } else {
    clearInterval(request_try);
  }
}

function cleanUserOnlineStatus() {
  for (var i = 0; i < user_list.length; i++) {
    var a = user_list[i];
    var user = new userdata(a.uid, a.label, false, a.device, -1, false, false, a.display_name, a.os_type);
    user_list[i] = user;
  }
}

var need_reconnection = false;

function checkConnectionTimeout() {
  if (need_reconnection) {
    try_times = 0;
    need_reconnection = false;
    clearInterval(request_try);
    clearTimeout(novo_try);
    closeCMDConnection();
    console.log("Connection Timeout");
    printTime();
    doLogout();
  } else {
    console.log("CheckConnectionTimeout Exit");
  }
}

function send_CMD_REMOVE_REQUEST() {
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.REMOVE_REQUEST;
  buf[2] = 0;
  buf[3] = 0;
  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send CMD REMOVE REQUEST Success");
      closeCMDConnection();
    } else {
      console.log("Send CMD REMOVE REQUEST Fail");

    }
  });
  close_all_sockets();
  // set all parameters to default
  initial_parameters();
}


function receive_CMD_SPLIT_SCREEN_READY() {
  console.log("Receive CMD SPLIT SCREEN READY");
  if (isDataConnected) {
    console.log("Data Connection is already initial");
  } else {
    isDataConnected = true;
    openDataConnection();
  }
}

function receive_CMD_FULL_SCREEN_READY() {
  console.log("Receive CMD FULL SCREEN READY");
  if (isDataConnected) {
    console.log("Data Connection is already initial");
  } else {
    isDataConnected = true;
    openDataConnection();
  }
}

//Accpet to start to be presenter
function receive_CMD_VIEWER_REQUEST(bValues, s_bytes) {
  console.log("Receive CMD VIEWER REQUEST");
  screen_number = bValues[s_bytes + 3];
  send_CMD_VIEWER_APPROVED();
}

var cmd_keep_alive_timeout;

function receive_CMD_KEEP_ALIVE() {
  //console.log("Receive CMD_KEEP ALIVE");
  clearTimeout(request_checkKeepAlive_timeout);
  if (isCMDConnected) {
    //update hotspot mode to 10s
    cmd_keep_alive_timeout = setTimeout(send_CMD_KEEP_ALIVE, 10000);
  }
}

//Chromebook do not support this
function receive_CMD_SCREEN_LOCK_UNLOCK(bValues) {
  console.log("Receive CMD SCREEN LOCK UNLOCK");
}

//Ask RVA to drop image with screen pausing
function receive_CMD_VIEWER_PAUSE() {
  console.log("Receive CMD VIEWER PAUSE");
  isPause = true;
  setTimeout(send_pause_true, 4000);
}

function send_pause_true() {
  receive_screen_pause(true);
}

function send_pause_false() {
  receive_screen_pause(false);
}

//Ask RVA to resume image when screen pausing
function receive_CMD_VIEWER_RESUME() {
  console.log("Receive CMD VIEWER RESUME");
  isPause = false;
  setTimeout(send_pause_false, 4000);
}

function send_CMD_VIEWER_APPROVED() {
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.VIEWER_APPROVED;
  buf[2] = client_id;
  buf[3] = screen_number;
  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send CMD VIEWER APPROVED Success");
    } else {
      console.log("Send CMD VIEWER APPROVED Fail");
    }
  });
}

var send_request_timeout = true;

function checkRequest() {
  if (send_request_timeout) {
    refreshUserList(user_list);
  }
}


function send_CMD_VIEWER_REQUEST(userId, screen_location) {
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.VIEWER_REQUEST;
  buf[2] = userId;
  buf[3] = screen_location;

  var range = 4000;
  if (supportFastSwitchScreen) {
    //reduce send timeout request
    var current_RVA_status = getUserListStatus();
    var request_device = getUserData(parseInt(userId));
    if (current_RVA_status === RVA_PLAY_STATUS.FULL_VIDEO) {
      console.log("VIDEO -> any = 8 seconds");
      range = 6000;
      if (isSoftwareDecoder) {
        range = 8500;
      }
    } else if (current_RVA_status === RVA_PLAY_STATUS.FULL_IMAGE) {
      if (request_device.os_type < 5 && parseInt(screen_location) === 0) {
        console.log("FULL IMAGE -> VIDEO = 8 seconds");
        range = 6000;
        if (isSoftwareDecoder) {
          range = 8500;
        }
      } else if (parseInt(screen_location) > -1) {
        console.log("FULL IMAGE -> FULL IMAGE / SPLIT IMAGE = 5 seconds");
        range = 3000;
        if (isSoftwareDecoder) {
          range = 6000;
        }
      }
    } else if (current_RVA_status === RVA_PLAY_STATUS.SPLIT_IMAGE) {
      if (request_device.os_type < 5 && parseInt(screen_location) === 0) {
        console.log("SPLIT IMAGE -> VIDEO = 8 seconds");
        range = 6000;
        if (isSoftwareDecoder) {
          range = 8500;
        }
      } else if (request_device.os_type > 4 && parseInt(screen_location) === 0) {
        console.log("SPLIT IMAGE -> FULL IMAGE = 5 seconds");
        range = 3000;
        if (isSoftwareDecoder) {
          range = 6000;
        }
      } else if (parseInt(screen_location) > 0) {
        console.log("SPLIT IMAGE -> SPLIT IMAGE = 5 seconds");
        range = 2000;
        if (isSoftwareDecoder) {
          range = 6000;
        }
      }
    } else if (current_RVA_status === RVA_PLAY_STATUS.PENDING_ALL) {
      if (request_device.os_type < 5 && parseInt(screen_location) === 0) {
        console.log("HOME PENDING -> VIDEO = 8 seconds");
        range = 6000;
        if (isSoftwareDecoder) {
          range = 8500;
        }
      } else if (parseInt(screen_location) > -1) {
        console.log("HOME PENDING -> FULL IMAGE / SPLIT IMAGE = 8 seconds");
        range = 4000;
        if (isSoftwareDecoder) {
          range = 8500;
        }
      }
    }
  }
  var range_timeout = range + 3000;
  console.log("Range timeout = " + range_timeout);

  thisRequestTime = new Date().getTime();
  if (-(lastRequestTime - thisRequestTime) > range) {
    chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
      if (sendInfo.resultCode == 0) {
        lastRequestTime = new Date().getTime();
        send_request_timeout = true;
        setTimeout(checkRequest, range_timeout);
        console.log("Send CMD VIEWER REQUEST UserId = " + userId + " SCREEN LOCATION = " + screen_location + " Success");
      } else {
        console.log("Send CMD VIEWER REQUEST UserId = " + userId + " Fail");
      }
    });
  } else {
    var nextTime = range - thisRequestTime + lastRequestTime + 1000;
    setTimeout(function() {
      chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
        if (sendInfo.resultCode == 0) {
          lastRequestTime = new Date().getTime();
          send_request_timeout = true;
          setTimeout(checkRequest, range_timeout);
          console.log("Send CMD VIEWER REQUEST UserId = " + userId + " SCREEN LOCATION = " + screen_location + " Success");
        } else {
          console.log("Send CMD VIEWER REQUEST UserId = " + userId + " Fail");
        }
      });
    }, nextTime);
  }
}

//RVA RESET
function receive_CMD_RESET_RVA() {
  console.log("Received CMD RESET RVA");
  closeCMDConnection();
  doLogout();
}

function receive_CMD_RESET_DEVICE() {
  console.log("Received CMD RESET DEVICE");
  closeCMDConnection();
  doLogout();
}

function send_CMD_MODERATOR_REQUEST(userid) {
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.MODERATOR_REQUEST;
  buf[2] = userid;
  buf[3] = 0;
  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send CMD MODERATOR REQUEST Userid = " + userid + " Success");
    } else {
      console.log("Send CMD MODERATOR REQUEST Userid = " + userid + " Fail");
    }
  });
}


function receive_CMD_MODERATOR_DENIED() {
  console.log("Receive CMD MODERATOR DENIED");
  moderatorRequestDenied($.t('login.requestDeclined')); //TODO:i18n
}

function receive_CMD_MODERATOR_APPROVED() {
  console.log("Receive CMD MODERATOR APPROVED");
  moderatorRequestApproved($.t('login.requestAccepted')); //TODO:i18n
}

function receive_CMD_MODERATOR_REQUEST() {
  console.log("Receive CMD MODERATOR REQUEST");
  //Popup
  chrome.app.window.current().focus();

  receive_moderator_request($.t('login.wannaBeHost')); //TODO:i18n
}

function send_CMD_MODERATOR_DENIED() {
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.MODERATOR_DENIED;
  buf[2] = client_id;
  buf[3] = 0;
  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send CMD MODERATOR DENIED Success");
      getAnnotationButtonState();
    } else {
      console.log("Send CMD MODERATOR DENIED Fail");
    }
  });
}

function send_CMD_MODERATOR_APPROVED() {
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.MODERATOR_APPROVED;
  buf[2] = client_id;
  buf[3] = 0;
  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send CMD MODERATOR APPROVED Success");
    } else {
      console.log("Send CMD MODERATOR APPROVED Fail");
    }
  });
}

function receive_CMD_PIN_REQUIRED() {
  console.log("Received CMD PIN REQUIRED");
  isPIN = true;

  qr_pin_status = true;
  qrObject.pinStatus = true;

  if (isCMDConnected) {
    console.log("Redisplay pin required");
    //Send Molly new Connection Object
    conObject.pin_need = qr_pin_status;
    conObject.qrObj = qrObject;
    connected_initial(conObject);
  }
}

function receive_CMD_RECONNECTION_ALLOWED() {
  console.log("Received CMD RECONNECTION ALLOWED");
  if (isNVCMatching) {
    if (isCorp) {
      doLogout();
      send_CMD_REMOVE_REQUEST();
      messagePage($.t("login.setToEducationVersion")); //TODO: i18n
    } else {
      printTime();
      need_reconnection = false;
      clearTimeout(novo_try);
      clearInterval(request_try);
      try_times = 0;

      doLogin(true);
      isCMDConnected = true;
      if (isGroupMode) {
        cleanUserOnlineStatus();
      } else {
        user_list = [];
      }
      send_CMD_CLIENT_STATUS_REFRESH();
      send_CMD_KEEP_ALIVE();
      if (supportSessionLock && isSessionLock) {
        send_CMD_SESSION_CLIENT_STATUS_REFRESH();
      }
      // var win = chrome.app.window.get("annotationWindow")
      // var annotation = (win && win.contentWindow) || null;
      // // console.log(annotation);
      // annotation && annotation.removeReconnectingDialogs();
    }
  } else {
    clearTimeout(connection_timeout);
    doLogout();
    send_CMD_REMOVE_REQUEST();
    // UI Action
    messagePage($.t("login.incompatible")); //TODO: i18n
  }
}

function receive_CMD_MODERATOR_BROADCAST_REQUEST() {
  console.log("Received CMD MODERATOR BROADCASE REQUEST");
  //UI Action popup action ask moderator
  if (chrome.app.window.current().isMinimized()) {
    chrome.app.window.current().focus();
  }
  // Handler when Voting starting
  votingHandler("closeVotingWindow");

  receive_moderator_broadcast_request($.t('login.wannaBeHost')); //TODO: i18n
}

function send_CMD_MODERATOR_BROADCAST_APPROVED() {
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.MODERATOR_BROADCAST_APPROVED;
  buf[2] = client_id;
  buf[3] = 0;
  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send CMD MODERATOR BROADCAST APPROVED Success");
    } else {
      console.log("Send CMD MODERATOR BROADCAST APPROVED Fail");
    }
  });
}

function receive_CMD_SCREENSHOT_REQUEST() {
  console.log("Received CMD SCREENSHOT REQUEST");
  // TODO: create DataConnection to received screenshot byte
  if (isScreenConnected) {
    console.log("Screen send already");
  } else {
    send_CMD_SCREENSHOT_RESPONSE();
    openScreenConnection(true);
  }
}

function receive_CMD_SCREENSHOT_RESPONSE() {
  console.log("Received CMD SCREENSHOT RESPONSE");
  if (isScreenConnected) {
    console.log("Screen Data Connection is already set");
  } else {
    openScreenConnection(false);
  }
}

function send_CMD_SCREENSHOT_RESPONSE() {
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.SCREENSHOT_RESPONSE;
  buf[2] = client_id;
  buf[3] = OS_DEV_TYPE.OS_CHROME_APP;
  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send CMD SCREENSHOT RESPONSE Success");
    } else {
      console.log("Send CMD SCREENSHOT RESPONSE Fail");
    }
  });
}

function request_PREVIEW_DATA(userid) {
  initial_DATA_EXCHANGE(CMD.PREVIEW_DATA, userid, null);
  //send_CMD_SCREENSHOT_REQUEST(userid);
}

function send_PREVIEW_DATA_Message(userid, arg1, arg2) {

  var data_length = 0;
  if (arg2 == null) {
    //Host request image
    data_length = 8;
  } else {
    // data_length
    data_length = 8 + arg2.length;
  }
  var buf = new Uint8Array(data_length);

  var data_size = convert_int_into_bytes_big_endian(data_length);
  buf[0] = data_size[0];
  buf[1] = data_size[1];
  buf[2] = data_size[2];
  buf[3] = data_size[3];

  buf[4] = CMD.PREVIEW_DATA;
  buf[5] = client_id;
  buf[6] = arg1;
  buf[7] = 0;

  if (data_length > 8) {
    for (var i = 0; i < arg2.length; i++) {
      buf[i + 8] = arg2[i];
    }
    chrome.sockets.tcp.send(exchange_data_socketId, buf.buffer.slice(0, data_length), function(sendInfo) {
      if (sendInfo.resultCode == 0) {
        console.log("Send PREVIEW DATA to DATA with ScreenShot Success ");
      } else {
        console.log("Send PREVIEW DATA to DATA with ScreenShot Fail");
      }
    });
  } else {
    chrome.sockets.tcp.send(exchange_data_socketId, buf.buffer.slice(0, data_length), function(sendInfo) {
      if (sendInfo.resultCode == 0) {
        console.log("Send PREVIEW DATA to DATA Success ");
        if (arg2 == null) {
          send_CMD_PREVIEW_REQUEST(userid);
        }
      } else {
        console.log("Send PREVIEW DATA to DATA Fail");
      }
    });
  }
}

function send_CMD_PREVIEW_REQUEST(userid) {
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.PREVIEW_DATA;
  buf[2] = userid;
  buf[3] = OS_DEV_TYPE.OS_CHROME_APP;

  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send PREVIEW DATA to CMD Success");
    } else {
      console.log("Send PREVIEW DATA to CMD Fail");
    }
  });
}

function receive_CMD_PREVIEW_DATA(bValues, s_bytes) {
  console.log("Receive CMD PREVIEW DATA REQUEST");
  initial_DATA_EXCHANGE(null, null, CMD.PREVIEW_DATA);
}

//function send_CMD_SCREENSHOT
function send_CMD_SCREENSHOT_REQUEST(userid) {
  screenshot_userid = userid;

  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.SCREENSHOT_REQUEST;
  buf[2] = userid;
  buf[3] = OS_DEV_TYPE.OS_CHROME_APP;
  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send CMD SCREENSHOT REQUEST ClientId = " + userid + " Success");
    } else {
      console.log("Send CMD SCREENSHOT REQUEST ClientId = " + userid + " Fail");
    }
  });
}



function connection_remove() {
  send_CMD_REMOVE_REQUEST();
}
//================================== new functions ===========================

function check_state_case(userid, cmd, arg) {

  if (isUserOnList(userid)) {

  } else {
    return;
  }
  switch (arg) {
    case STATE.VIEWER_PENDING:
      receive_STATE_VIEWER_PENDING(userid, cmd);
      break;
    case STATE.VIEWER_HOLDER:
      receive_STATE_VIEWER_HOLDER(userid, cmd);
      break;
    case STATE.MODERATOR_HOLDER:
      receive_STATE_MODERATOR_HOLDER(userid, cmd);
      break;
    case STATE.MODERATOR_RELEASE:
      receive_STATE_MODERATOR_RELEASE(userid, cmd);
      break;
    case STATE.MODERATOR_HOLDER_VIEWER_HOLDER:
      receive_STATE_MODERATOR_HOLDER_VIEWER_HOLDER(userid, cmd);
      break;
    case STATE.READY_FOR_DISPLAY_SCREENSHOT:
      receive_READY_FOR_DISPLAY_SCREENSHOT(userid, cmd);
      break;
    case STATE.VIEWER_HOLDER_1:
      receive_VIEWER_HOLDER(userid, cmd, 1);
      break;
    case STATE.VIEWER_HOLDER_2:
      receive_VIEWER_HOLDER(userid, cmd, 2);
      break;
    case STATE.VIEWER_HOLDER_3:
      receive_VIEWER_HOLDER(userid, cmd, 3);
      break;
    case STATE.VIEWER_HOLDER_4:
      receive_VIEWER_HOLDER(userid, cmd, 4);
      break;
    case STATE.MODERATOR_VIEWER_HOLDER_1:
      receive_MODERATOR_VIEWER_HOLDER(userid, cmd, 1);
      break;
    case STATE.MODERATOR_VIEWER_HOLDER_2:
      receive_MODERATOR_VIEWER_HOLDER(userid, cmd, 2);
      break;
    case STATE.MODERATOR_VIEWER_HOLDER_3:
      receive_MODERATOR_VIEWER_HOLDER(userid, cmd, 3);
      break;
    case STATE.MODERATOR_VIEWER_HOLDER_4:
      receive_MODERATOR_VIEWER_HOLDER(userid, cmd, 4);
      break;
    default:
      console.log("Check status error");
  }

  if (isHostOnline()) {
    stopWaitingPageWithTimer();
  } else {
    console.log("No Closed");
  }

  //Update when userlist refresh
  if (supportSessionLock) {
    updateSessionLock();
  }
  if (supportAnnotation) {
    getAnnotationButtonState();
  }
}

function receive_STATE_VIEWER_PENDING(userid, cmd) {
  console.log("Userid = " + userid + " is state_viewer_pending");
  if (userid == client_id) {
    ask_to_be_host(false);
    receive_screen_pause(false);
    if (isDataConnected) {
      closeDataConnection();
    }
  }
  // UI Action
  update_userdata(userid, false, -1);
  refreshUserList(user_list);
}

function receive_STATE_VIEWER_HOLDER(userid, cmd) {
  console.log("Userid = " + userid + " is state_viewer_holder");
  if (userid == client_id) {
    ask_to_be_host(false);
    receive_screen_pause(false)
    if (!isDataConnected) {
      openDataConnection();
    }
    notificationScreenLocation(0);
  }
  update_userdata(userid, false, 0);
  set_up_view_mode("full"); // full/split
  isSplitMode = false;
  refreshUserList(user_list);
}

function receive_STATE_MODERATOR_HOLDER(userid, cmd) {
  console.log("Userid = " + userid + " is moderator_holder");
  if (userid == client_id && cmd != CMD.MODERATOR_VIEWER_REQUEST) {
    ask_to_be_host(true);
    if (isDataConnected) {
      closeDataConnection();
    }
    receive_screen_pause(false)
  }
  update_userdata(userid, true, -1);
  //set_up_view_mode("full");
  refreshUserList(user_list);
}

function receive_STATE_MODERATOR_RELEASE(userid, cmd) {
  console.log("Userid = " + userid + " is moderator_release");
}

function receive_STATE_MODERATOR_HOLDER_VIEWER_HOLDER(userid, cmd) {
  console.log("Userid = " + userid + " is moderator_holder_viewer_holder");
  if (userid == client_id) {
    ask_to_be_host(true);
    if (cmd != CMD.MODERATOR_VIEWER_REQUEST) {
      if (!isDataConnected) {
        isDataConnected = true;
        openDataConnection();
      }
      notificationScreenLocation(0);
    }
    if (isDataConnected) {
      receive_screen_pause(isPause);
    }
  }
  update_userdata(userid, true, 0);
  set_up_view_mode("full");
  isSplitMode = false;
  refreshUserList(user_list);
}

function receive_READY_FOR_DISPLAY_SCREENSHOT(userid, cmd) {
  console.log("Userid = " + userid + " is ready for display screenshot");
}

function receive_VIEWER_HOLDER(userid, cmd, location) {
  console.log("Userid = " + userid + " is viewer_holder in location = " + location);
  if (userid == client_id) {
    ask_to_be_host(false);
    if (cmd != CMD.MODERATOR_VIEWER_REQUEST) {
      if (!isDataConnected) {
        isDataConnected = true;
        openDataConnection();
      }
      notificationScreenLocation(location);
    }
    receive_screen_pause(false)
  }
  update_userdata(userid, false, location);
  set_up_view_mode("split");
  isSplitMode = true;
  refreshUserList(user_list);
}

function receive_MODERATOR_VIEWER_HOLDER(userid, cmd, location) {
  console.log("Userid = " + userid + " is moderator_viewer_holder in location = " + location);
  if (userid == client_id) {
    ask_to_be_host(true);
    if (cmd != CMD.MODERATOR_VIEWER_REQUEST) {
      if (!isDataConnected) {
        isDataConnected = true;
        openDataConnection();
      }
      notificationScreenLocation(location);
    }
    receive_screen_pause(false)
  }
  update_userdata(userid, true, location);
  set_up_view_mode("split");
  isSplitMode = true;
  refreshUserList(user_list);
}

/*

  refreshUserList([
    { uid: "uid1", label: "User_xxxx_1djs;fj;dksfj;sdf helenhelenhelenhelenhelen", isHost: true,  device: "Android Tablet", online: true, panel: 0, isMyself: false },
    { uid: "uid2", label: "User_name_2", isHost: false, device: "Win PC", online: true, panel: 2, isMyself: true },
    { uid: "uid3", label: "User_name_3", isHost: false, device: "Android Tablet", online: false, panel: -1, isMyself: false },
    { uid: "uid4", label: "User_name_4 Steve Steve Steve", isHost: false, device: "Win PC", online: true, panel: 3, isMyself: false },
    { uid: "uid5", label: "User_name_5dsfjsdlafjdfjjijeh", isHost: false, device: "Win PC", online: true, panel: 1, isMyself: false },
    { uid: "uid6", label: "User_name_6", isHost: false, device: "Android Tablet", online: false, panel: -1, isMyself: false },
    { uid: "uid7", label: "User_name_7", isHost: false, device: "Android Tablet", online: false, panel: -1, isMyself: false },
    { uid: "uid8", label: "User_name_8", isHost: false, device: "Android Tablet", online: false, panel: -1, isMyself: false },
    { uid: "uid9", label: "User_name_9", isHost: false, device: "Android Tablet", online: false, panel: -1, isMyself: false },
  ]);
*/

var user_list = [];

//User data object, send to Molly
function userdata(uid, label, isHost, device, panel, isMyself, online, display_name, os_type) {
  this.uid = uid;
  this.label = label;
  this.isHost = isHost;
  if (device == null) {
    this.device = getOSDeviceNameByType(os_type);
  } else {
    this.device = device;
  }
  this.panel = panel;
  this.isMyself = isMyself;
  this.online = online;
  this.display_name = display_name;
  this.os_type = os_type;
}

function add_userdata(cmd, uid, label, isHost, device, panel, isMyself, online, os_type) {
  if (isGroupMode) {
    if (os_type == OS_DEV_TYPE.OS_HDMI_IN) {
      var user = new userdata(uid, label, isHost, device, panel, isMyself, true, label, os_type);
      user_list.push(user);
    } else {
      update_group_data(uid, label, isHost, device, panel, isMyself, online, os_type);
    }

  } else {
    if (isNewUser(uid)) {
      var isOnline = true;
      if (isSessionLock) {
        if (cmd == "STATUS_REFRESH") {
          update_session_lock_userdata("REFRESH", uid, label, isHost, device, panel, isMyself, true, os_type);
        } else {
          update_session_lock_userdata("Update", uid, label, isHost, device, panel, isMyself, true, os_type);
        }
      } else {
        var user = new userdata(uid, label, isHost, device, panel, isMyself, isOnline, label, os_type);
        user_list.push(user);
      }
    } else {
      console.log("Client Id= " + uid + " Name = " + label + " is already in userlist");
    }
  }
}

function update_group_data(uid, label, isHost, device, panel, isMyself, online, os_type) {
  for (var i = 0; i < user_list.length; i++) {
    var update_user = user_list[i];
    if (update_user.display_name.toUpperCase().replace(/\s/g, "") == label.toUpperCase().replace(/\s/g, "")) {
      var isMyself = false;
      //Add Function to create UserList
      if (update_user.uid == client_id) {
        isMyself = true;
      }
      var user;
      if (update_user.os_type != os_type) {
        update_user.os_type = os_type;
      }
      for (var k = 1; k < group_list.length; k = k + 2) {
        if (update_user.display_name.toUpperCase().replace(/\s/g, "") == group_list[k].toUpperCase().replace(/\s/g, "")) {
          if (group_list[k - 1] != group_list[k]) {
            //Device = OS Type + (User's + Device name)
            var d_name = getOSDeviceNameByType(update_user.os_type) + " (" + group_list[k - 1] + "'s " + group_list[k] + ")";
            user = new userdata(uid, update_user.label, isHost, d_name, panel, isMyself, online, update_user.display_name, update_user.os_type);
          } else {
            user = new userdata(uid, update_user.label, isHost, null, panel, isMyself, online, update_user.display_name, update_user.os_type);
          }
          break;
        }
      }
      if (!user) {
        console.log(update_user.display_name);
        user = new userdata(uid, update_user.label, isHost, null, panel, isMyself, online, update_user.display_name, update_user.os_type);
      }
      user_list[i] = user;
      break;
    }
  }
}

function update_userdata(uid, is_host, panel, online) {
  for (var i = 0; i < user_list.length; i++) {
    var update_user = user_list[i];
    if (update_user.uid == uid) {
      var isMyself = false;
      //Add Function to create UserList
      if (update_user.uid == client_id) {
        isMyself = true;
      }
      var user;
      if (isGroupMode) {
        for (var k = 1; k < group_list.length; k = k + 2) {
          if (update_user.display_name.toUpperCase().replace(/\s/g, "") == group_list[k].toUpperCase().replace(/\s/g, "")) {
            if (group_list[k - 1] != group_list[k]) {
              //Device = OS Type + (User's + Device name)
              var d_name = getOSDeviceNameByType(update_user.os_type) + " (" + group_list[k - 1] + "'s " + group_list[k] + ")";
              user = new userdata(uid, update_user.label, is_host, d_name, panel, isMyself, update_user.online, update_user.display_name, update_user.os_type);
            } else {
              user = new userdata(uid, update_user.label, is_host, getOSDeviceNameByType(update_user.os_type), panel, isMyself, update_user.online, update_user.display_name, update_user.os_type);
            }
            break;
          }
        }
        if (!user) {
          user = new userdata(uid, update_user.label, is_host, getOSDeviceNameByType(update_user.os_type), panel, isMyself, true, update_user.display_name, update_user.os_type);
        }
      } else {
        user = new userdata(uid, update_user.label, is_host, update_user.device, panel, isMyself, update_user.online, update_user.display_name, update_user.os_type);
      }

      user_list[i] = user;
      break;
    }
  }
}

function remove_userdata(uid, mode) {
  for (var i = 0; i < user_list.length; i++) {
    var remove_user = user_list[i];
    if (remove_user.uid == uid) {
      if (isGroupMode) {
        console.log(remove_user);
        if (remove_user.os_type == OS_DEV_TYPE.OS_HDMI_IN) {
          var r = user_list.indexOf(remove_user);
          if (r != -1) {
            user_list.splice(r, 1);
            break;
          }
        } else {
          var user = new userdata("None", remove_user.label, false, getOSDeviceNameByType(remove_user.os_type), -1, false, false, remove_user.display_name, remove_user.os_type);
          user_list[i] = user;
          break;
        }

      } else {
        if (isSessionLock) {

          if (mode == "CLIENT_REMOVE" || remove_user.os_type == OS_DEV_TYPE.OS_HDMI_IN) {
            var r = user_list.indexOf(remove_user);
            if (r != -1) {
              user_list.splice(r, 1);
              break;
            }
          } else {
            var user = new userdata("None", remove_user.label, false, getOSDeviceNameByType(remove_user.os_type), -1, false, false, remove_user.display_name, remove_user.os_type);
            user_list[i] = user;
          }
        } else {
          var r = user_list.indexOf(remove_user);
          if (r != -1) {
            user_list.splice(r, 1);
            break;
          }
        }
      }

    }
  }
}

function isNewUser(uid) {
  for (var i = 0; i < user_list.length; i++) {
    var userdata = user_list[i];
    console.log(userdata);
    if (typeof userdata.uid == "undefined" || userdata.uid == uid) {
      return false;
    }
  }

  return true;
}

function open_qrimage() {

  chrome.app.window.create('../views/qrimage.html', {
    id: "qr",
    bounds: {
      width: 540,
      height: 615
    },
    frame: 'none',
    resizable: false
  }, function(createdWindow) {
    //		  createdWindow.contentWindow.runAA = function() { };
  });
}

function send_screenshot_image() {

  var image_bytes = getImageCaptureBytesForScreenShot();
  var length = image_bytes.length;
  var buf = new Uint8Array(length + 4);

  var sizeArray = convert_int_into_bytes_big_endian(length);
  buf[0] = sizeArray[0];
  buf[1] = sizeArray[1];
  buf[2] = sizeArray[2];
  buf[3] = sizeArray[3];
  for (var i = 0; i < length; i++) {
    buf[i + 4] = image_bytes[i];
  }
  chrome.sockets.tcp.send(screenshot_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send SCREENSHOT IMAGE Success");
      closeScreenConnection();
    } else {
      console.log("Send SCREENSHOT IMAGE Fail");
    }
  });
}

var screenshot_times = 1;
var array_size = 0;
var scount = 0;
var screenBuf;

function receive_screenshot_image(receive_buffer) {
  if (screenshot_times == 1) {
    array_size = convert_bytes_big_endian_into_int(receive_buffer[0], receive_buffer[1], receive_buffer[2], receive_buffer[3]);
    screenBuf = new Uint8Array(array_size);
  }
  var length = receive_buffer.length;

  if (screenshot_times == 1) {
    for (var i = 4; i < length; i++) {
      screenBuf[scount] = receive_buffer[i];
      scount++;
    }
    screenshot_times = screenshot_times + 1;
  } else {
    for (var i = 0; i < length; i++) {
      screenBuf[scount] = receive_buffer[i];
      scount++;
    }
  }
  if (scount == array_size) {
    screenshot_times = 1;
    scount = 0;
    screenshot_value = covert_array_into_Base64(screenBuf);
    sendingImage(screenshot_userid, screenshot_value);
    closeScreenConnection();
  }
}

function send_screen_lock() {
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.CM_VIEWER_PAUSE;
  buf[2] = 0;
  buf[3] = 0;
  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send CMD VIEWER PAUSE Success");
    } else {
      console.log("Send CMD VIEWER PAUSE Fail");
    }
  });
}

function send_screen_unlock() {
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.CM_VIEWER_RESUME;
  buf[2] = 0;
  buf[3] = 0;
  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send CMD VIEWER RESUME Success");
    } else {
      console.log("Send CMD VIEWER RESUME Fail");
    }
  });
}

function receive_CMD_REMOVE_REQUEST(bValues) {
  console.log("Receive CMD REMOVE REQUEST");
  var removeId = bValues[2];
  if (removeId == annotator_uid) {
    console.log("Annotator Removed");
    annotator_uid = 0
    isAnnotator = false;
  }
  remove_userdata(removeId, "REMOVE_REQUEST");
  refreshUserList(user_list);
}

function send_CMD_PIN_REQUIRED() {
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.PIN_REQUIRED;
  buf[2] = client_id;
  buf[3] = 0;
  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send CMD PIN REQUIRED Success");
    } else {
      console.log("Send CMD PIN REQUIRED Fail");
    }
  });
}

function send_CMD_PIN_NOT_REQUIRED() {
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.PIN_NOT_REQUIRED;
  buf[2] = client_id;
  buf[3] = 0;
  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send CMD PIN NOT REQUIRED Success");
    } else {
      console.log("Send CMD PIN NOT REQUIRED Fail");
    }
  });
}

function windows_minimize() {
  chrome.app.window.current().minimize();
}

//Close DesktopStreamer App
function app_close() {
  closeUDP();
  if (isCMDConnected) {
    send_CMD_REMOVE_REQUEST();
  }
  chrome.sockets.tcp.close(offset_socketId);
  // save connect as Moderator
  chrome.storage.local.set({
    'moderator_status': isConnectAsModeratorChecked
  });
  chrome.app.window.current().close();
}

function resizeApp() {
  var bound = chrome.app.window.current().getBounds();
  if (imageSelected == 1) {
    bound.width = parseInt($("#container").width()) + 260;
    bound.height = parseInt($("#container").height()) + 220;
    chrome.app.window.current().setBounds(bound);
  } else if (bound.width != $("#container").width() || bound.height != $("#container").height()) {
    bound.width = parseInt($("#container").width()) + 4;
    bound.height = parseInt($("#container").height()) + 4;
    chrome.app.window.current().setBounds(bound);
  } else {

  }
}

var resizeId = setInterval(resizeApp, 100);

chrome.app.window.current().onMinimized.addListener(function() {
  clearInterval(resizeId);
});

chrome.app.window.current().onRestored.addListener(function() {
  resizeId = setInterval(resizeApp, 100);
});

//Handler Socket error
chrome.sockets.tcp.onReceiveError.addListener(function(info) {
  console.log("Receive SOCKET ERROR !! Socket = " + info.socketId + " ResultCode = " + info.resultCode);
  if (info.socketId == cmd_socketId) {
    console.log("DSA_CMD <- X -> RVA_CMD");
    if (need_reconnection) {

    } else {
      doLogout();
    }
  } else if (info.socketId == data_socketId) {
    console.log("DSA_DATA <- x -> RVA_DATA");
  } else if (info.socketId == stream_ch1) {
    console.log("DSA_1_Proxy <- X -> RVA_Proxy");
    if (isImageSendingPause) {
      streaming_channel = 2;
      chrome.sockets.tcp.disconnect(stream_ch1);
      chrome.sockets.tcp.disconnect(tcp_ch1);
      chrome.sockets.tcp.disconnect(tcp_ch1 + 1);
      connection_one();
    }
  } else if (info.socketId == stream_ch2) {
    console.log("DSA_2_Proxy <- X -> RVA_Proxy");
    if (isImageSendingPause) {
      if (support7SocketChannel) {
        streaming_channel = 3;
      } else {
        streaming_channel = 1;
      }
      chrome.sockets.tcp.disconnect(stream_ch2);
      chrome.sockets.tcp.disconnect(tcp_ch2);
      chrome.sockets.tcp.disconnect(tcp_ch2 + 1);
      connection_two();
    }
  } else if (info.socketId == stream_ch3) {
    console.log("DSA_3_Proxy <- X -> RVA_Proxy");
    if (isImageSendingPause) {
      streaming_channel = 4;
      chrome.sockets.tcp.disconnect(stream_ch3);
      chrome.sockets.tcp.disconnect(tcp_ch3);
      chrome.sockets.tcp.disconnect(tcp_ch3 + 1);
      connection_three();
    }
  } else if (info.socketId == stream_ch4) {
    console.log("DSA_4_Proxy <- X -> RVA_Proxy");
    if (isImageSendingPause) {
      streaming_channel = 5;
      chrome.sockets.tcp.disconnect(stream_ch4);
      chrome.sockets.tcp.disconnect(tcp_ch4);
      chrome.sockets.tcp.disconnect(tcp_ch4 + 1);
      connection_four();
    }
  } else if (info.socketId == stream_ch5) {
    console.log("DSA_5_Proxy <- X -> RVA_Proxy");
    if (isImageSendingPause) {
      streaming_channel = 6;
      chrome.sockets.tcp.disconnect(stream_ch5);
      chrome.sockets.tcp.disconnect(tcp_ch5);
      chrome.sockets.tcp.disconnect(tcp_ch5 + 1);
      connection_five();
    }
  } else if (info.socketId == stream_ch6) {
    console.log("DSA_6_Proxy <- X -> RVA_Proxy");
    if (isImageSendingPause) {
      streaming_channel = 7;
      chrome.sockets.tcp.disconnect(stream_ch6);
      chrome.sockets.tcp.disconnect(tcp_ch6);
      chrome.sockets.tcp.disconnect(tcp_ch6 + 1);
      connection_six();
    }
  } else if (info.socketId == stream_ch7) {
    console.log("DSA_2_Proxy <- X -> RVA_Proxy");
    if (isImageSendingPause) {
      streaming_channel = 1;
      chrome.sockets.tcp.disconnect(stream_ch7);
      chrome.sockets.tcp.disconnect(tcp_ch7);
      chrome.sockets.tcp.disconnect(tcp_ch7 + 1);
      connection_seven();
    }
  } else {
    console.log("DSA <- x -> HTTP SERVER");
  }
});

var ip_list;

function ipdata(value, label, broadcast, username, times) {
  this.value = value;
  this.label = label;
  this.broadcast = broadcast;
  this.username = username;
  this.times = times;
}

function add_ipdata(value, label, broadcast, username, times, needCheck) {
  if (needCheck) {
    if (isNewIpdata(value)) {
      var newIpdata = new ipdata(value, label, broadcast, username, new Date().getTime());
      ip_list.unshift(newIpdata);
    } else {
      update_ipdata(value, label, broadcast, username, new Date().getTime());
    }
  } else {
    var newIpdata = new ipdata(value, label, broadcast, username, times);
    ip_list.unshift(newIpdata);
  }
}

function isNewIpdata(rva_value) {
  for (var i = 0; i < ip_list.length; i++) {
    var ip_data = ip_list[i];
    if (ip_data.value == rva_value) {
      return false;
    }
  }

  return true;
}

function update_ipdata(value, label, broadcast, username, times) {
  for (var i = 0; i < ip_list.length; i++) {
    var ip_data = ip_list[i];
    if (ip_data.value == value) {
      var r = ip_list.indexOf(ip_data);
      if (r != -1) {
        ip_list.splice(r, 1);
        break;
      }
    }
  }

  var newIpdata = new ipdata(value, label, broadcast, username, times);
  ip_list.unshift(newIpdata);
}

//No use =.=
function isOverIPList() {
  console.log("IPLIST SIZE = " + ip_list.length);
  // 	if (ip_list.length > 8) {
  // 		return true;
  // 	} else {
  return false;
  // 	}
}

function printTime() {
  var thisTime = new Date();
  console.log("Day = " + thisTime.getDate() + " Hour = " + thisTime.getHours() + " Minute = " + thisTime.getMinutes() + " Second =" + thisTime.getSeconds());
}

//Do not support in Gen1
function send_Google_Drive(url) {
  if (url.length == 0) {
    // todo: message no url
  } else {
    isImageSendingPause = true;

    var length = 0;
    var buf = new Uint8Array(999);

    for (var i = 0; i < 999; i++) {
      buf[i] = 0;
    }

    var overSend = false;

    length = url.length;
    if (length > 0) {
      var data = convert_str_into_bytes(url);
      length = data.length;

      if (length + MINUM_MSG_LENGTH >= 127) {
        var data_length = length;
        var extention_length = convert_int_into_bytes_big_endian(data_length);
        if (extention_length != null && extention_length.length == 4) {
          for (var j = 0; j < 4; j++) {
            buf[j + 4] = extention_length[j];
          }
          for (var q = 0; q < length; q++) {
            buf[8 + q] = data[q];
          }
          overSend = true;
        }
      } else {
        buf[0] = length + MINUM_MSG_LENGTH;
        for (var i = 0; i < length; i++) {
          buf[4 + i] = data[i];
        }
        overSend = false;
      }
    }

    buf[1] = CMD.PLAY_VIDEO;
    buf[2] = client_id;
    buf[3] = 0;

    if (overSend) {
      chrome.sockets.tcp.send(cmd_socketId, buf.buffer.slice(0, length + 8), function(sendInfo) {
        if (sendInfo.resultCode == 0) {
          console.log("Send Google drive Success");
        } else {
          console.log("Send Google drive Fail");
        }
      });
    } else {
      chrome.sockets.tcp.send(cmd_socketId, buf.buffer.slice(0, length + 4), function(sendInfo) {
        if (sendInfo.resultCode == 0) {
          console.log("Send Google drive Success");
        } else {
          console.log("Send Google drive Fail");
        }
      });
    }
  }
}

//Video panel action, accroding to Video_panel.js
function controlStreaming(type, arg) {

  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  //Play Local Streaming or Youtube
  if (type == "local" || type == "web") {
    buf[1] = CMD.PLAY_VIDEO;
  } else {
    buf[1] = CMD.PLAY_YOUTUBE;
  }
  buf[2] = client_id;
  buf[3] = arg;
  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      if (chrome.app.window.get("videoWindow") == null) {
        return
      }
      var videoWindow = chrome.app.window.get("videoWindow").contentWindow;
      if (type == "local" && arg == PLAY_CMD.EXIT) {
        close_all_streaming_sockets();
        console.log("USER Send Local Streaming STOP");
        //continue sending image
        isImageSendingPause = false;
        openDataConnection();
        //Send to Molly to show result
        videoWindow.sendVideoResult(0);
      } else if (type == "youtube" && arg == PLAY_CMD.EXIT) {
        console.log("USER Send Youtube Streaming STOP");
        youtube_title = "";
        isImageSendingPause = false;
        openDataConnection();
        //Send to Molly to show result
        videoWindow.sendVideoResult(0);
      } else if (arg === PLAY_CMD.PAUSE) {
        skip_streaming_update = true;
      } else if (arg === PLAY_CMD.RESUME) {
        skip_streaming_update = false;
      } else {
        console.log("Send streaming control Success");
      }
    } else {
      console.log("Send streaming control Fail");
    }
  });
}

var youtube_title;

//Start to play Youtube streaming
function sendYoutubeStreaming(url, type) {

  // if presenter mode is pause, transfer to resume
  if (isPause) {
    send_screen_unlock();
  }

  var youId = getYoutubeId(url, type);
  //Send Youtube ID to get Information from Youtube.com
  youtube_title = url;
  $.get('https://service.launchnovo.com/api/youtube/title/'+youId, function(result) {
      if (result != "") {
        youtube_title = result;
      }
      isImageSendingPause = true;
      streaming_type = "youtube";

      var length = 0;
      var buf = new Uint8Array(MAXIUM_MSG_LENGTH);

      for (var i = 0; i < MAXIUM_MSG_LENGTH; i++) {
        buf[i] = 0;
      }

      var overSend = false;
      var data = convert_str_into_bytes(youId);
      length = data.length;

      if (length + MINUM_MSG_LENGTH >= 127) {
        var data_length = length;
        var extention_length = convert_int_into_bytes_big_endian(data_length);
        if (extention_length != null && extention_length.length == 4) {
          for (var j = 0; j < 4; j++) {
            buf[j + 4] = extention_length[j];
          }
          for (var q = 0; q < length; q++) {
            buf[8 + q] = data[q];
          }
          overSend = true;
        }
      } else {
        buf[0] = length + MINUM_MSG_LENGTH;
        for (var i = 0; i < length; i++) {
          buf[4 + i] = data[i];
        }
        overSend = false;
      }
      buf[1] = CMD.PLAY_YOUTUBE;
      buf[2] = 0;
      buf[3] = 0;

      if (overSend) {
        chrome.sockets.tcp.send(cmd_socketId, buf.buffer.slice(0, length + 8), function(sendInfo) {
          if (sendInfo.resultCode == 0) {
            console.log("Send Youtube Start Success");
          } else {
            console.log("Send Youtube Start Fail");
          }
        });
      } else {
        chrome.sockets.tcp.send(cmd_socketId, buf.buffer.slice(0, length + 4), function(sendInfo) {
          if (sendInfo.resultCode == 0) {
            console.log("Send Youtube Start Success");
          } else {
            console.log("Send Youtube Start Fail");
          }
        });
      }
  }).error(function() {
    youtube_title = url;
    //Pause image
    isImageSendingPause = true;

    // set type
    streaming_type = "youtube";

    var length = 0;
    var buf = new Uint8Array(MAXIUM_MSG_LENGTH);

    for (var i = 0; i < MAXIUM_MSG_LENGTH; i++) {
      buf[i] = 0;
    }

    var overSend = false;

    var data = convert_str_into_bytes(youId);
    length = data.length;

    if (length + MINUM_MSG_LENGTH >= 127) {
      var data_length = length;
      var extention_length = convert_int_into_bytes_big_endian(data_length);
      if (extention_length != null && extention_length.length == 4) {
        for (var j = 0; j < 4; j++) {
          buf[j + 4] = extention_length[j];
        }
        for (var q = 0; q < length; q++) {
          buf[8 + q] = data[q];
        }
        overSend = true;
      }
    } else {
      buf[0] = length + MINUM_MSG_LENGTH;
      for (var i = 0; i < length; i++) {
        buf[4 + i] = data[i];
      }
      overSend = false;
    }

    buf[1] = CMD.PLAY_YOUTUBE;
    buf[2] = 0;
    buf[3] = 0;

    if (overSend) {
      chrome.sockets.tcp.send(cmd_socketId, buf.buffer.slice(0, length + 8), function(sendInfo) {
        if (sendInfo.resultCode == 0) {
          console.log("Send Youtube Start Success");
        } else {
          console.log("Send Youtube Start Fail");
        }
      });
    } else {
      chrome.sockets.tcp.send(cmd_socketId, buf.buffer.slice(0, length + 4), function(sendInfo) {
        if (sendInfo.resultCode == 0) {
          console.log("Send Youtube Start Success");
        } else {
          console.log("Send Youtube Start Fail");
        }
      });
    }
  });
}

var localaddress = "";

chrome.system.network.getNetworkInterfaces(function(networkInterfaces) {
  localaddress = networkInterfaces[0].address;
});

var streaming_filename;
var streaming_type;

//Start to play Video streaming
function sendLocalStreaming(filename) {
  console.log("LOCAL STREAMING ", filename);

  // if presenter mode is pause, transfer to resume
  if (isPause) {
    send_screen_unlock();
  }
  //Pause image
  isImageSendingPause = true;

  // set Filename
  streaming_filename = filename;

  // set type
  streaming_type = "local";
  var addString = randomString(5, 'aA');
  var send2 = "http://" + localaddress + ":20100/" + filename + addString;
  var send_string = encodeURI(send2);
  console.log(send_string);

  if (send_string.length == 0) {
    // todo: message no url
    console.log("Local Streaming URL error");
  } else {
    var length = 0;
    var buf = new Uint8Array(999);

    for (var i = 0; i < 999; i++) {
      buf[i] = 0;
    }

    var overSend = false;

    length = send_string.length;
    if (length > 0) {
      var data = convert_str_into_bytes(send_string);
      length = data.length;

      if (length + MINUM_MSG_LENGTH >= 127) {
        var data_length = length;
        var extention_length = convert_int_into_bytes_big_endian(data_length);
        if (extention_length != null && extention_length.length == 4) {
          for (var j = 0; j < 4; j++) {
            buf[j + 4] = extention_length[j];
          }
          for (var q = 0; q < length; q++) {
            buf[8 + q] = data[q];
          }
          overSend = true;
          buf[0] = 127;
        }
      } else {
        buf[0] = length + MINUM_MSG_LENGTH;
        for (var i = 0; i < length; i++) {
          buf[4 + i] = data[i];
        }
        overSend = false;
      }
    }

    buf[1] = CMD.PLAY_VIDEO;
    buf[2] = client_id;
    buf[3] = PLAY_CMD.START; // 0 = START

    if (overSend) {
      chrome.sockets.tcp.send(cmd_socketId, buf.buffer.slice(0, length + 8), function(sendInfo) {
        if (sendInfo.resultCode == 0) {
          console.log("Send Local Streaming URL To RVA Success");
          // Open HTTP SERVER
          if (isTCP_Server_Started) {
            console.log("TCP is initial");
          } else {
            isTCP_Server_Started = true;
            open_local_tcp_server();
          }
          connect_to_rva_proxy();
        } else {
          console.log("Send Local Streaming URL To RVA Fail");
        }
      });
    } else {
      chrome.sockets.tcp.send(cmd_socketId, buf.buffer.slice(0, length + 4), function(sendInfo) {
        if (sendInfo.resultCode == 0) {
          console.log("Send Local Streaming URL To RVA Success");
          // Open HTTP SERVER
          if (isTCP_Server_Started) {
            console.log("TCP is initial");
          } else {
            isTCP_Server_Started = true;
            open_local_tcp_server();
          }
          connect_to_rva_proxy();
        } else {
          console.log("Send Local Streaming URL To RVA Fail");
        }
      });
    }
  }
}
//Playing Youtube streaming response from RVA
function receive_CMD_PLAY_YOUTUBE(bValues) {
  console.log("Receive CMD PLAY YOUTUBE");
  var video_status = bValues[3];
  if (chrome.app.window.get("videoWindow") != null) {
    var videoWindow = chrome.app.window.get("videoWindow").contentWindow;
    switch (video_status) {
      case PLAY_CMD.EXIT:
        console.log("Youtube PLAY_CMD_EXIT");
        streaming_isFirst = true;
        youtube_title = "";
        //continue sending image
        isImageSendingPause = false;
        openDataConnection();
        videoWindow.sendVideoResult(0);
        break;
      case PLAY_CMD.NOT_SEEKABLE:
        console.log("PLAY_CMD_NOT_SEEKABLE");
        //TODO: disable progress bar
        videoWindow.sendVideoResult(3, $.t("video.videoNotSeekable") );
        break;
      case PLAY_CMD.UNKNOWN_ERROR:
        controlStreaming("youtube", PLAY_CMD.EXIT);
        console.log("PLAY_CMD_UNKNOWN_ERROR");
        streaming_isFirst = true;
        youtube_title = "";
        isImageSendingPause = false;
        openDataConnection();
        videoWindow.sendVideoResult(-1, $.t("video.errorMsg"));
        break;
      case PLAY_CMD.ERROR_NO_NETWORK_CONNECTED:
        controlStreaming("youtube", PLAY_CMD.EXIT);
        console.log("PLAY_CMD_NO_NETWORK_CONNECTED");
        streaming_isFirst = true;
        youtube_title = "";
        isImageSendingPause = false;
        openDataConnection();
        videoWindow.sendVideoResult(-1, $.t("video.noNetwork"));
        break;
      case PLAY_CMD.ERROR_PLAYBACK_ERROR:
        controlStreaming("youtube", PLAY_CMD.EXIT);
        console.log("PLAY_CMD_PLAYBACK_ERROR");
        streaming_isFirst = true;
        youtube_title = "";
        isImageSendingPause = false;
        openDataConnection();
        videoWindow.sendVideoResult(-1, $.t("video.playbackError"));
        break;
      case PLAY_CMD.ERROR_NOT_STREAMING_URL:
        controlStreaming("youtube", PLAY_CMD.EXIT);
        console.log("PLAY_CMD_NOT_STREAMING_URL");
        streaming_isFirst = true;
        youtube_title = "";
        isImageSendingPause = false;
        openDataConnection();
        videoWindow.sendVideoResult(-1, $.t("video.notStreamingUrl"));
        break;
      case PLAY_CMD.ERROR_UNREACHABLE_URL:
        controlStreaming("youtube", PLAY_CMD.EXIT);
        console.log("PLAY_CMD_UNREACHABLE_URL");
        streaming_isFirst = true;
        youtube_title = "";
        isImageSendingPause = false;
        openDataConnection();
        videoWindow.sendVideoResult(-1, $.t("video.unreachableUrl"));
        break;
      case PLAY_CMD.READY_TO_SHOW:
        console.log("PLAY_CMD.READY_TO_SHOW");
        videoWindow.sendVideoResult(1, youtube_title);
        break;
    }
  } else {
    console.log("[0]" + bValues[0]);
    console.log("[1]" + bValues[1]);
    console.log("[2]" + bValues[2]);
    console.log("[3]" + bValues[3]);
  }
}

//Playing Local streaming response from RVA
function receive_CMD_PLAY_VIDEO(bValues) {
  console.log("Receive CMD PLAY VIDEO");
  console.log(bValues[3]);
  var video_status = bValues[3];
  if (chrome.app.window.get("videoWindow") != null) {
    var videoWindow = chrome.app.window.get("videoWindow").contentWindow;
    switch (video_status) {
      case PLAY_CMD.EXIT:
        console.log("PLAY_CMD_EXIT");
        streaming_isFirst = true;
        //continue sending image
        isImageSendingPause = false;
        openDataConnection();
        videoWindow.sendVideoResult(0);
        close_all_streaming_sockets();
        break;
      case PLAY_CMD.NOT_SEEKABLE:
        console.log("PLAY_CMD_NOT_SEEKABLE");
        //TODO: disable progress bar
        videoWindow.sendVideoResult(3, $.t("video.videoNotSeekable") );
        break;
      case PLAY_CMD.UNKNOWN_ERROR:
        controlStreaming("local", PLAY_CMD.EXIT);
        console.log("PLAY_CMD_UNKNOWN_ERROR");
        streaming_isFirst = true;
        close_all_streaming_sockets();
        isImageSendingPause = false;
        openDataConnection();
        videoWindow.sendVideoResult(-1, $.t("video.errorMsg"));
        break;
      case PLAY_CMD.ERROR_NO_NETWORK_CONNECTED:
        controlStreaming("local", PLAY_CMD.EXIT);
        console.log("PLAY_CMD_NO_NETWORK_CONNECTED");
        streaming_isFirst = true;
        close_all_streaming_sockets();
        isImageSendingPause = false;
        openDataConnection();
        videoWindow.sendVideoResult(-1, $.t("video.noNetwork"));
        break;
      case PLAY_CMD.ERROR_PLAYBACK_ERROR:
        controlStreaming("local", PLAY_CMD.EXIT);
        console.log("PLAY_CMD_PLAYBACK_ERROR");
        streaming_isFirst = true;
        close_all_streaming_sockets();
        isImageSendingPause = false;
        openDataConnection();
        videoWindow.sendVideoResult(-1, $.t("video.playbackError"));
        break;
      case PLAY_CMD.ERROR_NOT_STREAMING_URL:
        controlStreaming("local", PLAY_CMD.EXIT);
        console.log("PLAY_CMD_NOT_STREAMING_URL");
        streaming_isFirst = true;
        close_all_streaming_sockets();
        isImageSendingPause = false;
        openDataConnection();
        videoWindow.sendVideoResult(-1, $.t("video.notStreamingUrl"));
        break;
      case PLAY_CMD.ERROR_UNREACHABLE_URL:
        controlStreaming("local", PLAY_CMD.EXIT);
        console.log("PLAY_CMD_UNREACHABLE_URL");
        streaming_isFirst = true;
        close_all_streaming_sockets();
        isImageSendingPause = false;
        openDataConnection();
        videoWindow.sendVideoResult(-1, $.t("video.unreachableUrl"));
        break;
      case PLAY_CMD.READY_TO_SHOW:
        console.log("PLAY_CMD.READY_TO_SHOW");
        videoWindow.sendVideoResult(1, streaming_filename);
        break;
    }
  } else {
    console.log("[0]" + bValues[0]);
    console.log("[1]" + bValues[1]);
    console.log("[2]" + bValues[2]);
    console.log("[3]" + bValues[3]);
  }
}

//Close Video Panel and send STOP to RVA
function close_video_panel() {
  console.log("Close Video Panel and streaming_type =" + streaming_type);
  isImageSendingPause = false;
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  if (streaming_type == "local") {
    buf[1] = CMD.PLAY_VIDEO;
  } else {
    buf[1] = CMD.PLAY_YOUTUBE;
  }
  buf[2] = client_id;
  buf[3] = PLAY_CMD.EXIT;

  if (streaming_type == "local") {
    chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
      if (sendInfo.resultCode == 0) {
        console.log("Close Video Panel STOP local streaming");
        close_all_streaming_sockets();
      } else {
        console.log("Close Video Panel STOP Fail");
      }
    });
  } else if (streaming_type == "youtube") {
    if (youtube_title != "") {
      chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
        if (sendInfo.resultCode == 0) {
          console.log("close_video_panel STOP Youtube Streaming");
          youtube_title = "";
        } else {
          console.log("Close Video Panel error");
        }
      });
    }
  } else {
    console.log("Close Panel");
  }
  if (amIPresenter(client_id)) {
    openDataConnection();
  }
  //Reset Streaming type
  streaming_type = "";
}

//Call backend to start HTTP SERVER
function open_local_tcp_server() {
  chrome.runtime.getBackgroundPage(function(backgroundPage) {
    backgroundPage.open_TCPserver();
  });
}

//Call backend to close HTTP SERVER
function close_local_tcp_server() {
  chrome.runtime.getBackgroundPage(function(backgroundPage) {
    backgroundPage.close_TCPserver();
  });
}

var client_answer = 0;
var user_answer = 0;

//Receive Voting Command
function receive_CMD_POLLING_VOTING(bValues, s_bytes) {
  console.log("Receive CMD POLLING VOTING");
  var voting_status = bValues[3];
  var length = bValues[0];
  switch (voting_status) {
    case CMD.VOTING_REQUEST:
      console.log("Voting Request");
      length = voting_request(bValues, s_bytes);
      break;
    case CMD.VOTING_RESPONSE:
      //Teacher receive response, Chromebook do not support teacher mode
      console.log("Receive VOTING RESPONSE");
      break;
    case CMD.VOTING_EX_REQUEST:
      console.log("Voting Ex Request");
      receive_voting_ex_request();
      break;
    case CMD.VOTING_STOP:
      console.log("Voting Stop");
      isTesting = false;
      votingObject = new votingObj(false, null);
      // TODO: Call Molly stop answer question
      votingHandler("stopAnswerQuestion");
      break;
    default:
      break;
  };

  return length;
}

//Check answer
function check_voting_answer(votingJsonObject) {
  // TODO: Call Molly display Question
  votingObject = new votingObj(true, votingJsonObject);
  if (votingJsonObject.correct === null || votingJsonObject.correct === "") {
    // if (last_question_number != voting_json_num) {
    console.log("Clean user answer");
    user_answer = 0;
    isTesting = true;
    // }
    goVoting(votingObject);
  } else if (votingJsonObject.type == 6 || votingJsonObject.type == 1) {
    // ThumbsUpDown and OpenEnded didn't check correct answer
    goVoting(votingObject);
  } else {
    if (!isTesting) {
      return;
    }
    // TODO: Check answer and call MOlly Alert Message
    var q_answer = parseInt(votingJsonObject.correct)

    if (user_answer == 0) {
      // User does not answer in time
      var data = {};
      data.flag = 3;
      votingHandler('showAnswerResultDialog', data);
      // votingWindow.show_answer_Result_dialog(3);
    } else if (user_answer == q_answer) {
      // votingWindow.show_answer_Result_dialog(1);
      var data = {};
      data.flag = 1;
      votingHandler('showAnswerResultDialog', data);
    } else {
      var result = getVotingAnswer(q_answer);
      var data = {};
      data.flag = 2;
      data.correctAnswer = result;
      votingHandler('showAnswerResultDialog', data);
    }
  }
}

//Receive Voting request
function voting_request(bValues, s_bytes) {
  var msg_length = bValues[s_bytes + 0];
  if (msg_length < 127) {
    var votingBuffer = new Uint8Array(msg_length - 4);
    for (var i = 0; i < msg_length - 4; i++) {
      votingBuffer[i] = bValues[i + 4 + s_bytes];
    }
    var json = convert_bytes_array_into_str_utf8(votingBuffer);
    var obj = jQuery.parseJSON(json);
    voting_json_num = obj[0].num;
    check_voting_answer(obj[0]);
  } else {
    msg_length = convert_bytes_big_endian_into_int(bValues[s_bytes + 4], bValues[s_bytes + 5], bValues[s_bytes + 6], bValues[s_bytes + 7]);
    if (msg_length + 8 > bValues.length) {
      return msg_length + 8;
    } else {
      var votingBuffer = new Uint8Array(msg_length);
      for (var i = 0; i < msg_length; i++) {
        votingBuffer[i] = bValues[i + 8];
      }
      var json = convert_bytes_array_into_str_utf8(votingBuffer);
      var obj = jQuery.parseJSON(json);
      voting_json_num = obj[0].num;
      // TODO: Call Molly display Question
      check_voting_answer(obj[0]);

      return msg_length + 8;
    }
  }

  return msg_length;
}

var voting_json_num;

//Send voting answer to RVA
function sendVotingAnswer(num, answer) {
  // console.log("User Answer = "+answer);
  user_answer = answer;
  if (num != voting_json_num) {
    //Answer different Question
    console.log("Wrong question number");
  } else {
    last_question_number = num;
    console.log("Last number = " + last_question_number);
    if (answer.length > 2) {
      ansJson = "{" + "\"num\" : \"" + num + "\", \"user_name\" : \"" + clientName + "\", \"answer\" : \"" + answer + "\"}";
    } else {
      ansJson = "{" + "\"num\" : \"" + num + "\", \"user_name\" : \"" + clientName + "\", \"answer\" : " + answer + "}";
    }
    var ansByte = convert_str_into_bytes(utf8_encode(ansJson));
    sendVotingResponse(num, ansByte);
  }
}

//Send voting answer to RVA file type
function sendVotingEntryAnswer(num, fileEntry) {
  fileEntry.file(function(file) {
    readAsDataURL(fileEntry, function(result) {
      var image_size = dataURItoBlob(result).length;
      if (image_size <= 819200) {
        // var ansResult = result.substring(22,result.length);
        var ansResult = result.replace("data:image/png;base64,", "").replace("data:image/jpeg;base64,", "");
        sendVotingAnswer(num, ansResult);
      } else {
        console.log("Upload image too large, need to downscale");
        var ansResult = result;
        $('#up_img').attr("src", ansResult);
        var cropCanvas = document.querySelector('#up_img');
        cropCanvas.onload = function() {
          var raito = 0.4;
          if (image_size > 3000000) {
            raito = 0.2;
          } else if (image_size <= 3000000 && image_size > 1200000) {
            raito = 0.3;
          } else if (image_size <= 1200000 && image_size > 800000) {
            raito = 0.4;
          }
          var uri = downScaleImage(cropCanvas, raito).toDataURL("image/png", 0.2).replace("image/png", "image/octet-stream");
          var image = dataURItoBlob(uri);
          var ansResult = uri.substring(31, uri.length);
          sendVotingAnswer(num, ansResult);
        }
      }
    });
  });
}

//Send voting answer to RVA file type
function sendVotingDragEntryAnswer(num, fragFile) {
  readAsDragDataURL(fragFile, function(result) {
    var image_size = dataURItoBlob(result).length;
    if (image_size <= 819200) {
      // var ansResult = result.substring(22,result.length);
      var ansResult = result.replace("data:image/png;base64,", "").replace("data:image/jpeg;base64,", "");
      sendVotingAnswer(num, ansResult);
    } else {
      console.log("Upload image too large, need to downscale");
      var ansResult = result;
      $('#up_img').attr("src", ansResult);
      var cropCanvas = document.querySelector('#up_img');
      cropCanvas.onload = function() {
        var raito = 0.4;
        if (image_size > 3000000) {
          raito = 0.2;
        } else if (image_size <= 3000000 && image_size > 1200000) {
          raito = 0.3;
        } else if (image_size <= 1200000 && image_size > 800000) {
          raito = 0.4;
        }
        var uri = downScaleImage(cropCanvas, raito).toDataURL("image/png", 0.2).replace("image/png", "image/octet-stream");
        var image = dataURItoBlob(uri);
        var ansResult = uri.substring(31, uri.length);
        sendVotingAnswer(num, ansResult);
      }
    }
  });
}

function readAsDataURL(fileEntry, callback) {
  fileEntry.file(function(file) {
    var reader = new FileReader();
    reader.onload = function(e) {
      callback(e.target.result);
    };
    reader.readAsDataURL(file);
  });
}

function readAsDragDataURL(file, callback) {
  var reader = new FileReader();
  reader.onload = function(e) {
    callback(e.target.result);
  };
  reader.readAsDataURL(file);
}

function sendVotingResponse(num, answer) {
  if (supportExchangeServer) {
    initial_DATA_EXCHANGE(CMD.POLLING_VOTING_V2, answer, null);
  } else {
    if (MINUM_MSG_LENGTH + answer.length < 127) {
      // CMD PORT
      var buf = new Uint8Array(MINUM_MSG_LENGTH + answer.length);
      buf[0] = MINUM_MSG_LENGTH + answer.length;
      buf[1] = CMD.POLLING_VOTING;
      buf[2] = client_id;
      buf[3] = CMD.VOTING_RESPONSE;

      for (var k = 0; k < answer.length; k++) {
        buf[4 + k] = answer[k];
      }

      chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
        if (sendInfo.resultCode == 0) {
          console.log("Send Voting Response Success < 127");
          var data = {};
          data.result = true;
          data.message = $.t("voting.submitSuccess");
          votingHandler("submitAnswerResult", data);
        } else {
          console.log("Send Voting Response Fail");
          var data = {};
          data.result = false;
          data.message = $.t("voting.submitFail");
          votingHandler("submitAnswerResult", data);
        }
      });
    } else if (MINUM_MSG_LENGTH + 4 + answer.length <= 256) {
      // CMD PORT
      var buf = new Uint8Array(MINUM_MSG_LENGTH + 4 + answer.length);
      buf[0] = 127;
      buf[1] = CMD.POLLING_VOTING;
      buf[2] = client_id;
      buf[3] = CMD.VOTING_RESPONSE;

      var data_length = convert_int_into_bytes_big_endian(answer.length);
      buf[4] = data_length[0];
      buf[5] = data_length[1];
      buf[6] = data_length[2];
      buf[7] = data_length[3];

      for (var k = 0; k < answer.length; k++) {
        buf[8 + k] = answer[k];
      }
      chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
        if (sendInfo.resultCode == 0) {
          console.log("Send Voting Response Success > 127");
          var data = {};
          data.result = true;
          data.message = $.t("voting.submitSuccess");
          votingHandler("submitAnswerResult", data);
        } else {
          console.log("Send Voting Response Fail");
          var data = {};
          data.result = false;
          data.message = $.t("voting.submitFail");
          votingHandler("submitAnswerResult", data);
        }
      });
    } else {
      // DATA PORT
      var buf = new Uint8Array(MINUM_MSG_LENGTH + 4 + answer.length);
      buf[0] = 127;
      buf[1] = CMD.POLLING_VOTING;
      buf[2] = client_id;
      buf[3] = CMD.VOTING_EX_RESPONSE;

      var data_length = convert_int_into_bytes_big_endian(answer.length);
      buf[4] = data_length[0];
      buf[5] = data_length[1];
      buf[6] = data_length[2];
      buf[7] = data_length[3];

      for (var k = 0; k < answer.length; k++) {
        buf[8 + k] = answer[k];
      }

      chrome.sockets.tcp.create({
        persistent: true,
        name: "voting"
      }, function(createInfo) {
        voting_data_socket = createInfo.socketId;
        chrome.sockets.tcp.connect(voting_data_socket, rvaIp, voting_data_port, function(result) {
          if (result == 0) {
            console.log("Connect to Voting Server Success -> Sending voting response");
            chrome.sockets.tcp.send(voting_data_socket, buf.buffer, function(sendInfo) {
              if (sendInfo.resultCode == 0) {
                console.log("Send Voting ex response Success");
                var data = {};
                data.result = true;
                data.message = $.t("voting.submitSuccess");
                votingHandler("submitAnswerResult", data);
                //Close voting data port when sending complete
                chrome.sockets.tcp.close(voting_data_socket);
              } else {
                console.log("Send Voting ex response fail");
                var data = {};
                data.result = false;
                data.message = $.t("voting.submitFail");
                votingHandler("submitAnswerResult", data);
              }
            });
          } else {
            console.log("Connect to Voting Server Fail -> Close");
            var data = {};
            data.result = false;
            data.message = $.t("voting.submitFail");
            votingHandler("submitAnswerResult", data);
            //Close voting data port when sending complete
            chrome.sockets.tcp.close(voting_data_socket);
          }
        });
      });
    }
  }
}

var voting_data_socket;
var voting_data_port = 20129;

var voting_data_times = 1;
var voting_array_size = 0;
var voting_scount = 0;
var votingBuf;

var last_question_number = 0;

//Receive Voting data from Voting data port
function receiveVotingServer(receive_buffer) {
  if (voting_data_times == 1) {
    voting_array_size = convert_bytes_big_endian_into_int(receive_buffer[4], receive_buffer[5], receive_buffer[6], receive_buffer[7]);
    votingBuf = new Uint8Array(voting_array_size);
  }

  var length = receive_buffer.length;

  if (voting_data_times == 1) {
    for (var i = 8; i < length; i++) {
      votingBuf[voting_scount] = receive_buffer[i];
      voting_scount++;
    }
    voting_data_times = voting_data_times + 1;
  } else {
    for (var i = 0; i < length; i++) {
      votingBuf[voting_scount] = receive_buffer[i];
      voting_scount++;
    }
  }
  if (voting_scount == voting_array_size) {
    voting_data_times = 1;
    voting_scount = 0;
    var json = convert_bytes_array_into_str_utf8(votingBuf);
    var obj = jQuery.parseJSON(json);
    voting_json_num = obj[0].num;
    // TODO: Call Molly display Question
    check_voting_answer(obj[0]);
    //Close Voting data port when receive complete
    chrome.sockets.tcp.close(voting_data_socket);
  }
}

//Send voting receive is ready to RVA
function receive_voting_ex_request() {
  chrome.sockets.tcp.create({
    persistent: true,
    name: "voting"
  }, function(createInfo) {
    voting_data_socket = createInfo.socketId;
    chrome.sockets.tcp.connect(voting_data_socket, rvaIp, voting_data_port, function(result) {
      if (result == 0) {
        console.log("Connect to Voting Server Success -> Sending voting_request");
        var buf = new Uint8Array(MINUM_MSG_LENGTH);
        buf[0] = MINUM_MSG_LENGTH;
        buf[1] = CMD.POLLING_VOTING;
        buf[2] = client_id;
        buf[3] = CMD.VOTING_EX_REQUEST;

        chrome.sockets.tcp.send(voting_data_socket, buf.buffer, function(sendInfo) {
          if (sendInfo.resultCode == 0) {
            console.log("Send Voting ex request Success");
          } else {
            console.log("Send Voting ex request fail");
          }
        });
      } else {
        console.log("Connect to Voting Server Fail -> Close");
      }
    });
  });
}

function votingObj(isReady, question) {
  this.isReady = isReady;
  this.question = question;
}

var votingObject = new votingObj(false, null);

//For debug only, display all sockets
function show_all_sockets() {
  chrome.sockets.tcp.getSockets(function(socketInfos) {
    for (var i = 0; i < socketInfos.length; i++) {
      var s = socketInfos[i];
      console.log("SocketId = " + s.socketId);
      console.log("Name = " + s.name);
      console.log("connected = " + s.connected);
      console.log("localAddress = " + s.localAddress);
      console.log("peerAddress = " + s.peerAddress);
    }
  });
}

//For debug only, clean up all sockets
function clean_undefine_sockets() {
  chrome.sockets.tcp.getSockets(function(socketInfos) {
    for (var i = 0; i < socketInfos.length; i++) {
      var s = socketInfos[i];
      if (s.connected == false) {
        chrome.sockets.tcp.close(s.socketId);
      }
    }
  });
}

// add screen mirroring quality
function setup_image_rate(rate) {
  console.log("Change rate " + quality_rate + " to " + rate);
  quality_rate = parseFloat(rate);
  chrome.storage.local.set({
    'image_quality': quality_rate
  });
}

//new Voting from Data Exchange Server
function receive_CMD_POLLING_VOTING_V2(bValues, s_bytes) {
  console.log("Receive CMD POLLING VOTING V2");
  event_value = CMD.POLLING_VOTING_V2;
  var status = bValues[s_bytes + 3];
  if (status == 0) {
    console.log("Voting Start");
    request_POLLING_VOTING_DATA();
  } else if (status == 2) {
    console.log("Voting Stop");
    votingObject = new votingObj(false, null);
    //Add voting data
    votingHandler("stopAnswerQuestion");
  }
}

function request_POLLING_VOTING_DATA() {
  initial_DATA_EXCHANGE(null, null, CMD.POLLING_VOTING_V2);
}

function send_CMD_POLLING_VOTING_V2_MESSAGE(arg1, arg2) {
  var data_length = 0;
  if (arg2 == null) {
    // no Data
    data_length = 8;
  } else {
    data_length = 8 + arg2.length;
  }
  var buf = new Uint8Array(data_length);

  var data_size = convert_int_into_bytes_big_endian(data_length);
  buf[0] = data_size[0];
  buf[1] = data_size[1];
  buf[2] = data_size[2];
  buf[3] = data_size[3];

  buf[4] = CMD.POLLING_VOTING_V2;
  buf[5] = client_id;
  buf[6] = arg1;
  buf[7] = 0;

  if (data_length > 8) {
    for (var i = 0; i < arg2.length; i++) {
      buf[i + 8] = arg2[i];
    }
    chrome.sockets.tcp.send(exchange_data_socketId, buf.buffer.slice(0, data_length), function(sendInfo) {
      if (sendInfo.resultCode == 0) {
        console.log("Send POLLING VOTING V2 RESPONSE Success");
      } else {
        console.log("Send POLLING VOTING V2 RESPONSE Fail");
      }
    });
  } else {
    chrome.sockets.tcp.send(exchange_data_socketId, buf.buffer.slice(0, data_length), function(sendInfo) {
      if (sendInfo.resultCode == 0) {
        console.log("Send POLLING VOTING V2 DATA Success");
      } else {
        console.log("Send POLLING VOTING V2 DATA Fail");
      }
    });
  }
}

function receive_DATA_EXCHANGE_SERVER(bValues, sByte) {
  console.log("DATA EXCHANGE SERVER RECEIVE");
  var packet_length = convert_bytes_big_endian_into_int(bValues[sByte], bValues[sByte + 1], bValues[sByte + 2], bValues[sByte + 3]);
  if (packet_length === 8) {
    var cmdCode = bValues[sByte + 4];
    console.log("4 = " + bValues[sByte + 4]);
    console.log("5 = " + bValues[sByte + 5]);
    console.log("6 = " + bValues[sByte + 6]);
    console.log("7 = " + bValues[sByte + 7]);
    switch (cmdCode) {
      case CMD.PREVIEW_DATA:
        console.log("Receive DATA PREVIEW STATUS CODE");
        console.log("Status Code = " + bValues[sByte + 6]);
        if (bValues[sByte + 6] === STATUSCODE.FAIL) {
          console.log("Receive preview data fail");
        }
        console.log("Error Code = " + bValues[sByte + 7]);
        isPreview = false;
        checkExchangeDataNeedClose();
        break;
      case CMD.POLLING_VOTING_V2:
        console.log("Receive POLLING VOTING V2 STATUS CODE");
        console.log("Status Code = " + bValues[sByte + 6]);
        console.log("Error Code = " + bValues[sByte + 7]);
        isVotingPolling = false;
        if (bValues[sByte + 6] == 0 && bValues[sByte + 7] == 0) {
          var data = {};
          data.result = true;
          data.message = $.t("voting.submitSuccess");
          votingHandler("submitAnswerResult", data);
        } else {
          var data = {};
          data.result = true;
          data.message = $.t("voting.submitFail");
          votingHandler("submitAnswerResult", data);
        }
        checkExchangeDataNeedClose();
        break;
      case CMD.UPLOAD_GROUP_DATA_V2:
        isGroupUpload = false;
        // receive_CMD_UPLOAD_GROUP_DATA_V2(bValues);
        break;
      case CMD.FILE_SHARING_DATA:
        isFileSharing = false;
        receive_CMD_FILE_SHARING(bValues);
        break;
      default:
        console.log("Default Status");
    }
    return sByte + packet_length;
  } else {
    console.log("Packet length = " + packet_length);
    console.log("bValue length = " + bValues.length);
    var cmdCode = bValues[sByte + 4];
    switch (cmdCode) {
      case CMD.PREVIEW_DATA:
        isPreview = false;
        receive_CMD_PREVIEW_DATA_FROM_DATA(bValues);
        break;
      case CMD.POLLING_VOTING_V2:
        isVotingPolling = false;
        receive_CMD_POLLING_VOTING_V2_FROM_DATA(bValues);
        break;
      case CMD.UPLOAD_GROUP_DATA_V2:
        isGroupUpload = false;
        break;
      case CMD.FILE_SHARING_DATA:
        isFileSharing = false;
        receive_CMD_FILE_SHARING_DATA_FROM_DATA(bValues);
        break;
      default:
        console.log(cmdCode);
        console.log(bValues);
        console.log("Default");
    }
    return sByte + packet_length;


  }

}

var event_value = 0;

function receive_CMD_PREVIEW_DATA_FROM_DATA(receive_buffer) {
  console.log("Receive PREVIEW DATA from EXCHANGE SERVER");
  var data_value = new Uint8Array(receive_buffer.length - 8);
  for (var i = 0; i < receive_buffer.length; i++) {
    data_value[i] = receive_buffer[i + 8];
  }
  screenshot_value = covert_array_into_Base64(data_value);
  sendingImage(screenshot_userid, screenshot_value);
  checkExchangeDataNeedClose();
}

function receive_CMD_POLLING_VOTING_V2_FROM_DATA(receive_buffer) {
  console.log("Receive POLLING VOTING from EXCHANGE SERVER");
  var data_value = new Uint8Array(receive_buffer.length - 8);
  for (var i = 0; i < receive_buffer.length; i++) {
    data_value[i] = receive_buffer[i + 8];
  }
  var json = convert_bytes_array_into_str_utf8(data_value);
  var obj = jQuery.parseJSON(json);
  voting_json_num = obj[0].num;
  // TODO: Call Molly display Question
  check_voting_answer(obj[0]);
  checkExchangeDataNeedClose();
}

//---------------------------- Streaming with Progress BAR functions

var streaming_isFirst = true;
var streaming_duration_time = 0;
var streaming_current_time = 0;

function receive_CMD_STREAMING_PLAY_TIME_UPDATE(bValues, s_bytes) {
  var videoWindow = chrome.app.window.get("videoWindow").contentWindow;
  if (videoWindow) {
    if (streaming_isFirst) {
      streaming_isFirst = false;
      streaming_duration_time = getStreamingSecond(bValues[s_bytes + 2], bValues[s_bytes + 3]);
      var streaming_duration_time_title = transferToHHMMSS(streaming_duration_time);
      var streaming_percent = 0 / streaming_duration_time;
      console.log("First time receive play update -> Duration times = " + streaming_duration_time_title);
      if (streaming_type == "local") {
        videoWindow.sendVideoResult(2, streaming_filename, {
          total: streaming_duration_time,
          percent: streaming_percent
        });
      } else {
        videoWindow.sendVideoResult(2, youtube_title, {
          total: streaming_duration_time,
          percent: streaming_percent
        });
      }
    } else {
      if (skip_streaming_update) {
        console.log("Skip");
      } else {
        streaming_current_time = getStreamingSecond(bValues[s_bytes + 2], bValues[s_bytes + 3]);
        console.log("Current time = " + streaming_current_time);
        var streaming_percent = streaming_current_time / streaming_duration_time;
        if (streaming_percent === 1) {
          sendStreamingPercentToRVA(1);
        } else {
          if (streaming_type == "local") {
            videoWindow.sendVideoResult(2, streaming_filename, {
              total: streaming_duration_time,
              percent: streaming_percent
            });
          } else {
            videoWindow.sendVideoResult(2, youtube_title, {
              total: streaming_duration_time,
              percent: streaming_percent
            });
          }
        }
      }
    }
  }
}

var skip_streaming_update = false;

function sendStreamingPercentToRVA(percent) {
  if (percent == 1) {
    var buf = new Uint8Array(MINUM_MSG_LENGTH);
    buf[0] = MINUM_MSG_LENGTH;
    if (streaming_type == "local") {
      buf[1] = CMD.PLAY_VIDEO;
    } else {
      buf[1] = CMD.PLAY_YOUTUBE;
    }
    buf[2] = client_id;
    buf[3] = PLAY_CMD.EXIT;

    chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
      if (sendInfo.resultCode == 0) {
        console.log("Close Video Panel STOP local streaming");
      } else {
        console.log("Close Video Panel STOP Fail");
      }
    });
  } else {
    var seconds = percent * streaming_duration_time;
    var data3 = Math.floor(seconds / 256);
    var data4 = Math.floor(seconds % 256);
    if (last_data3 == data3 && last_data4 == data4) {
      return;
    }

    var buf = new Uint8Array(MINUM_MSG_LENGTH);
    buf[0] = MINUM_MSG_LENGTH;
    buf[1] = CMD.STREAMING_PLAY_TIME_UPDATE;
    buf[2] = data3;
    buf[3] = data4;
    chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
      if (sendInfo.resultCode == 0) {
        last_data3 = data3;
        last_data4 = data4;
        console.log("Send CMD STREAMING PLAY TIME UPDATE Success");
      } else {
        console.log("Send CMD STREAMING PLAY TIME UPDATE Fail");
      }
    });
  }
}

//-------------------------- Moderator Credential
function receive_CMD_REQUEST_TEACHER_PRIORITY(bValues, s_bytes) {
  console.log("Receive CMD REQUEST TEACHER PRIORITY");
  var arg = bValues[s_bytes + 3];
  switch (arg) {
    case TEACHER_CREDENTIAL_CMD.PASSWORD_CORRECT:
      console.log("Teacher credential password correct");
      break;
    case TEACHER_CREDENTIAL_CMD.PASSWORD_INCORRECT:
      // TODO: Tell Molly show password error
      if (isFirstTeacherPriorityError) {
        console.log("First time credential error");
        isFirstTeacherPriorityError = false;
        openModeratorPage(2);
      } else {
        console.log("Not first time credential error");
        openModeratorPage(1);
      }
      break;
    case TEACHER_CREDENTIAL_CMD.REQUEST:
      // check moderator_credential status
      console.log("Receive Teacher credential request");
      check_as_Moderator();
      break;
    case TEACHER_CREDENTIAL_CMD.NO_PERMISSION:
      console.log("Receive Teacher credential no permission");
      var data = {};
      data.title = $.t("login.credentialFail");
      data.description = $.t("login.credentialFailMsg");
      messagePage(data);
      break;
    case TEACHER_CREDENTIAL_CMD.NO_PERMISSION_VOTING_ON:
      console.log("Receive Teacher credential no permission voting on");
      var data = {};
      data.title = $.t("login.credentialFail");
      data.description = $.t("login.teacherCredentialNoPermissionVotingOn");
      messagePage(data);
      break;
    case TEACHER_CREDENTIAL_CMD.NO_PERMISSION_TEACHER_ON:
      console.log("Receive Teacher credential no permission teacher on");
      var data = {};
      data.title = $.t("login.credentialFail");
      data.description = $.t("login.teacherCredentialNoPermissionTeacherOn");
      messagePage(data);
      break;
    case TEACHER_CREDENTIAL_CMD.PASSWORD_CHECK_UNAVAILABLE:
      console.log("RVA doest not setup password");
      var data = {};
      data.title = $.t("login.credentialFail");
      data.description = $.t("login.teacherCredentialPasswordCheckUnavailable");
      messagePage(data);
      break;
    default:
      console.log("CMD REQUEST TEACHER PRIORITY DEFAULT");
  }
}

function save_Moderator_Status(status) {
  isConnectAsModeratorChecked = status;
  chrome.storage.local.set({
    'moderator_status': isConnectAsModeratorChecked
  });
}

function save_Moderator_Password(password) {
  moderatorPassword = password;
  chrome.storage.local.set({
    'moderator_password': moderatorPassword
  });
}

var isConnectAsModeratorChecked = false;
var moderatorPassword = "";

function send_CMD_REQUEST_TEACHER_PRIORITY(arg1, credential_password) {
  var buf = new Uint8Array(MAXIUM_MSG_LENGTH);
  buf[1] = CMD.REQUEST_TEACHER_PRIORITY;
  buf[2] = client_id;
  buf[3] = arg1;

  var length = credential_password.length;
  if (length > 0) {
    var data = convert_str_into_bytes(credential_password);
    length = data.length;

    for (var k = 0; k < length; k++) {
      buf[4 + k] = data[k];
    }
  }
  buf[0] = length + MINUM_MSG_LENGTH;

  chrome.sockets.tcp.send(cmd_socketId, buf.buffer.slice(0, length + MINUM_MSG_LENGTH), function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send CMD REQUEST TEACHER PRIORITY SUCCESS");
    } else {
      console.log("Send CMD REQUEST TEACHER PRIORITY FAIL");
    }
  });

}

function check_as_Moderator() {
  console.log("Check Moderator");
  if (isConnectAsModeratorChecked) {
    chrome.storage.local.set({
      'moderator_status': isConnectAsModeratorChecked
    });
    if (isGroupMode) {
      console.log("No Teacher credential in group mode");
    } else {
      send_CMD_REQUEST_TEACHER_PRIORITY(2, moderatorPassword);
      chrome.storage.local.set({
        'moderator_password': moderatorPassword
      });
    }
  } else {
    //Do nothing
    chrome.storage.local.set({
      'moderator_status': isConnectAsModeratorChecked
    });
  }
}

// --------------------------- File Sharing ------------------------------------

var isReadyToSend = true;

//Call from Molly's UI
// 1 = Select a file to share
// 2 = Share Desktop Screen-shot
function select_a_file_to_share(param) {
  //step1 check client is receiving file ?
  if (isFileDownloading) {
    // TODO: Call Molly to display System is busy message
    systemBusyPage();
    return;
  }
  if (isReadyToSend) { // Check isAlready Upload
    if (param == 1) {
      //step2 check select file size, should less than 3MB, chromebook ??
      chrome.fileSystem.chooseEntry({
        type: 'openFile'
      }, function(entry) {
        if (chrome.runtime.lastError) {
          console.log("cancel file select");
        } else {
          if (entry.isFile) {
            fileEntry = entry;
            console.log(entry.name);
            check_Upload_FILE_Size(fileEntry);
          }
        }
      });
    } else if (param == 2) {
      // Send screenshot
      chrome.app.window.current().minimize();
      setTimeout(capture_no_panel_screenshot, 600);
    }
  } else {
    // Already upload file to RVA
    // TODO: Call Molly show already upload and display download report
    askSendAnotherFilePage(upload_report);
  }
}

var upload_report = {};

function initialFileSharing() {
  initial_DATA_EXCHANGE(CMD.FILE_SHARING_DATA, null, null);
}

function send_CMD_FILE_SHARING(arg1, arg2, name_data, file_data) {
  var data_length = 0;
  if (file_data != null) {
    data_length = 8 + 1 + name_data.length + file_data.length;
  } else {
    data_length = 8;
  }

  var buf = new Uint8Array(data_length);
  var data_size = convert_int_into_bytes_big_endian(data_length);
  buf[0] = data_size[0];
  buf[1] = data_size[1];
  buf[2] = data_size[2];
  buf[3] = data_size[3];

  buf[4] = CMD.FILE_SHARING_DATA; //CMD
  buf[5] = client_id; // client_id
  buf[6] = arg1; // FS_CMD
  buf[7] = arg2; // number of user who have download file if arg1 = FS_CMD.PROGRESS
  if (data_length > 8) {
    //filename
    var name_length = name_data.length;
    buf[8] = name_length; // file name length (N)
    for (var i = 0; i < name_length; i++) {
      buf[9 + i] = name_data[i];
    }
    //filedata
    for (var k = 0; k < file_data.length; k++) {
      buf[9 + name_length + k] = file_data[k];
    }
    chrome.sockets.tcp.send(exchange_data_socketId, buf.buffer, function(sendInfo) {
      if (sendInfo.resultCode == 0) {
        console.log("Send FS CMD Success with DATA");
      } else {
        console.log("Send FS CMD Fail with DATA");
      }
    });
  } else {
    chrome.sockets.tcp.send(exchange_data_socketId, buf.buffer, function(sendInfo) {
      if (sendInfo.resultCode == 0) {
        console.log("Send FS CMD Success");
      } else {
        console.log("Send FS CMD Fail");
      }
    });
  }
}

function receive_CMD_FILE_SHARING(receive_buffer) {
  console.log("Receive CMD FILE SHARING");
  // Normal response
  var fs_cmd = receive_buffer[6];
  switch (fs_cmd) {
    case FS_CMD.AVAILABLE:
      receive_FS_CMD_AVAILABLE(receive_buffer);
      break;
    case FS_CMD.BUSY:
      receive_FS_CMD_BUSY(receive_buffer);
      break;
    case FS_CMD.STATUS:
      receive_FS_CMD_STATUS(receive_buffer);
      break;
    case FS_CMD.PROGRESS:
      receive_FS_CMD_PROGRESS(receive_buffer);
      break;
    case FS_CMD.CANCEL:
      receive_FS_CMD_CANCEL(receive_buffer);
      break;
    default:
      console.log("FS_CMD Default");
  }
}

function receive_FS_CMD_AVAILABLE(receive_buffer) {
  console.log("Receive FS CMD AVAILABLE");
  isReadyToSend = false;
  var filename_data = convert_str_into_bytes(utf8_encode(send_filename));
  // 	var send_data = convert_str_into_bytes(file_result);
  var send_data = file_result;
  send_CMD_FILE_SHARING(FS_CMD.UPLOAD, 0, filename_data, send_data);
  //TODO: Call Molly show progress bar
  upload_report.percentage = 50;
  if (amIHost(client_id)) {
    upload_report.total = getOnlineUserCounts() - 1;
  } else {
    // Send to host only
    upload_report.total = 1;
  }
  upload_report.finished = 0;
  sendingFilePage(upload_report);
}

function receive_FS_CMD_BUSY(receive_buffer) {
  console.log("Receive FS CMD BUSY");
  isFileSharing = false;
  checkExchangeDataNeedClose();
  // Call Molly show System is busy message
  systemBusyPage();
}

function receive_FS_CMD_CANCEL(receive_buffer) {
  console.log("Receive FS CMD CANCEL");
  isFileSharing = false;
  isFileDownloading = false;
  checkExchangeDataNeedClose();
}

var receive_file_user = 0;

function receive_FS_CMD_STATUS(receive_buffer) {
  var result = receive_buffer[7];
  if (result == STATUSCODE.SUCCESS) {
    console.log("CMD STATUS SUCCESS");
    if (isSendToCancel) {
      //WOn't go here, James transfer to CMD port...
      isReadyToSend = true;
      isFileDownloading = false;
      console.log("Send CMD FILE SHARING DATA CANCEL SUCCESS");
      checkExchangeDataNeedClose();
    } else {
      //Upload success, call client to start to download
      isFileSharing = true;
      isReadyToSend = false;
      upload_report.percentage = 100;
      if (amIHost(client_id)) {
        upload_report.total = getOnlineUserCounts() - 1;
        receive_file_user = getOnlineUserCounts() - 1;
      } else {
        // Send to host only
        upload_report.total = 1;
      }
      upload_report.finished = 0;
      if (!isClosingSendingFilepage) {
        sendingFilePage(upload_report);
      }
      send_CMD_FILE_SHARING_DATA_START();
    }
  } else if (result == STATUSCODE.FAIL) {
    console.log("CMD STATUS FAIL");
    isFileDownloading = false;
    isReadyToSend = true;
    isClosingSendingFilepage = false;
    isFileSharing = false;
    checkExchangeDataNeedClose();
  }
}

var isClosingSendingFilepage = false;

function set_background_file_sending(status) {
  isClosingSendingFilepage = status;
}

function receive_FS_CMD_PROGRESS(receive_buffer) {
  console.log("Receive FS_CMD_PROGRESS");
  if (isSendToCancel) {
    console.log("But File Sharing is already cancel");
  } else {
    isFileSharing = true;
    var all = receive_file_user;
    // call Molly update download report
    if (!amIHost(client_id)) {
      // Send to host only
      all = 1;
    }
    upload_report.finished = receive_buffer[7];
    console.log("Upload file 100% and send to " + receive_buffer[7] + "/" + all + " participarts last time.");
    //Check if all download complete
    checkIsAllDownloadingFinished(receive_buffer[7], all);
  }
}

function checkIsAllDownloadingFinished(download, receiver) {
  if (download >= receiver) {
    console.log("All download complete");
    isReadyToSend = true;
    isFileDownloading = false;
    isFileSharing = false;
    // close sending process icon
    closeSendingFilePage();
    checkExchangeDataNeedClose();
  } else {
    if (!isClosingSendingFilepage) {
      sendingFilePage(upload_report);
    }
  }
}

function check_Upload_FILE_Size(fileEntry) {
  fileEntry.file(function(file) {
    readAsArrayBuffer(fileEntry, function(result) {
      var filedata = new Uint8Array(result);
      console.log("Size = " + filedata.length);
      if (filedata.length > 10485760) {
        //Selected file big than 3 MB
        // TODO: Call Molly display selected file big than 3 MB
        fileTooLargePage();
      } else if (!supportSharingBigFile && filedata.length > 3145728) {
        fileTooLargePage();
      } else {
        console.log("Send name = " + fileEntry.name);
        file_result = filedata;
        send_filename = checkIfFilenameTooLong(fileEntry.name, clientName);
        // Call Molly show send message with Filename + isHost
        var data = {};
        if (amIHost(client_id)) {
          //Host, Send file to all participants
          // TODO: Call Molly show to ask send to all participants with filename message
          data.title = $.t("sharing.sendFile");
          data.description = $.t("sharing.sendFileMsg");//"Are you sure to send '" + send_filename + "' to all participants ?";
          data.description = data.description.replace(/__filename__/, send_filename);
          data.description = data.description.replace(/__receiver__/, $.t("sharing.allParticipants"));
        } else {
          //Client, Send file to Host only
          // TODO: Call Molly show to ask send to all participants with filename message
          if (typeof getHostName() === 'undefined') {
            data.title = $.t("sharing.noRecipient");
            data.description = $.t("sharing.moderatorAbsent");
            messagePage(data);
            return;
          } else {
            data.title = $.t("sharing.sendFile");
            // data.description = "Are you sure to send '" + send_filename + "' to " + getHostName() + "?";
            data.description = $.t("sharing.sendFileMsg");
            data.description = data.description.replace(/__filename__/, send_filename);
            data.description = data.description.replace(/__receiver__/, getHostName());
          }
        }
        askSendFilePage(data);
      }
    });
  });
}

function readAsArrayBuffer(fileEntry, callback) {
  fileEntry.file(function(file) {
    var reader = new FileReader();
    reader.onload = function(e) {
      callback(e.target.result);
    };
    reader.readAsArrayBuffer(file);
  });
}

var file_result;
var send_filename;

function confirm_to_send_file() {
  if (isMoreThanTwoUser()) {
    if (capture_screenshot) {
      var link = document.getElementById("myScreenshot");
      link.click();
      capture_screenshot = false;
    }
    // Initial Data Exchange Server to sending file
    if (isNewFileSharing) {
      console.log("Need to use new file sharing");
      send_CMD_FILE_SHARING_DATA_QUERY();
    } else {
      initialFileSharing();
    }
  } else {
    var data = {};
    data.title = $.t("sharing.noRecipient");
    data.description = $.t("sharing.noReceiverMsg");
    capture_screenshot = false;
    messagePage(data);
  }

}

var isSendToCancel = false;

function send_CMD_FILE_SHARING_DATA_START() {
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.FILE_SHARING_DATA;
  buf[2] = client_id;
  buf[3] = 0; // request to download

  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send CMD FILE SHARING DATA START SUCCESS");
    } else {
      console.log("Send CMD FILE SHARING DATA START FAIL");
    }
  });
}

function send_CMD_FILE_SHARING_DATA_CANCEL() {
  isSendToCancel = true;
  isReadyToSend = true;
  isFileDownloading = false;
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.FILE_SHARING_DATA;
  buf[2] = client_id;
  buf[3] = 1; // request to cancel

  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send CMD FILE SHARING DATA CANCEL SUCCESS");
    } else {
      console.log("Send CMD FILE SHARING DATA CANCEL FAIL");
    }
  });
}

function send_CMD_FILE_SHARING_DATA_QUERY() {
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.FILE_SHARING_DATA;
  buf[2] = client_id;
  buf[3] = 2; // request to query

  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send CMD FILE SHARING DATA QUERY SUCCESS");
    } else {
      console.log("Send CMD FILE SHARING DATA QUERY FAIL");
    }
  });
}



var isFileDownloading = false;

function receive_CMD_FILE_SHARING_DATA(bValues, s_bytes) {
  console.log("Receive CMD FILE SHARING DATA")
  if (bValues[3] == FS_CMD.CANCEL) {
    receive_FS_CMD_CANCEL("");
  } else if (bValues[3] == FS_CMD.BUSY) {
    receive_FS_CMD_BUSY("");
  } else if (bValues[3] == FS_CMD.AVAILABLE) {
    initial_DATA_EXCHANGE(CMD.FILE_SHARING_DATA, null, null);
  } else if (bValues[3] == 0) {
    //Education when student send to teacher, client would be 0
    event_value = CMD.FILE_SHARING_DATA;
    // start to download file from RVA
    isFileDownloading = true;
    initialFileDownloading();
  }
}

function initialFileDownloading() {
  initial_DATA_EXCHANGE(null, null, CMD.FILE_SHARING_DATA);
}

function receive_CMD_FILE_SHARING_DATA_FROM_DATA(receive_buffer) {
  var total_length = convert_bytes_big_endian_into_int(receive_buffer[0], receive_buffer[1], receive_buffer[2], receive_buffer[3]);
  var send_id = receive_buffer[5]; // to know who send this file
  var send_name = "";
  if (send_id === 255) {
    send_name = "Novo";
  } else {
    send_name = getSendNameById(send_id);
  }
  var filename_length = receive_buffer[8];
  // setp1 get filename
  console.log("Filename length = " + filename_length);
  var filename_buf = new Uint8Array(filename_length);
  for (var j = 0; j < filename_length; j++) {
    filename_buf[j] = receive_buffer[j + 9];
  }
  var receive_filename = convert_bytes_array_into_str_utf8(filename_buf);
  console.log("Filename = " + receive_filename);
  // setp2 get filedata
  var filedata_length = total_length - 8 - 1 - filename_length;
  var filedata_offset = 8 + 1 + filename_length;
  var filedata_buf = new Uint8Array(filedata_length);
  for (var k = 0; k < filedata_length; k++) {
    filedata_buf[k] = receive_buffer[filedata_offset + k];
  }

  var fileBlob = new Blob([filedata_buf.buffer], {
    type: 'application/octet-stream'
  });
  document.getElementById("myDownload").href = window.URL.createObjectURL(fileBlob);
  document.getElementById("myDownload").download = send_name + "_" + receive_filename;
  document.getElementById("myDownload").innerHTML = receive_filename;
  document.getElementById("myDownload").target = "_blank";
  var link = document.getElementById("myDownload");
  link.click();

  //Receive file notification
  var file_receive_notification = {
    type: "basic",
    title: $.t("sharing.receivedTitle"),
    message: $.t("sharing.receivedMsg"), //"Received file '" + receive_filename + "' from " + send_name,
    iconUrl: "../images/icon.png",
    priority: 1
  };
  file_receive_notification.message = file_progress_notification.message.replace(/__filename__/, receive_filename);
  file_receive_notification.message = file_progress_notification.message.replace(/__sender__/, send_name);
  chrome.notifications.clear("fileProgress");
  chrome.notifications.create("fileReceive", file_receive_notification);
  chrome.notifications.clear("fileReceive");

  isFileDownloading = false;



  checkExchangeDataNeedClose();
}
var capture_screenshot = false;

function capture_no_panel_screenshot() {
  var image_bytes = getScreenShotCaptureBytesForSharing();
  var fileBlob = new Blob([image_bytes], {
    type: 'image/jpg'
  });
  var show_image = covert_array_into_Base64(image_bytes);
  //Image file name, base on date time and sender name
  var send_name = getSendNameById(client_id);
  var filename = getFilenameByCurrentTime();
  //Save screenshot file to download folder
  document.getElementById("myScreenshot").href = window.URL.createObjectURL(fileBlob);
  document.getElementById("myScreenshot").download = filename;
  document.getElementById("myScreenshot").innerHTML = filename;
  document.getElementById("myScreenshot").target = "_blank";
  capture_screenshot = true;
  // 	var link = document.getElementById("myScreenshot");
  // 	link.click();
  //Prepare to send
  file_result = image_bytes;
  send_filename = filename;
  var data = {};
  if (amIHost(client_id)) {
    //Host, Send file to all participants
    // TODO: Call Molly show to ask send to all participants with filename message, image
    data.title = $.t("sharing.sendScreen");
    data.description = $.t("sharing.sendScreenMsg");
    data.description = data.description.replace(/__receiver__/, $.t("sharing.allParticipants"));
    data.image = show_image;
  } else {
    //Client, Send file to Host only
    // TODO: Call Molly show to ask send to all participants with filename message, image
    if (typeof getHostName() === 'undefined') {
      data.title = $.t("sharing.noRecipient");
      data.description = $.t("sharing.moderatorAbsent");
      messagePage(data);
      //Restore Panel
      if (chrome.app.window.current().isMinimized()) {
        //Popup
        chrome.app.window.current().focus();
      }
      return;
    } else {
      data.image = show_image;
      // data.title = "Send Screen";
      // data.description = "Are you sure to send this screenshot to " + getHostName() + "?";
      data.title = $.t("sharing.sendScreen");
      data.description = $.t("sharing.sendScreenMsg");
      data.description = data.description.replace(/__receiver__/, getHostName());
    }
  }
  //Restore Panel
  if (chrome.app.window.current().isMinimized()) {
    //Popup
    chrome.app.window.current().focus();
  }
  askSendScreenPage(data);

}

// Integration DATA EXCHANGE SERVER
var isPreview = false;
var isGroupUpload = false;
var isVotingPolling = false;
var isFileSharing = false;

//arg1 = Send CMD to RVA
//arg2 = parameter
//arg3 = Receive form RVA
function initial_DATA_EXCHANGE(arg1, arg2, arg3) {
  if (typeof exchange_data_socketId === 'undefined') {
    chrome.sockets.tcp.create({
      persistent: false,
      bufferSize: 8192,
      name: "Data Exchange"
    }, function(createInfo) {
      exchange_data_socketId = createInfo.socketId;
      chrome.sockets.tcp.connect(exchange_data_socketId, rvaIp, EXCHANGE_DATA_PORT, function(result) {
        if (result === 0) {
          console.log("DATA EXCHANGE SERVER CONNECTION SUCCESS");
          data_CMD_FUNCTIONS(arg1, arg2, arg3);
        } else {
          console.log("DATA EXCHANGE SERVER CONNECTION FAIL");
          chrome.sockets.tcp.close(exchange_data_socketId);
        }
      });
    });
  } else {
    chrome.sockets.tcp.getInfo(exchange_data_socketId, function(callback) {
      if (chrome.runtime.lastError) {
        chrome.sockets.tcp.create({
          persistent: false,
          bufferSize: 8192,
          name: "Data Exchange"
        }, function(createInfo) {
          exchange_data_socketId = createInfo.socketId;
          chrome.sockets.tcp.connect(exchange_data_socketId, rvaIp, EXCHANGE_DATA_PORT, function(result) {
            if (result === 0) {
              console.log("DATA EXCHANGE SERVER CONNECTION SUCCESS");
              data_CMD_FUNCTIONS(arg1, arg2, arg3);
            } else {
              console.log("DATA EXCHANGE SERVER CONNECTION FAIL");
              chrome.sockets.tcp.close(exchange_data_socketId);
            }
          });
        });
      } else {
        if (callback.connected) {
          // Already conneted to RVA
          data_CMD_FUNCTIONS(arg1, arg2, arg3);
        }
      }
    });
  }
}

function checkExchangeDataNeedClose() {
  if (isPreview || isGroupUpload || isVotingPolling || isFileSharing) {
    console.log("EXCHANGE DATA IS STILL USING");
  } else {
    if (typeof exchange_data_socketId != 'undefined') {
      chrome.sockets.tcp.close(exchange_data_socketId, function(callback) {
        if (chrome.runtime.lastError) {

        }
      });
    }
  }
}

function data_CMD_FUNCTIONS(arg1, arg2, arg3) {
  if (arg3 != null) {
    // Receive from RVA
    switch (arg3) {
      case CMD.PREVIEW_DATA:
        console.log("WITH PREVIEW");
        isPreview = true;
        var screen_shot_preview = getImageCaptureBytesForScreenShot();
        send_PREVIEW_DATA_Message(client_id, 1, screen_shot_preview);
        break;
      case CMD.POLLING_VOTING_V2:
        console.log("WITH POLLING VOTING");
        isVotingPolling = true;
        send_CMD_POLLING_VOTING_V2_MESSAGE(3, null);
        break;
      case CMD.UPLOAD_GROUP_DATA_V2:
        break;
      case CMD.FILE_SHARING_DATA:
        console.log("WITH FILE SHARING");
        //Receive file notification start
        file_progress_notification = {
          type: "progress",
          title: $.t("sharing.receivedTitle"),
          message: $.t("sharing.receivedTitle"),
          iconUrl: "../images/icon.png",
          progress: 0
        };

        chrome.notifications.create("fileProgress", file_progress_notification);
        isFileSharing = true;
        send_CMD_FILE_SHARING(FS_CMD.DOWNLOAD, 0, 0, null);
        break;
      default:
        console.log("EXCHANGE DEFAULT");
    }
  } else {
    // Send to RVA
    switch (arg1) {
      case CMD.PREVIEW_DATA:
        if (arg2 != null) {
          console.log("WITH PREVIEW");
          isPreview = true;
          screenshot_userid = arg2;
          send_PREVIEW_DATA_Message(arg2, 0, null);
        }
        break;
      case CMD.POLLING_VOTING_V2:
        if (arg2 != null) {
          console.log("WITH POLLING VOTING");
          isVotingPolling = true;
          send_CMD_POLLING_VOTING_V2_MESSAGE(1, arg2);
        }
        break;
      case CMD.UPLOAD_GROUP_DATA_V2:
        break;
      case CMD.FILE_SHARING_DATA:
        console.log("WITH FILE SHARING");
        upload_report = {}; // clean upload report
        isSendToCancel = false;
        if (isNewFileSharing) {
          receive_FS_CMD_AVAILABLE("");
        } else {
          send_CMD_FILE_SHARING(FS_CMD.STATUS, 0, null, null);
        }
        break;
      default:
        console.log("EXCHANGE DEFAULT");
    }
  }
}

function close_all_sockets() {
  chrome.sockets.tcp.getSockets(function(socketInfos) {
    for (var i = 0; i < socketInfos.length; i++) {
      var s = socketInfos[i];
      if (typeof s.connected != 'undefined') {
        chrome.sockets.tcp.close(s.socketId, function(callback) {
          if (chrome.runtime.lastError) {

          }
        });
      }
    }
  });
}

function reset_Data_Exchange_Server_Status() {
  isPreview = false;
  isGroupUpload = false;
  isVotingPolling = false;
  isFileSharing = false;
  isFileDownloading = false;
  isReadyToSend = true;
  isClosingSendFilepage = false;
  checkExchangeDataNeedClose();
}

function notificationScreenLocation(number) {
  if (notificationOn) {
    var location_message = "";
    switch (number) {
      case 0:
        location_message = $.t("info.showOnScreen");
        break;
      case 1:
      case 2:
      case 3:
      case 4:
        location_message = $.t("info.showOnSubScreen"); //"Your desktop is being shown on screen quadrant " + number + ".";
        location_message = location_message.replace(/__no__/, number)
        break;
    }

    var screen_location_notification = {
      type: "basic",
      title: $.t("info.screenChange"),
      message: location_message,
      iconUrl: "../images/icon.png",
      priority: 2
    };

    chrome.notifications.create("screen", screen_location_notification);
  }
  else {
    chrome.notifications.clear("screen");
  }
}

// remote control
function send_CMD_REMOTE_CONTROL(arg) {
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = 100;
  buf[2] = 0;
  buf[3] = arg;
  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send CMD send_CMD_REMOTE_CONTROL SUCCESS");
    } else {
      console.log("Send CMD send_CMD_REMOTE_CONTROL FAIL");
    }
  });
}

// Web Streaming
function sendWebStreaming(url) {
  console.log("Send web Streaming ", url)
  console.log(url);

  if (isPause) {
    send_screen_unlock();
  }
  //Pause image
  isImageSendingPause = true;
  // set Filename
  streaming_filename = url.substring(5, url.length);
  console.log(streaming_filename);
  // set type
  streaming_type = "local";

  var length = 0;
  var buf = new Uint8Array(MAXIUM_MSG_LENGTH);

  for (var i = 0; i < MAXIUM_MSG_LENGTH; i++) {
    buf[i] = 0;
  }

  var overSend = false;

  var data = convert_str_into_bytes(url);
  length = data.length;

  if (length + MINUM_MSG_LENGTH >= 127) {
    var data_length = length;
    var extention_length = convert_int_into_bytes_big_endian(data_length);
    if (extention_length != null && extention_length.length == 4) {
      for (var j = 0; j < 4; j++) {
        buf[j + 4] = extention_length[j];
      }
      for (var q = 0; q < length; q++) {
        buf[8 + q] = data[q];
      }
      overSend = true;
    }
  } else {
    buf[0] = length + MINUM_MSG_LENGTH;
    for (var i = 0; i < length; i++) {
      buf[4 + i] = data[i];
    }
    overSend = false;
  }

  buf[1] = CMD.PLAY_VIDEO;
  buf[2] = 0;
  buf[3] = 0;

  if (overSend) {
    chrome.sockets.tcp.send(cmd_socketId, buf.buffer.slice(0, length + 8), function(sendInfo) {
      if (sendInfo.resultCode == 0) {
        console.log("Send Web Streaming Start Success");
      } else {
        console.log("Send Web Streaming Start Fail");
      }
    });
  } else {
    chrome.sockets.tcp.send(cmd_socketId, buf.buffer.slice(0, length + 4), function(sendInfo) {
      if (sendInfo.resultCode == 0) {
        console.log("Send Web Streaming Start Success");
      } else {
        console.log("Send Web Streaming Start Fail");
      }
    });
  }
}

function sendURLSharing(url) {
  var length = 0;
  var buf = new Uint8Array(512);

  for (var i = 0; i < 512; i++) {
    buf[i] = 0;
  }

  var overSend = false;

  var data = convert_str_into_bytes(utf8_encode(url));
  length = data.length;
  if (length + MINUM_MSG_LENGTH >= 127) {
    var data_length = length;
    var extention_length = convert_int_into_bytes_big_endian(data_length);
    if (extention_length != null && extention_length.length == 4) {
      for (var j = 0; j < 4; j++) {
        buf[j + 4] = extention_length[j];
      }
      for (var q = 0; q < data_length; q++) {
        buf[8 + q] = data[q];
      }
      overSend = true;
    }
    buf[0] = 127;
  } else {
    buf[0] = length + MINUM_MSG_LENGTH;
    for (var i = 0; i < length; i++) {
      buf[4 + i] = data[i];
    }
    overSend = false;
  }

  buf[1] = CMD.URL_SHARING;
  buf[2] = client_id;
  buf[3] = 0;

  if (overSend) {
    chrome.sockets.tcp.send(cmd_socketId, buf.buffer.slice(0, length + 8), function(sendInfo) {
      if (sendInfo.resultCode == 0) {
        console.log("Send URL Sharing 1" + url);
      } else {
        console.log("Send URL Sharing Fail");
      }
    });
  } else {
    chrome.sockets.tcp.send(cmd_socketId, buf.buffer.slice(0, length + 4), function(sendInfo) {
      if (sendInfo.resultCode == 0) {
        console.log("Send URL Sharing 2" + url);
      } else {
        console.log("Send URL Sharing Fail");
      }
    });
  }
}

function receive_CMD_URL_SHARING(bValues, s_bytes) {
  console.log("Receive CMD URL SHARING");
  var length = bValues[s_bytes];
  var send_id = bValues[s_bytes + 2];
  var send_name = getSendNameById(send_id);
  var receive_url = "";
  if (length === 127) {
    var sharing_length = convert_bytes_big_endian_into_int(bValues[s_bytes + 4], bValues[s_bytes + 5], bValues[s_bytes + 6], bValues[s_bytes + 7]);
    var strBuf = new Uint8Array(sharing_length);
    var j = 0;
    for (var i = 8; i < sharing_length; i++) {
      strBuf[j] = bValues[i];
      j++;
    }
    receive_url = convert_bytes_array_into_str_utf8(strBuf);
    length = sharing_length + 8;
  } else {
    var j = 0;
    var strBuf = new Uint8Array(length - 4);
    for (var i = 0; i < length - 4; i++) {
      strBuf[j] = bValues[i + 4];
      j++;
    }
    receive_url = convert_bytes_array_into_str_utf8(strBuf);
  }

  document.getElementById("urlReceive").href = receive_url;
  document.getElementById("urlReceive").target = "_blank";
  //Receive url notification
  var url_receive_notification = {
    type: "basic",
    title: $.t("sharing.receiveLinkTitle"),
    message: $.t("sharing.receiveLinkMsg"),
    iconUrl: "../images/icon.png",
    isClickable: true,
    buttons: [{
      title: $.t("button.open")
    }, {
        title: $.t("button.close")
    }],
    priority: 2
  };
  url_receive_notification.message = url_receive_notification.message.replace(/__sender__/, send_name);

  chrome.notifications.create("urlReceive", url_receive_notification);
  chrome.notifications.clear("urlReceive");
  var url_data = {};
  url_data.pid = nextUrlNumber + 1;
  url_data.url = receive_url;
  url_data.sender = send_name;
  var nowTime = new Date().getTime();
  url_data.timestamp = nowTime;
  urlList.push(url_data);
  nextUrlNumber++;
  chrome.storage.local.set({
    'url_list': urlList
  });
  receiveURL();

  return length;

}

chrome.notifications.onButtonClicked.addListener(notificationBtnClick);

function notificationBtnClick(notId, iBtn) {
  if (notId == "urlReceive") {
    if (iBtn == "0") {
      var link = document.getElementById("urlReceive");
      link.click();
    }
    if (iBtn == "1") {
      chrome.notifications.clear("urlReceive");
    }
  }
}

function removeURLRecieveHistory(pid) {
  if (pid == -1) {
    urlList = [];
    chrome.storage.local.set({
      'url_list': urlList
    });
  } else {
    for (var i = 0; i < urlList.length; i++) {
      var remove_data = urlList[i];
      if (remove_data.pid == pid) {
        var r = urlList.indexOf(remove_data);
        if (r != -1) {
          urlList.splice(r, 1);
          chrome.storage.local.set({
            'url_list': urlList
          });
          break;
        }
      }
    }
  }

}

function receive_CMD_BROADCAST_MSG(bValues, s_bytes) {
  console.log("Receive CMD BROADCAST MSG");
  var length = bValues[s_bytes];
  var send_type = bValues[s_bytes + 2]; // 0 -> sends to all clients, 1 -> sends to all clients including itself
  if (length === 127) {
    var sharing_length = convert_bytes_big_endian_into_int(bValues[s_bytes + 4], bValues[s_bytes + 5], bValues[s_bytes + 6], bValues[s_bytes + 7]);
    length = sharing_length + 8;
  } else {

  }

  return length;
}

function receive_CMD_RESPONDER(bValues) {
  console.log("Receive CMD RESPONDER");
}

function send_CMD_STOP_PRESENTATION(uid) {
  if (typeof uid === "undefined") {
    uid = client_id;
  }
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.STOP_PRESENTATION;
  buf[2] = uid;
  buf[3] = 0; // N/A

  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send CMD STOP PRESENTATION SUCCESS");
    } else {
      console.log("Send CMD STOP PRESENTATION FAIL");
    }
  });
}

function send_CMD_CONNECT_SESSION_INFO() {
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.CONNECT_SESSION_INFO;
  buf[2] = client_id;
  buf[3] = 0; // N/A

  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send CMD CONNECT SESSION INFO SUCCESS");
    } else {
      console.log("Send CMD CONNECT SESSION INFO FAIL");
    }
  });
}

function send_Close_SESSION_INFO() {
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.CONNECT_SESSION_INFO;
  buf[2] = client_id;
  buf[3] = 1; // 1 -> close

  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send Close CONNECT SESSION INFO SUCCESS");
    } else {
      console.log("Send Close CONNECT SESSION INFO FAIL");
    }
  });
}

//Chromebook do not support this
function receive_CMD_REMOTE_CONTROL_CMD(bValues) {
  console.log("Receive CMD REMOTE CONTROL CMD");
}



// 2.3.0 Annotation

function start_ANNOTATION() {
  console.log("SEND ANNOTATION REQUEST START");
  send_CMD_ANNOTATION_COMMAND(ANNOTATION_CMD_STATE.REQUEST_START);
}

function stop_ANNOTATION() {
  console.log("SEND ANNOTATION REQUEST END");
  if (annotation_cmd == ANNOTATION_CMD_STATE.NOT_AVAILABLE) {
    console.log("No Send REQUEST END WITH ANNOTATION DISABLE");
  } else {
    send_CMD_ANNOTATION_COMMAND(ANNOTATION_CMD_STATE.REQUEST_END);
  }
}

function screenLock_ANNOTATION() {
  console.log("SEND ANNOTATION SCREEN LOCK");
  send_CMD_ANNOTATION_COMMAND(ANNOTATION_CMD_STATE.SCREEN_LOCK);
}

function screenUnlock_ANNOTATION() {
  console.log("SEND ANNOTATION SCREEN UNLOCK");
  send_CMD_ANNOTATION_COMMAND(ANNOTATION_CMD_STATE.SCREEN_UNLOCK);
}

function turnOn_ANNOTATION() {
  console.log("SEND ANNOTATION TURN ON");
  send_CMD_ANNOTATION_COMMAND(ANNOTATION_CMD_STATE.TURN_ON);
}

function turnOff_ANNOTATION() {
  console.log("SEND ANNOTATION TURN OFF");
  send_CMD_ANNOTATION_COMMAND(ANNOTATION_CMD_STATE.TURN_OFF);
}

function shareToAll_ANNOTATION() {
  console.log("SEND ANNOTATION SHARE ALL");
  send_CMD_ANNOTATION_COMMAND(ANNOTATION_CMD_STATE.SHARE);
}

function screen_ANNOTATION() {
  console.log("SEND ANNOTATION SCREEN");
  send_CMD_ANNOTATION_COMMAND(ANNOTATION_CMD_STATE.SCREEN);
}

function refresh_ANNOTATION() {
  console.log("REFRESH ANNOTATION SCREEN");
  send_CMD_ANNOTATION_COMMAND(ANNOTATION_CMD_STATE.REFRESH);
}

function drawUndo_ANNOTATION() {
  console.log("DRAW UNDO ANNOTATION");
  initial_ANNOTATION_SERVER(OP_CMD.DRAW_UNDO, client_id, null);
}

function drawRedo_ANNOTATION() {
  console.log("DRAW REDO ANNOTATION");
  initial_ANNOTATION_SERVER(OP_CMD.DRAW_REDO, client_id, null);
}

function drawDeleteAll_ANNOTATION() {
  console.log("DRAW DELETE ALL ANNOTATION");
  initial_ANNOTATION_SERVER(OP_CMD.DRAW_DELETE_ALL, client_id, null);
}

function drawScreen_ANNOTATION(data) {
  console.log("DRAW SCREEN ANNOTATION");
  initial_ANNOTATION_SERVER(OP_CMD.POSITION, data, null);
}

function changePen_ANNOTATION(data) {
  console.log("CHANGE PENINFO ANNOTATION");
  initial_ANNOTATION_SERVER(OP_CMD.PEN_INFO, data, null);
}

function send_CMD_ANNOTATION_COMMAND(arg) {
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.ANNOTATION;
  buf[2] = client_id;
  buf[3] = arg;

  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send CMD ANNOTATION COMMAND SUCCESS");
      if (arg === ANNOTATION_CMD_STATE.REFRESH) {
        initial_ANNOTATION_SERVER(OP_CMD.SCREEN_IMG, client_id, null);
        //initial_ANNOTATION_SERVER(OP_CMD.ANNOTATOR, client_id, null);
      }
    } else {
      console.log("Send CMD ANNOTATION COMMAND FAIL");
    }
  });
}

var isAnnotator = false;
var annotator_uid = 0;
var annotator_switcher = -1; // client_id
var annotation_cmd = -1;
var annotation_state = false;

function receive_CMD_ANNOTATION_REQUEST(bValues, s_bytes) {
  var senderId = bValues[s_bytes + 2];
  var state = bValues[s_bytes + 3];
  annotator_switcher = senderId;
  annotation_cmd = state;
  switch (state) {
    case ANNOTATION_CMD_STATE.REQUEST_START:
      console.log("Receive ANNOTATION CMD STATE REQUEST START");
      initial_ANNOTATION_SERVER(OP_CMD.PRESENTER, client_id, null);
      break;
    case ANNOTATION_CMD_STATE.REQUEST_END:
      console.log("Receive ANNOTATION CMD STATE REQUEST END");
      isAnnotator = false;
      annotator_uid = 0;
      chrome.sockets.tcp.close(annotation_data_socketId);
      break;
    case ANNOTATION_CMD_STATE.REQUEST_APPROVED:
      console.log("Receive ANNOTATION CMD STATE REQUEST APPROVED");
      isAnnotator = true;
      annotator_uid = client_id;
      annotation_state = true;
      initial_ANNOTATION_SERVER(OP_CMD.SCREEN_IMG, client_id, null);
      break;
    case ANNOTATION_CMD_STATE.REQUEST_DENIED:
      console.log("Receive ANNOTATION CMD STATE REQUEST DENIED");
      isAnnotator = false;
      getAnnotationButtonState();
      break;
    case ANNOTATION_CMD_STATE.IN_USE:
      console.log("Receive ANNOTATION CMD STATE IN USE");
      annotation_state = true;
      getAnnotationButtonState();
      break;
    case ANNOTATION_CMD_STATE.AVAILABLE:
      console.log("Receive ANNOTATION CMD STATE AVAILABLE");
      annotation_state = true;
      isAnnotator = false;
      annotator_uid = 0;
      getAnnotationButtonState();
      break;
    case ANNOTATION_CMD_STATE.NOT_AVAILABLE:
      console.log("Receive ANNOTATION CMD STATE NOT AVAILABLE");
      annotation_state = false;
      isAnnotator = false;
      annotator_uid = 0;
      getAnnotationButtonState();
      break;
    case ANNOTATION_CMD_STATE.CURRENT_ANNOTATOR:
      console.log("Receive ANNOTATION CMD STATE CURRENT_ANNOTATOR");
      annotation_state = true;
      annotator_uid = senderId;
      if (senderId == client_id) {
        isAnnotator = true;
      } else {
        isAnnotator = false;
      }
      getAnnotationButtonState();
      break;
    case ANNOTATION_CMD_STATE.LAUNCH_ANNOTATION:
      console.log("Receive ANNOTATION CMD STATE LAUNCH_ANNOTATION");
      isAnnotator = true;
      annotator_uid = client_id;
      annotation_state = true;
      initial_ANNOTATION_SERVER(OP_CMD.SCREEN_IMG, client_id, null);
      getAnnotationButtonState();
      break;
    case ANNOTATION_CMD_STATE.TERMINATE_ANNOTATION:
      console.log("Receive ANNOTATION CMD STATE TERMINATE_ANNOTATION");
      annotator_uid = 0;
      isAnnotator = false;
      getAnnotationButtonState();
      beAskToCloseAirnote();
    default:
      console.log("senderId ", senderId);
      console.log("state ", state);
  }
}



function getAnnotationButtonState() {

  if (supportNewAnnotation) {
    var annotationObject = {
      whoclick: 0,
      whoAnnotating: 0
    };
    if (isAnnotator) {
      annotationObject.whoAnnotating = 1; //Me
      annotationObject.whoclick = 0; // Green
    } else {
      if (annotation_state) {
        if (annotator_uid == 0) {
          annotationObject.whoAnnotating = 0; //NoBody
          annotationObject.whoclick = 0; // Green
        } else {
          annotationObject.whoAnnotating = 2; //Other
          if (amIHost(client_id) || amIPresenter(client_id)) {
            annotationObject.whoclick = 0; // Green
          } else {
            annotationObject.whoclick = 2; // Grey
          }
        }
      } else {
        annotationObject.whoAnnotating = 0; //NoBody
        if (isNoOneMirroring()) {
          annotationObject.whoclick = 2; // Grey
        } else {
          if (amIHost(client_id) || amIPresenter(client_id)) {
            annotationObject.whoclick = 1; // Green
          } else {
            annotationObject.whoclick = 2; // Grey
          }
        }
      }
    }
    refreshUserList(user_list);
  } else {
    var annotationObject = {
      whoclick: 0,
      whoAnnotating: 0
    };
    switch (annotation_cmd) {
      case ANNOTATION_CMD_STATE.IN_USE:
        if (amIPresenter(client_id)) {
          annotationObject.whoclick = 0; // enable
          annotationObject.whoAnnotating = 2; //Other
        } else {
          annotationObject.whoclick = 0; // enable
          if (isAnnotator) {
            annotationObject.whoAnnotating = 1; //Me
          } else {
            annotationObject.whoAnnotating = 2; //Other
          }
        }
        break;
      case ANNOTATION_CMD_STATE.AVAILABLE:
        annotationObject.whoclick = 0; // enable
        if (isNoOneMirroring()) {
          annotationObject.whoAnnotating = 2; //Other
        } else {
          annotationObject.whoAnnotating = 0; //enable
        }
        break;
      case ANNOTATION_CMD_STATE.NOT_AVAILABLE:
        if (annotator_switcher == client_id) {
          annotationObject.whoclick = 1; // enable
        } else {
          annotationObject.whoclick = 2; // enable
        }
        annotationObject.whoAnnotating = 0; //Other
        break;
    }
  }
  refreshAnnotationButton(annotationObject);
}

function receive_ANNOTATION_DATA_SERVER(bValues, sByte) {
  var packet_length = convert_bytes_big_endian_into_int(bValues[sByte], bValues[sByte + 1], bValues[sByte + 2], bValues[sByte + 3]);
  if (packet_length === 8) {
    var cmdCode = bValues[sByte + 6];
    switch (cmdCode) {
      case OP_CMD.SCREEN_IMG:
        console.log("Receive OP_CMD SCREE_IMG")
      default:
        console.log("Default Status");
    }
    return sByte + packet_length;
  } else {
    var cmdCode = bValues[sByte + 6];
    switch (cmdCode) {
      case OP_CMD.SCREEN_IMG:
        receive_OP_CMD_SCREEN_IMG_DATA(bValues);
        break;
      default:
        console.log("Default");
    }
    return sByte + packet_length;
  }
}

//arg1 = Send CMD to RVA
//arg2 = parameter
//arg3 = Receive form RVA

function initial_ANNOTATION_SERVER(arg1, arg2, arg3) {
  if (typeof annotation_data_socketId === 'undefined') {
    chrome.sockets.tcp.create({
      persistent: false,
      bufferSize: 8192,
      name: "Annotation server"
    }, function(createInfo) {
      annotation_data_socketId = createInfo.socketId;
      chrome.sockets.tcp.connect(annotation_data_socketId, rvaIp, ANNOTATION_DATA_PORT, function(result) {
        if (result === 0) {
          console.log("ANNOTATION SERVER CONNECTION SUCCESS");
          annotation_CMD_FUNCTIONS(arg1, arg2, arg3);
        } else {
          console.log("ANNOTATION SERVER CONNECTION FAIL");
          chrome.sockets.tcp.close(annotation_data_socketId);
        }
      });
    });
  } else {
    chrome.sockets.tcp.getInfo(annotation_data_socketId, function(callback) {
      if (chrome.runtime.lastError) {
        chrome.sockets.tcp.create({
          persistent: false,
          bufferSize: 8192,
          name: "Annotation server"
        }, function(createInfo) {
          annotation_data_socketId = createInfo.socketId;
          chrome.sockets.tcp.connect(annotation_data_socketId, rvaIp, ANNOTATION_DATA_PORT, function(result) {
            if (result === 0) {
              console.log("ANNOTATION SERVER CONNECTION SUCCESS");
              annotation_CMD_FUNCTIONS(arg1, arg2, arg3);
            } else {
              console.log("ANNOTATION SERVER CONNECTION FAIL");
              cchrome.sockets.tcp.close(annotation_data_socketId);
            }
          });
        });
      } else {
        if (callback.connected) {
          // Already conneted to RVA
          console.log("CONTINUE ANNOTATION SERVER CONNECTION");
          annotation_CMD_FUNCTIONS(arg1, arg2, arg3);
        }
        else{
          chrome.sockets.tcp.create({
            persistent: false,
            bufferSize: 8192,
            name: "Annotation server"
          }, function (createInfo) {
            annotation_data_socketId = createInfo.socketId;
            chrome.sockets.tcp.connect(annotation_data_socketId, rvaIp, ANNOTATION_DATA_PORT, function (result) {
              if (result === 0) {
                console.log("ANNOTATION SERVER CONNECTION SUCCESS");
                annotation_CMD_FUNCTIONS(arg1, arg2, arg3);
              } else {
                console.log("ANNOTATION SERVER CONNECTION FAIL");
                cchrome.sockets.tcp.close(annotation_data_socketId);
              }
            });
          });
        }
      }
    });
  }
}

function annotation_CMD_FUNCTIONS(arg1, arg2, arg3) {
  if (arg3 != null) {
    // Receive from RVA
    switch (arg3) {
      case OP_CMD.ANNOTATOR:
        break;
      default:
        console.log("EXCHANGE DEFAULT");
    }
  } else {
    // Send to RVA
    switch (arg1) {
      case OP_CMD.SCREEN_IMG:
        if (arg2 != null) {
          send_OP_CMD_SCREEN_IMG();
        }
        break;
      case OP_CMD.PEN_INFO:
        if (arg2 != null) {
          send_OP_CMD_PEN_INFO(arg2);
        }
        break;
      case OP_CMD.POSITION:
        if (arg2 != null) {
          var position_data = convertPositionToArray(arg2);
          send_OP_CMD_POSITION(position_data);
        }
        break;
      case OP_CMD.DRAW_DELETE_ALL:
        send_OP_CMD_FUNCTIONS(arg1);
        break;
      case OP_CMD.DRAW_UNDO:
        send_OP_CMD_FUNCTIONS(arg1);
        break;
      case OP_CMD.DRAW_REDO:
        send_OP_CMD_FUNCTIONS(arg1);
        break;
      default:
        console.log("EXCHANGE DEFAULT");
    }
  }
}

function send_OP_CMD_FUNCTIONS(arg) {
  var data_length = 8;
  var buf = new Uint8Array(data_length);
  var data_size = convert_int_into_bytes_big_endian(data_length);
  buf[0] = data_size[0];
  buf[1] = data_size[1];
  buf[2] = data_size[2];
  buf[3] = data_size[3];

  buf[4] = CMD.ANNOTATION;
  buf[5] = client_id;
  buf[6] = arg;
  buf[7] = 0;

  chrome.sockets.tcp.send(annotation_data_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send OP_CMD FUNCTION SUCCESS");
    } else {
      console.log("Send OP_CMD FUNCTION FAIL");
    }
  });
}

function send_OP_CMD_SCREEN_IMG() {

  var data_length = 8;
  var buf = new Uint8Array(data_length);
  var data_size = convert_int_into_bytes_big_endian(data_length);
  buf[0] = data_size[0];
  buf[1] = data_size[1];
  buf[2] = data_size[2];
  buf[3] = data_size[3];

  buf[4] = CMD.ANNOTATION;
  buf[5] = client_id;
  buf[6] = OP_CMD.SCREEN_IMG;
  buf[7] = 0;

  chrome.sockets.tcp.send(annotation_data_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send OP_CMD SCREEN IMG Success ");
    } else {
      console.log("Send OP_CMD SCREEN IMG Fail");
    }
  });
}

function receive_OP_CMD_SCREEN_IMG_DATA(receive_buffer) {
  console.log("Receive ANNOTATION SCREEN from ANNOTATION DATA SERVER");
  var data_value = new Uint8Array(receive_buffer.length - 8);
  for (var i = 0; i < receive_buffer.length; i++) {
    data_value[i] = receive_buffer[i + 8];
  }
  var annotation_screen = covert_array_into_Base64(data_value);
  sendAnnotationBackground(annotation_screen);
}

function send_OP_CMD_PEN_INFO(color) {
  /**
   * Pen info >>
   * width, red, green, blue, alpha
   *
   */
  var data_length = 18;
  var buf = new Uint8Array(data_length);
  var data_size = convert_int_into_bytes_big_endian(data_length);
  buf[0] = data_size[0];
  buf[1] = data_size[1];
  buf[2] = data_size[2];
  buf[3] = data_size[3];

  buf[4] = CMD.ANNOTATION;
  buf[5] = client_id;
  buf[6] = OP_CMD.PEN_INFO;
  buf[7] = 0;

  buf[8] = convertIntegerTwoBytes(color.width)[0];
  buf[9] = convertIntegerTwoBytes(color.width)[1];
  buf[10] = convertIntegerTwoBytes(color.red)[0];
  buf[11] = convertIntegerTwoBytes(color.red)[1];
  buf[12] = convertIntegerTwoBytes(color.green)[0];
  buf[13] = convertIntegerTwoBytes(color.green)[1];
  buf[14] = convertIntegerTwoBytes(color.blue)[0];
  buf[15] = convertIntegerTwoBytes(color.blue)[1];
  buf[16] = convertIntegerTwoBytes(color.alpha)[0];
  buf[17] = convertIntegerTwoBytes(color.alpha)[1];


  chrome.sockets.tcp.send(annotation_data_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send OP_CMD PEN_INFO Success");
    } else {
      console.log("Send OP_CMD PEN_INFO Fail");
    }
  });
}

function send_OP_CMD_POSITION(position) {
  // data_length
  var data_length = 8 + position.length;
  var buf = new Uint8Array(data_length);

  var data_size = convert_int_into_bytes_big_endian(data_length);
  buf[0] = data_size[0];
  buf[1] = data_size[1];
  buf[2] = data_size[2];
  buf[3] = data_size[3];

  buf[4] = CMD.ANNOTATION;
  buf[5] = client_id;
  buf[6] = OP_CMD.POSITION;
  buf[7] = 0;

  for (var i = 0; i < position.length; i++) {
    buf[i + 8] = position[i];
  }
  chrome.sockets.tcp.send(annotation_data_socketId, buf.buffer.slice(0, data_length), function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send OP_CMD POSITION Success ");
    } else {
      console.log("Send OP_CMD POSITION Fail");
    }
  });
}

function update_notificationOn(state) {
  notificationOn = state;
  chrome.storage.local.set({
    'notificationOn': notificationOn
  });
  (notificationOn === true)? null : chrome.notifications.clear("screen");
}

function send_CMD_CLIENT_REMOVE(user_id) {
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.CLIENT_REMOVE;
  buf[2] = user_id;
  buf[3] = 0;

  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("SEND CMD CLIENT REMOVE SUCCESS");
    } else {
      console.log("SEND CMD CLIENT REMOVE FAIL");
    }
  });
}

function receive_CMD_CLIENT_REMOVE(bValues, s_bytes) {
  console.log("Receive CMD CLIENT REMOVE");
  var user_id = bValues[s_bytes + 2];
  var state = bValues[s_bytes + 3];
  if (user_id == 0 && state == 0) {
    console.log("Kick from moderator");
    closeCMDConnection();
    doLogout();
  } else if (user_id > 0 && state == 1) {
    //Remove user fro userlist
    if (user_id == annotator_uid) {
      console.log("Annotator Kicked");
      annotator_uid = 0;
      isAnnotator = false;
    }
    remove_userdata(user_id, "CLIENT_REMOVE");
    refreshUserList(user_list);
  }
}

function receive_CMD_REQUEST_CANCELLED(bValues, s_bytes) {
  console.log("Receive CMD REQUEST CANCEL");
  refreshUserList(user_list);
}

function receive_CMD_ANNOTATION_SYSTEM_BUSY() {
  console.log("Receive CMD ANNOTATION SYSTEM BUSY");
  var annotation_notification = {
    type: "basic",
    title: $.t("login.softwareName"),
    message: $.t("sharing.systemBusy"),
    iconUrl: "../images/icon.png",
    priority: 2
  };

  chrome.notifications.create("airNote", annotation_notification);
  chrome.notifications.clear("airNote");
}

function sendImagePreload() {

  var buf = new Uint8Array(MINUM_MSG_LENGTH + 4);

  buf[0] = 8;
  buf[1] = 1; //JPEG
  buf[2] = client_id;
  buf[3] = 0;
  buf[4] = 0;
  buf[5] = 0;
  buf[6] = 0;
  buf[7] = 0;

  chrome.sockets.tcp.send(data_socketId, buf.buffer, function(sendInfo) {
    if (chrome.runtime.lastError) {
      console.log("Image Preload Error");
    }
  });
}

function receive_CMD_H264_VIDEO_CLIENT(bValues, s_bytes) {
  //console.log("Receive CMD H264 VIDEO CLIENT");
}

function launch_ANNOTATION(uid) {
  console.log("LAUNCH USER TO AIRNOTE");
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.ANNOTATION;
  buf[2] = uid;
  buf[3] = ANNOTATION_CMD_STATE.LAUNCH_ANNOTATION;

  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send CMD LAUNCH ANNOTATION SUCCESS");
    } else {
      console.log("Send CMD LAUNCH ANNOTATION FAIL");
    }
  });
}

function terminate_ANNOTATION(uid) {
  console.log("TERMINATE USER TO AIRNOTE");
  var buf = new Uint8Array(MINUM_MSG_LENGTH);
  buf[0] = MINUM_MSG_LENGTH;
  buf[1] = CMD.ANNOTATION;
  buf[2] = uid;
  buf[3] = ANNOTATION_CMD_STATE.TERMINATE_ANNOTATION;

  chrome.sockets.tcp.send(cmd_socketId, buf.buffer, function(sendInfo) {
    if (sendInfo.resultCode == 0) {
      console.log("Send CMD TERMINATE ANNOTATION SUCCESS");
    } else {
      console.log("Send CMD TERMINATE ANNOTATION FAIL");
    }
  });
}

function reset_Annotation_Server_Status() {
  isAnnotator = false;
  annotator_uid = 0;
  annotator_switcher = -1; // client_id
  annotation_cmd = -1;
  annotation_state = false;
  var win = chrome.app.window.get("annotationWindow");
  if (win) {
    win.close();
    chrome.sockets.tcp.close(annotation_data_socketId);
  }
}
