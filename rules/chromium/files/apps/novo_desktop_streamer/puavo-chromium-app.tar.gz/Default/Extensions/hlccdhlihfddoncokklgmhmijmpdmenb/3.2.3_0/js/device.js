var udp_handle_buffer = [];

// Broadcast UDP receive
var boardcast_udp_socketId_1;
var boardcast_udp_socketId_2;
var boardcast_udp_socketId_3;

var board_list = [];

var DISCOVERY_PORT = 20124;

chrome.sockets.udp.create({
  persistent: false,
  bufferSize: 8192,
  name: "BOARDCAST1"
}, function (createInfo) {
  boardcast_udp_socketId_1 = createInfo.socketId;
});

chrome.sockets.udp.create({
  persistent: false,
  bufferSize: 8192,
  name: "BOARDCAST2"
}, function (createInfo) {
  boardcast_udp_socketId_2 = createInfo.socketId;
});

chrome.sockets.udp.create({
  persistent: false,
  bufferSize: 8192,
  name: "BOARDCAST3"
}, function (createInfo) {
  boardcast_udp_socketId_3 = createInfo.socketId;
});

chrome.sockets.udp.onReceive.addListener(function (info) {
  if (info.socketId === boardcast_udp_socketId_1 || info.socketId === boardcast_udp_socketId_2 || info.socketId === boardcast_udp_socketId_3) {
    var receive_buffer = new Uint8Array(info.data);
    receive_BOARDCAST_MESSAGE(receive_buffer, info.remoteAddress);
  } else {
    console.log("Error");
  }
});

function update_IP_LIST_with_Boardcast() {
  chrome.system.network.getNetworkInterfaces(function (callback) {
    var count = 1;
    for (var i = 0; i < callback.length; i++) {
      var networkInterfaces = callback[i];
      if (networkInterfaces.prefixLength === 24) {
        console.log(networkInterfaces.address);
        board_list.push(networkInterfaces.address);
      }
    }
    initial_bindAddress();
  });
}

function initial_bindAddress() {
  for (var i = 0; i < board_list.length; i++) {
    if (i === 0) {
      chrome.sockets.udp.bind(boardcast_udp_socketId_1, board_list[0], DISCOVERY_PORT, function (result) {
        if (!chrome.runtime.lastError) {
          if (result === 0) {
            console.log("Success bind udp " + board_list[0]);
            send_UDP_BOARDCAST_REQUEST_WITH_IPADDRESS_1();
            setInterval(send_UDP_BOARDCAST_REQUEST_WITH_IPADDRESS_1, 10000);
          }
        }
      });
    } else if (i === 1) {
      chrome.sockets.udp.bind(boardcast_udp_socketId_2, board_list[1], DISCOVERY_PORT, function (result) {
        if (!chrome.runtime.lastError) {
          if (result === 0) {
            console.log("Success bind udp " + board_list[1]);
            send_UDP_BOARDCAST_REQUEST_WITH_IPADDRESS_2();
            setInterval(send_UDP_BOARDCAST_REQUEST_WITH_IPADDRESS_2, 10000);
          }
        }
      });
    } else if (i === 2) {
      chrome.sockets.udp.bind(boardcast_udp_socketId_3, board_list[2], DISCOVERY_PORT, function (result) {
        if (!chrome.runtime.lastError) {
          if (result === 0) {
            console.log("Success bind udp " + board_list[2]);
            send_UDP_BOARDCAST_REQUEST_WITH_IPADDRESS_3();
            setInterval(send_UDP_BOARDCAST_REQUEST_WITH_IPADDRESS_3, 10000);
          }
        }
      });
    }
  }
}

function send_UDP_BOARDCAST_REQUEST_WITH_IPADDRESS_1() {
  if (isDataConnected) {
//    console.log("DataConnection does not boardcast");
  } else {
    var message = convert_str_into_bytes("ipaddressssid");
    var buf = new Uint8Array(13);
    var length = 0;
    for (var k = 0; k < message.length; k++) {
      buf[k] = message[k];
    }
    var ip_1 = board_list[0].split(".");
    var new_ip = ip_1[0] + "." + ip_1[1] + "." + ip_1[2] + "." + 255;
    chrome.sockets.udp.setBroadcast(boardcast_udp_socketId_1, true, function (result) {
      chrome.sockets.udp.send(boardcast_udp_socketId_1, buf.buffer, new_ip, DISCOVERY_PORT, function (sendInfo) {
        if (sendInfo.resultCode === 0) {

        } else {
          console.log("UDP boardcast fail");
        }
      });
    });

  }
}

function send_UDP_BOARDCAST_REQUEST_WITH_IPADDRESS_2() {
  if (isDataConnected) {
//    console.log("DataConnection does not boardcast");
  } else {
    var message = convert_str_into_bytes("ipaddressssid");
    var buf = new Uint8Array(13);
    var length = 0;
    for (var k = 0; k < message.length; k++) {
      buf[k] = message[k];
    }
    var ip_1 = board_list[1].split(".");
    var new_ip = ip_1[0] + "." + ip_1[1] + "." + ip_1[2] + "." + 255;

    chrome.sockets.udp.send(boardcast_udp_socketId_2, buf.buffer, new_ip, DISCOVERY_PORT, function (sendInfo) {
      if (sendInfo.resultCode === 0) {

      } else {
        console.log("UDP boardcast fail");
      }
    });
  }
}

function send_UDP_BOARDCAST_REQUEST_WITH_IPADDRESS_3() {
  if (isDataConnected) {
//    console.log("DataConnection does not boardcast");
  } else {
    var message = convert_str_into_bytes("ipaddressssid");
    var buf = new Uint8Array(13);
    var length = 0;
    for (var k = 0; k < message.length; k++) {
      buf[k] = message[k];
    }
    var ip_1 = board_list[2].split(".");
    var new_ip = ip_1[0] + "." + ip_1[1] + "." + ip_1[2] + "." + 255;

    chrome.sockets.udp.send(boardcast_udp_socketId_3, buf.buffer, new_ip, DISCOVERY_PORT, function (sendInfo) {
      if (sendInfo.resultCode === 0) {

      } else {
        console.log("UDP boardcast fail");
      }
    });
  }
}

function receive_BOARDCAST_MESSAGE(receive_buffer, ipaddress) {
  var result = convert_bytes_array_into_str_utf8(receive_buffer);
  if (result.indexOf("NovoConnect") > -1) {
    getIPData(ipaddress, result);
  }
}

function getIPData(ipaddress, value) {
  var one = 12;
  var two = value.indexOf(" _%&*_ ");
  var three = two + 7;
  var four = value.length;
  var meetingname = value.substring(one, two);
  var wifiname = value.substring(three, four);
  if (ip_list.length > 0) {
    var status = true;
    for (var i = 0; i < ip_list.length; i++) {
      var ipd = ip_list[i];
      if (ipd.value === ipaddress) {
        add_ipdata(ipaddress, ipaddress + " (" + meetingname + ")", true, ipd.username, new Date().getTime, true);
        status = false;
      }
    }
    if (status) {
      add_ipdata(ipaddress, ipaddress + " (" + meetingname + ")", true, "", new Date().getTime, true);
    }
    refreshIPList(ip_list);
  } else {
    add_ipdata(ipaddress, ipaddress + " (" + meetingname + ")", true, "", new Date().getTime, true);
  }
}

function closeUDP() {
  if (typeof boardcast_udp_socketId_1 !== 'undefined') {
    chrome.sockets.udp.close(boardcast_udp_socketId_1);
  }

  if (typeof boardcast_udp_socketId_2 !== 'undefined') {
    chrome.sockets.udp.close(boardcast_udp_socketId_2);
  }

  if (typeof boardcast_udp_socketId_3 !== 'undefined') {
    chrome.sockets.udp.close(boardcast_udp_socketId_3);
  }
}
