    function PackageFilesHandler() {
        // this thing is ASS
        BaseHandler.prototype.constructor.call(this)
    }
    _.extend(PackageFilesHandler.prototype, {

        get: function() {

            // how does this handle streaming and cancel and all that?
            // not so good my guess...

            var uri = this.request.uri

            var xhr = new XMLHttpRequest();
            function stateChange(evt) {
                if (evt.target.readyState == 4) {
                    if (evt.target.status == 200) {
                        var resp = {data:evt.target.response,
                                    size:evt.target.response.byteLength,
                                    headers:evt.target.getAllResponseHeaders(),
                                    type:evt.target.getResponseHeader('content-type')
                                   }
                        this.writeResponse(resp)
                    } else {
                        //console.error('error in passthru package files',evt)
                        this.write('error', 404)
                    }
                }
            }
            xhr.onreadystatechange = stateChange.bind(this)
            if (this.request.headers['range']) {
                console.log('request had range',this.request)
            }
            xhr.open("GET", uri, true);
            for (key in this.request.headers) {

                if (key == 'connection' ||
                    key == 'host' ||
                    key == 'cookie' ||
                    key == 'accept-encoding' ||
                    key == 'user-agent' ||
                    key == 'referer') {
                } else {
                    //console.log('set req header',key)
                    xhr.setRequestHeader(key, this.request.headers[key])
                }
            }
            xhr.responseType = 'arraybuffer';
            xhr.send();
        }

    }, BaseHandler.prototype)


        getHeaders: function() {
            // guess content type...
            var lines = []
            var mime = {'html': 'text/html',
                        'js': 'application/javascript'}
            var parts = this.request.path.split('.')
            var ext = parts[parts.length-1]
            if (mime[ext]) {
                lines.push('content-type: '+ mime[ext])
            }


/*
            lines.push('accept-ranges: bytes')
            if (this.request.headers['range']) {
                debugger
                if (this.request.headers['range'] == 'bytes 0-') {
                    var cr = 'content-range: bytes 0-' + this.responseLength-1 + '/' + this.responseLength
                    this.fileLength = this.responseLength
                } else {
                    var cr = 'content-range: ' + this.request.headers['range'] + '/' + this.fileLength
                }
                debugger
                lines.push(cr)
            }
*/
            return lines
        },


        writeResponse: function(resp) {
            var lines = resp.headers.split('\r\n')
            var dheaders = parseHeaders(lines.slice(0,lines.length-1))
            this.responseLength = (resp.data.length || resp.data.byteLength)
            this.writeHeaders(200, dheaders)
            this.write(resp.data)
        },
