var novo;

$(document).ready(function () {
  translate(chrome.i18n.getUILanguage(), function (){
    $("#rva_url_input").val($.t("login.manualIInputIP"));
  });

  novo = $("#container").novoconnect();
  $(".custom-combobox-toggle").hide();
  
  getStorageSettings();
  // testLogin();
});

function refreshIPList(ipList) {
  console.debug("[refreshIPList] ipList=", ipList);
  novo.novoconnect("refreshIPList", ipList);

  // var control = $("#project").val("");

  // // remove the autocomplete behaviour
  // if ($(control).data('autocomplete')) {
  //   $(control).autocomplete("destroy");
  //   $(control).removeData('autocomplete');
  // }

  // $(control).autocomplete({
  //     minLength: 0,
  //     delay: 50,
  //     source: ipList,
  //     autoFocus: true,
  //     position: {
  //       my: "left top",
  //       at: "left bottom",
  //       of: "#rva_url"
  //     },
  //     focus: function (event, ui) {
  //       // console.debug('[main.js-refreshIPList] run autocomplete -> focus', ui.item);
  //       $("#rva_url").val(ui.item.value);
  //       $("#client_name").val(ui.item.username);
  //       return false;
  //     },
  //     select: function (event, ui) {
  //       // console.debug('[main.js-refreshIPList] run autocomplete -> select', ui.item);
  //       $("#rva_url").val(ui.item.value );
  //       $("#client_name").val(ui.item.username);
  //       $("#launch_ip_list").data('toggle', false);
  //       // event.stopPropagation();
  //         return false;
  //     },
  //     change: function (event, ui) {
  //       return false;
  //     },
  //   })
  //   .autocomplete("instance")._renderItem = function (ul, item) {
  //     return $("<li>")
  //       .addClass(item.broadcast ? "broadcast" : "")
  //       .append("<a>" + item.label + "</a>") // + "<br>" + item.username
  //       .appendTo(ul);
  //   };

  // $("#launch_ip_list").off().show().click(function () {
  //   //console.log("click launch_ip_list");
  //   $("#rva_url").focus();
  //   if ($(this).data('toggle')) {
  //     $(".ui-autocomplete").hide();
  //     $(this).data('toggle', false);
  //   }
  //   else {
  //     $("#project").trigger("keydown");
  //     $(this).data('toggle', true);
  //   }
  //   return false;
  // });

  // $("#rva_url").off().keydown(function (e) {
  //   var code = e.keyCode || e.which;
  //   //console.debug("[main.js-refreshIPList] keydown", code);

  //   // arrow down
  //   if (code == 40) {
  //     if ($(".ui-autocomplete").css("display") == "none") {
  //       //console.log('Display ip list');
  //       $("#project").trigger("keydown");
  //       return;
  //     }
  //     //console.log('Enter', $(".ui-state-focus").index());
  //     $(".ui-autocomplete .ui-state-focus").next().trigger("mouseover");
  //   }

  //   // arrow up
  //   if (code == 38) {
  //     $(".ui-autocomplete .ui-state-focus").prev().trigger("mouseover");
  //   }

  //   // enter
  //   if (code == 13) {
  //     $(".ui-autocomplete .ui-state-focus").trigger("click");
  //   }
  // });
}

function refreshUserList(userList) {
//  console.debug("[refreshUserList] userList=", userList);
  novo.novoconnect("updateUserList", userList);
}

function doLogin(result) {
//  console.debug("[doLogin] result=", result);
  novo.novoconnect("doLogin", true, result);
  chrome.notifications.clear("newVersionRelease");
}

function doLogout() {
//  console.debug("[doLogout] ");
  $("#disconnect-btn").trigger("click");
}

function connection_fail(message) {
//  console.debug("[connection_fail] message=", message);
  novo.novoconnect("connectionFailPage", message);
}

function connection_fail_invalid_pincode() {
  console.warn("[connection_fail_invalid_pincode] ");
  messagePagePinCode();
  //novo.novoconnect("invalid_pincode");  // TODO: next version
}

function connected_initial(conSuccess) {
//  console.debug("[connected_initial] conSuccess=", conSuccess);
  novo.novoconnect("updateInfo", conSuccess);
}

/*  grace TBD
dsaApi.closeAllDialogs.connect(function() {
  console.warn('[main.js-closeAllDialog]...');
  novo.novoconnect("closeAllDialogs");
});

dsaApi.closeDialogWaitingNeverStop.connect(function() {
  console.warn('[main.js-closeDialogWaitingNeverStop]...');
  novo.novoconnect("closeDialogWaitingNeverStop");
});

dsaApi.closeDialogVotingNotStart.connect(function() {
  console.warn('[main.js-closeDialogVotingNotStart]...');
  novo.novoconnect("closeDialogVotingNotStart");
});
*/

function set_up_view_mode(mode) {
//  console.debug("[set_up_view_mode] mode=", mode);
  novo.novoconnect("setViewMode", mode);
}

function receive_moderator_request(message) {
//  console.debug("[receive_moderator_request] message=", message);
  novo.novoconnect("moderatorRequest", message);
}

function receive_moderator_broadcast_request(message) {
//  console.debug("[receive_moderator_broadcast_request] message=", message);
  novo.novoconnect("moderatorRequest", message);
}

function ask_to_be_host(flag) {
//  console.debug("[ask_to_be_host] flag=", flag.toString());
  novo.novoconnect("toBeHost", flag);
}

function sendingImage(uid, qrsrc) {
//  console.debug("[sendingImage] uid=", uid, "qrsrc=", qrsrc);
  novo.novoconnect("previewImage", uid, qrsrc);
}

function receive_screen_pause(flag) {
//  console.debug("[receive_screen_pause] flag=", flag);
  novo.novoconnect("receiveScreenPause", flag);
}

function moderatorRequestApproved(){
//  console.debug("[moderatorRequestApproved]");
  novo.novoconnect('closeWaitingForModeratorRequest', $.t('login.requestAccepted'));
}

function moderatorRequestDenied(){
//  console.debug("[moderatorRequestDenied]";
  novo.novoconnect('closeWaitingForModeratorRequest', $.t('login.requestDeclined'));
}

function messagePage(message) {
//  console.debug("[messagePage] message=", message);
  novo.novoconnect("messagePage", message);
}
function messagePagePinCode() {
//  console.debug("[messagePage] message=", message);
  novo.novoconnect("messagePagePinCode");
}

function openWaitingPageNoTimer(message) {
  console.debug("[openWaitingPageNoTimer] message=", message);
  //var win = chrome.app.window.get("annotationWindow")
  //var annotation = (win && win.contentWindow) || null;
  // console.log(annotation);
  //annotation && annotation.ReconnectingTimer("Reconnecting...");
  novo.novoconnect("openWaitingPageNoTimer", message);
}

function closeWaitingPageWithTimer(message) {
//  console.debug("[closeWaitingPageWithTimer] message=", message);
  novo.novoconnect("closeWaitingPageWithTimer", message);
}

function stopWaitingPageWithTimer() {
//  console.debug("[stopWaitingPageWithTimer] ");
  novo.novoconnect("stopWaitingPageWithTimer");
}

function setInitValue(data) {
  //console.debug("[setInitValue] data=", data);
  novo.novoconnect("setInitValue", data);
  return;
}

function goVoting(data) {
//  console.debug("[goVoting] data=", data);
  novo.novoconnect("goVoting", data);
}

function votingHandler(evt, data) {
//  console.debug("[votingHandler] evt=", evt, "data=", data);
  novo.novoconnect('votingHandler', evt, data);
}

function openModeratorPage(data) {
//  console.debug("[openModeratorPage] data=", data);
  novo.novoconnect("openModeratorPage", data);
}

function askSendAnotherFilePage(data) {
//  console.debug("[askSendAnotherFilePage] data=", data);
  novo.novoconnect("askSendAnotherFilePage", data);
}

function fileTooLargePage() {
//  console.debug("[fileTooLargePage] ");
  novo.novoconnect("fileTooLargePage");
}

function askSendFilePage(data) {
//  console.debug("[askSendFilePage] data=", data);
  novo.novoconnect("askSendFilePage", data);
}

function askSendScreenPage(data) {
//  console.debug("[askSendFilePage] data=", data);
  novo.novoconnect("askSendScreenPage", data);
}

function waitingforSendingPage() {
//  console.debug("[waitingforSendingPage] ");
  novo.novoconnect("waitingforSendingPage");
}

function systemBusyPage() {
//  console.debug("[systemBusyPage] ");
  novo.novoconnect("systemBusyPage");
}

function sendingFilePage(data) {
//  console.debug("[sendingFilePage] data=", data);
  novo.novoconnect("sendingFilePage", data);
}

function closeSendingFilePage() {
//  console.debug("[closeSendingFilePage] ");
  novo.novoconnect("closeSendingFilePage");
}

function receiveURL() {
//  console.debug("[receiveURL] ");
  novo.novoconnect('refreshHistoryDialog');
}

function updateSessionLock() {
  novo.novoconnect('updateSessionLockState');
}

function failSessionLockLogin(message) {
  novo.novoconnect('sessionLockFailLogin', message);
}

function enableVideoProgressBar(state) {
  //TODO: true : enable progress bar function, false : disable progress bar and display 0:00 / 0:00
  //novo.novoconnect('enableVideoProgressBar', state);
}

function sendAnnotationBackground(annotation_screen) {
  console.debug("[sendAnnotationBackground] ");
  novo.novoconnect("setAnnotationBackground", annotation_screen);
}

function refreshAnnotationButton(annotationObject) {
//  console.debug('[refreshAnnotationButton] annotationObject', annotationObject);
  /*
  annotationObject = {
    whoclick = 0,
    whoAnnotating = 0
  };
  */
  novo.novoconnect("setAnnotationBtns", annotationObject);
}

function beAskToCloseAirnote() {
  novo.novoconnect("beAskToCloseAirnote");
}

$(window).resize(function(e) {
  var cnt = $(".ui-dialog-content").length;
  if (cnt > 0) {
    //console.warn("Locate dialog...", cnt);
    $(".ui-dialog-content").dialog("option","position",{ my: "center", at: "center", of: window });
  }
});

function testLogin() {
  console.debug("[testLogin]");

  novo.novoconnect("setInitValue", {
    "imageQuality": 0.6,
    "moderator": false,
    "moderatorPassword": ""
  });
  novo.novoconnect("doLogin", true);
  novo.novoconnect("updateInfo", {
    "message": "You are connected.",
    "ipaddress": "192.168.8.103",
    "pin_value": 8228,
    "qrsrc": "iVBORw0KGgoAAAANSUhEUgAAAJYAAACWCAYAAAA8AXHiAAAABHNCSVQICAgIfAhkiAAABIVJREFUeJzt3dFu3iAMhuFk6v3fcnY6oUiG2K9h2/scrn+TrP1ELSDmfp7nuaRiP9d1Xfd9t950zHL2/qvXy35+lL3f6tdX7fj9/mq9o/4bBksIgyXEz9s/Vtfz2Romul62JsnWUJHVmqr6+qOO368jlhAGSwiDJcRrjTVarQGq511Wa4ZsTTN+vnoe6zTE79cRSwiDJYTBEmKqxupWPc9z2v3+B45YQhgsIQyWEEfWWKvotbLq/VurqvdndXDEEsJgCWGwhJiqsbr/pmf3hFfvQY++P0LXZLu//40jlhAGSwiDJcRrjdW9VlZdU3XvKe/eP5a9f8fv1xFLCIMlhMES4ue6zlt7yq6NRTXE6Wtv1c+34//niCWEwRLCYAkx1R+LXovb3S9rtFqjRV/Prj1293aouL4jlhAGSwiDJcT9PM9DrzXRNVTktB6n3T/fHb0nHLGEMFhCGCwhpvZjZfcXddckq/Nkq89/Wv+v1ftFsvdzHksYgyWEwRLidT9W9d/wbI20WkOtPt/ufljZPfvdPWJnrueIJYTBEsJgCXHEWTrVn8/OY2WfZ0T3iqiuESve03TEEsJgCWGwhPi05736DGP6PEN6/1b12TzZ54nuT9e81+WIJYjBEsJgCfFpHoveU53dD0XXeNXzbKedaV1R0zpiCWGwhDBYQkz1x6ruqx45rYfo39YDlH5ez4TWNgZLCIMlRMlZOt3vFdLzQqu69691r51G13vjiCWEwRLCYAkxtR9rVL1Wt6r7LB16Hoju6VrNeSxtY7CEMFhCTO3HyvY1r67hqtfaqmuySPe8Er22634stTFYQhgsIabWCkf0HvRVu+eZIvR7hPR5hvZ51zEMlhAGS4j7+fAHlH4PL3u97rNl6HcCdvd4/fI8jlhCGCwhDJYQJf2xIt170um+7nTPz+rr7dif5YglhMESwmAJMbVWuHu/Fd37oeM9uxXd+8OImtkRSwiDJYTBEqLkvEJ6noreLxXdb1T9Hh99lk73mdDX5YgliMESwmAJcT/P81SfPUP3uxrtruF278+i5xUjzmOpjcESwmAJ8VpjZdH7f7p7mkb3P+3zo+4a77ocsQQxWEIYLCE+9W6IdPf8rD4/MPr86vW6+19lv7+iJnTEEsJgCWGwhCg5EzpSvV+puj9XtkbqPk8xK3s20szzOWIJYbCEMFhCTO3Hoteusk57b3D3/qxurhWqjcESwmAJ8fpe4Sj7bn+ku59TJFtTdp89NKruK//l+RyxhDBYQhgsIT6dCZ0VrcWdNu/T3de+WnUNa38sbWOwhDBYQnzaj7Wqu+boOPN45fp03/lI9Tyk81jaxmAJYbCE+NTnPdJdw6yi31Mc/W1nBVVwxBLCYAlhsIRAejfQsjVf9/6z6v5Yu9dWZ34+jlhCGCwhDJYQR9RY3Xu+6Z6gEbqv/qi7d4X7sYQxWEIYLCGmaqzuvu3V5x/SPUpXndZjdfV6MxyxhDBYQhgsIV5rrBP28/ypugdp1Guh+iwe+vzGbK+IyJc98I5YQhgsIQyWEPezuxmV/km/Aa2t0URT5SAYAAAAAElFTkSuQmCC",
    "pin_need": false,
    "ssid": "",
    "groupMode": false,
    "groupName": "None",
    "rvaVersion": 2.2,
    "qrObj": {
      "pinStatus": false,
      "pinValue": 8228,
      "deviceName": "Nono-BE948",
      "wifi": {
        "ip": "192.168.8.103",
        "ssid": "\"QQ WiFi\""
      },
      "qrImg": "iVBORw0KGgoAAAANSUhEUgAAAJYAAACWCAYAAAA8AXHiAAAABHNCSVQICAgIfAhkiAAABIVJREFUeJzt3dFu3iAMhuFk6v3fcnY6oUiG2K9h2/scrn+TrP1ELSDmfp7nuaRiP9d1Xfd9t950zHL2/qvXy35+lL3f6tdX7fj9/mq9o/4bBksIgyXEz9s/Vtfz2Romul62JsnWUJHVmqr6+qOO368jlhAGSwiDJcRrjTVarQGq511Wa4ZsTTN+vnoe6zTE79cRSwiDJYTBEmKqxupWPc9z2v3+B45YQhgsIQyWEEfWWKvotbLq/VurqvdndXDEEsJgCWGwhJiqsbr/pmf3hFfvQY++P0LXZLu//40jlhAGSwiDJcRrjdW9VlZdU3XvKe/eP5a9f8fv1xFLCIMlhMES4ue6zlt7yq6NRTXE6Wtv1c+34//niCWEwRLCYAkx1R+LXovb3S9rtFqjRV/Prj1293aouL4jlhAGSwiDJcT9PM9DrzXRNVTktB6n3T/fHb0nHLGEMFhCGCwhpvZjZfcXddckq/Nkq89/Wv+v1ftFsvdzHksYgyWEwRLidT9W9d/wbI20WkOtPt/ufljZPfvdPWJnrueIJYTBEsJgCXHEWTrVn8/OY2WfZ0T3iqiuESve03TEEsJgCWGwhPi05736DGP6PEN6/1b12TzZ54nuT9e81+WIJYjBEsJgCfFpHoveU53dD0XXeNXzbKedaV1R0zpiCWGwhDBYQkz1x6ruqx45rYfo39YDlH5ez4TWNgZLCIMlRMlZOt3vFdLzQqu69691r51G13vjiCWEwRLCYAkxtR9rVL1Wt6r7LB16Hoju6VrNeSxtY7CEMFhCTO3HyvY1r67hqtfaqmuySPe8Er22634stTFYQhgsIabWCkf0HvRVu+eZIvR7hPR5hvZ51zEMlhAGS4j7+fAHlH4PL3u97rNl6HcCdvd4/fI8jlhCGCwhDJYQJf2xIt170um+7nTPz+rr7dif5YglhMESwmAJMbVWuHu/Fd37oeM9uxXd+8OImtkRSwiDJYTBEqLkvEJ6noreLxXdb1T9Hh99lk73mdDX5YgliMESwmAJcT/P81SfPUP3uxrtruF278+i5xUjzmOpjcESwmAJ8VpjZdH7f7p7mkb3P+3zo+4a77ocsQQxWEIYLCE+9W6IdPf8rD4/MPr86vW6+19lv7+iJnTEEsJgCWGwhCg5EzpSvV+puj9XtkbqPk8xK3s20szzOWIJYbCEMFhCTO3Hoteusk57b3D3/qxurhWqjcESwmAJ8fpe4Sj7bn+ku59TJFtTdp89NKruK//l+RyxhDBYQhgsIT6dCZ0VrcWdNu/T3de+WnUNa38sbWOwhDBYQnzaj7Wqu+boOPN45fp03/lI9Tyk81jaxmAJYbCE+NTnPdJdw6yi31Mc/W1nBVVwxBLCYAlhsIRAejfQsjVf9/6z6v5Yu9dWZ34+jlhCGCwhDJYQR9RY3Xu+6Z6gEbqv/qi7d4X7sYQxWEIYLCGmaqzuvu3V5x/SPUpXndZjdfV6MxyxhDBYQhgsIV5rrBP28/ypugdp1Guh+iwe+vzGbK+IyJc98I5YQhgsIQyWEPezuxmV/km/Aa2t0URT5SAYAAAAAElFTkSuQmCC",
      "isHost": true
    },
    "client_name": "Vince"
  });
  novo.novoconnect("stopWaitingPageWithTimer");
  novo.novoconnect("toBeHost", true);
  novo.novoconnect("receiveScreenPause", false);
  novo.novoconnect("setViewMode", "full");

  var userList = [{
    "uid": 1,
    "label": "Vince",
    "isHost": true,
    "device": "Chrome on Win",
    "panel": 0,
    "isMyself": true,
    "showSnapshot": true,
    "online": true,
    "display_name": "Vince",
    "os_type": 10
  }];
  novo.novoconnect("updateUserList", userList);
  $("#icon-tool").trigger("click");

  /*
    $("#rva_url").val("192.168.8.103");
    $("#client_name").val("Vince");
    $("#connect-btn").trigger("click");
  */

}