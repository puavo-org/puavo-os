var manifest = {};
$.getJSON( "../manifest.json", function(data) {
  manifest = data;
});
var lastManualIP = "";
var showClientNameInput = false;
var presenterImgs = {
  "-1": '../images/screen_default.png',
   "0": '../images/screen_full.png',
   "1": '../images/screen_channel_01.png',
   "2": '../images/screen_channel_02.png',
   "3": '../images/screen_channel_03.png',
   "4": '../images/screen_channel_04.png',
};
var presenterImages = {
   "-1": '../images/mirrorPanel/screen_default.png',
    "0": '../images/mirrorPanel/screen_full.png',
    "1": '../images/mirrorPanel/screen_channel_01.png',
    "2": '../images/mirrorPanel/screen_channel_02.png',
    "3": '../images/mirrorPanel/screen_channel_03.png',
    "4": '../images/mirrorPanel/screen_channel_04.png',
   "10": '../images/mirrorPanel/screen_full_hover.png',
   "11": '../images/mirrorPanel/screen_channel_01_hover.png',
   "12": '../images/mirrorPanel/screen_channel_02_hover.png',
   "13": '../images/mirrorPanel/screen_channel_03_hover.png',
   "14": '../images/mirrorPanel/screen_channel_04_hover.png',
};
var presenterImagesUnWithdraw = {
        "-1": '../images/mirrorPanel/screen_default.png',
          "0": '../images/mirrorPanel/screen_full_hover.png',
          "1": '../images/mirrorPanel/screen_channel_01_hover.png',
          "2": '../images/mirrorPanel/screen_channel_02_hover.png',
          "3": '../images/mirrorPanel/screen_channel_03_hover.png',
          "4": '../images/mirrorPanel/screen_channel_04_hover.png',
        "10": '../images/mirrorPanel/screen_full_hover.png',
        "11": '../images/mirrorPanel/screen_channel_01_hover.png',
        "12": '../images/mirrorPanel/screen_channel_02_hover.png',
        "13": '../images/mirrorPanel/screen_channel_03_hover.png',
        "14": '../images/mirrorPanel/screen_channel_04_hover.png',
      };

$.widget("custom.novoconnect", {
  // Default options
  options: {
    deviceModel: 'NovoConnect-B380',  // NovoConnect-B380 / NovoConnect-NE3000 / NovoConnect-NT1000 / NovoConnect-NC1000 / ...
    rvaModel: 'NovoPro',    // NovoPro / NovoEnterprise / NovoConnect / NovoCast / NovoTouch / ...
    rvaType: 'EDU',         // 'EDU': Education  'CORP': Corporation
    rvaVersion: 3.0,
    flexibleUserList: false,  // true/false, only NovoEnterprise 3.0.0 true
    os: '', // 9 cros/10 win/11 mac
    connected: false, // true/false
    isHost: false, // true/false
    groupMode: false, // true/false
    groupName: "Not selected",
    pinMandatory: false, // true/false
    pinRequired: false, // true/false
    pinCode: "----",
    qrObj: null,
    viewMode: "full",
    hasProjectionPrevilege: false,  // true/false
    sharedScreenNo: 1,   // 0:none 1:primary-display(default) 2:secondary-display
    sessionLockedMode: false, // true/false - after NovoPro v2.3
    nowPage: "#icon-connect", // #icon-connect/#icon-group/#icon-tool/#icon-offline-tool
    userList: [],              // display user list
    userListSortKey: 'name',   // name/time
    viewModel: null,
    projectionData: {grayOut: true},
    rvaWidth: 1920,
    rvaHeight: 1080,
    isHideVoting: false,
    videoMode: false, // after v1.5
    supportVoting: 1,          // -1: never support / 0: need to upgrade / 1: after NovoPro v1.5
    votingObject: null,
    sharingMode: 1, // -1: never support / 0: need to upgrade / 1: after NovoPro v1.6
    supportPreview: true,
    moderator: false, // true/false
    imageQuality: 0.6, // 0.6/0.8/0.97
    sendingFile: {
      sending: false, // true/false
      file: null,
      percentage: 0,
      finished: 0,
      total: 0
    },
    annotation: {             // after NovoPro 2.3.0
      annotateWindow: false,  // annotation window is open or not
      rvaAirnoteStatus: 0,        // 0/1/2,  0: nobody  1: it's me  2: not me
      whoAnnotating: 0,       // 0/1/2,  0: nobody  1: it's me  2: not me
      notifyRvaClose: true    // true: notify rva   false: not notify rva
    },
    //annotatebg: null,
    receivingFile: false, // true/false
    screenNo: -1,              // playing on screen number
  },
  
  //new UI
  _create: function _create() {
    var instance = this;
    // ko.bindingProvider.instance = new ko.secureBindingsProvider();
    // this.options.viewModel = new UserViewModel(this.options.userList);
    // ko.cleanNode($("*[data-sbind]")[0]);
    // ko.applyBindings(this.options.viewModel);

    // TaskBar: close
    $(".icon-close").off().click(function(){
      instance.askQuitDsa();
    });
    // TaskBar: minimize
    $(".icon-minimize").off().click(function(){
      windows_minimize();
    });

    $('#toggle-settings-block').off().click(function(){
      if ($(this).css("display")=="block"){
        $('.login').removeClass("expand");
      }
      $("#setting").toggle();
    });


    $('#toggle-moderator-block').off().click(function(){
      if ($(this).css("display") == "block") {
        $('.login').removeClass("expand");
      }      
      $("#moderator-credential").toggle();
    });

    $(".icon-logo").off().click(function(){
      instance._displayAboutInfo();
    });

    $("#logo").off().click(function(){
      instance._displayAboutInfo();
    });
    
    chrome.runtime.getPlatformInfo(function (info) {
      // Display host OS in the console
      //console.log(info.os);
      instance.options.os = info.os;
    });

    instance._initSetting();

    $("#container").show();

  },
  //new UI
  _init: function _init() {
    var instance = this;
    instance._hideAllpages();
    // Connected
    if (instance.options.connected) {
      $(".taskbar .disconnect").hide();
      $(".taskbar .connected").show();
      $(".connected-part").show();
      instance._removeAllDialogs();
      $("#connect-btn").off();

      // Disconnect button
      $("#disconnect-btn").off().click(function(event){
        event.preventDefault();
        instance._doLogout();
        return false;
      });

      // QR button
      $('#qr-btn').off().click(function(event){
        event.preventDefault();
        // console.info('Open QR page...', instance.options.qrObj);

        // The window exists.
        if (qrWin = chrome.app.window.get("qrWindow")) {
          qrWin.contentWindow.displaySessionInfo(
            instance.options.qrObj,
            instance.options.rvaVersion
          );
          qrWin.show(true);
          return;
        }

        // open new window
        chrome.app.window.create(
          '../views/qrimage.html', {
            id: "qrWindow",
            bounds: {
              width: 540,
              height: 615
            },
            frame: 'none',
            resizable: false,
          },
          function (createdWindow) {
            //console.info("I am new open....");
            qrWin = createdWindow.contentWindow;
            createdWindow.onClosed.addListener(function () {
              qrWin = null;
              chrome.app.window.current().show(true);
              if (sessionInfoOn && instance.options.isHost) {
                send_Close_SESSION_INFO();
              }

            });
            qrWin.onload = function () {
              this.displaySessionInfo(
                instance.options.qrObj,
                instance.options.rvaVersion
              );
            }
          }
        );

      });

      // connected information
      $('#toggleConnectedInfo').off().click(function(){
        $('#setting-info').hide();
        $('#toggleSettingsInfo').removeClass("up");
        if ($(this).hasClass('up')) {
          $('#connected-info').hide();
          $(this).toggleClass('up');
          return;
        }
        $(this).toggleClass('up');
        $('#connected-info').show();
      });

      // connected information
      $('#toggleConnectedInfo').off().click(function(){
        $('#setting-info').hide();
        $('#toggleSettingsInfo').removeClass("up");
        if ($(this).hasClass('up')) {
          $('#connected-info').hide();
          $(this).toggleClass('up');
          return;
        }
        $(this).toggleClass('up');
        $('#connected-info').show();
        instance.refresh();
      });

      // Setting information
      $('#toggleSettingsInfo').off().click(function(){
        $('#connected-info').hide();
        $('#toggleConnectedInfo').removeClass("up");
        if ($(this).hasClass('up')) {
          $('#setting-info').hide();
          $(this).toggleClass('up');
          return;
        }
        $(this).toggleClass('up');
        $('#setting-info').show();
        var w = $('#setting-info').width() - 40 - $('#settings-info-label').width();
        $('#setting-info .set-line').width(w);
      });
      
      if (!instance.options.isHideVoting){
        $("#open-voting").removeClass("hide");
        $('#open-voting-text').text($.t('info.openVoting'));
      }
      
      instance._enableTaskbar();
      instance.refresh();
      $(instance.options.nowPage).trigger("click");
      return;
    }

    // Disconnect
    if (!instance.options.connected) {
      $("#pin_code").val("");
      $("#open-voting").removeClass("hide").addClass("hide");
      $(".taskbar .disconnect").show();
      $(".taskbar .connected").hide();
      $(".login").show();
      $("#disconnect-btn").off().click(function (event) {
        event.preventDefault();
        return false;
      });

      // // Connect button
      // $("#connect-btn").off().click(function(event){
      //   event.preventDefault();
      //   instance._removeAllDialogs();
      //   instance._login();
      // });

      $(".userImg").off().click(function (event) {
        if (!$("#client_name").val()) {
          $(".nameInput").removeClass("displayInput").addClass("displayInput");
          $('.nameInput .tooltip').text($.t("login.nameRequired")).show();
          $("#client_name").addClass("red").focus();
          $(".err").show();
          $(".done").hide();
          return;
        }
        $(".nameInput").toggleClass("displayInput");
        $(".done").hide();
        if ($(".nameInput").hasClass("displayInput")){
          $("#client_name").focus();
          $(".done").show();
        }
        instance.checkManualIP();
        $("#manualIP").removeClass("displayInput");
        return;
      });

      $(".nameInput .done").off().click(function (event) {
        if (!$("#client_name").val()) {
          $(".nameInput").removeClass("displayInput").addClass("displayInput");
          $('.nameInput .tooltip').text($.t("login.nameRequired")).show();
          $("#client_name").addClass("red").focus();
          $(".err").show();
          $(".done").hide();
          return false;
        }        
        $(".nameInput").removeClass("displayInput");
        $(".done").hide();
        $('#toggle-drop-setting').removeClass("focus");
        $(".tooltip").hide();
        return false;
      });

      $("#client_name").off().click(function (event) {
        $(".pinCode .tooltip").hide();
        if (!$("#client_name").val()) {
          $(".nameInput").removeClass("displayInput").addClass("displayInput");
          $("#client_name").addClass("red").focus();
          $(".err").show();
          $(".done").hide();   
          return false;
        }
        if ($(".nameInput").hasClass("displayInput")){
          return false;
        }
        $(".err").hide();
        $(".nameInput").hasClass("displayInput") ? $(".done").hide() : $(".done").show();
        $(".nameInput").toggleClass("displayInput");
        $("#client_name").removeClass("red");
        instance.checkManualIP();
        $(".manualIP").removeClass("displayInput");
        return false;
      });
      $("#client_name").on('change keyup mouseup blur', function (e) {
        if ($("#client_name").val()) {
          $(".err").hide();
          $(".done").show();
          $("#client_name").removeClass("red");
          $(".nameInput .tooltip").hide();
          showClientNameInput = false;   
        }else{
          $(".nameInput").removeClass("displayInput").addClass("displayInput");
          $("#client_name").addClass("red");
          $(".err").show();  
          $(".done").hide();
          $(".nameInput .tooltip").show();
        }
        return false;
      });
      $(".manualIpImg").off().click(function (event) {
        instance.checkManualIP(true);
        if ($("#client_name").val()) {
          $(".nameInput").removeClass("displayInput");
          $(".done").hide(); 
        }  
         $(".manualIP").toggleClass("displayInput");
        return false;
      });      
      $(".manualIP").off().click(function (event) {
        $('#toggle-drop-setting').removeClass("focus");
        if (!showClientNameInput) {
          $(".nameInput").removeClass("displayInput");
          $("#client_name").removeClass("red");
          $(".done").hide();
          $(".nameInput .tooltip").hide();
        }
        if ($(".manualIP").hasClass("displayInput")) {
          return false;
        }
        instance.checkManualIP(true);
        $(".manualIP").toggleClass("displayInput");
        return false;
      });
      $("#rva_url_input").val($.t("login.manualIInputIP")).off().on('paste', function (e) {
        $("#manualIP_Connect").removeClass("active");
        if (e.originalEvent.clipboardData.getData('text') != "") {
          $("#manualIP_Connect").addClass("active");
        }
        $("#rva_url").val(e.originalEvent.clipboardData.getData('text'));
      });
      
      $("#rva_url_input").on('change keyup mouseup', function (e) {
        $("#manualIP_Connect").removeClass("active");
        if ($(this).val()  != ""){
          $("#manualIP_Connect").addClass("active");
        }
        var n = $("#manualIP_Connect").width() + 60 ;
        $(this).css("paddingRight", n > 457 ? 400 : n + 'px');
        $("#rva_url").val($(this).val());
      });

      $(".exDown").off().click(function () {
        $(this).parent().parent().removeClass("down").addClass("up").find(".ipList").removeClass("expand").addClass("expand");
        return false;
      });

      $(".exUp").off().click(function () {
        $(this).parent().parent().removeClass("up").addClass("down").find(".ipList").removeClass("expand");
        return false;
      });

      $("#manualIP_Connect").off().click(function () {
        if (!$("#manualIP_Connect").hasClass("active")){
          return false;
        }
        $("#rva_url").val($("#rva_url_input").val());
        event.preventDefault();
        instance._removeAllDialogs();
        instance._login();
      });

      // TaskBar: offline-tool
      $("#icon-offline-tool").show().off().click(function () {
        instance._removeAllDialogs();
        if ($(this).hasClass("focus")) {
          $(this).removeClass("focus");
          instance._hideAllpages();
          $(".login").show();
          return;
        }
        $(this).addClass("focus");
        instance._hideAllpages();
        $(".tool-list").show();
        return false;
      });

      $('#toggle-drop-setting').off().click(function(){
        $(".pinCode .tooltip").hide();
        instance._hideAllPopup();
        $(this).toggleClass("focus");
        return false;
      });

      // Close if outside click
      $(".connected").off().on('click',function(e){
        instance._hideAllPopup();
        return false;
      });
      $(document).off().on('click',function(e){
        instance._hideAllPopup();
        if (e.which != 1) {
            e.preventDefault();
            //console.debug("document - middle click", e.which, e);
            return false;
        }
      });

      // toggle setting
      $('#toggle-setting').off().click(function(){
        instance._resetBlocks();
        $('#setting').show();
        $('.login').removeClass("expand").addClass("expand");
        return false;
      });

      // toggle modertor credentials
      $('#toggle-modertor').off().click(function(){
        instance._resetBlocks();
        $('#moderator-credential').show();
        $('.login').removeClass("expand").addClass("expand");
        return false;
      });

      $("#pin_code").on('focus', function (e) {
        $(".pinImg").animate({
          fontSize: ".5rem",
          left: "10px",
          top: "5px",
        }, 200);
        $("#pin_code").animate({ borderColor: 'black' }, 0)
          .delay(200)
          .animate({ borderColor: '#B2B2B2' }, 200);    
          var v = $(this).val();
          if (v.length == 0 || (v.length == 4 && !isNaN(v))) {
            $("#pin_code").removeClass("red");
            $(".pinCode .tooltip").hide();
            return false;
          }
          if (v.length > 0 && (v.length < 4 || isNaN(v))) {
            $("#pin_code").addClass("red");
            $(".pinCode .tooltip").show();
            return false;
          }
      });
      $("#pin_code").on('blur', function (e) {
        if (!$("#pin_code").val()){
          $(".pinImg").animate({
            fontSize: "14px",
            left: "30px",
            top: "10px",
          }, 200);
        }
      });
      $(".pinImg").click( function (e) {
        $("#pin_code").focus();
      })
      $("#pin_code").on('click change keyup', function (e) {
        instance._hideAllPopup();
        var v = $(this).val();
        if (v.length == 0 || (v.length == 4 && !isNaN(v))) {
          $("#pin_code").removeClass("red");
          $(".pinCode .tooltip").hide();
          return ;
        }
        if (v.length > 0 && (v.length < 4 || isNaN(v))) {
          $("#pin_code").addClass("red");
          $(".pinCode .tooltip").show();
          if (!showClientNameInput) {
            $(".nameInput").removeClass("displayInput");
            $("#client_name").removeClass("red");
            $(".done").hide();
            $(".nameInput .tooltip").hide();
          }
          return ;
        }
      });
      
      $('#moderator').off().change(function(){
        save_Moderator_Status($(this).prop("checked"));

        if ($(this).prop("checked")){
          // enable Teacher credentials
          $('.pwBlock').show();
          $('#toggleTeacherPw').focus();
          return;
        }
        // disable Teacher credentials
        $('.pwBlock').hide();
      });

      $('#toggleTeacherPw').focusout(function() {
        var pw = $(this).val();
        if (pw=="") {
          $('.pwBlock').addClass('error');
          $('.toggleTeacherPwMsg').text($.t('login.required'));
          $(this).focus();
          return;
        }
        if (pw.length < 4 || pw.length > 24) {
          $('.pwBlock').addClass('error');
          $('.toggleTeacherPwMsg').text($.t('login.moderatorPasswordLength'));
          // $(this).focus();
          return;
        }
        $('.pwBlock').removeClass('error');
        $('.toggleTeacherPwMsg').empty();
        save_Moderator_Password(pw);
      });


      $(".tool-list > div").not('#launch-screenote').addClass("disable");

      // Enable Tool: Voting
      if (!instance.options.isHideVoting){
        $("#open-voting").removeClass("disable").off().click(function(){
          instance._openVotingEditor();
        });
      }

      $('.online-edu').hide();

      $("#toggle-airnote").hide();

      instance._disableSharing();
    }
  },
  _hideAllPopup: function _hideAllPopup (){
    console.log("_hideAllPopup");
    var instance = this;
    // Tool blocks
    $('#drop-sharing').removeClass('open');
    $("#drop-airnote").removeClass('open');
    $("#drop-airnote-user").removeClass('open');
    // user list
    $('#drop-userlist-menu').removeClass('open');
    $('#drop-person-menu').remove();
    $(".viewArea > li").removeClass("focused");
    $(".project-user").removeClass("clicked");
    // offline
    $('#toggle-drop-setting').removeClass("focus");
    $("#drop-mode").fadeOut(500);
    if (!showClientNameInput ) {
      $(".nameInput").removeClass("displayInput");
      $("#client_name").removeClass("red");
      $(".done").hide();
      $(".nameInput .tooltip").hide();
    } else {
      showClientNameInput = false;
    }
    if ($(".manualIP").hasClass("displayInput")) {
      instance.checkManualIP();
      $(".manualIP").removeClass("displayInput")
    }
    $(".iplistDiv").removeClass("down").removeClass("up").addClass("down").find(".ipList").removeClass("expand");
  }, 
  refreshIPList: function refreshIPList(ipList) {  
    $(".connHistory .ipList").empty();  
    var history = 0;
    ipList.sort(function (a, b) {
      return b.times - a.times;
    });
    for (var i = 0; i < ipList.length; i++) {
      this.createHistoryIpList(ipList[i]);
      history++;
    } 
    (history == 0) && $(".connHistory .ipList").append($("<span class='noDevice'>").text($.t('login.noHistoryData')));
  },
  createHistoryIpList: function createHistoryIpList(data) {  
    var instance = this;
    var ip = "";
    var name = "";
    ip = data.value;
    name = data.label.substring(ip.length + 1, data.label.length);
    var div = $('<div class="ipListRow">')
      .append($('<div class="img">').append(data.broadcast === true ? '<img src="../images/nearbyDevice.png"/></div>' : ""))  
      .append($('<div class="ip">').text(ip))
      .append($('<div class="name">').text(name))
      .off().click(function (e) {
        $("#rva_url").val(data.value);
        e.preventDefault();
        instance._removeAllDialogs();
        instance._login();   
        return false;   
      });
    $(".connHistory .ipList").append(div);
  },
  createNearbyDeviceIpList: function createNearbyDeviceIpList(data) {
    var div = $('<div class="ipListRow">').text(data.label).off().click(function (event) {
      return false;   
    });
    $(".nearByDevice .ipList").append(div);
  },
  checkManualIP: function checkManualIP(active){
     if ($(".manualIP").hasClass("displayInput")) {
      lastManualIP = $("#rva_url_input").val();
      $("#rva_url_input").val($.t("login.manualIInputIP")).blur();

    } else {
      var ip = rvaIP || lastManualIP || $(".connHistory .ipList .ipListRow:first-child .ip").text() ;
      if (active){
        $("#rva_url_input").val(ip).focus();
      }
      $("#manualIP_Connect").removeClass("active");
      if ($("#rva_url_input").val() != "") {
        $("#manualIP_Connect").addClass("active");
      }
    }
  },
  showClientNameTooltip: function showClientNameTooltip(msg) {
    $('.nameInput .tooltip').text(msg).show();
    $(".nameInput").removeClass("displayInput").addClass("displayInput");
    $("#client_name").focus().addClass("red");
    $(".done").show();
    showClientNameInput = true;
    this.messagePage(msg);
  },
  _removeAllDialogs: function _removeAllDialogs(){
    // console.log('_removeAllDialogs...');
    $(novo).css('height','');
    if ($('.message-page').length > 0){
      $('.message-page').dialog('destroy').remove();
    }
    $(".ui-effects-wrapper").remove();
  },

  //new UI
  _initSetting: function _initSetting() {
    //console.warn("[_initSetting]...");
    var instance = this;

    $('[name="videoQuality"]').off().change(function(){
      setup_image_rate($(this).val());
      $('[name="videoQualityConnected"]').val($(this).val());
      return false;
    }).click(function(){
      return false;
    });

    $('[name="videoQualityConnected"]').off().change(function(){
      setup_image_rate($(this).val());
      $('[name="videoQuality"]').val($(this).val());
      return false;
    }).click(function () {
      return false;
    });

    $('[name="notifyOption"]').off().change(function(){
      update_notificationOn(($(this).val() == "true"));
      $('[name="notifyOptionConnected"]').val($(this).val());
      return false;
      //console.warn("[_initSetting] notifyOption=", $(this).val(), ($(this).val() == "true"));
    }).click(function () {
      return false;
    });

    $('[name="notifyOptionConnected"]').off().change(function(){
      update_notificationOn(($(this).val() == "true"));
      $('[name="notifyOption"]').val($(this).val());
      return false;
      //console.warn("[_initSetting] notifyOption=", $(this).val(), ($(this).val() == "true"));
    }).click(function () {
      return false;
    });
  },
  setInitValue: function setInitValue(data) {
    console.warn("[setInitValue] data=", data);
    
    //display last login name
    if (data.client_name != undefined) {
      $('#client_name').val(data.client_name);
    }
    
    //display last rva url
    if (data.rva_url != undefined) {
      $('#rva_url').val(data.rva_url);
      $('#project').val(data.rva_url);
    }

    
    if (data.imageQuality != undefined) {
      this.options.imageQuality = data.imageQuality; // 0.6/0.8/0.97;
      $('[name="videoQuality"]').val(this.options.imageQuality);
      $('[name="videoQualityConnected"]').val(this.options.imageQuality);
    }
    
    //console.warn("[setInitValue] notificationOn =", data.notificationOn);
    if (data.notificationOn != undefined) {
      $('[name="notifyOption"]').val(data.notificationOn.toString());
      $('[name="notifyOptionConnected"]').val(data.notificationOn.toString());
    }

    if (data.moderator != undefined) {
      this.options.moderator = data.moderator; // true/false;
      var moderator = this.options.moderator;
      $('#moderator').prop('checked', moderator);
      (moderator)? $('.pwBlock').show() : $('.pwBlock').hide();
      var password = data.moderatorPassword;
      if (password == undefined || password == null || password=="") {
        $('.pwBlock').addClass('error');
        $('.toggleTeacherPwMsg').text($.t('login.required'));
      }
    }

    if (data.moderatorPassword != undefined) {
      this.options.moderatorPassword = data.moderatorPassword; // string;
      $('#toggleTeacherPw').val(this.options.moderatorPassword);
    }
  },

  _initUserList: function _initUserList() {
    //console.warn('[_initUserList] isflexibleGUI, supportVoting=', isflexibleGUI, supportVoting);
    // var rvaModel = rvaModels[info.deviceModel];

    var flexibleUserList = this.options.flexibleUserList = isflexibleGUI;

    var connectedList = $(".connected-list").empty(); // clear all user list
    //console.warn('[_initUserList] rvaModel=', rvaModel, "flexibleUserList=", flexibleUserList);

    var rightSide;
    if (flexibleUserList) {
      console.debug('[_initUserList] initialize flexible User List');

      var viewer = $("<li>").attr("data-sbind","attr: { uid: uid, panel: data().panel, isMyself: data().isMyself, showSnapshot : showSnapshot , data-osType : osType }").append($('<span data-sbind="text: username">'));
      var viewers = $('<div class="view">').append($('<div>').append($('<div>').addClass("viewArea").attr("data-sbind","foreach: flexibleViews").append(viewer)));
      var rightSide = $('<div class="rightSide">');

      // top functions
      $('<div>').append(viewers).append(rightSide).appendTo(connectedList);

      if (isflexibleGUIDnD){
        viewer.append(
          $('<div class="tools">')
            .append($('<span>').addClass("goFull").text($.t("info.fullScreen")))
            .append($('<span>').addClass("goStop").text($.t("info.stopMirroring")))
        );
      }

      // nonGroupMode
      $('<div id="nonGroupMode">').append(
        $('<div id="edu-lock-session">')
          .append($('<span class="icon">'))
          .append($('<span>').text($.t("info.lockSession")))
      ).appendTo(rightSide);

      var userlistMenu = $('<div id="userlistMenu">').appendTo(rightSide);

      // user list menu
      $('<div id="totalFunctions">').append(
        $('<span class="countUser">')
          .append($('<span>').text($.t("info.total")))
          .append($('<span>').attr("data-sbind", "text: displayUsers().length").text(1))
      ).append(
        $('<span class="sort-key navy">').attr("title", $.t("group.sortBy"))
          .append($('<span class="icon-sort">'))
          .append($('<span class="guillemet triangleDown">'))
      ).appendTo(userlistMenu);

      // Group Mode function
      $('<div id="groupFuncArea">').attr("data-sbind", "visible: groupMode()").append(
        $('<div id="group-select" class="navy">')
          .append($('<span class="guillemet triangleRight">'))
          .append($('<span>').attr("data-sbind", "text: groupName()"))
      ).append(
        $('<ul id="group-tabs">').append(
          $('<li display="0">')
            .append($('<span>').text($.t("group.all"))).append(' (').append($('<span>').attr("data-sbind", "text: allusers().length")).append(')')
        ).append(
          $('<li display="1">')
            .append($('<span>').text($.t("group.online"))).append(' (').append($('<span>').attr("data-sbind", "text: onlineCount()")).append(')')
        ).append(
          $('<li display="2">')
            .append($('<span>').text($.t("group.offline"))).append(' (').append($('<span>').attr("data-sbind", "text: offlineCount()")).append(')')
        )
      ).append(
        $('<div id="dialog-group-list">').addClass("hide").append($('<div id="g-list"></div>'))
      ).appendTo(userlistMenu);

    }


    if (!flexibleUserList) {
      //console.warn('[_initUserList] initialize user list for NovoPro/NovoTouch/NovoCast/NovoConnect');
      rightSide = $('<div>').addClass("right-side").append(
        $('<span>').addClass("sort-key navy").attr('title', $.t("group.sortBy"))
                      .append($('<span>').addClass("icon-sort"))
                      .append($('<span>').addClass("guillemet triangleDown"))
                  );
      // top functions
      $('<div>').append(
        // full screen
        $('<div>').addClass("full-view").append(
          $('<ul>').addClass("view-list").append(
            $('<li>')
              .append('<img src="../images/img_List_title_presenter.png" />')
              .append($('<span>').attr("data-sbind","text: fullViewName()"))
            )
        )
      ).append(
        // split screen
        $('<div>').addClass("split-view").append(
          $('<ul>').addClass("view-list")
            .append($('<li>1. <span data-sbind="text: splitViews()[0]"></span></li>'))
            .append($('<li>2. <span data-sbind="text: splitViews()[1]"></span></li>'))
            .append($('<li>3. <span data-sbind="text: splitViews()[2]"></span></li>'))
            .append($('<li>4. <span data-sbind="text: splitViews()[3]"></span></li>'))
        )
      ).append(rightSide).appendTo(connectedList);
    }

    if (!flexibleUserList) {
      //console.warn('[_initUserList] initialize "EDU" user list for NovoPro/NovoTouch/NovoCast/NovoConnect');
      // nonGroupMode
      $('<div id="nonGroupMode">').append(
        $('<div class="left">').append(
          $('<div id="edu-lock-session">')
            .append($('<span>').addClass("icon"))
            .append($('<span>').text($.t("info.lockSession")))
        )
      ).append(
        $('<div class="right">')
          .append($('<span>').text($.t("info.total")))
          .append($('<span>').attr("data-sbind","text: displayUsers().length"))
      ).appendTo(connectedList);

      // Group Mode function
      $('<div id="groupFuncArea">').attr("data-sbind","visible: groupMode()").append(
        $('<div id="group-select" class="navy">')
          .append($('<span>').addClass("guillemet triangleRight"))
          .append($('<span>').attr("data-sbind","text: groupName()"))
      ).append(
        $('<ul id="group-tabs">').append(
          $('<li display="0">')
            .append($('<span>').text($.t("group.all"))).append(' (').append($('<span>').attr("data-sbind", "text: allusers().length")).append(')')
        ).append(
          $('<li display="1">')
            .append($('<span>').text($.t("group.online"))).append(' (').append($('<span>').attr("data-sbind", "text: onlineCount()")).append(')')
        ).append(
          $('<li display="2">')
            .append($('<span>').text($.t("group.offline"))).append(' (').append($('<span>').attr("data-sbind", "text: offlineCount()")).append(')')
        )
      ).append(
        $('<div id="dialog-group-list">').addClass("hide").append($('<div id="g-list"></div>'))
      ).appendTo(connectedList);
    }

    // [All] User List Div
    $('<div>').addClass("user-list").append(
      $("<ul>").attr("data-sbind","css: iamHostClass() + hasHostClass(), foreach: displayUsers").append(
        $("<li>").addClass("user").attr("data-sbind","attr: { id: uid, data-osType : osType }, css: online + ' ' + isMyself + ' ' + showSnapshot + ' ' + playing, hoverToggle: 'focused'").append(
          $("<table>").append(
            $("<tr>")
              .append($('<td class="icon-user" rowspan="2">').attr("data-sbind","css: ishost"))
              .append($('<td class="user-name">').attr("data-sbind","css: ishost, text: username"))
              .append($('<td class="user-control" rowspan="2">').attr("data-sbind", "css: isAirNote")
                  .append($('<div class="airnote-user" data-sbind="css: isAirNote">'))
                  .append($('<div class="project-user">').attr("data-sbind","css: panelcss")
                    .append($('<div class="panel">').attr("data-sbind","css: panelcss, attr: { src: panelimgsrc, no: data().panel }"))
                    .append($('<div class="panel-overlay">'))
                )
              )
          ).append(
            $("<tr>").append($('<td class="user-device">').attr("data-sbind","text: data().device"))
          )
        )
      )
    ).appendTo(connectedList);

    // initialize KnockoutJS
    ko.bindingProvider.instance = new ko.secureBindingsProvider();
    this.options.viewModel = new UserViewModel(this.options.userList);
    ko.cleanNode($(connectedList)[0]);
    ko.applyBindings(this.options.viewModel, $(connectedList)[0]);

    var instance = this;
    $('.sort-key').addClass((instance.options.userListSortKey=='time')? 'byTime' : '').off().click(function(){
      instance.options.userListSortKey = $(this).hasClass('byTime')? 'name' : 'time';
      instance.refresh();
      $(this).toggleClass('byTime');
    });

    this.refresh();
  },

  _resetBlocks: function _resetBlocks() {
    this._removeAllDialogs();
    this._hideAllpages();
    $('.login').show();
    $("#icon-offline-tool").removeClass("focus");
    $('#toggle-drop-setting').removeClass("focus");
    $('#setting').hide();
    $('#moderator-credential').hide();
    $('.login').removeClass("expand");
  },
  _login: function _login() {
    //console.log("_login......");
    var instance = this;
    pinCode = $("#pin_code").val();
    isPIN = !!pinCode;
    instance.openWaitingPageNoTimer($.t('login.connecting'));

    var rvaIp = $.trim($('#rva_url').val());
    //if (rvaIp == "" || !validateIPaddress(rvaIp)) {
    if (rvaIp == "") {
      instance.messagePage($.t('login.ipInvalid')); // i18n
      return;
    }
    showClientNameInput = false;
    $(".pinCode .tooltip").hide();
    $("#pin_code").removeClass("red").val("");
    $(".pinImg").animate({
      fontSize: "14px",
      left: "30px",
      top: "10px",
    }, 200);
    connection_request();
  },
  doLogin: function doLogin(result) {
    //console.debug("[doLogin]", result, info);
    // Real Login
    if (result) {
      this.options.connected = true; // set connected
      this._initUserList();
    }
    this._init();
  },
  _doLogout: function _doLogout() {
    console.log("Logout.");
    var win = chrome.app.window.get("annotationWindow");
    if (win) {
      stop_ANNOTATION();
    }
    connection_remove();
    chrome.notifications.clear("screen");
    this._removeAllDialogs();
    
    // Close all child windows
    for (var i = 0, wins = chrome.app.window.getAll(); i < wins.length; i++) {
      if (wins[i] != chrome.app.window.current()){
        wins[i].close();
      }
    }

    // Clear options...
    this._disableTaskbar();
    this._resetInfo();

    this._init();
  },
  _resetInfo: function _resetInfo() {

    this.options.deviceModel = 'NovoConnect-B380';
    this.options.rvaModel = 'NovoPro';
    this.options.rvaType = 'EDU';
    this.options.rvaVersion = 3.0;
    this.options.flexibleUserList = false;

    this.options.os = '';
    this.options.connected = false;
    this.options.isHost = false;
    this.options.groupMode = false;
    this.options.groupName = "Not selected";
    this.options.pinRequired = false;
    this.options.pinCode = "----";
    this.options.qrObj = null;
    this.options.viewMode = "full";
    this.options.nowPage = '#icon-connect';
    this.options.videoMode = false;
    this.options.supportVoting = false;
    this.options.votingObject = null;
    this.options.sharingMode = 1;
    this.options.moderator = false;
    this.options.imageQuality = 0.6;

    this.options.myName = "";
    this.options.sendingFile = {
      sending: false,  // true/false
      file: null,
      percentage: 0,
      finished: 0,
      total: 0
    };
    this.options.receivingFile = false;

    this.options.rvaIP = null;
    this.options.ssid = null;
    this.options.lanIP = null;
    this.options.wifi = null;
    this.options.qrImg = null;
    this.options.screenNo = -1;

    $("#connected_rvaurl").text("");

    this.updateUserList([]);  // with refresh();

    this.options.votingEditorObject == false;
    this.options.tabletsLocked = false;
    this.options.projectionData = {grayOut: true};

    this.options.annotation = {
      annotateWindow: false,
      rvaAirnoteStatus: 0,   // 0/1/2,  0: nobody  1: it's me  2: not me
      whoAnnotating: 0,  // 0/1/2,  0: nobody  1: it's me  2: not me
      notifyRvaClose: true
    };

    this._disablePlayVideo();
    this._disableSharing();

    $("#extendScreen").attr("title","").removeClass().off();
    $("#open-voting").removeClass("hide").addClass("hide");
    $('#open-voting-text').text($.t('info.editVoting'));

    // reset because of NovoCast
    $("#icon-connect").show();
    $("#icon-group").show();
    $("#icon-tool").show();
    $("#icon-disconnect").hide();
    $("#myProjectArea").show();
    $(".has-toggle").show();
    $("#qr-btn").show();
    $(".pinDiv").show();
    $("#pinCodeBtn").css("display","").removeClass();
    $("#toggleConnectedInfo").removeClass();
    $("#connected-info").hide();
    $("#toggleSettingsInfo").removeClass();
    $("#setting-info").hide();
    $("#toggle-airnote").removeClass().hide();

    $(".connected-list").empty();
    novo.removeClass("flexible");
    $("#open-voting").removeClass("hide");

    this.updateUserList([]); // with refresh();
  },
  updateInfo: function updateInfo(info) {
    console.debug("updateInfo...", info);

    this.options.pinMandatory = info.pin_mandatory;
    this.options.pinRequired = info.pin_need;
    this.options.pinCode = info.pin_value;
    this.options.qrObj = info.qrObj;
    this.options.qrObj.isHost = this.options.isHost;
    //
    this.options.rvaType = info.rvaType;
    console.log(info.rvaType);

    this.options.sessionLockedMode = isSessionLock;

    this.options.groupMode = info.groupMode;
    this.options.groupName = (this.options.groupMode)? info.groupName : $.t('group.notSelected');
    if (this.options.viewModel != undefined && this.options.viewModel != null) {
      this.options.viewModel.updateSessionStatus(this.options.sessionLockedMode);
      this.options.viewModel.updateGroup(this.options.groupMode, this.options.groupName);
    }

    $("#connected-username").text(info.client_name);
    $("#connected-message").text(info.message);
    $("#connected_rvaurl").text(info.ipaddress);

    this.options.rvaVersion = info.rvaVersion;
    this.options.flexibleUserList = isflexibleGUI;

    this.options.rvaWidth = info.rvaWidth;
    this.options.videoMode = supportLocalVideo;
    this.options.rvaHeight = info.rvaHeight;

    this.options.supportVoting = supportVoting;
    if (this.options.supportVoting == 1){
      this._enableVoting();
    } else if (this.options.supportVoting == 0){
      this._disableVoting();
    } else{
      this._hideVoting();
    }
    this.options.sharingMode = supportExchangeServer ? 1 :(isCastTW1 || isCastCN)? -1 :0;
    if (this.options.sharingMode == 1) {
      this._receivers() ? this._enableSharing() : this._disableSharing();
    } else {
      this._disableSharing();
    }
    $(this.options.nowPage).trigger("click"); // trigger refresh
  },
  updatePinCode: function updatePinCode(pin) {
    //console.debug('[pinRequired]... pin=', pin);
    //if (this.options.connected)
    if (pin != "false") {
      this.options.pinRequired = true;
      this.options.pinCode = pin;
      this.refresh();
      return;
    }

    this.options.pinRequired = false;
    this.options.pinCode = '----';
    this.refresh();
  },
  updateUserList: function updateUserList(data) {
    var instance = this;
    if (instance.options.connected) {
      instance.options.userList = data;  // update user list
      $.each(data, function(i, user) {
        user['isAirNote'] = false;
        if (supportNewAnnotation && annotator_uid > -1 && annotator_uid == user['uid']) {
          user['isAirNote'] = true;   // update AirNote status
        }
        // console.log("i am", user, annotator_uid);
        if (user['isMyself']){
          instance.options.screenNo = user['panel'];  // get currnet screen no
          instance.options.myName = user['label'];    // get my name
          instance.options.myuid = user['uid'];    // get my uid
          return;
        }
      });
      (notificationOn && instance.options.screenNo < 0)? chrome.notifications.clear("screen") : null;
      instance.refresh();
    }
  },
  toBeHost: function toBeHost(flag) {
    this.options.isHost = flag; // set as moderator or not
    this.refresh();
  },
  setViewMode: function setViewMode(mode) {
    this.options.viewMode = mode; // full/split
    this.refresh();
  },
  refresh: function refresh() {
    //console.log("[refresh] ", this.options.rvaModel, this.options.rvaType, this.options.userList);
    //console.log("[refresh] this.options.votingEditorWindow=", this.options.votingEditorWindow);
    //console.log("[refresh] this.options.sharingMode=", this.options.sharingMode);

    // Return to login page when disconnected
    if (!this.options.connected){
      $(".taskbar .disconnect").show();
      $(".taskbar .connected").hide();
      $(".login").show();
      return;
    }

    // handler when connected
    var instance = this;

    if (instance.options.viewModel === undefined || instance.options.viewModel == null) {
      console.error(" instance.options.viewModel === undefined !!! viewModel=", instance.options.viewModel);
      return;
    }
    instance.options.viewModel.sortPeople(instance.options.userListSortKey, instance.options.rvaType);
    instance.options.viewModel.refresh(instance.options.userList);
    instance._setGroupMode(instance.options.groupMode);
    instance.options.isHost = instance.options.viewModel.iamHost();

    if (!instance.options.videoMode) instance._disablePlayVideo();

    var hasProjectionPrevilege = false;
    if (instance.options.rvaType == 'EDU') {
      hasProjectionPrevilege = instance.options.isHost;
    }
    if (instance.options.rvaType == 'CORP') {
      if (instance.options.viewModel.hasHost()) {
        hasProjectionPrevilege = instance.options.isHost;
      }
      else {
        hasProjectionPrevilege = true;
      }
    }
    //grace TBD
    if (hasProjectionPrevilege != instance.options.hasProjectionPrevilege) {
      // dsaApi.updateQRpage(hasProjectionPrevilege);  // update QR page
    }
    instance.options.hasProjectionPrevilege = hasProjectionPrevilege;

    (instance.options.viewMode=="full") ? instance._getFullMode() : instance._getSplitMode();
    $("#pin-code").text((instance.option.pinMandatory || instance.options.pinRequired) ? instance.options.pinCode : "----");
    (!instance.option.pinMandatory && instance.options.pinRequired)? $("#pinCodeBtn").addClass("true") : $("#pinCodeBtn").removeClass("true");
    if (this.options.supportVoting == 1) {
      this._enableVoting();
    } else if (this.options.supportVoting == 0) {
      this._disableVoting();
    } else {
      this._hideVoting();
    }
    var opt = instance.options.projectionData;  //{grayOut: false, lightOn: true}
    if (!opt.grayOut && opt.lightOn) instance._disablePlayVideo();

    if (this.options.sharingMode == 1) {
      instance._receivers() ? instance._enableSharing() : instance._disableSharing();
    } else {
      instance._disableSharing();
    } 

    (instance.options.rvaModel == "NovoConnect")? $('.remoteMouseDiv').show() : $('.remoteMouseDiv').hide();

    instance._refreshProjectionPage();
    if (instance.options.qrObj != null) instance.options.qrObj.isHost = instance.options.isHost;
    instance.refreshAnnotationBtns();

    if (instance.options.rvaType == 'EDU') {
      // Education version
      $("#nonGroupMode").removeClass("hide");
      $("#groupFuncArea").removeClass("hide");
      $('.online-edu').show();
      $('.online-corp').hide();
      $('#white-cover').hide();
      instance._setEduLockSessionMode();
      (instance.options.isHost)? instance._enableEduHostControls() : instance._disableEduHostControls();
    }

    // if (instance.options.rvaType == 'CORP') {
    //   // Corporation version
    //   $("#nonGroupMode").addClass("hide");
    //   $("#groupFuncArea").addClass("hide");
    //   $('.online-edu').hide();
    //   $('.online-corp').show();

    //   if (instance.options.hasProjectionPrevilege) {  // no host or i am the host
    //     instance._enableCorpPanelControls();  // enable panel function
    //     instance._createPinCodeControls();    // enable pin code function
    //   }
    //   else { // someone is host, not me
    //     instance._disableCorpPanelControls(); // disable user list function
    //     instance._removePinCodeControls();    // disable pin code function
    //   }

    // }
    // pin code mandatory will disable pin code function
    (instance.options.pinMandatory === true)? instance._removePinCodeControls() : null;

    // QR window exists.
    if (qrWin = chrome.app.window.get("qrWindow")) {
      qrWin.contentWindow.displaySessionInfo(
        instance.options.qrObj,
        instance.options.rvaVersion
      );
      return;
    }

    // // Return login page
    // $(".taskbar .disconnect").show();
    // $(".taskbar .connected").hide();
    // $(".login").show();
  },
  refreshTabletsLocked: function refreshTabletsLocked(value) {
    var tabletIcon = $("#toggle-tablet");
    if (!tabletIcon.hasClass('disable')) {
      (value)? tabletIcon.addClass('locked') : tabletIcon.removeClass('locked');
    }
    this.options.tabletsLocked = value;
  },
  _flexibleDragDrop: function _flexibleDragDrop() {
    //console.debug("[_flexibleDragDrop]...");
    var instance = this;

    // Flexible user list for Enterprise - corp & edu version
    if (instance.options.flexibleUserList && isflexibleGUIDnD) {
      //console.log("[flexibleUserList] render new layout...");
      var viewArea = $(".viewArea").addClass('has-right'),
        presenters = viewArea.children("li").off().click(function () {
          //console.debug("Click presenter...", this);
          presenters.removeClass("focused");
          $(".project-user").removeClass("clicked");
          $('#drop-person-menu').remove();
          $('#drop-userlist-menu').removeClass('open'); // user list
          ($(this).hasClass("ui-sortable-helper")) ? null: $(this).addClass("focused");
          return false;
        });

      var fullProjection = function () {
        var user = $(this).closest('li'),
          uid = user.attr("uid"),
          isMyself = (user.attr("isMyself") == 'true');
        //console.debug("[_enableCorpPanelControls] full screen uid=", uid, ", isMyself=", isMyself);
        // dsaApi.clearNotification();
        if (!instance.options.hasProjectionPrevilege) return false;
        send_CMD_VIEWER_REQUEST(uid, 0);
        console.log("[_enableCorpPanelControls] flexibleUserList - full screen projection - Call RVA to project uid, pno=", uid, 0);
        (isMyself === true) ?
          instance.openWaitingPageNoTimer($.t("settings.waitToSwitch")) : null;
        return false;
      }

      // support after RVA 2.2.0
      var withdrawProjection = function () {
        var user = $(this).closest('li'),
          uid = user.attr("uid");
        //console.debug("Withdraw Projection uid=", uid, "isMyself=", isMyself);
        send_CMD_STOP_PRESENTATION(uid);
        return false;
      }

      if (presenters.length > 1) {
        $(".goFull").off().click(fullProjection);
      }
      else {
        $(".goFull").remove();
      }

      presenters.each(function () {
        if ($(this).attr("isMyself") == 'true' || instance.options.isHost) {
          $(this).find(".goStop").off().click(withdrawProjection);
        }
        else {
          $(this).find(".goStop").remove();
        }
        if (!$(this).is("[data-sbind]")) {
          $(this).remove();
          //console.debug("[flexibleUserList] Remove this presenter...");
        }

      });

      $(".tools").each(function () {
        if ($(this).children().length === 0) {
          $(this).remove();
        }
      });

      var replaceMode = false;  // > 4 will replace presenter
      var draggableUsers = $("li.user.online");
      viewArea.sortable({
        disabled: false,
        containment: viewArea,
        revert: true,
        start: function (event, ui) {
          //console.log("[sortable-start] replaceMode=", replaceMode);
          presenters.removeClass("focused");
          if ($(".flexible").hasClass("small")) {
            $(ui.helper).css('width', "142px").css('height', "80px");
          }else{
            $(ui.helper).css('width', "220px").css('height', "112px");
          }
        },
        over: function (event, ui) {
          //console.log("[sortable-over] replaceMode=", replaceMode);
          if (replaceMode === true) {
            if ($(ui.item).index() + 1 > 4) {
              presenters.show();
              $(ui.item).show();
              $(ui.item).prev().hide();
            }
          }
        },
        out: function (event, ui) {
          //console.log("[sortable-out] replaceMode=", replaceMode);
          if (replaceMode === true) {
            presenters.show();
          }
        },
        change: function (event, ui) {
          //console.log("[sortable-change] replaceMode=", replaceMode);
          if (replaceMode === true) {
            presenters.show();
            $(ui.item).show();
            if ($(ui.placeholder).index() + 1 > 4) {
              $(ui.placeholder).prev().hide();
            }
            else {
              $(ui.placeholder).next().hide();
            }
          }
        },
        update: function (event, ui) {
          //console.debug("[sortable-update] replaceMode=", replaceMode);
          var elm = $($(ui.item)[0]).removeAttr("style"),
            isMyself = (elm.attr("isMyself") == 'true'),
            uid = elm.attr("uid"),
            oldIdx = elm.attr("panel"),
            newIdx = $(ui.item).index() + 1;
          newIdx = (newIdx > 4) ? 4 : newIdx;

          //console.log("[sortable-update] ask RVA to project uid=", uid, "from", oldIdx, "to", newIdx, "isMyself", isMyself);
          var result = instance._checkIfProjectOrNot(uid, newIdx, isMyself);
          if (result === true) {
            $("#myProjectPanel area").off();
            $("#myProjectPanel").addClass("disable");
            $(".myProjectBtns > div").off().addClass("disable");
            (oldIdx > -1) ? null : elm.remove();
            draggableUsers.draggable("disable");
            draggableUsers.off();
            viewArea.sortable("disable");
          }
          else {
            elm.remove();
          }
        },
        stop: function (event, ui) {
          //console.log("[sortable-stop] replaceMode=", replaceMode);
          replaceMode = false;
          presenters = viewArea.children("li");
        },
      }).disableSelection();

      draggableUsers.draggable({
        disabled: false,
        // containment: viewArea,
        connectToSortable: viewArea,
        scroll: false,
        snap: true,
        revert: "invalid",
        opacity: 0.5,
        cancel: ".playing",
        helper: function () {
          var uid = $(this).attr("id"),
            panel = $(this).find(".panel").attr("no"),
            isMyself = $(this).hasClass("isMyself"),
            username = $(this).find(".user-name").text();
          return $('<li>').attr("uid", uid).attr("panel", panel).attr("isMyself", isMyself)
            .append($('<span>').text(username));
        },
        start: function (event, ui) {
          if (presenters.length >= 4) {
            replaceMode = true;
          }
        },
        stop: function (event, ui) {
          replaceMode = false;
          //console.log("[draggable-stop] replaceMode=", replaceMode);
        }
      }).disableSelection();

    }
  },
  _checkIfProjectOrNot: function _checkIfProjectOrNot(uid, pno, isMyself) {
    console.debug("[_checkIfProjectOrNot] uid, pno, isMyself =", uid, pno, isMyself);
    var instance = this;

    // grace TBD
    // dsaApi.clearNotification();

    if (!instance.options.hasProjectionPrevilege) return false; // reject no previlege operation

    if ($("#dialogBeAskToPresent").length > 0 || $("#dialogAskSomeoneToPresent").length > 0) {
      console.log("[_checkIfProjectOrNot] Not allowed action because dialogBeAskToPresent or dialogAskSomeoneToPresent dialog exists.");
      return false;
    }

    // Rule for flexibleUserList
    if (instance.options.flexibleUserList) {
      //console.debug("[flexibleUserList] users=", instance.options.userList);

      var presentersCnt = $('.viewArea > li').length,
          user = instance.options.userList.filter(function(item){if(item.uid == uid) return item;})[0],
          oldPos = user.panel,
          isPresenter = (user.panel > -1)? true : false;

      //console.debug("[flexibleUserList] uid, oldPos, isPresenter, user.device, presentersCnt=", uid, oldPos, isPresenter, user.device, presentersCnt);
      if (isPresenter && ((pno > presentersCnt) || (presentersCnt == 1 && pno == 1) )) {
        var msg = (isMyself)? $.t('info.cantShowSplit') : $.t('info.cantShowOthersSplit');
        instance._showToast(msg, 3);
        return false;
      }

      send_CMD_VIEWER_REQUEST(uid, pno);
      // dsaApi.send_CMD_VIEWER_REQUEST(uid, pno); // send command to RVA
      console.log("[_checkIfProjectOrNot] flexibleUserList - Call RVA to project uid, pno=", uid, pno);
      if (isMyself === true) {
        instance.openWaitingPageNoTimer($.t("settings.waitToSwitch"));
      }
      else {
        (instance.options.rvaType === "EDU" || isPresenter || (noRespondOsType.indexOf(user.os_type) > -1)) ? null: instance._dialogAskSomeoneToPresent();
      }
      return true;
    }

    // Rule for NovoPro V2.4.x and below, NovoTouch, NovoCast, NovoConnect
    send_CMD_VIEWER_REQUEST(uid, pno);
    // dsaApi.send_CMD_VIEWER_REQUEST(uid, pno);
    console.log("[_checkIfProjectOrNot] Old version - Call RVA to project uid, pno=", uid, pno);
    if (isMyself === true) {
      instance.openWaitingPageNoTimer($.t("settings.waitToSwitch"));
    }
    return true;
  },
  _showToast: function _showToast(msg, showTime) {
    console.debug("[_showToast]...");
    var instance = this;
    instance._removeAllDialogs();
    instance.options.second = showTime; // default 3 seconds

    // show dialog like toast
    var page = $('<div class="message-page"></div>')
                .append($('<p>').text(msg))
                .append($('<p>').text(instance.options.second).attr("id","second"));

    page.dialog({
      autoOpen: true,
      resizable: false,
      closeOnEscape: false,
      modal: true,
      width: '80%',
      minheight: '200',
      dialogClass: "msg-page no-titlebar",
      open: function( event, ui) {

        // dsaApi.mouseUp();
      },
      close: function(event, ui) {
        clearInterval(instance.options.timeInterval);
        instance.options.second = 0;
        $(this).dialog('destroy').remove();
        instance.refresh();
        // dsaApi.mouseUp();
      },
      buttons: [
        {
          text: $.t("button.ok"),
          click: function() {
            page.dialog('close');
          }
        },
      ]
    });

    instance.options.timeInterval = window.setInterval(function(){
      instance.options.second--;
      $('#second').text(instance.options.second);
      if ( instance.options.second <= 0) {
        clearInterval(instance.options.timeInterval);
        instance.options.second = 0;
        page.dialog('close');
      }
    }, 1000);

  },
  _setEduLockSessionMode: function _setEduLockSessionMode() {
    //console.log("[_setEduLockSessionMode] sessionLockedMode=", this.options.sessionLockedMode);
    //console.log("[_setEduLockSessionMode] groupMode=", this.options.groupMode);
    var instance = this;

    // reset button
    var lockSessionBtn = $("#lockSessionBtn").removeClass();
    var eduLockSessionBtn = $("#edu-lock-session").removeClass();
    var lockSessionDiv = $("#lockSessionDiv").removeClass();

    // lock session mode
    if (instance.options.sessionLockedMode === true) {
      $("#nonGroupMode").removeClass("hide");
      eduLockSessionBtn.addClass("true");
      lockSessionBtn.addClass("true");
      //$("#groupFuncArea").addClass("hide");
      $("#select-user-group").addClass("hide");
      $('#save-user-list').removeClass("hide");

      if (instance.options.isHost === false) {
        eduLockSessionBtn.addClass("disable");
        lockSessionDiv.addClass("disable");
      }
      return;
    }

    // group mode
    if (instance.options.groupMode === true) {
      $("#nonGroupMode").addClass("hide");
      //$("#groupFuncArea").removeClass("hide");
      $('#save-user-list').addClass("hide").off();
      instance._setGroupMode(true);
      lockSessionDiv.addClass("hide");
      return;
    }
    else {
      instance._setGroupMode(false);
    }

    // hide lock session with low version
    if (instance.options.rvaVersion < 2.3) {
      eduLockSessionBtn.addClass("hide");
      lockSessionDiv.addClass("hide");
    }

    // [stud] unlock session and non-group mode
    if (instance.options.isHost === false) {
      eduLockSessionBtn.addClass("hide");
      lockSessionDiv.addClass("hide");
      //$("#groupFuncArea").addClass("hide");
      return;
    }

    // [teacher] unlock session and non-group mode
    //$("#groupFuncArea").addClass("hide");
    $("#select-user-group").removeClass("hide");
    $('#save-user-list').removeClass("hide");

  },
  _refreshProjectionPage: function _refreshProjectionPage() {
    var instance = this;
    //console.log("[_refreshProjectionPage]... screenNo=", this.options.screenNo, instance.options.hasProjectionPrevilege);
    var imgs = supportScreenWithdraw?presenterImages:presenterImagesUnWithdraw;
    var src = imgs[instance.options.screenNo];
    var displayImg = $('#myProjectPanel > img').attr("src", src);
    var extendBtn = $("#extendScreen").attr("title","");

    var area = $("#myProjectPanel area").off();
    if (instance.options.hasProjectionPrevilege === true){
      $("#myProjectPanel").removeClass("disable").addClass("enable");
      area.hover(
        function() {
          var no = parseInt($(this).attr('region'));
          no =  no + ((no == instance.options.screenNo)? 0 : 10)
          var imgSrc = imgs[no];
          displayImg.attr('src', imgSrc);
        },
        function() {
          displayImg.attr('src',src);
        }
      )
      .click(function() {
        area.off();
        $("#myProjectPanel").addClass("disable");
        $(".myProjectBtns > div").off().addClass("disable");
        var no = $(this).attr('region');
        if (no == instance.options.screenNo && supportScreenWithdraw) {
          console.warn("[novoconnect.js-_refreshProjectionPage] Withdraw myself projection");
          instance.options.sharedScreenNo = 0;
          send_CMD_STOP_PRESENTATION();
          return;
        }
        console.warn("[novoconnect.js-_refreshProjectionPage] Click to project myself on screen", no);
        $('.user.isMyself .panel area[region="' + no + '"]').trigger('click');  // projection myself
      });
    }
    else {
      // Support withdraw projection after RVA 2.2.0
      if (instance.options.screenNo > -1 && supportScreenWithdraw) {
        // I am presenter to withdraw my projection only
        $("#myProjectPanel").removeClass("disable").addClass("enable");
        area.hover(
          function() {
            var no = parseInt($(this).attr('region'));
            if (no == instance.options.screenNo) {
              no =  no + ((no == instance.options.screenNo)? 10 : 0)
              displayImg.attr('src', imgs[no]);
            }
          },
          function() {
            displayImg.attr('src',src);
          }
        ).click(function() {
          var no = $(this).attr('region');
          if (no == instance.options.screenNo) {
            area.off();
            $("#myProjectPanel").addClass("disable");
            console.warn("[novoconnect.js-_refreshProjectionPage] Withdraw myself projection");
            instance.options.sharedScreenNo = 0;
            send_CMD_STOP_PRESENTATION();
            return;
          }
        });
      }
      else {
        // Disable all
        $("#myProjectPanel").addClass("disable");
      }
    }
  },
  _disableProjectionBtns: function _disableProjectionBtns() {
    //console.log("[_disableProjectionBtns] this.options.rvaVersion=", this.options.rvaVersion);
    var instance = this;
    var imgs = supportScreenWithdraw?presenterImages:presenterImagesUnWithdraw;
    $('#myProjectPanel').removeClass();
    $('#myProjectPanel > img').attr("src", imgs[instance.options.screenNo]);
    $("#myProjectPanel area").off();

    (instance.options.hasProjectionPrevilege === false)? $("#myProjectPanel").addClass("disable") : $("#myProjectPanel").addClass("enable");

  },
  _confirmStopProjection: function _confirmStopProjection(msg, uid) {
    var instance = this;
    instance._removeAllDialogs();
    var page = $('<div class="message-page"></div>').text(msg);
    var btns = [
        {
          text: $.t("button.ok"),
          click: function() {
            instance.refresh();
            $(page).remove();
            if (instance.options.connected)
              $(instance.options.nowPage).trigger("click");
          }
        },
      ]

    if (supportScreenWithdraw){
      btns.push({
        text: $.t("button.stopProjection"),
        click: function() {
          send_CMD_STOP_PRESENTATION(uid);
          instance.refresh();
          $(page).remove();
          if (instance.options.connected)
            $(instance.options.nowPage).trigger("click");
        }
      });
    }

    // confirm to No/Yes
    page.dialog({
      autoOpen: true,
      resizable: false,
      modal: true,
      width: '95%',
      minheight: '200',
      maxHeight: $('#container').height(),
      dialogClass: "msg-page",
      open: function( event, ui ) {
      },
      close: function(event, ui) {
        // instance.refresh();
      },
      buttons: btns
    });
  },
  _receivers: function _receivers(){
    //console.log('[_receivers] userList:', this.options.userList);
    // return true when there are file receivers; false when no file receiver

    // Case 1: return false when only one user is online
    var totalNum = this.options.userList.reduce(function (total, user) {
      return total + ((noSharingOsType.indexOf(user.os_type) > -1) ? 0 : 1);
    }, 0);
    if (totalNum < 2) return false;

    // Case 2: [CORP,EDU] I am host and send to all
    if (this.options.viewModel.iamHost()) {
      totalNum = this.options.userList.reduce(function (total, user) {
        return total + ((user.online && !user.isMyself && noSharingOsType.indexOf(user.os_type) === -1) ? 1 : 0); // filter offline / host / Airplay / Google Cast / HDMI IN / Win Lite / Mac Lite
      }, 0);
      return (totalNum > 0);
    }

    // Case 3: [CORP,EDU] I am not host and send file to the host
    totalNum = this.options.userList.reduce(function(total, user){
      return total + ((user.online && !user.isMyself && user.isHost)? 1 : 0); // catch the host
    }, 0);
    if (totalNum > 0) return true;

    // Case 4: [CORP-No host] I am not host and send file to all when NO host is online.
    if (this.options.rvaType == 'CORP') {
      totalNum = this.options.userList.reduce(function (total, user) {
        return total + ((user.online && !user.isMyself && noSharingOsType.indexOf(user.os_type) === -1) ? 1 : 0); // filter offline / host / Airplay / Google Cast / HDMI IN / Win Lite / Mac Lite
      }, 0);
      return (totalNum > 0);
    }

    //Case 5: [EDU-No host] I am not host and do nothing when NO host is online.
    return false;
  },

  previewImage: function previewImage(uid, qrsrc) {
    // console.log('[previewImage]', uid, $('#' + uid));
    $('#' + uid).removeClass('waiting').find('.preview > img').attr('src','data:image/png;base64,' + qrsrc ).end();
  },
  previewTimeout: function previewTimeout(uid) {
    //console.log('[previewTimeout]', uid, $('#' + uid));
    var person = $('#' + uid),
        preview = person.find('.preview');
    person.removeClass('waiting');
    if (person.hasClass('focused') && preview.css('display') != "none") {
      $(".user-list").css("max-height", "").end();
      person.removeClass('focused');
      preview.hide().find("img").attr("src","").end();
      //console.debug('Hide preview...');
    }
  },
  _enableTaskbar: function _enableTaskbar() {
    var instance = this;

    // TaskBar: connect
    $("#icon-connect").off().click(function(){
      novo.removeClass("flexible");
      instance.options.nowPage = "#icon-connect";
      $(".topBtn").removeClass("focus");
      $(this).addClass("focus");
      instance.refresh();
      instance._hideAllpages();
      $(".connected-part").show();
    });

    // TaskBar: group
    $("#icon-group").off().click(function(){
      instance.options.nowPage = "#icon-group";
      $(".topBtn").removeClass("focus");
      $(this).addClass("focus");
      getScreenDisplayHeight(function (screenHight) {
        (instance.options.flexibleUserList) ? (novo.addClass("flexible " + (screenHight < 620 ?"small":""))): null;
        instance.refresh();
        instance._hideAllpages();
        $(".connected-list").show();
        ($('#white-cover').css('display')=='block')? instance._disableCorpPanelControls() : null;
      });
    });

    // TaskBar: tool
    $("#icon-tool").off().click(function(){
      novo.removeClass("flexible");
      instance.options.nowPage = "#icon-tool";
      $(".topBtn").removeClass("focus");
      $(this).addClass("focus");
      instance.refresh();
      instance._hideAllpages();
      $(".tool-list").show();
    });

    // TaskBar: close
    $(".connected .icon-close").off().click(function () {
      instance.askQuitDsa();
    });

    // TaskBar: minimize
    $(".connected .icon-minimize").off().click(function () {
      windows_minimize();
    });

  },
  _disableTaskbar: function _disableTaskbar() {
    $("#icon-connect").off();
    $("#icon-group").off();
    $("#icon-tool").off();
    //console.log("_disableTaskbar...");
  },

  _getFullMode: function _getFullMode() {
    $(".full-view").show();
    $(".split-view").hide();

    var instance = this;
    (instance.options.videoMode && $("li.isMyself.playing").find(".panel.full-on").length == 1) ? instance._enablePlayVideo(): instance._disablePlayVideo();
  },
  _getSplitMode: function _getSplitMode() {
    $(".full-view").hide();
    $(".split-view").show();
    this._disablePlayVideo();
  },
  _enablePlayVideo: function _enablePlayVideo() {
    var instance = this;
    $("#play-video").removeClass("disable").attr('title', '').off().click(function () {
      //console.log("Open video player...");
      if (win = chrome.app.window.get("videoWindow")) {
        win.focus();
        return;
      }
      chrome.app.window.create(
        '../views/video.html', {
          id: "videoWindow",
          bounds: {
            width: 352,
            height: 220
          },
          frame: 'none',
          resizable: false,
        },
        function (createdWindow) {
          createdWindow.contentWindow.rvaVersion = instance.options.rvaVersion;
          createdWindow.contentWindow.rvaType = instance.options.rvaType;
          window.mainWindow = createdWindow;
        }
      );
    });

    // Set videoClipBtn
    $("#videoClipBtn").removeClass().attr('title',$.t("video.title")).off().click(function(){
      //console.log("Click videoClipBtn...");
      $("#play-video").trigger("click");
    });

  },
  _disablePlayVideo: function _disablePlayVideo() {
    var instance = this;
    $("#play-video").addClass("disable").attr('title','').off();
    $("#videoClipBtn").removeClass().attr('title','').addClass("disable").off();

    if (win = chrome.app.window.get("videoWindow")) {
      win.close();
      close_video_panel();
    }

    if (instance.options.videoMode) {
      $("#play-video").addClass("disable").attr('title','').off();
      return;
    }

    var obj = $("#play-video").off().addClass("disable");
    if (supportLocalVideo) {
      $(obj).attr('title', $.t("info.upgradeTo1.5"));
    }
  },
  _setGroupMode: function _setGroupMode(groupMode) {
    // console.log("[_setGroupMode] groupMode=", groupMode)
    var instance = this;
    if (groupMode) {
      $("#group-tabs > li").off().click(function(){
        $("#group-tabs > li").removeClass("active");
        $(this).addClass("active");
        instance.options.viewModel.display($(this).attr("display"));
        instance.refresh();
      });

      return;
    }

    // Not group mode
    $("#group-tabs > li").off().removeClass("active").first().addClass("active").end();
    instance.options.viewModel.display("0");
  },
  receiveScreenPause: function receiveScreenPause(flag) {
    console.log("instance.receiveScreenPause...", flag);
    var logo = $("#logo").removeClass("loading");
    if (flag) {
      logo.addClass("pause");
    } else {
      logo.removeClass("pause");
    }
    this.refresh();
  },

  setAnnotationBtns: function setAnnotationBtns(status) {
    // console.log("setAnnotationBtns", status);
    if (supportAnnotation) {
      this.options.annotation.rvaAirnoteStatus = status.whoclick;   // OLD(who disable airnote): 0/1/2,  0: nobody  1: it's me  2: not me
                                                                    // NEW(rva Airnote Status): 0/1/2,
                                                                    //        0: enabled (can be disabled)
                                                                    //        1: disabled (can be enabled)
                                                                    //        2: grayout (can not control)
      this.options.annotation.whoAnnotating = status.whoAnnotating; // 0/1/2,  0: nobody  1: it's me  2: not me
      this.refreshAnnotationBtns();
    }
  },
  AnnotationBtnsLanuchAnnotation: function AnnotationBtnsLanuchAnnotation(id) {
    var popup = $("#drop-airnote-user");
    $("#launchAirNote").show().off().click(function () {
      $("#drop-airnote").removeClass('open');
      popup.removeClass("open");
      var win = chrome.app.window.get("annotationWindow");
      if (win) return win.focus();
      launch_ANNOTATION(id);
      return false;
    });
  },
  startAnnotation: function startAnnotation() {
    var win = chrome.app.window.get("annotationWindow");
    if (win) {
      win.focus();
      return;
    }
    if (this.options.annotation.annotateWindow ){
      console.log('startAnnotation, this.options.annotation.annotateWindow', this.options.annotation.annotateWindow);
      return;
    }
    start_ANNOTATION();
  },
  refreshAnnotationBtns: function refreshAnnotationBtns() {
    var toggleBtn = $('#toggle-airnote').css("display", "").removeClass().off(); // reset button
    var instance = this;

    if (!supportAnnotation) {
      //console.log("[refreshAirNoteBtns] OLD RvaVersion no show", this.options.rvaVersion);
      toggleBtn.hide();
      return;
    };

    var toggleBtnIndex = $(".tool-list>div:not(.hide)").index(toggleBtn) + 1;
    toggleBtn.removeClass("mostRight");
    if (toggleBtnIndex % 3 == 0){
      toggleBtn.addClass("mostRight");
    }
    var rvaAirnoteStatus = instance.options.annotation.rvaAirnoteStatus;
                                                                    // OLD(who disable airnote): 0/1/2,  0: nobody  1: it's me  2: not me
                                                                    // NEW(rva Airnote Status): 0/1/2,
                                                                    //        0: enabled (can be disabled)
                                                                    //        1: disabled (can be enabled)
                                                                    //        2: grayout (can not control)
    var whoAnnotating = instance.options.annotation.whoAnnotating;// 0/1/2,  0: nobody  1: it's me  2: not me
    instance.options.annotation.annotateWindow = (whoAnnotating == 1);

    // reset button
    var win = chrome.app.window.get("annotationWindow");
    var whoIsAirNote = annotator_uid;
    var isModerator = amIHost(client_id);
    var isPresenter = amIPresenter(client_id);
    var iconDropUser = $(".icon-drop-airnote-user");
    var popup = $("#drop-airnote-user");
    // console.log('[refreshAnnotationBtns]', rvaAirnoteStatus, whoAnnotating, supportNewAnnotation, annotation_state, isModerator, isPresenter);

    $("#launchAirNote").hide();
    $("#toggleAirNote").hide();

    //general rule - tool 9 block btn
    if (rvaAirnoteStatus == 0) {
      toggleBtn.removeClass("false disable true").addClass("true");
    } else if (rvaAirnoteStatus == 1) {
      toggleBtn.removeClass("false disable true").addClass("false");
    } else if (rvaAirnoteStatus == 2) {
      toggleBtn.off().removeClass("false disable true").addClass("disable").off();
    }

    //general rule - airnote window
    (win && (!annotation_state || whoAnnotating != 1 || isPresenter)) && win.close();

    //new version specific rule
    if (supportNewAnnotation) {
      $("#launchAirNote").show();
      $("#toggleAirNote").show();
      toggleBtn.removeClass("isAirnote").addClass(whoIsAirNote > 0?"isAirnote":"");
      if (rvaAirnoteStatus != 2){
        toggleBtn.off().click(function () {
          $("#drop-airnote").toggleClass('open');
          $('#drop-sharing').removeClass('open');
          popup.removeClass("open");
          return false;
        });
      }

      //user list show status
      if (whoIsAirNote > 0) {
        var person = $("#" + whoIsAirNote);
        $(".user-control > .airnote").remove();
        person.children(".user-control").prepend($('<div class="airnote">').text("airnote")).end();
        popup.html($.t('airnote.usingAirNote', person.find(".user-name").text()));

        iconDropUser.off().click(function () {
          popup.toggleClass("open");
          $("#drop-airnote").removeClass('open');
          return false;
        });
      }

      //role specific
      if (isModerator) {
        if (rvaAirnoteStatus == 0 || rvaAirnoteStatus == 1) {
          $("#toggleAirNote").show().text(rvaAirnoteStatus == 0 ? $.t("airnote.offAirnote") : $.t("airnote.onAirnote")).off().click(function () {
            rvaAirnoteStatus == 0 ? turnOff_ANNOTATION() : turnOn_ANNOTATION();
            $("#drop-airnote").removeClass("open");
            return false;
          });

          if (!isPresenter){
            instance.AnnotationBtnsLanuchAnnotation(client_id);
          }
          else{
            $("#launchAirNote").hide();
          }
        }
        else if (rvaAirnoteStatus == 2) {
          popup.removeClass("open");
          $("#drop-airnote").removeClass("open");
        }
      } else if (isPresenter) {
        popup.removeClass("open");
        if (rvaAirnoteStatus == 0 || rvaAirnoteStatus == 1) {
          toggleBtn.off().click(function() {
            rvaAirnoteStatus == 0 ? turnOff_ANNOTATION() : turnOn_ANNOTATION();
            popup.removeClass("open");
            return;
          });
        }
        else if (rvaAirnoteStatus == 2) {
          toggleBtn.off().removeClass("ture").addClass("false disable").off();
        }
      } else {
        $("#launchAirNote").hide().off();
        $("#toggleAirNote").hide().off();
        toggleBtn.off().on("click", function() {
          instance.startAnnotation();
        });
      }
    }


    //old version specific rule
    if (!supportNewAnnotation) {
      toggleBtn.removeClass("isAirnote");
      popup.removeClass("open");
      $("#drop-airnote").removeClass('open');
      toggleBtn.off().click(function () {
        if (isPresenter) {
          rvaAirnoteStatus == 1 ? turnOn_ANNOTATION() : rvaAirnoteStatus == 0 ? turnOff_ANNOTATION() : toggleBtn.addClass("false disable");;
          return false;
        }
        (whoAnnotating == 0) ? instance.startAnnotation() : (whoAnnotating == 2) ? toggleBtn.addClass("false disable") : instance.startAnnotation();
        return false;
      });
      if (whoAnnotating == 2 || rvaAirnoteStatus == 2) {
        toggleBtn.removeClass("false disable true").addClass("false disable").off();
      }
    }
    //old version specific rule

  },
  _disableAnnotation: function _disableAnnotation() {
    console.debug("[_disableAnnotation]...");
    // hide and reset bottons
    var toggleModeBtn = $('#annotation-mode').removeClass().addClass("tool-block").addClass("hide").off();

    // close annotation window
    var win = chrome.app.window.get("annotationWindow");
    if (win) {
      win.close();
      win = null;
    }
  },
  setAnnotationBackground: function setAnnotationBackground(annotation_screen) {
    if (supportAnnotation) {
      console.log("[setAnnotationBackground]");
      var instance = this;

      //this.options.annotatebg = annotation_screen;
      var win = chrome.app.window.get("annotationWindow");
      if (win) {
        win.focus();
        win.contentWindow.displayBG(annotation_screen);
        return;
      }

      // open Annotation window
      chrome.app.window.create(
        '../views/annotation.html',
        {
          id: "annotationWindow",
          frame: 'none',
          resizable: false
        },
        function (createdWindow) {
          //window.mainWindow = createdWindow;
          if (!createdWindow){
            console.error("[setAnnotationBackground] createdWindow=", createdWindow);
            return;
          }
          console.log("[setAnnotationBackground] createdWindow=", createdWindow, instance.options.rvaWidth, instance.options.rvaHeight);
          childwin = createdWindow.contentWindow;
          createdWindow.maximize();
          
          childwin.onload = function () {
            childwin.initBG(annotation_screen);
            childwin.createCanvas({
              width: instance.options.rvaWidth,
              height: instance.options.rvaHeight
            });
            createdWindow.focus();
          }
          
          createdWindow.onClosed.addListener(function () {
            console.log("[setAnnotationBackground] Close AirNote window...");
            chrome.app.window.current().show(true);
            (instance.options.annotation.notifyRvaClose)? stop_ANNOTATION() : null;  // flag to notify RVA or not
            childwin = null;
            instance.options.annotation.notifyRvaClose = true;
          });
        }
      );
    }
  },
  beAskToCloseAirnote: function beAskToCloseAirnote() {
    console.log("[beAskToCloseAirnote] ...");
    this.options.annotation.notifyRvaClose = false;
    var win = chrome.app.window.get("annotationWindow");
    if(win){
      win.close();
    }

  },

  _enableSharing: function _enableSharing() {
    console.log("[_enableSharing] this.options.sharingMode=", this.options.sharingMode);
    var instance = this;

    // sharing button
    $('#open-sharing').removeClass("disable").attr('title', '').off().click(function() {
      // console.log("_enableSharing, Click sharing...", this);
      $('#drop-sharing').toggleClass('open');
      $('#drop-airnote').removeClass('open');
      $("#drop-airnote-user").removeClass('open');
      $('#toggle-drop-setting').removeClass("focus");
      return false;
    });

    $('#drop-sharing').removeClass('hide').find('.online').removeClass('hide').end();

    // choose file to share
    $('#chooseFile').off().click(function(e){
      e.preventDefault();
      //console.log("Click chooseFile...");
      select_a_file_to_share(1);
      return false;
    });

    // send screen
    $('#shareScreenShot').off().click(function(e){
      e.preventDefault();
      //console.log("Click shareScreenShot...");
      select_a_file_to_share(2);
    });

    $("#callUploading").off().click(function(){
      // open this dialog
      set_background_file_sending(false);
      sendingFilePage(upload_report);
      //console.log('Open dialog...');
    });

    // by RVA version
    if (supportURLSharing ) {
      // share a URL
      $('#shareLink').off().click(function(e){
        e.preventDefault();
        instance._enterLinkDialog();
      });
    }
    else {
      $('#shareLink').off().closest('li').addClass('hide').end();
    }

    // open links dialog
    if (supportURLSharing ) {
      $('#receivedLinks').off().click(function(e){
        e.preventDefault();
        instance.linkHistory();
      });
    }
    else {
      $('#receivedLinks').off().closest('li').addClass('hide');
      $('#drop-sharing').removeClass('hide');
    }
    instance.refreshHistoryDialog();

  },
  _disableSharing: function _disableSharing() {
    // console.log("[_disableSharing] this.options.sharingMode=", this.options.sharingMode);
    var instance = this;

    if (this.options.sharingMode == 1) {
      // No Receiver
      // open pop-up
      $('#open-sharing').removeClass("disable").attr('title', '').show().off().click(function() {
        // console.log("_disableSharing, Click sharing...", this);
        $('#drop-sharing').toggleClass('open');
        $('#drop-airnote').removeClass('open');
        $("#drop-airnote-user").removeClass('open');
        $('#toggle-drop-setting').removeClass("focus");
        return false;
      });
      // hide on-line function
      $('#drop-sharing').removeClass('hide').find('.online').addClass('hide').end();


      // open links history
      if (supportURLSharing ) {
        $('#receivedLinks').off().click(function(e){
          e.preventDefault();
          instance.linkHistory();
        });
      }
      else{
        $('#drop-sharing').addClass('hide').end();
      }

    }
    else if (this.options.sharingMode == 0){
      // too low version and need to upgrade, disable all function
      $("#open-sharing").off().removeClass('active').addClass("disable").attr('title', $.t('info.needToGradeMsg', {verNo: "1.6"})).show();
      $('#openGroupShare').off();
      $('#receivedLinks').off()
    }else{
      $("#open-sharing").off().hide();
    }

    $('#chooseFile').off();
    $('#shareScreenShot').off();
    $("#callUploading").removeClass("active").off();
  },
  _enterLinkDialog: function _enterLinkDialog() {
    var instance = this;
    instance._removeAllDialogs();

    var input = $('<input type="text">').attr('placeholder', 'Enter here...');
    var clear = $('<span>').addClass('clear').click(function () {
      input.val('').focus();
    });
    var error = $('<div>').addClass('error');
    var inputArea = $('<div>').addClass('inputURLArea').append(clear).append(input).append(error);

    if (document.queryCommandSupported('paste')) {
      $('<span>').addClass('paste').click(function () {
        input.focus();
        document.execCommand('paste');
      }).insertAfter(clear);
    }

    // Display message
    var page = $('<div class="message-page"></div>')
      .append($('<h4>').text($.t("sharing.shareLink")))
      .append($('<p>').text($.t("sharing.urlInput")))
      .append(inputArea);

    page.dialog({
      autoOpen: true,
      resizable: false,
      modal: true,
      width: '95%',
      minheight: '200',
      maxHeight: $('#container').height(),
      dialogClass: "msg-page",
      open: function( event, ui ) {
      },
      close: function(event, ui) {
      },
      buttons: [
        {
          text: $.t("button.ok"),
          click: function(e) {
            e.preventDefault();
            error.empty();
            if (input.val() == "") {
              error.text($.t("sharing.urlNone"));
              input.focus();
              return;
            }
            if (input.val().length > 504) {
              error.text($.t("sharing.urlOverLength"));
              input.focus();
              return;
            }
            instance._confirmSendUrlDialog(input.val().trim());
            $(page).remove();
          }
        },
        {
          text: $.t("button.cancel"),
          click: function(e) {
            e.preventDefault();
            instance.refresh();
            $(page).remove();
            $("#icon-tool").trigger("click");
          }
        },
      ]
    });
  },
  _confirmSendUrlDialog: function _confirmSendUrlDialog(url, orgPage) {
    var instance = this;
    instance._removeAllDialogs();
    var receivers = (instance.options.isHost) ? $.t("sharing.allParticipants") : $('.user-name.ishost').text();
    var sendString = $.t("sharing.sendURLMsg");
    sendString = sendString.replace(/__link__/, "<a href='" + url + "' target='_blank'>" + url + "</a>");
    sendString = sendString.replace(/__receiver__/, receivers);
    // Display message
    var page = $('<div class="message-page"></div>')
      .append($('<h4>').text($.t("sharing.shareLink")))
      .append($('<p>').html(sendString));

    page.dialog({
      autoOpen: true,
      resizable: false,
      modal: true,
      width: '95%',
      minheight: '200',
      maxHeight: $('#container').height(),
      dialogClass: "msg-page",
      open: function( event, ui ) {
      },
      close: function(event, ui) {
      },
      buttons: [
        {
          text: $.t("button.yes"),
          click: function(e) {
            e.preventDefault();
            sendURLSharing(url);
            instance._sendUrlDoneDialog(url, orgPage);
            $(page).remove();
          }
        },
        {
          text: $.t("button.no"),
          click: function (e) {
            e.preventDefault();
            instance.refresh();
            $(page).remove();
            $("#icon-tool").trigger("click");
            (orgPage != undefined) ? orgPage(): null;
          }
        },
      ]
    });
  },
  _sendUrlDoneDialog: function _sendUrlDoneDialog(url, orgPage) {
    var instance = this;
    instance._removeAllDialogs();
    var sentString = $.t("sharing.sentLinkMsg");
    sentString = sentString.replace(/__link__/, "<a href='" + url + "' target='_blank'>" + url + "</a>");

    // Display message
    var page = $('<div class="message-page"></div>')
      .append($('<h4>').text($.t("sharing.sentLinkTitle")))
      // .append($('<a>').text(url).attr('href', url).attr("target", "_blank"))
      .append($('<p>').html(sentString));

    page.dialog({
      autoOpen: true,
      resizable: false,
      modal: true,
      width: '95%',
      minheight: '200',
      maxHeight: $('#container').height(),
      dialogClass: "msg-page",
      open: function( event, ui ) {
      },
      close: function(event, ui) {
      },
      buttons: [
        {
          text: $.t("button.close"),
          click: function(e) {
            e.preventDefault();
            instance.refresh();
            $(page).remove();
            $("#icon-tool").trigger("click");
            (orgPage != undefined) ? orgPage(): null;
          }
        },
      ]
    });
  },
  refreshHistoryDialog: function refreshHistoryDialog() {
    if ($('.linkHistory').length > 0) {
      this.linkHistory();
    }
  },
  linkHistory: function linkHistory() {
    var instance = this;
    instance._removeAllDialogs();

    var links = urlList;

    // Sort by timestamp
    links.sort(function (a, b) {
      return a.pid < b.pid;
      //return a.timestamp < b.timestamp;
    });


    var page = $('<div class="message-page"></div>')
                .append($('<h4>').text($.t('sharing.receiveLinkTitle')));
    var div = $('<div>').addClass('remove-cover').appendTo(page);
    var removeAll = $('<span>').text($.t('sharing.removeAll')).appendTo(div);
    var list = $('<ul>').addClass('left').addClass('linkHistory').appendTo(page);

    $.each(links, function(index, row) {
      //console.log(index, ": ", row.pid, row.url, row.timestamp);
      var link = $('<a>').text(row.url).attr('href', row.url).attr("target", "_blank");
      var li = $('<li>').append(link).append('<br>')
                .append($("<span>").addClass('senderName').text(row.sender))
                .appendTo(list);
      // remove icon
      $('<span>').addClass('remove').appendTo(li).click(function(){
        //console.log("Remove pid=", row.pid, links.length, links);
        removeURLRecieveHistory(row.pid);
        $(li).remove();
        if (links.length == 0) {
          $('<li>').text($.t("sharing.noLink")).appendTo(list);
          removeAll.hide();
        }
      });
      // send url icon
      if (instance.options.connected && instance.options.sharingMode == 1 && instance._receivers()) {
        $('<span>').addClass('send-url').appendTo(li).click(function(){
          //console.log("Send url=", row.url);
          instance._confirmSendUrlDialog(
            row.url,
            function(){ $('#receivedLinks').trigger('click'); }
          );
        });
      }
    });

    // remove all icon
    removeAll.click(function(){
      //console.log("Remove all links...");
      instance.removeAllLinksDialog();  // dialog
    });

    if (links.length == 0) {
      $('<li>').text($.t('sharing.noLink')).appendTo(list);
      removeAll.hide();
    }

    page.dialog({
      autoOpen: true,
      resizable: false,
      modal: true,
      width: '95%',
      minheight: '200',
      maxHeight: $('#container').height(),
      dialogClass: "msg-page no-titlebar",
      open: function( event, ui ) {
      },
      close: function(event, ui) {
      },
      buttons: [
        {
          text: $.t("button.close"),
          click: function() {
            // $(this).dialog("close");
            // instance.refresh();
            $(page).remove();
            $("#icon-tool").trigger("click");
          }
        },
      ]
    });
  },
  removeAllLinksDialog: function removeAllLinksDialog() {
    var instance = this;
    instance._removeAllDialogs();

    var page = $('<div class="message-page"></div>')
      .append($('<h4>').text($.t("sharing.removeAllLinksTitle")))
      .append($('<p>').text($.t("sharing.removeAllLinksMsg")));

   page.dialog({
      autoOpen: true,
      resizable: false,
      modal: true,
      width: '95%',
      minheight: '200',
      maxHeight: $('#container').height(),
      dialogClass: "msg-page",
      open: function( event, ui ) {
      },
      close: function(event, ui) {

      },
      buttons: [
        {
          text: $.t("button.yes"),
          click: function(e) {
            e.preventDefault();
            removeURLRecieveHistory(-1);
            $(page).remove();
            instance.linkHistory();
          }
        },
        {
          text: $.t("button.no"),
          click: function (e) {
            e.preventDefault();
            $(page).remove();
            instance.linkHistory();
          }
        },
      ]
    });

  },
  goVoting: function goVoting(data) {
    var instance = this;
    //console.info('goVoting...', data);
    instance.options.votingObject = {
      isReady: data.isReady,
      question: data.question
    };
    // the window existed.
    if (childwin = chrome.app.window.get("votingWindow")) {
      //console.log("New question....");
      childwin.contentWindow.createQuestion(instance.options.votingObject);
      childwin.show(true);
      return;
    }
    $('#open-voting').trigger('click');
  },
  _enableVoting: function _enableVoting() {
    //console.log('_enableVoting...', votingObject);
    var instance = this,
        votingIcon = $('#open-voting');

    // Voting button
    $(votingIcon).removeClass('disable').attr('title','').off();
    if (!instance.options.viewModel.hasHost()) {  // no host
        $(votingIcon).addClass('disable');
    }

    $('#open-voting').removeClass("disable").attr('title', '').off().click(function () {
      //console.log("Open votingWindow...", instance.options.votingObject);

      if (!instance.options.votingObject || !instance.options.votingObject.isReady) {
        instance.messagePage($.t('voting.notStarted'));
        $(".message-page").attr("id", "VotingNotStarted");
        return;
      }

      // the window existed.
      if (childwin = chrome.app.window.get("votingWindow")) {
        //(instance.options.os='win')? chrome.app.window.current().minimize() : '';
        childwin.show(true);
        return;
      }

      // open new window
      chrome.app.window.create(
        '../views/voting.html', {
          id: "votingWindow",
          bounds: {
            width: 820,
            height: 620
          },
          frame: 'none',
          resizable: false,
        },
        function (createdWindow) {
          //console.log("I am new open....");
          childwin = createdWindow.contentWindow;
          createdWindow.onClosed.addListener(function () {
            childwin = null;
            chrome.app.window.current().show(true);
          });
          childwin.onload = function () {
            this.createQuestion(instance.options.votingObject);
          }
        }
      );
    });
  },
  _disableVoting: function _disableVoting() {
    var instance = this;
    var obj = $("#open-voting").off().addClass("disable");
    $(obj).attr('title', $.t("info.upgradeTo1.5"));
    if (win = chrome.app.window.get("votingWindow")) {
      win.close(); // Close it when open
    }
  },
  closeDialogVotingNotStart: function closeDialogVotingNotStart() {
    console.log('[closeDialogVotingNotStart]');
    ($("#VotingNotStarted").length > 0)? $("#VotingNotStarted").dialog("close") : null;
  },
  _enableEduHostControls: function _enableEduHostControls() {
    console.debug("[_enableEduHostControls]...");
    var instance = this;

    // enable pin code function
    instance._createPinCodeControls();

    // enable lock session function
    // $('.userList-menu').removeClass("hide").removeClass("disable").off().click(function(){
    //   //console.log("Click user list menu...");
    //   $("#drop-userlist-menu").toggleClass("open");
    //   return false;
    // });


    // enable edu lock/unlock session function
    instance._enableEduLockSessionFunc();

    // enable function area
    // instance._enableFunctionArea();

    // Enable user list function
    $(".user-list > ul").addClass('has-right');

    $(".project-user").off().click(function(){
      $('#drop-userlist-menu').removeClass('open');
      $('#drop-person-menu').remove();
      $(".viewArea > li").removeClass("focused");
      $(".project-user").removeClass("clicked");
      $(this).addClass('clicked');
      var panel = $('.panel', this),
          layer = $('.panel-overlay', this);

      // flexible user list
      if (instance.options.flexibleUserList) {
        var xy = panel.closest('li').offset(),
          x = Math.round(xy.left + 65),
          y = Math.round(xy.top - 173);
        panel.css('top', (y + 11) + "px").css('left', (x + 7) + "px");
        layer.css('top', y + "px").css('left', x + "px");
      }
      else {
        // other devices without flexible user list
        var top = $(this).closest('li').offset().top;
        $(panel).css('top', top - 67);
        $(layer).css('top', top - 78);
      }
      scrollToRemoveElement($(".user-list"), function () { $(".project-user").removeClass("clicked"); });
      return false;
    });

    if ($(".panel > img").length == 0){

      // create panel image
      var img = $('<img alt="Assign panel" width="186" height="108">'),
          map = $('<map class="panelMap"></map>'),
          areas = ['<area region="0" alt="0" shape="rect" coords="62,27,123,80" href="#">',
                   '<area region="1" alt="1" shape="poly" coords="0,0,93,0,93,27,62,27,62,54,0,54" href="#">',
                   '<area region="2" alt="2" shape="poly" coords="93,0,186,0,186,54,123,54,123,27,93,27" href="#">',
                   '<area region="3" alt="3" shape="poly" coords="0,54,62,54,62,80,93,80,93,108,0,108" href="#">',
                   '<area region="4" alt="4" shape="poly" coords="93,80,123,80,123,54,186,54,186,108,93,108" href="#">'];

      $.map(areas, function(area){ map.append(area); });

      $('.user.online').each(function(index) {
        var person = $(this),
            uid = person.attr("id"),
            user = instance.options.userList.filter(function(item){if(item.uid == uid) return item;})[0],
            osType = person.attr("data-osType"),
            iconUser = person.find('.icon-user'),
            middle = [person.find('.user-name'), person.find('.user-device')],
            userName = person.find('.user-name').text(),
            panel = person.find('.panel');

        //console.log("user=", user);

        // create preview and panel
        if (!instance.options.supportPreview || person.hasClass("isMyself") || !person.hasClass("showSnapshot") || panel.attr("no") > -1) {
          middle = null;
        }
        else {
          var preview = $('<div>').addClass("preview").append('<img>').appendTo(person);
        }

        panel.append(img.attr('src', panel.attr('src')).attr('usemap','#panel_'+uid).clone())
             .append(map.attr('name', 'panel_'+uid).clone()).end();

        // li.user
        person.hover(
          function() {
            person.addClass("focused");
          },
          function() {
            person.removeClass("focused");
          }
        );

        iconUser.addClass("pointer").off().click(function(){
          instance._popUpUserMenu(iconUser, uid);
          return false;
        });

        person.find(".airnote-user.isAirNote").addClass("pointer").off().click(function () {
          console.debug("[_enableEduHostControls] moderator click uid=", uid);
          instance._popUpUserMenu(iconUser, uid);
          return false;
        }).end();

        // click to preview and load image
        if (middle){
          $.map(middle, function(element) {
            $(element).off().click(function() {
              if (person.hasClass('waiting')) {
                return;
              }

              if (preview.css('display') != "none") {
                person.removeClass('waiting').end();
                $(".user-list").css("max-height", "").end();
                preview.hide().end();
                console.debug('Hide preview...');
              }
              else {
                person.addClass('waiting').end();

                preview.show().find("img").attr("src","").end();
                //preview.show().end();
                console.debug('Show preview...', preview);

                var w = window,
                  d = document,
                  e = d.documentElement,
                  g = d.getElementsByTagName('body')[0],
                  x = w.innerWidth || e.clientWidth || g.clientWidth,
                  y = w.innerHeight || e.clientHeight || g.clientHeight;
                var browserHeight = y;
                var screenHeight = window.screen.height;
                // var screenTop = window.screenTop;  not work
                var bound = chrome.app.window.current().getBounds();
                var addHeight = (screenHeight - bound.top - browserHeight - 80) + 300; // 80 is preserve for window task bar
                var max = $(".flexible").hasClass("small")?200:450;
                $(".user-list").css("max-height", addHeight < max ? addHeight : max);
                $('.preview').not(preview).hide().end(); // hide the other preview images
                $('.user.online').not(person).removeClass('waiting').end();  // reset the others

                // Ask preview image and display
                console.debug("Ask preview image and display for uid:", uid);
                request_PREVIEW_DATA(uid);
              }
            })
          });
        }

      });

      // map area
      $(".panel area").hover(
        function() {
          var displayImg = $(this).closest('map').prev();
          var src= displayImg.attr('src');
          displayImg.attr('src',presenterImgs[$(this).attr('region')]);
        },
        function() {
          var displayImg = $(this).closest('map').prev();
          var src= displayImg.closest('td').attr('src');
          displayImg.attr('src',src);
        }
      ).click(function() {
        var pno = $(this).attr("region"),
            pnoNow = $(this).closest("div.panel").attr("no"),
            uid = $(this).closest("li").attr("id"),
            isMyself = $(this).closest("li").hasClass("isMyself");

        // click mirroring panel
        if (pno == pnoNow) {
          var msg = (isMyself)?
              ((pno == 0)? $.t('info.currentPanel') : $.t('info.currentPanelSplit')) :
              ((pno == 0)? $.t('info.othersCurrentPanel') : $.t('info.othersCurrentPanelSplit'));
          //console.log("[_enableEduHostControls] Edu - no projection", uid, pno);
          (instance.options.rvaVersion >= 2.2)? instance._confirmStopProjection(msg, uid) : instance._showToast(msg, 3);
        }
        else {
          console.log("[_enableEduHostControls] Edu - Call RVA to project uid, pno=", uid, pno);
          var resultAfterCheck = instance._checkIfProjectOrNot(uid, pno, isMyself);
          if (resultAfterCheck === true) {
            $(this).off().closest("td").addClass("loading").empty().append($('<div>')).end();
            $("#myProjectPanel area").off();
            $("#myProjectPanel").addClass("disable");
            $(".myProjectBtns > div").off().addClass("disable").end();
          }
        }
        return false;
      });
    }

    // enable drag & drop functions
	if (isflexibleGUIDnD){
		instance._flexibleDragDrop();
	}

    //console.log("(END)[_enableEduHostControls]...");
  },
  _disableGroupFunction: function _disableGroupFunction(){
    //console.log("[_disableGroupFunction]...");
    $('#group-select').off().addClass('disabled');
    $('#group-select .triangleRight').hide();
    $('#g-list').empty();
    $('#select-user-group').addClass("hide").off();
    $('#deselect-user-group').addClass("hide").off();
  },
  // _enableFunctionArea: function _enableFunctionArea(){
  //   //console.log("[_enableFunctionArea]...");
  //   var instance = this;

  //   // enable Student Tablets
  //   var tabletIcon = $('#toggle-tablet');
  //   (instance.options.tabletsLocked)? tabletIcon.addClass('locked') : tabletIcon.removeClass('locked');
  //   tabletIcon.removeClass('disable').off().click(function(){
  //     if ($(this).hasClass('loading')){
  //       return;
  //     }

  //     $(this).addClass('loading');

  //     if ($(this).hasClass('locked')){
  //       $(this).removeClass('locked');
  //       //grace TBD
  //       // dsaApi.sendLockUnlock();  //Unlock all student Tablet
  //       window.setTimeout(function(){
  //         $(tabletIcon).removeClass('loading');
  //       }, 5000);
  //       return;
  //     }

  //     $(this).addClass('locked');
  //     //grace TBD
  //     // dsaApi.sendLockUnlock();  //Lock all student Tablet
  //     window.setTimeout(function(){
  //       $(tabletIcon).removeClass('loading');
  //     }, 5000);
  //     return;
  //   });

  //   // enable Terminate Session function
  //   $('#terminate-session').removeClass('disable').off().click(function(){
  //     instance._confirmTerminateSession();
  //     return;
  //   });

  // },
  // _disableFunctionArea: function _disableFunctionArea(){
  //   //console.log("[_disableGroupFunction]...");

  //   // disable Tablets
  //   $('#toggle-tablet').removeClass('locked').removeClass('loading').addClass('disable').off();

  //   // disable Terminate Session function
  //   $('#terminate-session').addClass('disable').off();

  // },
  _disableEduHostControls: function _disableEduHostControls() {
    console.debug("[_disableEduHostControls]...");

    // disable pin code function
    this._removePinCodeControls();

    // disable lock session function
    this._disableEduLockSessionFunc();

    // disable group function
    this._disableGroupFunction();

    // disable save user list function
    $('#save-user-list').off().addClass("hide");
    if (isflexibleGUIDnD){
      $(".userList-menu").off().addClass("hide").addClass("disable");
    }

    // // disable function area
    // this._disableFunctionArea();

    $(".user-list > ul").removeClass('has-right');

    // disable click function
    $(".user").off();
    $(".icon-user").off();
    $(".user-name").off();
    $(".panel").off().empty();
    $(".user-device").off();

    // remove preview
    $(".preview").remove();

    // disable hover function
    $(".user").off("mouseenter mouseleave");

    // disable drap & drop functions
    if (this.options.flexibleUserList && isflexibleGUIDnD) {
      //console.log("Destory sortable");
      var viewArea = $(".viewArea");
      viewArea.children("li").off();
      (viewArea.sortable("instance") == undefined) ? null : viewArea.sortable("destroy");
      $("li.user").each(function () {
        ($(this).draggable("instance") == undefined) ? null : $(this).draggable("destroy");
      });
    }
  //console.log("_disableEduHostControls...");
  },
  _hideVoting: function _hideVoting() {
    console.log("_hideVoting");
    var instance = this;
    var obj = $("#open-voting");
    $("#open-voting").removeClass("hide").addClass("hide");
    if (win = chrome.app.window.get("votingWindow")) {
      win.close(); // Close it when open
    }
  },
  votingHandler: function votingHandler(evt, data) {
    var instance = this;
    //console.info('votingHandler...', evt, data);

    //votingHandler('closeVotingWindow');
    if (evt === 'closeVotingWindow') {
      if (votingWin = chrome.app.window.get("votingWindow")) {
        votingWin.close(); // Close it when open
      }
      chrome.app.window.get("main").show(true);
      return;
    }

    // no preious question
    if (!instance.options.votingObject) {
      return;
    }

    //votingHandler('clickVotingAnswer', {answer: 'A'});
    if (evt === 'clickVotingAnswer') {
      //console.info('clickVotingAnswer...', data, instance.options.votingObject);
      instance.options.votingObject.studentClickAnswer = data.answer;
      return;
    }

    //votingHandler('submitVotingAnswer', {answer: 'A'});
    if (evt === 'submitVotingAnswer') {
      //console.info('submitVotingAnswer...', data, instance.options.votingObject);
      instance.options.votingObject.studentSubmitAnswer = data.answer;
      return;
    }

    var votingWin = chrome.app.window.get("votingWindow");

    //votingHandler('submitAnswerResult', {result: true, message: $.t("voting.submitSuccess")});
    if (evt === 'submitAnswerResult') {
      //console.info('submitAnswerResult...', data);
      instance.options.votingObject.studentAnswerSubmited = data.result;
      instance.options.votingObject.studentAnswerSubmitedMsg = data.message;
      (votingWin) ? votingWin.contentWindow.voting.votingPanel("submitAnswerResult", data.result, data.message): $('#open-voting').trigger('click');
      return;
    }

    //votingHandler('showAnswerResultDialog', {flag: 1/2/3, correctAnswer: '...'});
    if (evt === 'showAnswerResultDialog') {
      //console.info('showAnswerResultDialog...', data);
      votingWin.show(); //Molly help to rewrite this
      instance.options.votingObject.flag = data.flag;
      instance.options.votingObject.correctAnswer = data.correctAnswer;
      (votingWin) ? votingWin.contentWindow.voting.votingPanel("showAnswerResultDialog", data.flag, data.correctAnswer): $('#open-voting').trigger('click');
      return;
    }

    //votingHandler('removeVotingDialog');
    if (evt === 'removeVotingDialog') {
      //console.info('removeVotingDialog...', instance.options.votingObject);
      delete instance.options.votingObject['flag'];
      delete instance.options.votingObject['correctAnswer'];
      return;
    }

    //votingHandler('stopAnswerQuestion');
    if (evt === 'stopAnswerQuestion') {
      //console.info('stopAnswerQuestion...');
      instance.options.votingObject.stopVoting = true;
      instance.options.votingObject.isReady = false;
      (votingWin) ? votingWin.contentWindow.voting.votingPanel("stopAnswerQuestion"): null;
      // after stop voting, user can't open the voting window.
      instance.options.votingObject = {
        isReady: false,
        question: null
      };
      return;
    }

  },
  _popUpUserMenu: function _popUpUserMenu(iconUser, uid) {
    console.log("[_popUpUserMenu] uid, iconUser=", uid, iconUser);
    var instance = this;
    var user = instance.options.userList.filter(function (item) { if (item.uid == uid) return item; })[0];
    $('#drop-userlist-menu').removeClass('open');
    $(".viewArea > li").removeClass("focused");
    $(".project-user").removeClass("clicked");
    $("#drop-person-menu").remove();  // remove the others

    // HDMI IN user -- no choice
    if (user.os_type == 14) {
      console.log("[_popUpUserMenu2] I am HDMI IN, and no choice.");
      return;
    }

    console.log("[_popUpUserMenu] user=", user);
    var ul = $('<ul id="drop-person-menu" class="f-dropdown open">');
    //console.log("[_popUpUserMenu] x, y, user=", x, y, user);

    // You can NOT transfer host to AirPlay / Google Cast / HDMI IN user / DSA Lite
    if (instance.options.rvaType == "EDU" && user.isHost == false && noModeratorOsType.indexOf(user.os_type) == -1) {
      $('<li>').append($('<a href="#">').text($.t("info.transferRole"))).click(function(){
        if (instance.options.votingObject && instance.options.votingObject.isReady) {
            instance.messagePage($.t('voting.notAllowTransferHost'));
            return;
          }
          instance._confirmAskSomeoneToBeModerator(user.label, uid);
          ul.remove();
      }).appendTo(ul);
    }

    // You can NOT remove Moderator
    if (instance.options.rvaVersion >= 2.3 && user.isHost === false) {
      $('<li>').append($('<a href="#">').text($.t("info.terminateUserTitle"))).click(function () {
        instance._confirmTerminateUser(user.label, uid);
        ul.remove();
      }).appendTo(ul);
    }

    // You can NOT ask AirPlay / Google Cast / HDMI IN / DSA Lite users of AirNote
    if (supportNewAnnotation && !isNoOneMirroring() && user.isAirNote === false && user.panel < 0 && noAirNoteOsType.indexOf(user.os_type) == -1) {
      $('<li>').append($('<a href="#">').text($.t("airnote.launchAirNote"))).click(function () {
        // TODO: send command to RVA
        console.debug("[_popUpUserMenu] Moderator ask uid " + uid + " to AirNote");
        launch_ANNOTATION(uid);
        ul.remove();
      }).appendTo(ul);
    }

    // You can ask AirNote user to stop
    if (supportNewAnnotation  && user.isAirNote === true && user.panel < 0) {
      $('<li>').append($('<a href="#">').text($.t("airnote.terminateAirNote"))).click(function () {
        // TODO: send command to RVA
        console.debug("[_popUpUserMenu] Moderator ask uid " + uid + " to Terminate AirNote");
        terminate_ANNOTATION(uid);
        ul.remove();
      }).appendTo(ul);
    }

    if (ul.children("li").length == 0) {
      ul.remove();
      return;
    }

    ul.appendTo("body");

    var x = iconUser.position().left + 30,
      y = iconUser.position().top;
    //console.log("[_popUpUserMenu2]...", ul.children("li").length, x, y);

    if (instance.options.flexibleUserList) {
      switch (ul.children("li").length) {
        case 1:
          y += 70;
          break;
        case 2:
          y += 35;
          break;
        default:
      }
    }
    else {
      y += 15;
    }

    ul.css("left", x).css("top", y);
    //console.log("[_popUpUserMenu2-2] ", ul.position().left, ul.position().top);

    // below to suport old version user list pop-up
    var h = ul.outerHeight();
    var z = y + h;
    if (z > $(window).height()) {
      ul.css("top", $(window).height() - h - 15);
      //ul.css("bottom", 5).css("top", "auto");
    };

    scrollToRemoveElement($(".user-list"), function () { ul.remove(); });

  },
  _createPinCodeControls: function _createPinCodeControls() {
    //console.debug("[_createPinCodeControls]...", this.option.pinMandatory);
    var instance = this;

    $("#pinCodeBtn").css("display","").removeClass("hide").off().click(function(){
      if ($(this).hasClass("true")) {
        //console.log("Disable Pin Code");
        send_CMD_PIN_NOT_REQUIRED();
        instance.options.pinRequired = false;
        $(this).removeClass("true");
        return;
      }

      //console.log("Enable pin code");
      send_CMD_PIN_REQUIRED();
      instance.options.pinRequired = true;
      $(this).addClass("true");
    });

    //console.debug("[_createPinCodeControls]...", $("#pinCodeBtn"));
  },

  _removePinCodeControls: function _removePinCodeControls() {
    // console.log("[_removePinCodeControls]...", $("#pinCodeBtn"));
    $("#pinCodeBtn").addClass("hide").off();
  },

  _hideAllpages: function _hideAllpages() {
    $(this.element).children("div:not(.taskbar)").hide();
  },
  messagePage: function messagePage(msg, orgPage) {
     //console.log('[messagePage]...', msg, orgPage);
    var instance = this;
    instance._removeAllDialogs();

    var page = $('<div class="message-page">');

    //console.log(msg, typeof(msg));
    if (typeof(msg) == "string") {
      page.text(msg);
    }
    else {
      if (msg.title != undefined && msg.title != '') {
        $('<h4>').text(msg.title).prependTo(page);
      }
      //console.log(msg.description, typeof(msg.description));
      if (typeof(msg.description) == "string") {
        $('<p>').text(msg.description).appendTo(page);
      }
      else {
        $('<p>').append($(msg.description)).appendTo(page);
      }
    }
    page.dialog({
      autoOpen: true,
      resizable: false,
      modal: true,
      width: '95%',
      minheight: '200',
      // position: { my: "center", at: "left+50 top+110"},
      maxHeight: $('#container').height(),
      dialogClass: "msg-page",
      open: function( event, ui ) {
        //$( ".selector" ).dialog( "option", "position", { my: "center", at: "left bottom", of: button } );
      },
      close: function(event, ui) {
      },
      buttons: [
        {
          text: $.t((msg.btn != undefined)? msg.btn : "button.ok"),
          click: function(e) {
            $(this).dialog('close');
            (orgPage != undefined)? orgPage() : null;
            $(page).remove();
            e.preventDefault();
            return false;
         }
        }
      ]
    });

    if (instance.options.connected)
      instance._enableTaskbar();
  },
  messagePagePinCode: function messagePagePinCode(orgPage) {
     //console.log('[messagePage]...', msg, orgPage);
    var instance = this;
    instance._removeAllDialogs();
    var page = $('<div class="message-page" id="invalidPinCodePage">')
                .append($('<p>').text(!!pinCode?$.t("login.pinInvalid"):$.t('login.pinKeyin')))
                .append($('<input>').attr("id", "pinCodeInput").attr("type", "text").attr("maxLength", "4"))

    //console.log(msg, typeof(msg));
    page.dialog({
      autoOpen: true,
      resizable: false,
      modal: true,
      width: '70%',
      minheight: '200',
      // position: { my: "center", at: "left+50 top+110"},
      maxHeight: $('#container').height(),
      dialogClass: "msg-page no-titlebar",
      open: function( event, ui ) {
        //$( ".selector" ).dialog( "option", "position", { my: "center", at: "left bottom", of: button } );
      },
      close: function(event, ui) {
      },
      buttons: [
        {
          text: $.t("button.ok"),
          click: function() {
            pinCode = $("#pinCodeInput").val();            
            if (!pinCode){
              !!$(".message-page #pincodeRequireRemind").length 
                ? $("#pincodeRequireRemind").text($.t('login.pinRequired'))
                : $(".message-page").append($('<div id="pincodeRequireRemind" class="error center">').text($.t('login.pinRequired')));
              page.dialog("option", "position", { my: "center", at: "center", of: window });
              return;
            }
            if (pinCode.length != 4 || isNaN(pinCode)) {
              !!$(".message-page #pincodeRequireRemind").length
                ? $("#pincodeRequireRemind").text($.t('login.pinRequired'))
                : $(".message-page").append($('<div id="pincodeRequireRemind" class="error center">').text($.t('login.pinRequired')));
              page.dialog("option", "position", { my: "center", at: "center", of: window });
              return;
            }
            instance.openWaitingPageNoTimer($.t('login.connecting'));
            connectToRVA(true);
         }
        },
        {
          text: $.t("button.cancel"),
          click: function () {
            isPIN = false;
            $(this).dialog('close');            
          }
        },
      ]
    });

    if (instance.options.connected)
      instance._enableTaskbar();
  },
  connectionFailPage: function connectionFailPage(msg) {
    var instance = this;
    instance._removeAllDialogs();
    $(".message-page").remove();

    // Display message
    var page = $('<div class="message-page"></div>')
      .append($('<h4>').text($.t("login.connectFail")))
      .append($('<p>').text(msg));


    page.dialog({
      autoOpen: true,
      resizable: false,
      modal: true,
      width: '95%',
      minheight: '200',
      maxHeight: $('#container').height(),
      dialogClass: "msg-page",
      open: function( event, ui ) {
      },
      close: function(event, ui) {
      },
      buttons: [
        {
          text: $.t("login.tryAgain"),
          click: function() {
            event.preventDefault();
            $("#connect-btn").trigger("click");
            instance.openWaitingPageNoTimer($.t('login.connecting'));
            $(page).remove();
          }
        },
        {
          text: $.t("button.cancel"),
          click: function() {
            event.preventDefault();
            instance.refresh();
            $(page).remove();
          }
        },
      ]
    });

  },
  openModeratorPage: function openModeratorPage(data){
    //console.log("[openModeratorPage] data=", data);
    var instance = this;
    instance._removeAllDialogs();

    var err = (data==0 || data==1)? 'error' : '';
    var errMsg = (data==0)? $.t('login.required') : ((data==1)? $.t('login.wrongPassword') : '');

    // Display message
    var page = $('<div class="message-page"></div>')
                .append($('<h4>').text($.t('login.credentialFail')))
                .append($('<p>').text($.t('login.credentialFailMsg')))
                .append($('<p>').addClass('left').addClass('error').css('margin','auto 1rem')
                          .append($('<input id="moderatorPw" type="password">').attr('placeholder',$.t('info.pleaseEnterPassword')).addClass(err))
                          .append('<span class="toggleTeacherPwMsg">'+ errMsg +'</span>'));

    page.dialog({
      autoOpen: true,
      resizable: false,
      closeOnEscape: false,
      modal: true,
      width: '95%',
      minheight: '200',
      maxHeight: $('#container').height(),
      dialogClass: "msg-page no-titlebar",
      create: function( event, ui ) {
        $('#moderatorPw').focus();
      },
      open: function( event, ui ) {
      },
      close: function(event, ui) {
        instance.refresh();
        $('#icon-connect').trigger('click');
      },
      buttons: [
        {
          text: $.t("button.ok"),
          click: function() {
            var pw = $('#moderatorPw').val();
            if (pw=="") {
              $('#moderatorPw').addClass('error');
              $('.toggleTeacherPwMsg').text($.t('login.required'));
              $(this).focus();
              return;
            }
            if (pw.length < 4 || pw.length > 24) {
              $('#moderatorPw').addClass('error');
              $('.toggleTeacherPwMsg').text($.t('login.moderatorPasswordLength'));
              $(this).focus();
              return;
            }
            $('#pwBlock').removeClass('error');
            $('#toggleTeacherPw').val(pw);
            $('.toggleTeacherPwMsg').empty();
            $(this).dialog('close');
            $('#icon-connect').trigger('click');
            // Check and save modified password
            save_Moderator_Password(pw);
            check_as_Moderator();
            $(page).remove();
          }
        },
        {
          text: $.t("button.cancel"),
          click: function() {
            $(this).dialog('close');
            instance.refresh();
            $('#icon-connect').trigger('click');
            $(page).remove();
          }
        },
      ]
    });
  },
  openWaitingPageNoTimer: function openWaitingPageNoTimer(msg){
    //console.log('openWaitingPageNoTimer...');
    var instance = this;
    instance._removeAllDialogs();

    // Waiting with loading image and message
    var page = $('<div class="message-page" id="dialogWaitingNeverStop"></div>')
            .append($('<div>').addClass('loading-circle'))
            .append($('<p>').append($('<span class="msg">').text(msg)));

    page.dialog({
      autoOpen: true,
      resizable: false,
      closeOnEscape: false,
      modal: true,
      width: '95%',
      minheight: '200',
      maxHeight: $('#container').height(),
      open: function( event, ui ) {

      },
      close: function(event, ui) {
        $(this).dialog('destroy').remove();
      },
      dialogClass: "msg-page no-close",
    });
  },
  // openConnectedTimer: function openConnectedTimer(msg){
  //   //console.log('openConnectedTimer...');
  //   var instance = this;
  //   instance._removeAllDialogs();

  //   // Waiting with loading image and message
  //   page = $('<div id="connectedTimerPage"></div>')
  //           .append($('<div>').addClass('loading-circle'))
  //           .append($('<p>').append($('<span class="msg"></span>').text(msg)));

  //   page.dialog({
  //     autoOpen: true,
  //     resizable: false,
  //     closeOnEscape: false,
  //     modal: true,
  //     width: '95%',
  //     minheight: '200',
  //     maxHeight: $('#container').height(),
  //     open: function( event, ui ) {
  //     },
  //     close: function(event, ui) {
  //     },
  //     dialogClass: "msg-page no-close connectedTimerPage",
  //   });

  //   $('.connectedTimerPage').css('top',50);

  //   setTimeout(function(){
  //     //TBD
  //     // dsaApi.requestAttention();
  //     // dsaApi.displayOnTop();
  //     page.dialog('close');
  //     $(page).remove();
  //     //console.log('connectedTimer Timeout...');
  //   }, 3000);
  // },
  // _openWaitingPageWithTimer: function _openWaitingPageWithTimer(msg){
  //   //console.log('_openWaitingPageWithTimer...', msg);
  //   var instance = this;
  //   instance._removeAllDialogs();
  //   instance.options.second = 25;

  //   // Waiting page with Timer
  //   var page = $('<div class="message-page"></div>')
  //             .append($('<div>').addClass('loading-circle'))
  //             .append($('<p>').append($('<span class="msg"></span>').text(msg)))
  //             .append($('<p>').text(instance.options.second).attr("id","second"));

  //   page.dialog({
  //     autoOpen: true,
  //     resizable: false,
  //     closeOnEscape: false,
  //     modal: true,
  //     width: '95%',
  //     minheight: '200',
  //     maxHeight: $('#container').height(),
  //     dialogClass: "msg-page no-titlebar",
  //     open: function( event, ui ) {
  //     },
  //     close: function( event, ui ) {
  //     },
  //   });

  //   $('#second').powerTimer({
  //     interval: 1000,
  //     func: function(params) {
  //       instance.options.second--;
  //       $('#second').text(instance.options.second);
  //       //console.log('interval...', instance.options.second, params);
  //     },
  //   });

  //   instance.options.timer = window.setTimeout(function(){
  //     $('#second').powerTimer('stop');
  //     instance.options.second = 0;
  //     page.dialog('close');
  //     $(page).remove();
  //     //console.log('setTimeout...');
  //   }, instance.options.second * 1000);

  // },
  closeWaitingPageWithTimer: function closeWaitingPageWithTimer(msg) {
    //console.log('closeWaitingPageWithTimer...', msg);
    var instance = this;
    instance.stopWaitingPageWithTimer();
    instance.messagePage(msg);
  },
  stopWaitingPageWithTimer: function stopWaitingPageWithTimer() {
    //console.log('stopWaitingPageWithTimer...');
    var instance = this;
    $('#second').powerTimer('stop');
    clearTimeout(instance.options.timeInterval);
    instance.options.second = 0;
    instance._removeAllDialogs();
    instance.refresh();
  },
  _confirmTerminateUser: function _confirmTerminateUser(askName, uid) {
    //console.log("[_confirmTerminateUser] (askName, uid)=", askName, uid);
    var instance = this;
    instance._removeAllDialogs();

    // confirm to terminate someone
    var page = $('<div class="message-page"></div>')
                .append($('<h4>').text($.t('info.terminateUserTitle')))
                .append($('<p>').html($.t('info.terminateUserMsg', {username: '<b>'+ askName +'</b>'})));

    page.dialog({
      autoOpen: true,
      resizable: false,
      modal: true,
      width: '95%',
      minheight: '200',
      maxHeight: $('#container').height(),
      dialogClass: "msg-page",
      open: function( event, ui ) {
      },
      close: function(event, ui) {
      },
      buttons: [
        {
          text: $.t("button.yes"),
          click: function() {
            $(this).dialog('close');
            send_CMD_CLIENT_REMOVE(uid);
          }
        },
        {
          text: $.t("button.no"),
          click: function () {
            $(this).dialog('close');
          }
        },
      ]
    });

  },
  //-----------------------------
  beAskedHostPage: function beAskedHostPage(msg) {
    var instance = this;
    instance._removeAllDialogs();
    instance._disableTaskbar();


    instance.options.second = 23;

    // Ask to be moderator page
    var page = $('<div class="message-page"></div>')
      .append($('<p></p>').text(msg))
      .append($('<p></p>').text(instance.options.second).attr("id", "second"));

   page.dialog({
      autoOpen: true,
      resizable: false,
      modal: true,
      width: '95%',
      minheight: '200',
      maxHeight: $('#container').height(),
      dialogClass: "msg-page",
      open: function( event, ui ) {
      },
      close: function(event, ui) {
      },
      buttons: [
        {
          text: $.t("button.yes"),
          click: function() {
            event.preventDefault();
            instance.options.second = 0;
            $('#second').powerTimer('stop');
            instance._enableTaskbar();
            instance.refresh();
            $(page).remove();
            $(instance.options.nowPage).trigger("click");
            // say YES
            send_CMD_MODERATOR_APPROVED();
          }
        },
        {
          text: $.t("button.no"),
          click: function () {
            event.preventDefault();
            instance.options.second = 0;
            $('#second').powerTimer('stop');
            instance._enableTaskbar();
            instance.refresh();
            $(page).remove();
            $(instance.options.nowPage).trigger("click");
            // say NO
            send_CMD_MODERATOR_DENIED();
          }
        },
      ]
    });

    $('#second').powerTimer({
      name: 'mytimer',
      sleep: 1000,
      func: function () {
        $('#second').text(instance.options.second);
        if (instance.options.second <= 0) {
          instance._enableTaskbar();
          instance.refresh();
          $(instance.options.nowPage).trigger("click");
          instance.options.second = 0;
          $(".message-page").remove();
          $('#second').powerTimer('stop');
          //console.log('End beAskedHostPage Timer...');
        } else {
          instance.options.second--;
          //console.log('beAskedHostPage Timer --');
        }
      },
    });
  },
  // EDU - receive request to be moderator
  moderatorRequest: function moderatorRequest() {
    var instance = this;
    instance._removeAllDialogs();
    instance.options.second = 23;

    // Ask to be host page
    var page = $('<div class="message-page" id="dialogModeratorRequest">')
                .append($('<p>').text($.t('login.wannaBeHost')))
                .append($('<p>').text(instance.options.second).attr("id","second"));

    page.dialog({
      autoOpen: true,
      resizable: false,
      closeOnEscape: false,
      modal: true,
      width: '95%',
      minheight: '200',
      maxHeight: $('#container').height(),
      dialogClass: "msg-page no-titlebar",
      open: function( event, ui ) {

        // dsaApi.mouseUp();
        // grace TBD
        var w = chrome.app.window.current();
        w && w.focus();
        w && console.log(w);
      },
      close: function(event, ui) {
        clearInterval(instance.options.timeInterval);
        instance.options.second = 0;
        $(this).dialog('destroy').remove();
        // dsaApi.mouseUp();
      },
      buttons: [
        {
          text: $.t("button.yes"),
          click: function() {
            send_CMD_MODERATOR_APPROVED();
            page.dialog('close');
          }
        },
        {
          text: $.t("button.no"),
          click: function () {
            send_CMD_MODERATOR_DENIED();
            page.dialog('close');
          }
        },
      ]
    });

    instance.options.timeInterval = window.setInterval(function(){
      instance.options.second--;
      $('#second').text(instance.options.second);
      if ( instance.options.second <= 0) {
        page.dialog('close');
      }
    }, 1000);

    if (instance.options.tabletsLocked) {
      $("#toggle-tablet").removeClass('locked');
      instance.options.tabletsLocked = false;
    }

  },
  _confirmAskSomeoneToBeModerator: function _confirmAskSomeoneToBeModerator(askName, uid) {
    console.log("[_confirmAskSomeoneToBeModerator] (askName, uid)=", askName, uid);
    var instance = this;
    instance._removeAllDialogs();

    // confirm to Ask someone to be host page
    var page = $('<div class="message-page"></div>')
     .append($('<p>').html($.t('login.transfterHost', {username: '<b>'+ askName +'</b>'})));

    page.dialog({
      autoOpen: true,
      resizable: false,
      modal: true,
      width: '95%',
      minheight: '200',
      maxHeight: $('#container').height(),
      dialogClass: "msg-page",
      open: function( event, ui ) {
      },
      close: function(event, ui) {
        $(this).dialog('destroy').remove();
      },
      buttons: [
        {
          text: $.t("button.yes"),
          click: function() {
            $(this).dialog('close');
            instance._waitingForModeratorRequest();
            send_CMD_MODERATOR_REQUEST(uid);
          }
        },
        {
          text: $.t("button.no"),
          click: function () {
            $(this).dialog('close');
          }
        },
      ]
    });
  },
  _waitingForModeratorRequest: function _waitingForModeratorRequest(){
    //console.debug('[_waitingForModeratorRequest]...');
    var instance = this;
    instance._removeAllDialogs();
    instance.options.second = 25;

    // Waiting page with Timer
    var page = $('<div class="message-page" id="dialogModeratorRequest"></div>')
              .append($('<div>').addClass('loading-circle'))
              .append($('<p>').append($('<span class="msg"></span>').text($.t('login.waiting'))))
              .append($('<p>').text(instance.options.second).attr("id","second"));

    page.dialog({
      autoOpen: true,
      resizable: false,
      closeOnEscape: false,
      modal: true,
      width: '95%',
      minheight: '200',
      maxHeight: $('#container').height(),
      dialogClass: "msg-page no-titlebar",
      open: function( event, ui ) {

        // dsaApi.mouseUp();
      },
      close: function( event, ui ) {
        $(this).dialog('destroy').remove();
        // dsaApi.mouseUp();
      },
    });

    instance.options.timeInterval = window.setInterval(function(){
      instance.options.second--;
      $('#second').text(instance.options.second);
      if ( instance.options.second <= 0) {
        clearInterval(instance.options.timeInterval);
        page.dialog('close');
      }
    }, 1000);

  },
  closeWaitingForModeratorRequest: function closeWaitingForModeratorRequest(msg) {
    console.debug('[closeWaitingForModeratorRequest]...', msg);
    var instance = this;
    instance.closeAllDialogs();
    instance.messagePage(msg);
    // dsaApi.mouseUp();
  },
  // Remove all dialogs
  closeAllDialogs: function closeAllDialogs() {
    //console.error('[closeAllDialogs]...');
    var instance = this;
    // stop timer
    clearInterval(instance.options.timeInterval);
    instance.options.second = 0;
    instance._removeAllDialogs(); // Remove all dialogs
    //($("#dialogModeratorRequest").length > 0)? $("#dialogModeratorRequest").dialog("close") : null;
    instance.refresh();
    // dsaApi.mouseUp();
  },
  closeDialogWaitingNeverStop: function closeDialogWaitingNeverStop() {
    //console.error('[closeDialogWaitingNeverStop]...');
    //($("#dialogWaitingNeverStop").length > 0)? $("#dialogWaitingNeverStop").dialog("close") : null;
    $("#dialogWaitingNeverStop").dialog("close");
    this.refresh();
  },
  //-----------------------------
  _confirmTermHost: function _confirmTermHost(askName, uid) {
    var instance = this;
    instance._removeAllDialogs();
    instance._disableTaskbar();
    $(".message-page").remove();

    // confirm to Ask someone to be host page
    var rmStirng = $.t("info.terminateUserMsg");
    rmStirng = rmStirng.replace(/__username__/, '<b>' + askName + ' ?</b>');
    var page = $('<div class="message-page"><b>' + $.t("info.terminateUserTitle") + '</b></div>')
      .append($('<p></p>').html(rmStirng));


    page.dialog({
      autoOpen: true,
      resizable: false,
      modal: true,
      width: '95%',
      minheight: '200',
      maxHeight: $('#container').height(),
      dialogClass: "msg-page",
      open: function( event, ui ) {
      },
      close: function(event, ui) {
      },
      buttons: [
        {
          text: $.t("button.yes"),
          click: function() {
            event.preventDefault();
            instance._enableTaskbar();
            instance.refresh();
            $(page).remove();
            $(instance.options.nowPage).trigger("click");
            // say YES
            //console.log("Ask someone to be moderator...", uid);
            //instance._openWaitingPageWithTimer($.t("login.waiting"));
            // Ask someone to be moderator
            send_CMD_CLIENT_REMOVE(uid);
          }
        },
        {
          text: $.t("button.no"),
          click: function () {
            event.preventDefault();
            instance._enableTaskbar();
            instance.refresh();
            $(page).remove();
            $(instance.options.nowPage).trigger("click");
          }
        },
      ]
    });
  },

  _remindNoVideoPage: function _remindNoVideoPage() {
    var instance = this;
    instance._removeAllDialogs();

    // Display message
    var page = $('<div class="message-page"></div>')
      .append($('<p></p>').text($.t("video.needFullScreen")));

   page.dialog({
      autoOpen: true,
      resizable: false,
      modal: true,
      width: '95%',
      minheight: '200',
      maxHeight: $('#container').height(),
      dialogClass: "msg-page",
      open: function( event, ui ) {
      },
      close: function(event, ui) {
      },
      buttons: [
        {
          text: $.t("button.ok"),
          click: function() {
            event.preventDefault();
            instance._enableTaskbar();
            instance.refresh();
            $(page).remove();
            $(instance.options.nowPage).trigger("click");
          }
        },
      ]
    });
  },
  askSendAnotherFilePage: function askSendAnotherFilePage(data) {
    //console.log('[askSendAnotherFilePage]...', data);
    var instance = this;
    instance._removeAllDialogs();

    var page = $('<div class="message-page"></div>')
                .append($('<h4>').text($.t('sharing.shareInProgress')))
                .append($('<p>').text($.t('sharing.shareUploading')+' : '+ data.finished +'/'+ data.total +'.'))
                .append($('<p>').text($.t('sharing.shareGiveUp')));
    // No, Yes
    page.dialog({
      autoOpen: true,
      resizable: false,
      modal: true,
      width: '95%',
      minheight: '200',
      maxHeight: $('#container').height(),
      dialogClass: "msg-page",
      open: function( event, ui ) {
      },
      close: function(event, ui) {
      },
      buttons: [
        {
          text: $.t("button.yes"),
          click: function() {
            event.preventDefault();
            instance.refresh();
            $(page).remove();
            send_CMD_FILE_SHARING_DATA_CANCEL();
            select_a_file_to_share(1);
          }
        },
        {
          text: $.t("button.no"),
          click: function () {
            event.preventDefault();
            instance.refresh();
            $(page).remove();
            $("#icon-tool").trigger("click");
          }
        },
      ]
    });

  },
  fileTooLargePage: function fileTooLargePage() {
    var instance = this;
    instance._removeAllDialogs();

    var fileLimit = 3;
    if (supportSharingBigFile) {
      fileLimit = 10;
    }
    var page = $('<div class="message-page"></div>')
                .append($('<h4>').text($.t('sharing.failTitle')))
                .append($('<p>').text($.t('sharing.sizeError', { postProcess: "sprintf", sprintf: [fileLimit]})));

    page.dialog({
      autoOpen: true,
      resizable: false,
      modal: true,
      width: '95%',
      minheight: '200',
      maxHeight: $('#container').height(),
      dialogClass: "msg-page",
      open: function( event, ui ) {
      },
      close: function(event, ui) {
      },
      buttons: [
        {
          text: $.t("button.ok"),
          click: function() {
            event.preventDefault();
            $(page).remove();
            instance.refresh();
            $("#icon-tool").trigger("click");
          }
        },
      ]
    });
  },
  askSendFilePage: function askSendFilePage(data) {
    var instance = this;
    instance._removeAllDialogs();

    var img = (data.image && data.image != '') ? '<p><img src="data:image/png;base64,' + data.image + '"></p>' : '';

    var page = $('<div class="message-page"></div>')
      .append($('<h4></h4>').text(data.title))
      .append(img)
      .append($('<p></p>').text(data.description));

    page.dialog({
      autoOpen: true,
      resizable: false,
      modal: true,
      width: '95%',
      minheight: '200',
      maxHeight: $('#container').height(),
      dialogClass: "msg-page",
      open: function( event, ui ) {
      },
      close: function(event, ui) {
      },
      buttons: [
        {
          text: $.t("button.yes"),
          click: function() {
            event.preventDefault();
            $(page).remove();
            instance.waitingforSendingPage();
            // file to send
            confirm_to_send_file();
          }
        },
        {
          text: $.t("button.no"),
          click: function () {
            event.preventDefault();
            instance.refresh();
            $(page).remove();
            $("#icon-tool").trigger("click");
          }
        },
      ]
    });
  },
  askSendScreenPage: function askSendFilePage(data) {
    var instance = this;
    instance._removeAllDialogs();

    var img = (data.image && data.image != '') ? '<p><img src="data:image/png;base64,' + data.image + '"></p>' : '';

    var page = $('<div class="message-page" id="sendScreen"></div>')
      .append($('<h4></h4>').text(data.title))
      .append(img)
      .append($('<p></p>').text(data.description));

    page.dialog({
      autoOpen: true,
      resizable: false,
      modal: true,
      width: '95%',
      minheight: '200',
      maxHeight: $('#container').height(),
      dialogClass: "msg-page",
      open: function( event, ui ) {
      },
      close: function(event, ui) {
      },
      buttons: [
        {
          text: $.t("button.yes"),
          click: function() {
            event.preventDefault();
            $(page).remove();
            instance.waitingforSendingPage();
            // file to send
            confirm_to_send_file();
          }
        },
        {
          text: $.t("button.no"),
          click: function () {
            event.preventDefault();
            instance.refresh();
            $(page).remove();
            $("#icon-tool").trigger("click");
          }
        },
      ]
    });
  },
  waitingforSendingPage: function waitingforSendingPage() {
    var instance = this;
    instance._removeAllDialogs();
    instance._disableTaskbar();

    var page = $('<div class="message-page"></div>')
      .append($('<p><img src="../images/loading_green-50x50.gif"></p>'));

    page.dialog({
      autoOpen: true,
      resizable: false,
      modal: true,
      width: '95%',
      minheight: '200',
      maxHeight: $('#container').height(),
      dialogClass: "msg-page",
      open: function( event, ui ) {
      },
      close: function(event, ui) {
      },
      buttons: [

      ]
    });

  },
  systemBusyPage: function systemBusyPage() {
    var instance = this;
    instance._removeAllDialogs();
    instance._enableTaskbar();

    var page = $('<div class="message-page"></div>')
      .append($('<b></b>').text($.t("sharing.systemBusy")))
      .append($('<p></p>').text($.t("sharing.systemBusyMsg")));

    page.dialog({
      autoOpen: true,
      resizable: false,
      modal: true,
      width: '95%',
      minheight: '200',
      maxHeight: $('#container').height(),
      dialogClass: "msg-page",
      open: function( event, ui ) {
      },
      close: function(event, ui) {
      },
      buttons: [
        {
          text: $.t("button.ok"),
          click: function() {
            event.preventDefault();
            instance.refresh();
            $(page).remove();
            $("#icon-tool").trigger("click");
          }
        },
      ]
    });
  },
  sendingFilePage: function sendingFilePage(data) {
    var instance = this;
    instance._removeAllDialogs();
    instance._disableTaskbar();

    $("#callUploading").addClass("active");

    // Sending file
    var page = $('<div class="message-page" id="sendingFilePage"></div>')
      .append($('<h4>').text($.t('sharing.sendingFile')))
      .append($('<div class="sending-image"></div>'))
      .append($('<p></p>').text(data.finished + '/' + data.total + ' ' +  $.t("sharing.haveReceived")));

    page.dialog({
      autoOpen: true,
      resizable: false,
      modal: true,
      width: '95%',
      minheight: '200',
      maxHeight: $('#container').height(),
      dialogClass: "msg-page",
      open: function( event, ui ) {
        $(novo).height(400);
      },
      close: function(event, ui) {
        $(novo).css('height','');
      },
      buttons: [
        {
          text: $.t("button.cancel"),
          click: function() {
            event.preventDefault();
            $(novo).css('height','');
            instance._enableTaskbar();
            $(page).remove();
            instance.refresh();
            $("#callUploading").removeClass("active");
            $("#icon-tool").trigger("click");
            // ask RVA to stop sending file
            send_CMD_FILE_SHARING_DATA_CANCEL();
          }
        },
        {
          text: $.t("button.close"),
          click: function() {
            $(novo).css('height','');
            event.preventDefault();
            instance._enableTaskbar();
            set_background_file_sending(true);
            $(page).remove();
            instance.refresh();
            $("#icon-tool").trigger("click");
          }
        },
      ]
    });
  },
  closeSendingFilePage: function closeSendingFilePage() {
    var instance = this;
    $("#callUploading").removeClass("active");
    if ($("#sendingFilePage").length > 0) {
      instance._removeAllDialogs();
      instance._hideAllpages();
      instance._enableTaskbar();
      $("#sendingFilePage").remove();
      instance.refresh();
      $("#icon-tool").trigger("click");
    }
  },

  _displayAboutInfo: function _displayAboutInfo() {
    var instance = this;
    instance._removeAllDialogs();

    var Version = $('<div>').addClass("vs").text($.t("login.version") + " " + manifest.version); // DSA version number
    var link = $('<a target="_blank" href=https://service.launchnovo.com/novoconnect/version/' + ((chrome.i18n.getUILanguage() === "zh-CN") ? "cn" : "ww") + ' id="aboutLink" > ').text($.t("login.compatibilityUrl"));

    // Ask to be close page
    var page = $('<div id="aboutInfo"></div>')
                .append($('<img src="../images/icon.png">'))
                .append($('<h4>').text(manifest.name))
                .append(Version)
                .append($('<div>').addClass("cp").html('Copyright &copy; 2018 Delta Electronics, Inc. All Rights Reserved.'))
                .append($('<div>').text($.t("login.aboutInfo2")))
                .append($('<div class="right">').append(link));

    page.dialog({
      autoOpen: true,
      resizable: false,
      modal: true,
      closeOnEscape: true,
      width: '90%',
      maxHeight: $('#container').height(),
      dialogClass: "msg-page titlbar-only-close no-buttonpane",
      open: function( event, ui ) {
        (window.innerWidth > 500)? $(this).dialog("option", "width", 400).dialog("option","position",{ my: "center", at: "center", of: window }) : null;
      },
      close: function(event, ui) {
      }
    });
  },
  _disableVersionPage: function _disableVersionPage() {
    $("#version-btn").click(function () {
      console.log('ICONB');
    });

  },
  askQuitDsa: function askQuitDsa() {
    var instance = this;
    // instance._removeAllDialogs();

    // Ask to be close page
    var page = $('<div class="message-page" id="close-page"></div>')
                .append($('<h4>').text($.t('info.confirmExitTitle')))
                .append($('<p>').text($.t('info.confirmExitMsg')));

    page.dialog({
      autoOpen: true,
      resizable: false,
      modal: true,
      width: '95%',
      minheight: '200',
      maxHeight: $('#container').height(),
      dialogClass: "msg-page",
      open: function( event, ui ) {
      },
      close: function(event, ui) {

      },
      buttons: [
        {
          text: $.t("button.yes"),
          click: function(event) {
             event.preventDefault();
            // call luke
            app_close();
            //instance.destroy();
            // Close all window
            for (var i = 0, wins = chrome.app.window.getAll(); i < wins.length; i++) {
              wins[i].close();
            }
          }
        },
        {
          text: $.t("button.no"),
          click: function (event) {
            $(this).dialog("close");
            $(page).remove();
          }
        },
      ]
    });
  },
  _destroy: function _destroy() {
    this.element.remove();
  },
  updateSessionLockState: function updateSessionLockState() {
    var instance = this;
   console.log("Session Lock State", isSessionLock);

    this.options.sessionLockedMode = isSessionLock;
    this.refresh();
    $(this.options.nowPage).trigger("click");
  },
  sessionLockFailLogin: function sessionLockFailLogin(msg) {
    var instance = this;
    instance._removeAllDialogs();

    // Display message
    var page = $('<div class="message-page"></div>')
      .append($('<h4>').text($.t("group.connectFailSessionLockedTitle")))
      .append($('<p>').text(msg));

    page.dialog({
      autoOpen: true,
      resizable: false,
      modal: true,
      width: '95%',
      minheight: '200',
      maxHeight: $('#container').height(),
      dialogClass: "msg-page",
      open: function( event, ui ) {
      },
      close: function(event, ui) {
      },
      buttons: [
        {
          text: $.t("button.ok"),
          click: function() {
            event.preventDefault();
            $(page).remove();
            instance.refresh();
          }
        },
      ]
    });

  },
  _askSessionLock: function _askSessionLock() {
    var instance = this;
    instance._removeAllDialogs();

    // Ask to be close page
    var page = $('<div class="message-page" id="close-page"></div>')
      .append('<h4>' + $.t("info.lockSession") + '</h4>')
      .append('<p> ' + $.t("info.confirmLockSession") + ' </p>');

    page.dialog({
      autoOpen: true,
      resizable: false,
      modal: true,
      width: '95%',
      minheight: '200',
      maxHeight: $('#container').height(),
      dialogClass: "msg-page",
      open: function( event, ui ) {
      },
      close: function(event, ui) {
      },
      buttons: [
        {
          text: $.t("button.yes"),
          click: function() {
          event.preventDefault();
          $(page).remove();
          var others = $(".message-page").not('#close-page');
          if (others && others.length > 0) {
            $(others).show();
            return;
          }
          instance.refresh();
          if (instance.options.connected)
            $(instance.options.nowPage).trigger("click");
          }
        },
        {
          text: $.t("button.no"),
          click: function() {
            event.preventDefault();
            instance._enableTaskbar();
            instance.refresh();
            $(page).remove();
            $(instance.options.nowPage).trigger("click");
            request_SESSION_LOCK();
          }
        },
      ]
    });
  },
  _enableEduLockSessionFunc: function _enableEduLockSessionFunc(){
    //console.log("[_enableEduLockSessionFunc]...");

    var eduLockSession = $('#edu-lock-session');
    $('#edu-lock-session .icon').off().click(function(){
      if ( eduLockSession.hasClass("true") ) {
        //console.log("Unlock session...");
        request_SESSION_UNLOCK();
        $(this).off();
        return;
      }

      // ask dialog
      var page = $('<div class="message-page"></div>');
      $('<h4>').text($.t("group.confirm")).prependTo(page);
      $('<p>').text($.t("info.confirmLockSession")).appendTo(page);
      page.dialog({
        autoOpen: true,
        resizable: false,
        modal: true,
        width: '90%',
        //minheight: '200',
        //maxHeight: $('#container').height(),
        dialogClass: "msg-page",
        close: function(event, ui) {
          $(this).dialog('destroy').remove();
        },
        buttons: [
          {
            text: $.t("button.yes"),
            click: function() {
              $(this).dialog('close');
              //console.log("Lock session...");
              request_SESSION_LOCK();
              $('#edu-lock-session .icon').off();
              $(page).remove();
            }
          },
          {
            text: $.t("button.no"),
            click: function () {
              $(this).dialog('close');
              $(page).remove();
            }
          },
        ]
      });
    });
    $("#lockSessionBtn").off().click(function(){
      $('#edu-lock-session .icon').trigger("click");
    });
  },
  _disableEduLockSessionFunc: function _disableEduLockSessionFunc(){
    //console.log("[_disableEduLockSessionFunc]...");
    $('#edu-lock-session .icon').off();
    $("#lockSessionBtn").off();
  },
});
