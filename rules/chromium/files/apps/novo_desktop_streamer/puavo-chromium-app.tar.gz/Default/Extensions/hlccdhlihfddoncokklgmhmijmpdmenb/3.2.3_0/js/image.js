var pending_request_id = null;

var imageSelected = 0;

function imageStart(id) {
  navigator.webkitGetUserMedia({
    audio: false,
    video: {
      mandatory: {
        chromeMediaSource: "desktop",
        chromeMediaSourceId: id,
        maxWidth: display_width,
        maxHeight: display_height
      },
      optional: [{
        maxFrameRate: 12
      }]
    }
  }, gotStream, getUserMediaError);
}

function initial_ImageService() {
  imageSelected = 1;
  pending_request_id = chrome.desktopCapture.chooseDesktopMedia(["screen"], imageStart);
}

function gotStream(stream) {
  console.log("Received local stream");
  imageSelected = 0;
  var video = document.querySelector("video");
  video.srcObject = stream;
  localstream = stream;
  connectToRVA(true);
  stream.oninactive = function () {
    send_CMD_REMOVE_REQUEST();
    pending_request_id = null;
    doLogout();
    console.log("Ended");
  };
}

function getUserMediaError() {
  imageSelected = 0;
  //	  chrome.desktopCapture.cancelChooseDesktopMedia(pending_request_id);
  pending_request_id = null;
  connectToRVA(false);
  console.log("getUserMedia() failed.");
}

function getImageCaptureBytes() {
  var cropCanvas = document.querySelector('canvas');
  var canvasContext = cropCanvas.getContext('2d');
  canvasContext.drawImage(video, 0, 0);
  var uri = cropCanvas.toDataURL("image/jpeg", quality_rate).replace("image/jpeg", "image/octet-stream");

  var image = dataURItoBlob(uri);
  //screen-mirroring quality
  var scale_time = 0;
  while (image.length >= 768000) {
    scale_time = scale_time + 1;
    var new_q_rate = quality_rate - scale_time * 0.05;
    uri = cropCanvas.toDataURL("image/jpeg", new_q_rate).replace("image/jpeg", "image/octet-stream");
    image = dataURItoBlob(uri);
    if (image.length < 768000 || scale_time > 10) {
      break;
    }
  }
  return image;
}

function getImageCaptureBytesForScreenShot() {
  var cropCanvas = document.querySelector('canvas');
  var canvasContext = cropCanvas.getContext('2d');
  canvasContext.drawImage(video, 0, 0);
  var uri = downScaleImage(cropCanvas, 0.4).toDataURL("image/png", 0.2).replace("image/png", "image/octet-stream");
  var image = dataURItoBlob(uri);
  console.log("Screenshot size = " + image.length);
  if (image.length > 512000) {
    uri = downScaleImage(cropCanvas, 0.1).toDataURL("image/png", 0.2).replace("image/png", "image/octet-stream");
  }
  return image;
}

function getScreenShotCaptureBytesForSharing() {
  var cropCanvas = document.querySelector('canvas');
  var canvasContext = cropCanvas.getContext('2d');
  canvasContext.drawImage(video, 0, 0);

  var uri = cropCanvas.toDataURL("image/jpg", quality_rate).replace("image/jpg", "image/octet-stream");

  var image = dataURItoBlob(uri);
  //screen-mirroring quality
  var scale_time = 0;
  while (image.length >= 1536000) {
    scale_time = scale_time + 1;
    var new_q_rate = quality_rate - scale_time * 0.05;
    uri = cropCanvas.toDataURL("image/jpg", new_q_rate).replace("image/jpg", "image/octet-stream");
    image = dataURItoBlob(uri);
    if (image.length < 1536000 || scale_time > 10) {
      break;
    }
  }
  return image;
}


function dataURItoBlob(dataURI) {
  // adapted from:
  // http://stackoverflow.com/questions/6431281/save-png-canvas-image-to-html5-storage-javascript

  // convert base64 to raw binary data held in a string
  // doesn't handle URLEncoded DataURIs
  var byteString = atob(dataURI.split(',')[1]);

  // separate out the mime component
  var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0]

  // write the bytes of the string to an ArrayBuffer
  var ab = new ArrayBuffer(byteString.length);
  var ia = new Uint8Array(ab);
  for (var i = 0; i < byteString.length; i++) {
    ia[i] = byteString.charCodeAt(i);
  }

  // write the ArrayBuffer to a blob, and you're done
  var blob = new Blob([ab], {
    "type": mimeString
  });
  //	  return blob;
  return ia;
};

function downScaleImage(img, scale) {
  var imgCV = document.createElement('canvas');
  imgCV.width = img.width;
  imgCV.height = img.height;
  var imgCtx = imgCV.getContext('2d');
  imgCtx.drawImage(img, 0, 0);
  return downScaleCanvas(imgCV, scale);
}

// scales the canvas by (float) scale < 1
// returns a new canvas containing the scaled image.
function downScaleCanvas(cv, scale) {
  if (!(scale < 1) || !(scale > 0)) throw ('scale must be a positive number <1 ');
  var sqScale = scale * scale; // square scale = area of source pixel within target
  var sw = cv.width; // source image width
  var sh = cv.height; // source image height
  var tw = Math.floor(sw * scale); // target image width
  var th = Math.floor(sh * scale); // target image height
  // EDIT (credits to @Enric ) : was ceil before, and creating artifacts :
  //                           var tw = Math.ceil(sw * scale); // target image width
  //                           var th = Math.ceil(sh * scale); // target image height
  var sx = 0,
    sy = 0,
    sIndex = 0; // source x,y, index within source array
  var tx = 0,
    ty = 0,
    yIndex = 0,
    tIndex = 0; // target x,y, x,y index within target array
  var tX = 0,
    tY = 0; // rounded tx, ty
  var w = 0,
    nw = 0,
    wx = 0,
    nwx = 0,
    wy = 0,
    nwy = 0; // weight / next weight x / y
  // weight is weight of current source point within target.
  // next weight is weight of current source point within next target's point.
  var crossX = false; // does scaled px cross its current px right border ?
  var crossY = false; // does scaled px cross its current px bottom border ?
  var sBuffer = cv.getContext('2d').
  getImageData(0, 0, sw, sh).data; // source buffer 8 bit rgba
  var tBuffer = new Float32Array(3 * sw * sh); // target buffer Float32 rgb
  var sR = 0,
    sG = 0,
    sB = 0; // source's current point r,g,b
  /* untested !
  var sA = 0;  //source alpha  */

  for (sy = 0; sy < sh; sy++) {
    ty = sy * scale; // y src position within target
    tY = 0 | ty; // rounded : target pixel's y
    yIndex = 3 * tY * tw; // line index within target array
    crossY = (tY != (0 | ty + scale));
    if (crossY) { // if pixel is crossing botton target pixel
      wy = (tY + 1 - ty); // weight of point within target pixel
      nwy = (ty + scale - tY - 1); // ... within y+1 target pixel
    }
    for (sx = 0; sx < sw; sx++, sIndex += 4) {
      tx = sx * scale; // x src position within target
      tX = 0 | tx; // rounded : target pixel's x
      tIndex = yIndex + tX * 3; // target pixel index within target array
      crossX = (tX != (0 | tx + scale));
      if (crossX) { // if pixel is crossing target pixel's right
        wx = (tX + 1 - tx); // weight of point within target pixel
        nwx = (tx + scale - tX - 1); // ... within x+1 target pixel
      }
      sR = sBuffer[sIndex]; // retrieving r,g,b for curr src px.
      sG = sBuffer[sIndex + 1];
      sB = sBuffer[sIndex + 2];

      /* !! untested : handling alpha !!
         sA = sBuffer[sIndex + 3];
         if (!sA) continue;
         if (sA != 0xFF) {
             sR = (sR * sA) >> 8;  // or use /256 instead ??
             sG = (sG * sA) >> 8;
             sB = (sB * sA) >> 8;
         }
      */
      if (!crossX && !crossY) { // pixel does not cross
        // just add components weighted by squared scale.
        tBuffer[tIndex] += sR * sqScale;
        tBuffer[tIndex + 1] += sG * sqScale;
        tBuffer[tIndex + 2] += sB * sqScale;
      } else if (crossX && !crossY) { // cross on X only
        w = wx * scale;
        // add weighted component for current px
        tBuffer[tIndex] += sR * w;
        tBuffer[tIndex + 1] += sG * w;
        tBuffer[tIndex + 2] += sB * w;
        // add weighted component for next (tX+1) px
        nw = nwx * scale
        tBuffer[tIndex + 3] += sR * nw;
        tBuffer[tIndex + 4] += sG * nw;
        tBuffer[tIndex + 5] += sB * nw;
      } else if (crossY && !crossX) { // cross on Y only
        w = wy * scale;
        // add weighted component for current px
        tBuffer[tIndex] += sR * w;
        tBuffer[tIndex + 1] += sG * w;
        tBuffer[tIndex + 2] += sB * w;
        // add weighted component for next (tY+1) px
        nw = nwy * scale
        tBuffer[tIndex + 3 * tw] += sR * nw;
        tBuffer[tIndex + 3 * tw + 1] += sG * nw;
        tBuffer[tIndex + 3 * tw + 2] += sB * nw;
      } else { // crosses both x and y : four target points involved
        // add weighted component for current px
        w = wx * wy;
        tBuffer[tIndex] += sR * w;
        tBuffer[tIndex + 1] += sG * w;
        tBuffer[tIndex + 2] += sB * w;
        // for tX + 1; tY px
        nw = nwx * wy;
        tBuffer[tIndex + 3] += sR * nw;
        tBuffer[tIndex + 4] += sG * nw;
        tBuffer[tIndex + 5] += sB * nw;
        // for tX ; tY + 1 px
        nw = wx * nwy;
        tBuffer[tIndex + 3 * tw] += sR * nw;
        tBuffer[tIndex + 3 * tw + 1] += sG * nw;
        tBuffer[tIndex + 3 * tw + 2] += sB * nw;
        // for tX + 1 ; tY +1 px
        nw = nwx * nwy;
        tBuffer[tIndex + 3 * tw + 3] += sR * nw;
        tBuffer[tIndex + 3 * tw + 4] += sG * nw;
        tBuffer[tIndex + 3 * tw + 5] += sB * nw;
      }
    } // end for sx
  } // end for sy

  // create result canvas
  var resCV = document.createElement('canvas');
  resCV.width = tw;
  resCV.height = th;
  var resCtx = resCV.getContext('2d');
  var imgRes = resCtx.getImageData(0, 0, tw, th);
  var tByteBuffer = imgRes.data;
  // convert float32 array into a UInt8Clamped Array
  var pxIndex = 0; //
  for (sIndex = 0, tIndex = 0; pxIndex < tw * th; sIndex += 3, tIndex += 4, pxIndex++) {
    tByteBuffer[tIndex] = Math.ceil(tBuffer[sIndex]);
    tByteBuffer[tIndex + 1] = Math.ceil(tBuffer[sIndex + 1]);
    tByteBuffer[tIndex + 2] = Math.ceil(tBuffer[sIndex + 2]);
    tByteBuffer[tIndex + 3] = 255;
  }
  // writing result to canvas.
  resCtx.putImageData(imgRes, 0, 0);
  return resCV;
}


function initial_IMAGESOCKET() {
  if (typeof data_socketId === 'undefined') {
    chrome.sockets.tcp.create({
      persistent: false,
      bufferSize: 8192,
      name: "ImageData"
    }, function(createInfo) {
      data_socketId = createInfo.socketId;
      chrome.sockets.tcp.connect(data_socketId, rvaIp, TCP_DATA_PORT, function(result) {
        if (result === 0) {
          isDataConnected = true;
          console.log("Data Connection Success -> Intial Image Sending");
          if (isDataNeedPreload) {
            sendImagePreload();
          }
          start_SENDING_IMAGE();
        } else {
          console.log("Data Connection Fail");
        }
      });
    });
  } else {
    chrome.sockets.tcp.getInfo(data_socketId, function(socketInfo) {
      if (chrome.runtime.lastError) {
        console.log("No Image Connection Intial");
        chrome.sockets.tcp.create({
          persistent: false,
          bufferSize: 8192,
          name: "ImageData"
        }, function(createInfo) {
          data_socketId = createInfo.socketId;
          chrome.sockets.tcp.connect(data_socketId, rvaIp, TCP_DATA_PORT, function(result) {
            if (result === 0) {
              isDataConnected = true;
              console.log("Data Connection Success -> Intial Image Sending");
              if (isDataNeedPreload) {
                sendImagePreload();
              }
              start_SENDING_IMAGE();
            } else {
              console.log("Data Connection Fail");
            }
          });
        });
      } else {
        if (socketInfo.connected) {
          console.log("Data Image Already connected");
          if (isImageSendingPause) {
            console.log("Streaming mode pause image");
          } else {
            start_SENDING_IMAGE();
          }
        } else {
          chrome.sockets.tcp.create({
            persistent: false,
            bufferSize: 8192,
            name: "ImageData"
          }, function(createInfo) {
            data_socketId = createInfo.socketId;
            chrome.sockets.tcp.connect(data_socketId, rvaIp, TCP_DATA_PORT, function(result) {
              if (result === 0) {
                isDataConnected = true;
                console.log("Data Connection Success -> Intial Image Sending");
                if (isDataNeedPreload) {
                  sendImagePreload();
                }
                start_SENDING_IMAGE();
              } else {
                console.log("Data Connection Fail");
              }
            });
          });
        }
      }
    });
  }
}
function sendImagePreload() {
  //buf[1] 1 :JPEG 2 : PNG 3 : H264
  var buf = new Uint8Array(MINUM_MSG_LENGTH + 4);
  buf[0] = 8;
  if (supportH264) {
    buf[1] = 3;
  } else {
    buf[1] = 1;
  }
  buf[2] = client_id;
  buf[3] = 0;
  buf[4] = 0;
  buf[5] = 0;
  buf[6] = 0;
  buf[7] = 0;

  chrome.sockets.tcp.send(data_socketId, buf.buffer, function(sendInfo) {
    if (chrome.runtime.lastError) {
      console.log("Image Preload Error");
    }
  });
}

var times = 1;

function start_SENDING_IMAGE() {
  if (isDataConnected) {
    if (times == 128) {
      times = 1;
    }

    lastImageTime = new Date().getTime();
    var image_bytes = getImageCaptureBytes();
    var length = image_bytes.length;
    var buf = new Uint8Array(length + 6);
    buf[0] = 1;
    buf[1] = times; // seq number
    var sizeArray = convert_int_into_bytes_big_endian(length);
    buf[2] = sizeArray[0];
    buf[3] = sizeArray[1];
    buf[4] = sizeArray[2];
    buf[5] = sizeArray[3];
    for (var i = 0; i < length; i++) {
      buf[i + 6] = image_bytes[i];
    }
    chrome.sockets.tcp.send(data_socketId, buf.buffer, function(sendInfo) {
      if (chrome.runtime.lastError) {
        console.log("Image Error");
      } else {
        if (sendInfo.resultCode == 0) {
          times = times + 1;
        } else {
          console.log("Send DATA_IMAGE Fail");
        }
      }
    });
  } else {
    console.log("Data Connection is closed");
  }
}
