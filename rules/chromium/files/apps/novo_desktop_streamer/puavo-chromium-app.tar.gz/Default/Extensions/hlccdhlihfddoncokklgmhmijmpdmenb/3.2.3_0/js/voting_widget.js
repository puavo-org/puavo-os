var mainWindow = chrome.app.window.get("main").contentWindow,
    questionType = {
      1: "Thumb Up/Down",
      2: "True/False",
      3: "Multiple-choice: 3",
      4: "Multiple-choice: 4",
      5: "Multiple-choice: 5",
      6: "Open-ended",
    },
    questionTypeTransfer = {
      1: "voting.thumbsUpDown",
      2: "voting.TrueFalse",
      3: "voting.3Choices",
      4: "voting.4Choices",
      5: "voting.5Choices",
      6: "voting.openEnded",
    };

$.widget("custom.votingPanel", {
  // Default options
  options: {
    currentQuestion: null,
    answerFilePath: null,
  },
  _create: function _create() {
    $("#font-func .bigger").click(function() {
      var fontSize = parseInt($("#q-content").css("font-size")) + 2;
      $("#q-content").css("font-size", fontSize);
    });
    $("#font-func .smaller").click(function() {
      var fontSize = parseInt($("#q-content").css("font-size")) - 2;
      if (fontSize <= 5) fontSize = 5;
      $("#q-content").css("font-size", fontSize);
    });
  },
  _init: function _init() {
    // init status
    this.options.currentQuestion = null;
    this.options.answerFilePath = null;
    this.closeAllDialogs();
    $("#sidebar").empty();
    $("#q-title").empty();
    $("#q-content").empty().append('<div id="q-image" style="position: absolute; top: 38%; left: 38%;"><img src="../images/logo_watermark.png" /></div>');
    $("#answers").empty().removeClass();
    $("#bottom-btn").css("visibility", "hidden");
    $("#send-btn").off();
    $("#hint").empty();
  },
  // file selection
  createQuestion: function createQuestion(question){
    console.log("[createQuestion] question=", question);
    var instance = this;
    instance._init();  // reset all objects
    instance.options.currentQuestion = question;
    
    $("#sidebar").append($("<div>").addClass("active").append($('<b>Q' + (question.num+1) + '. </b>')).append(question.subject));
    $("#q-title").text($.t("voting.newTitle") + (question.num+1))
      .append($('<span class="small"> ('+ $.t(questionTypeTransfer[question.type]) + ')</span>'));
    $("#q-content").show().html(question.richSubject);
    
    if (question.image){
      var img = $('<img src="data:image/png;base64,'+ question.image +'">').click(function(){
                  instance.closeAllDialogs();
                  $('#dialog-preview').empty().append($('<img>').attr('src','data:image/png;base64,'+ question.image).addClass('only-img'));
                  $("#dialog-preview").dialog({
                    autoOpen: true,
                    modal: true,
                    resizable: false,
                    draggable: false,
                    width: '90%',
                    dialogClass: "msg-page titlbar-only-close",
                    show: {
                      effect: "blind",
                      duration: 300
                    }
                  });
                });
      $("#q-content").append($('<div id="q-image"></div>').append(img));
    }
    $("#send-btn").click(function(){
      instance._submitAnswerEvent(this);
    });
    
    var answer = $('<button class="answer"></button>').click(instance._answerEvent);
    var qType = parseFloat(question.type);
    switch(qType) {
      case 1:  // QuestionTypeThumbsUpDown = 1
        answer = $('<span class="answer"></span>').click(instance._answerEvent);
        $("#answers").addClass("commend")
          .append($(answer).clone(true).addClass('thumbs-down').attr('value',4))
          .append($(answer).clone(true).addClass('thumbs-up').attr('value',3));
        break;
      case 2:  // QuestionTypeTrueFalse = 2
        $("#answers").addClass("boolean")
          .append($(answer).clone(true).val(1).text($.t('voting.true')))
          .append($(answer).clone(true).val(2).text($.t('voting.false')));
        break;
      case 3:  // QuestionType3Choices = 3
        $("#answers").addClass("choice-3")
          .append($(answer).clone(true).val(5).text('A'))
          .append($(answer).clone(true).val(6).text('B'))
          .append($(answer).clone(true).val(7).text('C'));
        break;
      case 4:  // QuestionType4Choices = 4
        $("#answers").addClass("choice-4")
          .append($(answer).clone(true).val(5).text('A'))
          .append($(answer).clone(true).val(6).text('B'))
          .append($(answer).clone(true).val(7).text('C'))
          .append($(answer).clone(true).val(8).text('D'));
        break;
      case 5:  // QuestionType5Choices = 5
        $("#answers").addClass("choice-5")
          .append($(answer).clone(true).val(5).text('A'))
          .append($(answer).clone(true).val(6).text('B'))
          .append($(answer).clone(true).val(7).text('C'))
          .append($(answer).clone(true).val(8).text('D'))
          .append($(answer).clone(true).val(9).text('E'));
        break;
      case 6:  // QuestionTypeOpenEnded = 6
        answer = $('<span id="choose_img">...</span>').click(function() {
                    chrome.fileSystem.chooseEntry({
                      type:'openFile',
                      accepts: [{ mimeTypes: ['image/*'] }]},  // access type
                      function(entry){
                        if (entry.isFile) {
                          fileEntry = entry;
                          setUploading(fileEntry);
                        }
                        else {
                        	console.error("cancel folder select");
                        }
                      }
                    );
                  });
        $("#answers").addClass("upload")
          .append($('<input id="img_path" type="text" />')
                    .attr('placeholder',$.t('voting.drogImage'))
                    .attr('readonly','readonly')
                    .click(function(){$("#choose_img").trigger('click');}))
          .append($(answer));
          drag = false;
          if (window.File && window.FileList && window.FileReader) {
            drag_init();
          }          
        break;
      default:
        console.error("Question Type does NOT exist.", question);
        //video.videoPanel("[createQuestion] question=", question);
    }

    //(chrome.app.window.current().isMaximized()) ? winOnMax() : winOnRestore();
  },
  submitAnswerResult: function submitAnswerResult(result, message) {
    console.log("submitAnswerResult...", result, message, this.options.currentQuestion.answerSubmited);
    this.options.currentQuestion.answerSubmited = result;
    if (message && message!='') {
      $("#send-btn").hide();
      $("#hint").show().text($.t(message));
      $("#bottom-btn").css("visibility", "visible");
    }
  },
  stopAnswerQuestion: function stopAnswerQuestion() {
    var instance = this;
    //console.log("stopAnswerQuestion......", instance.options.currentQuestion);
    if (instance.options.currentQuestion != null){
      // disable all buttons
      instance._disableAnswer();
      // show message
      $("#hint").show().text($.t('voting.stoppedMsg'));
      $("#bottom-btn").css("visibility", "visible");
      // close all dialogs
      instance.closeAllDialogs();
    }
  },
  showAnswerResultDialog: function showAnswerResultDialog(flag, correctAnswer) {
    console.log("[showAnswerResultDialog] ", flag, correctAnswer);
    var instance = this;
    instance._disableAnswer();
    instance.closeAllDialogs();

    var answerDialog = {
      1: "#dialog-correct",
      2: "#dialog-incorrect",
      3: "#dialog-timeout",
    };
    
    var correctList = {
      0: "notSelected",
      1: "true",
      2: "false",
      3: "thumbUp",
      4: "thumbDown",
      5: "A",
      6: "B",
      7: "C",
      8: "D",
      9: "E",
    };

    if(flag == 2){
        var ans = "";
        for (var key in correctList) {
            // skip loop if the property is from prototype
            if (!correctList.hasOwnProperty(key)) continue;

            var obj = correctList[key];
            if (correctAnswer.toLowerCase() == obj.toLowerCase()){
                ans = obj;
                break;
            }
        }
        $("#correctAnswer").text(  ans ? $.t('voting.' + ans): correctAnswer);
    }
    
    console.log("[showAnswerResultDialog] answerDialog[flag]=", flag, answerDialog[flag]);
    $(answerDialog[flag]).dialog({
      closeOnEscape: true,
      resizable: false,
      width: 400,
      modal: true,
      dialogClass: "msg-page",
      buttons: [
        {
          text: $.t('button.ok'),
          click: function() {
            instance.closeAllDialogs();
            $(this).dialog("close");
          }
        }
      ]
    });
    return;
  },
  _answerEvent: function _answerEvent() {
    if ($(this).hasClass("checked")){
      return false;
    }
    $(this).siblings().removeClass("checked");
    $(this).addClass("checked");
    
    var data = {
      answer: $(this).attr('value')
    };
    //console.info('_answerEvent...', data);

    // show button
    $("#send-btn").removeClass("active").show();
    $("#hint").empty();
    $("#bottom-btn").css("visibility", "visible");
  },
  _submitAnswerEvent: function _submitAnswerEvent(btn) {

    if ($(btn).hasClass('active')){
      return false;
    }

    var instance = this;

    // Double confirm when the user send duplicate answer.
    if (instance.options.currentQuestion.answerSubmited){
      $("#dialog-confirm").dialog({
        resizable: false,
        width: 400,
        modal: true,
        dialogClass: "msg-page alert",
        buttons: [
          {
            text: $.t('button.ok'),
            click: function() {
              instance._sendAnswer();
              $(this).dialog("close");
              $("#img_path").focus();
            }
          },
          {
            text: $.t('button.cancel'),
            click: function () {
              $(this).dialog("close");
              $("#img_path").focus();
            }
          },
        ]
      });
      return false;
    }

    instance._sendAnswer();
  },
  _sendAnswer: function _sendAnswer() {
    var instance = this;
    $("#send-btn").addClass('active');
  
    // answer type 6
    if ($("#answers").hasClass("upload")){
      console.log(this.options.answerFilePath, drag);
      if (this.options.answerFilePath != "" && !drag) {
        // TODO: call luke
        mainWindow.sendVotingEntryAnswer(instance.options.currentQuestion.num, fileEntry);
        mainWindow.novo.novoconnect('votingHandler', 'submitVotingAnswer', {answer: fileEntry});
      }else{
        mainWindow.sendVotingDragEntryAnswer(instance.options.currentQuestion.num, dragFile);
        mainWindow.novo.novoconnect('votingHandler', 'submitVotingAnswer', {answer: dragFile});        
      }
      return false;
    }

    // TODO: call luke
    mainWindow.sendVotingAnswer(instance.options.currentQuestion.num, $('.answer.checked').attr('value'));
    mainWindow.novo.novoconnect('votingHandler', 'submitVotingAnswer', {answer: $('.answer.checked').attr('value')});
    return false;
  },
  _disableAnswer: function _disableAnswer() {
    //console.log("_disableAnswer......");
    // disable all answer buttons, input
    $(".answer").off().removeClass("answer");
    $("#answers").addClass("stopped");
    $("#answers input").off();
    $("#answers span").off();
    $("#img_path").off().attr("disabled", true);
    $("#choose_img").off().addClass("disabled");
    $("#send-btn").hide();
  },
  closeAllDialogs: function closeAllDialogs() {
    //console.log("closeAllDialogs......");
    var answerDialogs = ["#dialog-correct","#dialog-incorrect","#dialog-timeout","#dialog-confirm","#dialog-preview"];
    $.map(answerDialogs, function( val, idx ) {
      // Check exist and open, then close it.
      if ($(val) && $(val).hasClass("ui-dialog-content") && $(val).dialog("isOpen"))
        $(val).dialog("close");
      return;
    });
  },
  _destroy: function _destroy() {
    // events bound via _on are removed automatically
    // revert other modifications here
    // remove generated elements
    this.remove();
  }
});

function setUploading(fileEntry){
  chrome.fileSystem.getDisplayPath(fileEntry, function(displayPath) {
    $('#img_path').val(displayPath);
  });
  drag = false;
  // show button
  $("#send-btn").removeClass("active").show();
  $("#hint").empty();
  $("#bottom-btn").css("visibility", "visible");
}

// https://github.com/GoogleChrome/chrome-app-codelab/tree/master/lab5_data/javascript/2_drop_files
function dragOver(e) {
    e.stopPropagation();
    e.preventDefault();
    // var valid = isValid(e.dataTransfer);
    // if (valid) {
    //   dropText.innerText="Drop files and remote images and they will become Todos";
    //   // document.body.classList.add("dragging");
    // } else {
    //   dropText.innerText="Can only drop files and remote images here";
    //   // document.body.classList.add("invalid-dragging");
    // }
}

function isValid(dataTransfer) {
    return dataTransfer && dataTransfer.types 
      && ( dataTransfer.types.indexOf('Files') >= 0 
        || dataTransfer.types.indexOf('text/uri-list') >=0 )
}

// reset style and text to the default
function dragLeave(e) {
    // dropText.innerText=defaultDropText;
    // document.body.classList.remove('dragging');
    // document.body.classList.remove('invalid-dragging');
}

// on drop, we create the appropriate TODOs using dropped data
function drop(e, model) {
    e.preventDefault();
    // e.stopPropagation();
    if (isValid(e.dataTransfer)) {
      if (e.dataTransfer.types.indexOf('Files') >= 0) {
        var files = e.dataTransfer.files;
        for (var i = 0; i < files.length; i++) {
          // var text = files[i].name+', '+files[i].size+' bytes';
          // model.addTodo(text, false, {file: files[i]});
          drag = true;
          dragFile = files[i];
          console.log(files[i]);
          $('#img_path').val(files[i].name);
          $("#send-btn").removeClass("active").show();
          $("#hint").empty();
          $("#bottom-btn").css("visibility", "visible");          
        }
      } else { // uris
        // var uri=e.dataTransfer.getData("text/uri-list");
        // model.addTodo(uri, false, {uri: uri});
        // console.log(uri);
      }
    }
    dragLeave();
}

function drag_init() {
    console.log("drag_init");
    document.getElementById("img_path").addEventListener("dragover", dragOver, false);
    document.getElementById("img_path").addEventListener("dragleave", dragLeave, false);
    document.getElementById("img_path").addEventListener("drop", drop, false);
}
