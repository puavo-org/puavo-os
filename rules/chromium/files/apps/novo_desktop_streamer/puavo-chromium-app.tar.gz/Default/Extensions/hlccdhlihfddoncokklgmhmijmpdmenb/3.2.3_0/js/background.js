var app;

function reload() { chrome.runtime.reload() }

chrome.runtime.onInstalled.addListener(function (callback) {
   console.log(callback);
   if (callback.reason == "update") {
       notifyNewVersion();
   }
});

chrome.runtime.requestUpdateCheck(function (status) {
    if (status == "update_available") {
        console.log("update pending...");
    } else if (status == "no_update") {
        console.log("no update found");
    } else if (status == "throttled") {

    } else {

    }
});

function send_CMD_REMOVE_REQUEST() {
    var buf = new Uint8Array(4);
    buf[0] = 4;
    buf[1] = 1;
    buf[2] = 0;
    buf[3] = 0;
    mainWindow = chrome.app.window.get("main").contentWindow;
    chrome.sockets.tcp.send(mainWindow.cmd_socketId, buf.buffer, function (sendInfo) {
        // if (sendInfo.resultCode == 0) {
        //     console.log("Send CMD REMOVE REQUEST Success");
        //     closeCMDConnection();
        // } else {
        //     console.log("Send CMD REMOVE REQUEST Fail");
        //     close_all_sockets();
        //     doLogout();
        //     // set all parameters to default
        //     initial_parameters();
        // }
    });
}

function notifyNewVersion() {
    var title = "New Version Release";
    var message = "Your software is up-to-date.";
    if (chrome.i18n.getUILanguage() == "zh-TW"){
        title = "新版本發佈";
        message = "您的軟體已經是最新的。";
    }
    var opt = {
        type: "basic",
        title: title,
        message: message,
		iconUrl: "../images/icon.png",
		priority: 0
	};
	chrome.notifications.create("newVersionRelease", opt, function(callback) {
		console.log("notifyNewVersion", callback);
	});
}

chrome.notifications.clear("newVersionRelease");

chrome.app.runtime.onLaunched.addListener(function() {
	chrome.app.window.create(
    '../views/main.html',
    {
      id: 'main',
      bounds: {
        width: 438,
        height: 213
    	},
    	frame: {
    	  type: "none"
    	},
    // 	frame: 'none',
    	resizable: false
    },
    function(win) {
      win.onClosed.addListener(function() {
        send_CMD_REMOVE_REQUEST();

        // Close all child windows
        close_TCPserver();
        for(var i=0, wins=chrome.app.window.getAll(); i < wins.length; i++) {
          if (wins[i]!=chrome.app.window.current())
            wins[i].close();
        }
        //connection_remove();
      });
    }
  );

  	function MainHandler() {
  		BaseHandler.prototype.constructor.call(this)
  	}

    _.extend(MainHandler.prototype, {
        get: function() {
        // handle get request
        this.write('OK!, ' + this.request.uri)
        	}
    	})

    for (var key in BaseHandler.prototype) {
        MainHandler.prototype[key] = BaseHandler.prototype[key]
    }

    var handlers = [
//        ['.*', MainHandler]
//        ['.*', PackageFilesHandler]
        ['.*', DirectoryEntryHandler]
    ]

    app = new chrome.WebApplication({handlers:handlers, port:9090});

});

function open_TCPserver() {
	app.start();
}

function close_TCPserver() {
	app.stop();
}