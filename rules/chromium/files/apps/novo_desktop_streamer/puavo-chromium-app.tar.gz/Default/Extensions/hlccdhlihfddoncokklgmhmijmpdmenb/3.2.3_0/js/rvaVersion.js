var rvaNumber = 2.0;
var nvc = "B380";
var isCorp = false;
var nvc_edition = "";
var bsp = "";

var sessionInfoOn = false;
var supportVoting = 0;
var supportExchangeServer = false;
var supportURLSharing = false;
var supportSharingBigFile = false;
var supportLocalVideo = false;
var supportNewVideoPlay = false;
var isNVCMatching = false;
var isSoftwareMatching = false;
var supportFastSwitchScreen = false;
var supportFastImageSending = false;
var supportNewWifiLan = false;
var supportScreenWithdraw = false;
var supportSessionLock = false;
var supportAnnotation = false;
var supportTerminateUser = false;
var isNewFileSharing = false;

var isNovoCast = false;

var isDataNeedPreload = false;
var isSoftwareDecoder = false;
var isHideVoting = false;
var isflexibleGUI = false;
var isflexibleGUIDnD = false;
//NE3000
var isSupportUsbLan = false;
//New function for annotation
var supportNewAnnotation = false;
//For Cast TW1
var isCastTW1 = false;
var isCastCN = false;
//For new NovoTouch
var supportH264 = false;
var isNewDataConnection = false;
var support7SocketChannel = false;


function receive_CMD_NVC_EDITION_STRING(bValues, s_bytes) {
  //  console.log("Receive CMD BSP_VERSION");
  var j = 0;
  var length = bValues[s_bytes] + s_bytes;
  var strBuf = new Uint8Array(bValues[s_bytes] - 4);
  for (var i = s_bytes + 4; i < length; i++) {
    strBuf[j] = bValues[i];
    j++;
  }

  nvc_edition = convert_bytes_array_into_str(strBuf);
  console.log("nvc_edition = ", nvc_edition);
}

function receive_CMD_BSP_VERSION(bValues, s_bytes) {
  //  console.log("Receive CMD BSP_VERSION");
  var j = 0;
  var length = bValues[s_bytes] + s_bytes;
  var strBuf = new Uint8Array(bValues[s_bytes] - 4);
  for (var i = s_bytes + 4; i < length; i++) {
    strBuf[j] = bValues[i];
    j++;
  }

  bsp = convert_bytes_array_into_str(strBuf);
  console.log("BSP = ", bsp);
}

function receive_CMD_RVA_EDUCATION(bValues, s_bytes) {
  console.log("Receive CMD RVA EDUCATION");
  isCorp = false;
}

function receive_CMD_RVA_ENTERPRISE_V2(bValues, s_bytes) {
  console.log("Receive CMD RVA ENTERPRISSE_v2");
  isCorp = true;
}

function receive_CMD_NVC_MODEL(bValues, s_bytes) {
  //  console.log("Receive CMD NVC_MODEL");
  var j = 0;
  var length = bValues[s_bytes] + s_bytes;
  var strBuf = new Uint8Array(bValues[s_bytes] - 4);
  for (var i = s_bytes + 4; i < length; i++) {
    strBuf[j] = bValues[i];
    j++;
  }
  //setRvaNVC("NovoConnect-B380");
  //setRvaNVC("NovoConnect-B100");
  setRvaNVC(convert_bytes_array_into_str(strBuf));
}

function receive_CMD_RVA_VERSION(bValues, s_bytes) {
  //  console.log("Receive CMD RVA VERSION");
  var j = 0;
  var length = bValues[s_bytes] + s_bytes;
  var strBuf = new Uint8Array(bValues[s_bytes] - 4);
  for (var i = s_bytes + 4; i < length; i++) {
    strBuf[j] = bValues[i];
    j++;
  }
  //setRvaVersion("v2.3");
  //setRvaVersion("v2.2");
  //setRvaVersion("v1.6");
  setRvaVersion(convert_bytes_array_into_str(strBuf));
  refreshAllFunctionState();
}

function setRvaVersion(verion_string) {
  console.log("verion_string ", verion_string);
  rvaNumber = parseFloat(verion_string.replace("v", ""));
  console.log("RVA VERSION ", rvaNumber);
}

function setRvaNVC(nvc_string) {
  console.log(nvc_string);
  nvc = nvc_string.replace("NovoConnect-", "").replace("NT-", "").replace("NC-", "");
  console.log("NVC MODEL ", nvc);
}

function setRvaType(state) {
  isCorp = state;
}

function refreshAllFunctionState() {
  console.log(nvc);

  switch (nvc) {
    case "T336":
    case "CN360S":
      isNVCMatching = false;
      break;
    case "B360":
    case "B380":
      isNVCMatching = true;
      isflexibleGUIDnD = false;
      isSoftwareMatching = true;
      if (rvaNumber >= 1.5) {
        supportVoting = 1;
        supportNewWifiLan = true;
        supportLocalVideo = true;
      }
      if (rvaNumber >= 1.6) {
        supportExchangeServer = true;
        supportNewVideoPlay = true;
      }
      if (rvaNumber >= 2.0) {
        supportFastImageSending = true;
        supportSharingBigFile = true;
      }
      if (rvaNumber >= 2.1) {
        supportFastSwitchScreen = true;
      }
      if (rvaNumber >= 2.2) {
        supportURLSharing = true;
        supportScreenWithdraw = true;
      }
      if (rvaNumber >= 2.3) {
        supportSessionLock = true;
        supportAnnotation = true;
        supportTerminateUser = true;
      }
      if (rvaNumber >= 2.4) {
        isDataNeedPreload = true;
        isNewFileSharing = true;
        isSoftwareDecoder = true;
      }
      if (rvaNumber >= 2.5) {
        isflexibleGUI = true;
      }
      if (rvaNumber >= 2.6) {
        supportNewAnnotation = true;
      }
      if (rvaNumber >= 2.7) {
        isNewDataConnection = true;
      }
      if (rvaNumber >= 2.8) {
        isSoftwareMatching = false;
        isNVCMatching = false;
      }
      break;
    case "NT1000":
      //Novo Touch
      isNVCMatching = true;
      isflexibleGUIDnD = false;
      isSoftwareMatching = true;
      if (rvaNumber >= 1.5) {
        supportVoting = 1;
        supportNewWifiLan = true;
        supportLocalVideo = true;
      }
      if (rvaNumber >= 1.6) {
        supportExchangeServer = true;
        supportNewVideoPlay = true;
      }
      if (rvaNumber >= 2.0) {
        supportFastImageSending = true;
        supportSharingBigFile = true;
      }
      if (rvaNumber >= 2.1) {
        supportFastSwitchScreen = true;
      }
      if (rvaNumber >= 2.2) {
        supportURLSharing = true;
        supportScreenWithdraw = true;
      }
      if (rvaNumber >= 2.3) {
        supportSessionLock = true;
        supportAnnotation = true;
        supportTerminateUser = true;
      }
      if (rvaNumber >= 2.4) {
        isDataNeedPreload = true;
        isNewFileSharing = true;
        isSoftwareDecoder = true;
      }
      if (rvaNumber >= 2.5) {
        isflexibleGUI = true;
        supportNewAnnotation = true;
      }
      if (rvaNumber >= 3.0) {
		    isflexibleGUI = true;
        isflexibleGUIDnD = true;
        isSupportUsbLan = true;
        isNVCMatching = true;
        supportNewAnnotation = true;
        isNewDataConnection = true;
        support7SocketChannel = true;
      }
      if (rvaNumber >= 3.1) {
        isSoftwareMatching = false;
        isNVCMatching = false;
      }
      break;
      //case "C300":
    case "NC300":
      //Novo Cast Intermediate Releases
    case "NC1000":
      //Novo Cast
      isNovoCast = true;
      isNVCMatching = true;
      isSoftwareMatching = true;
      if (rvaNumber >= 3.0) {
        supportFastSwitchScreen = true;
        supportExchangeServer = true;
        supportFastImageSending = true;
        supportURLSharing = true;
        supportSharingBigFile = true;
        supportScreenWithdraw = true;
        supportSessionLock = true;
        supportAnnotation = true;
        supportTerminateUser = true;
        supportNewWifiLan = true;
        supportLocalVideo = true;
        supportNewVideoPlay = true;
        isSoftwareDecoder = true;
        isDataNeedPreload = true;
        isNewFileSharing = true;
        isHideVoting = true;
        supportVoting = -1;
        isflexibleGUIDnD = false;
      }
      if (rvaNumber >= 3.1) {
        supportNewAnnotation = true;
      }
      //FOR TW1
      if (nvc_edition == "PRO-TW1-EDU") {
        isCastTW1 = true;
        supportNewAnnotation = false;
        supportAnnotation = false;
        supportURLSharing = false;
        supportExchangeServer = false;
      }
      if (nvc_edition == "PRO-CN-EDU") {
        isCastCN = true;
        supportNewAnnotation = false;
        supportAnnotation = false;
        supportURLSharing = false;
        supportExchangeServer = false;
      }
      if (rvaNumber >= 3.2) {
        isSoftwareMatching = false;
        isNVCMatching = false;
      }
      break;
    case "NE3000":
      //Novo Enterprise
      isSoftwareMatching = true;
      if (rvaNumber >= 3.1) {
        supportFastSwitchScreen = true;
        supportExchangeServer = true;
        supportFastImageSending = true;
        supportURLSharing = true;
        supportSharingBigFile = true;
        supportScreenWithdraw = true;
        supportSessionLock = true;
        supportAnnotation = true;
        supportTerminateUser = true;
        supportNewWifiLan = true;
        supportLocalVideo = true;
        supportNewVideoPlay = true;
        isSoftwareDecoder = true;
        isDataNeedPreload = true;
        isNewFileSharing = true;
        isHideVoting = false;
        supportVoting = 1;
        isflexibleGUI = true;
        isflexibleGUIDnD = true;
        isSupportUsbLan = true;
        isNVCMatching = true;
        supportNewAnnotation = true;
      }
      if (rvaNumber >= 3.2) {
        isSoftwareMatching = false;
        isNVCMatching = false;
      }
      break;
    case "K1000":
      isNVCMatching = false;
      isSoftwareMatching = true;
      /*
      isflexibleGUIDnD = false;
      supportVoting = 1;
      supportNewWifiLan = true;
      supportLocalVideo = true;
      supportExchangeServer = true;
      supportNewVideoPlay = true;
      supportFastImageSending = true;
      supportSharingBigFile = true;
      supportFastSwitchScreen = true;
      supportURLSharing = true;
      supportScreenWithdraw = true;
      supportSessionLock = true;
      supportAnnotation = true;
      supportTerminateUser = true;
      isDataNeedPreload = true;
      isNewFileSharing = true;
      isSoftwareDecoder = true;
      if (rvaNumber >= 3.1) {
        isSoftwareMatching = false;
        isNVCMatching = false;
      }
      */
      break;
    case "B100":
      isNVCMatching = false;
      isSoftwareMatching = true;
      /*
      isflexibleGUIDnD = false;
      supportVoting = 1;
      supportNewWifiLan = true;
      supportLocalVideo = true;
      supportExchangeServer = true;
      supportNewVideoPlay = true;
      supportFastImageSending = true;
      supportSharingBigFile = true;
      supportFastSwitchScreen = true;
      supportURLSharing = true;
      supportScreenWithdraw = true;
      supportSessionLock = true;
      supportAnnotation = true;
      supportTerminateUser = true;
      isDataNeedPreload = true;
      isNewFileSharing = true;
      isSoftwareDecoder = true;
      isflexibleGUI = true;
      supportNewAnnotation = true;
      isNewDataConnection = true;
      if (rvaNumber >= 3.1) {
        isSoftwareMatching = false;
        isNVCMatching = false;
      }
      */
      break;
    default:
      isSoftwareMatching = true;
      isNVCMatching = false;
  }
}
