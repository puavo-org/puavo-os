var main = chrome.app.window.get("main").contentWindow;
var rvaSize, ctx;
var mode = 'pen', // pen / bush / clean
    colorToRVA = {},
    lineWidth = 10,
    rgbacolor = "rgba(255, 0, 0, 1)";

var annotate = {
  canvas: null,
  history: [],
  historyNext: [],
  bg: "",
  scale: 1
};
var currentImageData;

var refreshBgSeconds = 0,
    refreshBgFlag = false;

$(document).ready(function() {
  var language = 'en-US'; //zh-TW zh-CN en-US en-GB ja fr es ru it sv da
  translate(chrome.i18n.getUILanguage());

  closeAllBox();

  $(".icon-minimize").off().click(function() {
    chrome.app.window.current().minimize();
    return false;
  });
  $(".icon-close").off().click(function() {
    chrome.app.window.current().close();
    return false;
  });
  $("#annotation").click(function(){
    closeAllBox();
    return false;
  });

  // set up icons
  $('#btn-menu').click(showMenu);
  $('#save-png').click(download);
  $('#send-all').click(sendImage);
  $('#exit').click(function() {
    chrome.app.window.current().close();
    return false;
  });

  refreshBtns();
  $('#btn-pen').click(function() {
    penCanvas();
    closeAllBox();
    $("#pen_box").css("left", $("#btn-pen").position().left-95).show();
    $(this).closest("ul").children("li").removeClass("clicked").end();
    $(this).addClass("clicked");
    return false;
  });
  $('#btn-highlight').click(function() {
    highlightCanvas();
    closeAllBox();
    $("#highlight_box").css("left", $("#btn-highlight").position().left-176).show();
    $(this).closest("ul").children("li").removeClass("clicked").end();
    $(this).addClass("clicked");
    return false;
  });
  $('#btn-clean').click(cleanCanvas);
  $('#btn-delete').click(clearCanvas);
  $('#btn-refresh').click(refreshBG);

  // pick up pen stroke
  $("#pen_box .stroke-box li").off().click(function() {
    $(this).closest("ul").children("li").removeClass("clicked").end();
    $(this).addClass("clicked");
    penCanvas();
    return false;
  });
  $("#pen_box .stroke-box li.bush").off();

  // pick up pen color
  $("#pen_box .color-box li").off().click(function() {
    $(this).closest("ul").children("li").removeClass("clicked").end();
    $(this).addClass("clicked");
    penCanvas();
    return false;
  });
  $("#pen_box .stroke-box li.bush").off();

  //pick up highlight lineWidth
  $("#highlight_box .stroke-box li").off().click(function() {
    $(this).closest("ul").children("li").removeClass("clicked").end();
    $(this).addClass("clicked");
    highlightCanvas();
    return false;
  });
  $("#highlight_box .stroke-box li.bush").off();

  //pick up highlight color
  $("#highlight_box .color-box li").off().click(function() {
    $(this).closest("ul").children("li").removeClass("clicked").end();
    $(this).addClass("clicked");
    highlightCanvas();
    return false;
  });
  $("#highlight_box").off().click(function(){return false;});

});

$(window).resize(function(){
  console.log("[window.resize] Go resizeCanvas");
  resizeCanvas();
});

function resizeCanvas() {
  console.log("[resizeCanvas] rvaSize, ctx=", rvaSize, ctx);
  if (rvaSize == undefined || rvaSize.width == undefined) return;

  //console.log("[resizeCanvas] rvaSize.width, rvaSize.height=", rvaSize.width, rvaSize.height);
  //$(".content").width(window.innerWidth).height(window.innerHeight - $("header").outerHeight() - $("footer").outerHeight());
  $(".content").height(window.innerHeight - $("header").outerHeight() - $("footer").outerHeight());

  var sectionW = $(".content").innerWidth();
  var sectionH = $(".content").innerHeight();
  //console.log("[resizeCanvas2] window.innerWidth, window.innerHeight = ", window.innerWidth, window.innerHeight);
  //console.log("[resizeCanvas3] sectionW, sectionH = ", sectionW, sectionH);

  var canvasWidth = rvaSize.width;
  var canvasHeight = rvaSize.height;
  annotate.scale = 1;

  if (rvaSize.width > sectionW || rvaSize.height > sectionH) {
    var ratioW = rvaSize.width / sectionW;
    var ratioH = rvaSize.height / sectionH;
    if (ratioH > ratioW) {
      canvasWidth = rvaSize.width/ratioH;
      canvasHeight = sectionH;
      annotate.scale = ratioH;
    }
    else {
      canvasWidth = sectionW;
      canvasHeight = rvaSize.height/ratioW;
      annotate.scale = ratioW;
    }
  }

  $("section").width(canvasWidth).height(canvasHeight);
  $('#myCanvas').attr("width", canvasWidth).attr("height", canvasHeight);
  
  if (ctx != undefined) {
    $("#pen_box .yellow").trigger("click");
  }

  //console.log("[resizeCanvas-end] canvasWidth, canvasHeight=", canvasWidth, canvasHeight);

  var cnt = $(".ui-dialog-content").length;
  if (cnt > 0) {
    //console.warn("Locate dialog...", cnt);
    $(".ui-dialog-content").dialog({
      height: 600
    });
  }

}

function createCanvas(rva) {
  console.log("[createCanvas] rva=", rva);
  rvaSize = rva;
  if (rvaSize == undefined || rvaSize.width == undefined) return;

  //console.log("[createCanvas] rvaSize.width, rvaSize.height=", rvaSize.width, rvaSize.height);
  resizeCanvas();
  annotate.canvas = document.getElementById("myCanvas");
  ctx = annotate.canvas.getContext("2d");
  
  console.log("[createCanvas] show background image");
  $("#myCanvas").css("background-image", "url('" + annotate.bg + "')");
  
  console.log("[createCanvas] init RVA - set default pen color and brush");
  $("#pen_box .yellow").trigger("click");

  recordCanvas();

  //console.log("[createCanvas-end] rvaSize.width, rvaSize.height=", rvaSize.width, rvaSize.height);
}

function setCanvas() {
  console.log("[setCanvas] mode=", mode);

  ctx.globalCompositeOperation = "source-over";
  ctx.lineCap = 'butt';   //'butt','round','square'
  ctx.lineJoin = 'round';   //'round','bevel','miter'
  ctx.lineWidth = lineWidth;
  ctx.strokeStyle = rgbacolor;
  ctx.beginPath();
  //console.debug("[setCanvas] lineWidth, rgbacolor=", lineWidth, rgbacolor);

  var canvas = annotate.canvas;
  $(canvas).off()
  .on("mousedown", MouseDown)
  .on("mousemove", MouseMove)
  .on("mouseup", MouseUp)
  .on("mouseout", MouseUp)
  .drawTouch().drawPointer().drawMouse();

  var lockpen = false;
  var drawList = [];
  function MouseDown(event) {
    //console.log("[MouseDown]", event.offsetX, event.offsetY);
    lockpen = true;
    drawList = [{x: event.offsetX * annotate.scale, y: event.offsetY * annotate.scale}];  // draw track
  }

  function MouseMove(event) {
    if (lockpen) {
      //console.log("[MouseMove]", event.offsetX, event.offsetY);
      drawList.push({x: event.offsetX * annotate.scale, y: event.offsetY * annotate.scale});  // draw track
    }
  }

  function MouseUp(event) {
    if (lockpen) {
      //console.debug("[MouseUp]", event.offsetX, event.offsetY, drawList);
      drawList.push({x: event.offsetX * annotate.scale, y: event.offsetY * annotate.scale});  // draw track
      lockpen = false;

      // call RVA
      if (mode == "clean") {
        //console.log("[MouseUp] erase", drawList);
        if (isDrawDot(drawList) == true) {
          //console.log("[MouseUp] clean arc", rgbacolor, colorToRVA);
          ctx.globalCompositeOperation = "destination-out";
          ctx.strokeStyle = "rgba("+colorToRVA.red+","+colorToRVA.green+","+colorToRVA.blue+",1)";
          ctx.fillStyle = ctx.strokeStyle;
          ctx.save();
          ctx.arc(event.offsetX, event.offsetY, lineWidth/2, 0, 2*Math.PI);
          ctx.fill();
          if (drawList.length >= 3) drawList = drawList.slice(0,2);
        }
        main.drawScreen_ANNOTATION(drawList);
        recordCanvas();
        return;
      }

      //console.log("[MouseUp] render", drawList.length);
      // draw dot
      if (isDrawDot(drawList) == true) {
        var alpha = ((mode=='pen')? 1 : 0.5);
        ctx.strokeStyle = "rgba("+colorToRVA.red+","+colorToRVA.green+","+colorToRVA.blue+","+alpha+")";
        ctx.fillStyle = ctx.strokeStyle;
        ctx.arc(event.offsetX, event.offsetY, lineWidth/2, 0, 2*Math.PI);
        ctx.fill();
        //console.info("[MouseUp] arc", colorToRVA, rgbacolor, ctx.fillStyle, ctx.strokeStyle);
        if (drawList.length >= 3) drawList = drawList.slice(0,2);
      }
      main.drawScreen_ANNOTATION(drawList);
      recordCanvas();
    }
  }

  function isDrawDot(drawList) {
    var x = drawList[0].x, y = drawList[0].y, result = true;
    $(drawList).each(function(index) {
      if (x != $(this)[0].x || y != $(this)[0].y){
        result = false;
        return;
      }
      x = $(this)[0].x;
      y = $(this)[0].y;
    });
    //console.debug("[isDrawDot] result=", result);
    return result;
  }

}

function initBG(annotation_screen) {
  annotate.bg = "data:image/png;base64," + annotation_screen;
}

function displayBG(annotation_screen) {
  console.log("[displayBG] ...");
  annotate.bg = "data:image/png;base64," + annotation_screen;
  $("#myCanvas").css("background-image", "url('" + annotate.bg + "')");
  refreshBgFlag = false;
  (refreshBgSeconds <= 0)? stopTimer() : null;
  //console.log("[displayBG-end]");
}

function removeReconnectingDialogs() {
  console.log('[removeReconnectingDialogs]...');
  if ($('.message-page').length > 0) {
    $('.message-page').dialog('destroy').remove();
  }
  $(".ui-effects-wrapper").remove();
}

function ReconnectingTimer(msg) {

  // Waiting with loading image and message
  var page = $('<div class="message-page" id=""></div>')
    .append($('<div>').addClass('loading-circle'))
    .append($('<p>').append($('<span class="msg">').text(msg)));

  page.dialog({
    autoOpen: true,
    resizable: false,
    closeOnEscape: false,
    modal: true,
    width: '500px',
    minWidth: '50%',
    // maxHeight: $('#container').height(),
    open: function (event, ui) {

    },
    close: function (event, ui) {
      $(this).dialog('destroy').remove();
    },
    dialogClass: "msg-page no-close",
  });
}

function closeAllBox() {
  $("#menu_box").hide();
  $("#pen_box").hide();
  $("#highlight_box").hide();
}

function showMenu() {
  closeAllBox();
  $("#menu_box").show();
  return false;
}

function sendImage() {
  console.log("[sendImage]");
  main.shareToAll_ANNOTATION();
}

function download() {
  console.log("[download]");

  var MIME_TYPE = "image/png";

  // create new canvas to draw
  var newCanvas = document.createElement('canvas'),
      context = newCanvas.getContext('2d');
  newCanvas.width = annotate.canvas.width;
  newCanvas.height = annotate.canvas.height;

  // draw black background color
  context.beginPath();
  context.rect(0, 0, newCanvas.width, newCanvas.height);
  context.fillStyle = "#000";
  context.fill();
  document.body.appendChild(newCanvas);

  // draw background image
  var img1 = new Image();
  img1.onload = function() {
    var x = (annotate.canvas.width  - img1.width ) * 0.5,
        y = (annotate.canvas.height - img1.height) * 0.5,
        w = img1.width,
        h = img1.height;
    if (x < 0 || y < 0) {
      var scaleW = img1.width / annotate.canvas.width;
      var scaleH = img1.height / annotate.canvas.height;
      if (scaleH > scaleW) {
        w = img1.width/scaleH;
        h = annotate.canvas.height;
        x = ( annotate.canvas.width - w ) * 0.5;
        y = 0;
      }
      else {
        w = annotate.canvas.width;
        h = img1.height/scaleW;
        x = 0;
        y = ( annotate.canvas.height - img1.height/scaleW ) * 0.5;
      }
    }
    context.drawImage(img1, x, y, w, h);
    //console.log("[download] img1=", img1.width, img1.height, x, y, w, h);
  };
  img1.src = annotate.bg;

  // draw painting trace
  var img2 = new Image();
  img2.onload = function() {
    //console.log("[download] img2=", img2.width, img2.height);
    context.drawImage(img2, 0, 0);
    ddd();
  };
  img2.src = annotate.canvas.toDataURL(MIME_TYPE);

  // download it
  function ddd() {
    var dlLink = document.createElement('a');
    dlLink.download = "annotate.png";
    dlLink.href = newCanvas.toDataURL(MIME_TYPE);
    dlLink.dataset.downloadurl = [MIME_TYPE, dlLink.download, dlLink.href].join(':');

    document.body.appendChild(dlLink);
    dlLink.click();

    // clear all
    document.body.removeChild(dlLink);
    document.body.removeChild(newCanvas);
    img1 = null;
    img2 = null;
    newCanvas = null;
    context = null;
  }
}

function refreshBtns() {
  (annotate.history.length < 2)?
    $("#btn-back").removeClass("enable").off() :
    $("#btn-back").addClass("enable").off().click(backCanvas);

  (annotate.historyNext.length < 2)?
    $("#btn-next").removeClass("enable").off() :
    $("#btn-next").addClass("enable").off().click(nextCanvas);
}

function recordCanvas() {
  //console.log("[recordCanvas]");
  // Get and Push the canvas data:
  currentImageData = ctx.getImageData(0, 0, annotate.canvas.width, annotate.canvas.height);
  annotate.history.push(currentImageData);
  annotate.historyNext = [currentImageData];

  // annotate.history maximum:5
  // Change max to 5 since NovoPro V2.4.0
  while (annotate.history.length > 6) {
    annotate.history.shift();
  }

  refreshBtns();
}

function backCanvas() {
  //console.log("[backCanvas1]", annotate.history.length, annotate.historyNext.length);

  if(annotate.history == undefined || annotate.history.length == 0) {
    dialogBox("No Back Steps");
    return;
  }

  // Reload data:
  var imageData = annotate.history.pop();
  if (currentImageData == imageData) {
    imageData = annotate.history.pop();
  }

  ctx.clearRect(0, 0, imageData.width, imageData.height);
  ctx.putImageData(imageData, 0, 0);

  currentImageData = imageData;
  annotate.history.push(currentImageData);
  annotate.historyNext.push(currentImageData);
  refreshBtns();

  main.drawUndo_ANNOTATION();
  //console.log("[backCanvas3]", annotate.history.length, annotate.historyNext.length);
}

function nextCanvas() {
  //console.log("[nextCanvas1]", annotate.history.length, annotate.historyNext.length);

  if(annotate.historyNext == undefined || annotate.historyNext.length == 0) {
    dialogBox("No Next Steps");
    return;
  }

  var imageData = annotate.historyNext.pop();
  if (currentImageData == imageData) {
    imageData = annotate.historyNext.pop();
  }

  ctx.clearRect(0, 0, imageData.width, imageData.height);
  ctx.putImageData(imageData, 0, 0);

  currentImageData = imageData;
  annotate.history.push(currentImageData);
  annotate.historyNext.push(currentImageData);
  refreshBtns();

  main.drawRedo_ANNOTATION();
  //console.log("[nextCanvas2]", annotate.history.length, annotate.historyNext.length);
}

// set up painting brush
function changePaintingBrush() {
  //console.log("[changePaintingBrush] rgbacolor=", rgbacolor);
  var colors = rgbacolor.substring(rgbacolor.indexOf('(') + 1, rgbacolor.lastIndexOf(')')).split(/,\s*/);
  colorToRVA.red   = parseFloat(colors[0]);
  colorToRVA.green = parseFloat(colors[1]);
  colorToRVA.blue  = parseFloat(colors[2]);
  colorToRVA.alpha = (mode == "clean")? 0 : ((mode == "bush")? 150 : 255);
  colorToRVA.width = parseFloat(lineWidth) * annotate.scale * 100;
  console.log("[changePaintingBrush] lineWidth, rgbacolor, colorToRVA=", lineWidth, rgbacolor, colorToRVA);
  setCanvas();
  main.changePen_ANNOTATION(colorToRVA);
}

function penCanvas() {
  console.log("[penCanvas]...");
  mode = "pen";
  rgbacolor = getColor($("#pen_box .color-box li.clicked").css("background-color"), 1);
  lineWidth = parseFloat($("#pen_box .stroke-box li.clicked").find("span").css("width").replace(/[^\d]+/img, ""));
  changePaintingBrush();
  //console.log("[penCanvas-end]");
  return false;
}

function highlightCanvas() {
  mode = "bush";
  rgbacolor = getColor($("#highlight_box .color-box li.clicked").css("background-color"), .1);
  lineWidth = parseFloat($("#highlight_box .stroke-box li.clicked").find("span").css("width").replace(/[^\d]+/img, ""));
  changePaintingBrush();
  return false;
}

function cleanCanvas() {
  console.log("[cleanCanvas]");
  mode = "clean";
  colorToRVA.alpha = 0;
  main.changePen_ANNOTATION(colorToRVA);

  ctx.globalCompositeOperation = "destination-out";
  ctx.strokeStyle = "rgba("+colorToRVA.red+","+colorToRVA.green+","+colorToRVA.blue+",1)";
  ctx.fillStyle = ctx.strokeStyle;
  ctx.save();

  $(this).closest("ul").children("li").removeClass("clicked").end();
  $(this).addClass("clicked");
}

function clearCanvas() {
  console.log("[clearCanvas]");
  // clear all
  ctx.clearRect(0, 0, $(annotate.canvas).width(), $(annotate.canvas).height());
  recordCanvas();
  main.drawDeleteAll_ANNOTATION();
}

function refreshBG(){
  console.log("[refreshBG] refreshBgFlag=", refreshBgFlag);
  $("#btn-refresh").off().addClass("loading");
  refreshBgFlag = true;
  startTimer();
  main.refresh_ANNOTATION();
}

//-----------------------------------------------------

// prototype to	start drawing on touch using canvas moveTo and lineTo
$.fn.drawTouch = function () {
  var start = function (e) {
    e = e.originalEvent;
    ctx.beginPath();
    x = e.changedTouches[0].offsetX;
    y = e.changedTouches[0].offsetY;
    ctx.moveTo(x, y);
  };
  var move = function (e) {
    e.preventDefault();
    e = e.originalEvent;
    x = e.changedTouches[0].offsetX;
    y = e.changedTouches[0].offsetY;
    ctx.lineTo(x, y);
    ctx.stroke();
  };
  $(this).on("touchstart", start);
  $(this).on("touchmove", move);
  return $(this);
};
// prototype to	start drawing on pointer(microsoft ie) using canvas moveTo and lineTo
$.fn.drawPointer = function () {
  var start = function (e) {
    e = e.originalEvent;
    ctx.beginPath();
    x = e.offsetX;
    y = e.offsetY;
    ctx.moveTo(x, y);
  };
  var move = function (e) {
    e.preventDefault();
    e = e.originalEvent;
    x = e.offsetX;
    y = e.offsetY;
    ctx.lineTo(x, y);
    ctx.stroke();
  };
  $(this).on("MSPointerDown", start);
  $(this).on("MSPointerMove", move);
  return $(this);
};
// prototype to	start drawing on mouse using canvas moveTo and lineTo
$.fn.drawMouse = function () {
  var clicked = false;
  var start = function (e) {
    clicked = true;
    ctx.beginPath();
    ctx.moveTo(e.offsetX, e.offsetY);
  };
  var move = function (e) {
    if (clicked) {
      ctx.lineTo(e.offsetX, e.offsetY);
      ctx.stroke();
    }
  };
  var stop = function (e) {
    if (clicked) {
      ctx.closePath();
      //console.debug("[drawMouse-stop] ", colorToRVA, rgbacolor, ctx.fillStyle, ctx.strokeStyle);
    }
    clicked = false;
  };
  $(this).on("mousedown", start);
  $(this).on("mousemove", move);
  $(window).on("mouseup", stop);
  $(this).on("mouseout", stop);
  return $(this);
};

//-----------------------------------------------------

//helper
function getColor(bgColor, alpha) {
  //console.debug('[getColor] bgColor, alpha=', bgColor, alpha);
  var rgb = bgColor.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
  //console.debug('[getColor] rgb=', rgb);
  var rgba = 'rgba(' + rgb[1] + ',' + rgb[2] + ',' + rgb[3] + ',' + alpha + ')';
  //console.debug('[getColor] rgba=', rgba);
  return rgba;
}

function dialogBox(msg){
  //console.log("New dialogBox...", msg);
  var box = $('<div id="myModal" class="modal">').appendTo("body");
  var modalContent = $('<div class="modal-content">').appendTo(box);
  $('<div class="modal-header"><span class="close">?</span><h2>Warning</h2></div>').appendTo(modalContent);
  $('<div class="modal-body">').append($('<p>').text(msg)).appendTo(modalContent);
  //$('<div class="modal-footer"><h3>Modal Footer</h3></div>').appendTo(modalContent);

  var obj = new simpleDialog("#myModal");
}

function simpleDialog(container) {
  console.log("New simpleDialog...");
  var modal = $(container);
  this.container = modal;
  modal.show();

  this.close = function() {
    return modal.remove();
  };

  modal.find(".close").click(function(event) {
    console.debug("Click close modal...");
    modal.remove();
  });

  // When the user clicks anywhere outside of the modal, close it
  modal.click(function(event) {
    console.debug("Click modal...");
    modal.remove();
    return false;
  });
}

// Timer to refresh background image
var myTimer;
function startTimer() {
  clearInterval(myTimer);
  refreshBgSeconds = 3;
  myTimer = setInterval(function(){
    ((refreshBgSeconds <= 0 && refreshBgFlag === false) || refreshBgSeconds <= -10 )? stopTimer() : refreshBgSeconds--;
    console.log("Timer - refreshBgSeconds=", refreshBgSeconds, ", refreshBgFlag=", refreshBgFlag);
  }, 1000);
}
function stopTimer() {
  clearInterval(myTimer);
  refreshBgSeconds = 0;
  $("#btn-refresh").removeClass("loading").off().click(refreshBG);
}
