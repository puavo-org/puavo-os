function getParameterByName(name) {
  name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
  var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
      results = regex.exec(location.search);
  return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

function translate(language, cb){
  var opts = {
    lng: language,
    fallbackLng: 'en-US',
    debug: true,
    resGetPath: "../locales/__ns__-__lng__.json"
  };

  i18n.init(opts, function (t) {
    $(document).i18n();
    try {
      //console.log("[translate] translateMore=", translateMore);
      if (translateMore != undefined){ translateMore(); }
    }
    catch(err) {
      //do nothing
    }
    cb && cb();
  });
  //console.log("language=", language);
}

function validateIPaddress(ipaddress) {
  if (/^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(ipaddress)) {
    return (true);
  }
  console.error("Invalid IP address: ", ipaddress);
  return (false);
}

function supportRightClick(obj) {
  console.warn("TODO: [helper-supportRightClick]", obj);

  // Create an empty menu
  /*
  var menu = $('<ul class="custom-menu">'); //.appendTo("body");
  var cutItem = $('<li>Cut</li>').appendTo(menu);
  var copyItem = $('<li>Copy</li>').appendTo(menu);
  var pasteItem = $('<li>Paste</li>').appendTo(menu);
  var deleteItem = $('<li>Delete</li>').appendTo(menu);
  var separatorItem = $('<hr>').appendTo(menu);
  var selectAllItem = $('<li>Select all</li>').appendTo(menu);

  cutItem.click(function(){
    console.log('Cut is clicked',this);
    dsaApi.execCommand('cut');
    $(menu).hide(100);
  });
  pasteItem.click(function(){
    console.log('Paste is clicked',this);
    dsaApi.executePaste("#inputLink");
    $(menu).hide(100);
  });
  deleteItem.click(function(){
    console.log('Delete is clicked',this);
    $(obj).val('');
    $(menu).hide(100);
  });
  
  // Trigger action when the contexmenu is about to be shown
  $(obj).off().contextmenu(function() {
    // Show contextmenu
    //$(menu).finish().toggle(100);
    $(menu).show();
  });
  */
  /*
  function isTextSelected(input){
    var startPos = input.selectionStart;
    var endPos = input.selectionEnd;
    var doc = document.selection;
    if(doc && doc.createRange().text.length != 0){
      return true;
    }
    else if (!doc && input.value.substring(startPos,endPos).length != 0){
      return true;
    }
    return false;
  }
  $(obj).mousedown(function(ev){
    $(this).focus();
    if( ev.button == 2 ) {
      for (var i = 0; i < menu.items.length; ++i) {
        menu.items[i].enabled = false;
      }
      if ($(obj).val()==''){
        console.log('No input.');
        menu.items[2].enabled = true;
      }
      else {
        menu.items[2].enabled = true;
        menu.items[5].enabled = true;
        if (isTextSelected(this)){
          menu.items[0].enabled = true;
          menu.items[1].enabled = true;
          menu.items[3].enabled = true;
        }
      }
      menu.popup(ev.clientX, ev.clientY);
      return false;
    }
    return true;
  });
  */
}

function sortIpList(array) {
  return array.sort(function(a, b) {
      var key1 = 'status', key2 = 'deviceName', key3 = 'ip';
      var x  = a[key1]; var y  = b[key1];
      var x2 = a[key2]; var y2 = b[key2];
      var x3 = a[key3]; var y3 = b[key3];
      return ((x > y) ? -1 : ((x < y) ? 1 : ((x2 < y2) ? -1 : ((x2 > y2) ? 1 : ((x3 < y3) ? -1 : ((x3 > y3) ? 1 : 0))))));
  });
}

function formatBytes(bytes, decimals) {
  if (bytes == 0) return '0 Byte';
  var k = 1024;
  var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
  var i = Math.floor(Math.log(bytes) / Math.log(k));
  var num = (bytes / Math.pow(k, i));
  var dm = ((num >= 1000)? 4 : (decimals + 1 || 3));
  return num.toPrecision(dm) + " " + sizes[i];
}

function toTimeString(seconds) {
  var str = (new Date(seconds * 1000)).toUTCString().match(/(\d\d:\d\d:\d\d)/)[0];
  return (seconds >= 3600)? str : str.substr(3,5);
}

function wiFiSignalLevel(num) {
  /*  strength = 0~100
      Excellent >50 dBm
      Good 40 to 50 dBm
      Fair 30 to 40 dBm
      Weak < 30 dBm
  */
  return (num > 50)? 4 : 
          ((num > 40)? 3 : 
           ((num > 30)? 2 :
            ((num > 0)? 1 : 0)));
}

function validateStringOnlyAscii(str) {
  //(0~9,A~Z,a~z,~!@#$%^&*-_
  //console.warn("[validateStringOnlyAscii]", /^[\x00-\x7F]+$/.test(str)); //true/false
  return /^[\x00-\x7F]+$/.test(str);
}

function validateStringOnlyHexadecimal(str) {
  //(0~9,A~F,a~f) characters
  return /^[a-fA-F0-9]+$/.test(str);
}

function validateWepKey(key) {
  // WEP password: 5/13 ASCII, 10/26 Hexadecimal
  if ( [5,13].indexOf(key.length) > -1 && validateStringOnlyAscii(key)) return true;
  if ([10,26].indexOf(key.length) > -1 && validateStringOnlyHexadecimal(key)) return true;
  return false;
}

function convertNameToCompare(name) {
  var output = name.toUpperCase().trim();
  while (output.indexOf("  ") > -1) {output = output.replace(/  /g," ")}
  return output;
}


function scrollToRemoveElement(scrollingElm, cmd) {

  var raf = window.requestAnimationFrame ||
    window.webkitRequestAnimationFrame ||
    window.mozRequestAnimationFrame ||
    window.msRequestAnimationFrame ||
    window.oRequestAnimationFrame;

  //var $window = $(window);
  //var lastScrollTop = $window.scrollTop();
  var lastScrollTop = $(scrollingElm).scrollTop();

  var scroll = function () {
    //console.debug("[_popUpUserMenu] I am scrolling...............", scrollingElm);
    cmd();  // execute it
    raf = null;
    lastScrollTop = null;
    scroll = null
  };

  if (raf && raf != undefined) {
    loop();
  }

  function loop() {
    var scrollTop = $(scrollingElm).scrollTop();
    if (lastScrollTop === scrollTop) {
      scrollTop = null;
      raf(loop);  // countinue not stop
      return;
    }
    else {
      lastScrollTop = scrollTop;
      scrollTop = null;
      // fire scroll function if scrolls vertically
      scroll();   // only once
      //raf(loop);
    }
  }

}