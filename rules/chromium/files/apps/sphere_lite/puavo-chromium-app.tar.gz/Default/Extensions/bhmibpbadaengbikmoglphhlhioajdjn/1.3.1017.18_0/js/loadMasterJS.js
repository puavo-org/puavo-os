var __loadedFiles  = {};

function loadJS(jsFile)
{
    if(__loadedFiles[jsFile])
    {
            return;
    }
    __loadedFiles[jsFile] = true;
    var script = document.createElement("script");
    script.type = "text/javascript";
    script.src = jsFile;
    document.head.appendChild(script);
}

// for annotation
loadJS("../js/canvas/canvas-editor.js");
loadJS("../js/canvas/canvas-model.js");
loadJS("../js/canvas/freehand-graphic.js");
loadJS("../js/canvas/freehand-tool.js");
loadJS("../js/canvas/line-graphic.js");
loadJS("../js/canvas/line-tool.js");
loadJS("../js/canvas/text-graphic.js");
loadJS("../js/canvas/text-tool.js");
loadJS("../js/canvas/selection-tool.js");
loadJS("../js/canvas/graphic.js");
loadJS("../js/canvas/annotation-tool.js");
loadJS("../js/canvas/circle-graphic.js");
loadJS("../js/canvas/ellipse-graphic.js");
loadJS("../js/canvas/rectangle-graphic.js");
loadJS("../js/canvas/triangle-graphic.js");
loadJS("../js/canvas/shape-tool.js");
loadJS("../js/canvas/undo-item.js");
loadJS("../js/canvas/undo-manager.js");
loadJS("../js/canvas/eraser-tool.js");
loadJS("../js/canvas/highlighter-graphic.js");
loadJS("../js/canvas/canvas-utility.js");
loadJS("../js/canvas/image-graphic.js");
loadJS("../js/canvas/annotation-implement.js");
loadJS("../js/canvas/canvas-view.js");