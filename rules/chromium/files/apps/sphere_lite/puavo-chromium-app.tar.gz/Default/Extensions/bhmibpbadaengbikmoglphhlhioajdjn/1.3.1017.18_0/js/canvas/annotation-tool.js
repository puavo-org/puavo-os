// at for annotation tool prefix

var at_m_debug_name;

function AnnotationTool()
{
	at_m_debug_name = "Annotation tool base";
};

AnnotationTool.prototype.getName = function()
{
	return at_m_debug_name;
};

AnnotationTool.prototype.annoToolAnnotationStart = function(at_anno_start_p_x, at_anno_start_p_y)
{
	
};

AnnotationTool.prototype.annoToolAnnotationMove = function(at_anno_move_p_x, at_anno_move_p_y)
{
	
};

AnnotationTool.prototype.annoToolAnnotationStop = function(at_anno_stop_p_x, at_anno_stop_p_y)
{
	
};

AnnotationTool.prototype.render = function()
{

};