

function TriangleGraphic()
{
	this.rect_x = 0;
	this.rect_y = 0;
	this.rect_w = 0;
	this.rect_h = 0;
	this.parent_canvas_model = null;
	this.start_pt_x = 0;
	this.start_pt_y = 0;
	this.end_pt_x = 0;
	this.end_pt_y = 0;
	this.is_selected = false;
	this.line_width = 3;
	this.line_color = "#FF0000";
	// this.line_color_r = 255;
	// this.line_color_g = 155;
	// this.line_color_b = 55;
	// this.line_color_a = 1;
	this.is_filled = false;
	this.zorderIndex = -1;
	this.angle = rotate;
};

TriangleGraphic.prototype.getType = function()
{
	return "TriangleGraphic";
};

TriangleGraphic.prototype.setFilled = function(filled)
{
	this.is_filled = filled;
};

TriangleGraphic.prototype.setLineWidth = function(width)
{
	this.line_width = width;
};

TriangleGraphic.prototype.setLineColor = function(color)
{
	this.line_color = color;
	// this.line_color_r = r;
	// this.line_color_g = g;
	// this.line_color_b = b;
	// this.line_color_a = a;
};

TriangleGraphic.prototype.setParentCanvasModel = function(canvas_model)
{
	this.parent_canvas_model = canvas_model;
	this.calcGraphicRect();
};

TriangleGraphic.prototype.setSelected = function(selected)
{
	this.is_selected = selected;
};

TriangleGraphic.prototype.isSelected = function()
{
	return this.is_selected;
};

TriangleGraphic.prototype.move = function(dx , dy)
{
	this.rect_x += dx;
	this.rect_y += dy;
};

TriangleGraphic.prototype.setStartPoint = function(x, y)
{
	this.start_pt_x = x;
	this.start_pt_y = y;
};

TriangleGraphic.prototype.setEndPoint = function(x, y)
{
	this.end_pt_x = x;
	this.end_pt_y = y;
	this.calcGraphicRect();
};

TriangleGraphic.prototype.calcGraphicRect = function()
{
	this.rect_x = this.start_pt_x;
	this.rect_w = this.end_pt_x - this.start_pt_x;
	if(this.end_pt_x < this.start_pt_x)
	{
		this.rect_x = this.end_pt_x;
		this.rect_w = this.start_pt_x - this.rect_x;
	}
	this.rect_y = this.start_pt_y;
	this.rect_h = this.end_pt_y - this.start_pt_y;
	if(this.end_pt_y < this.start_pt_y)
	{
		this.rect_y = this.end_pt_y;
		this.rect_h = this.start_pt_y - this.rect_y;
	}
};

TriangleGraphic.prototype.calcIsSelected = function(x, y, w, h)
{
	var gLeft = this.rect_x;
	var gRight = this.rect_x + this.rect_w;
	var gTop = this.rect_y;
	var gBottom = this.rect_y + this.rect_h;
	var l = x;
	var r = x + w;
	var t = y;
	var b = y + h;
	if(b < gTop || r < gLeft|| l > gRight || t > gBottom)
		return false;
	return true;
};

TriangleGraphic.prototype.hitTest = function(x, y)
{
	var gLeft = this.rect_x;
	var gRight = this.rect_x + this.rect_w;
	var gTop = this.rect_y;
	var gBottom = this.rect_y + this.rect_h;
	if(x > gRight || x < gLeft || y > gBottom || y < gTop)
	{
		return false;
	}
	return true;
};

TriangleGraphic.prototype.eraseTest = function(ax, ay, bx, by)
{
//	ax -= this.rect_x;
//	ay -= this.rect_y;
//	bx -= this.rect_x;
//	by -= this.rect_y;
	
	var pt_1_x = this.rect_x + this.rect_w / 2;
	var pt_1_y = this.rect_y;
	var pt_2_x = this.rect_x;
	var pt_2_y = this.rect_y + this.rect_h;
	var pt_3_x = this.rect_x + this.rect_w;
	var pt_3_y = this.rect_y + this.rect_h;
	
	var doErase = false;
	doErase |= isIntersected(pt_1_x, pt_1_y, pt_2_x, pt_2_y, ax, ay, bx, by);
	doErase |= isIntersected(pt_1_x, pt_1_y, pt_3_x, pt_3_y, ax, ay, bx, by);
	doErase |= isIntersected(pt_3_x, pt_3_y, pt_2_x, pt_2_y, ax, ay, bx, by);
	
	return doErase;
};

TriangleGraphic.prototype.setZorderIndex = function(index)
{
	this.zorderIndex = index;
}

TriangleGraphic.prototype.getZorderIndex = function(index)
{
	return this.zorderIndex;
}

TriangleGraphic.prototype.render = function()
{
	systemCanvasContext.save();
	
	//systemCanvasContext.strokeStyle = colorPurple;
	//systemCanvasContext.strokeRect(this.rect_x, this.rect_y, this.rect_w, this.rect_h);
	var pt_1_x = this.rect_x + this.rect_w / 2;
	var pt_1_y = this.rect_y;
	var pt_2_x = this.rect_x;
	var pt_2_y = this.rect_y + this.rect_h;
	var pt_3_x = this.rect_x + this.rect_w;
	var pt_3_y = this.rect_y + this.rect_h;

	if (this.angle === 90 || this.angle === -270){
		 pt_1_x = this.rect_x + this.rect_w;
		 pt_1_y = this.rect_y;
		 pt_2_x = this.rect_x;
		 pt_2_y = this.rect_y + this.rect_h/2;;
		 pt_3_x = this.rect_x + this.rect_w;
		 pt_3_y = this.rect_y + this.rect_h; 
	}else if( this.angle === 180 || this.angle === -180){
		 pt_1_x = this.rect_x + this.rect_w ;
		 pt_1_y = this.rect_y;
		 pt_2_x = this.rect_x + this.rect_w/2;
	 	 pt_2_y = this.rect_y + this.rect_h;
	 	 pt_3_x = this.rect_x ;
	 	 pt_3_y = this.rect_y ;
	}else if(this.angle === 270 || this.angle === -90){
		 pt_1_x = this.rect_x 
		 pt_1_y = this.rect_y;
		 pt_2_x = this.rect_x + this.rect_w;
	 	 pt_2_y = this.rect_y + this.rect_h/2;
	 	pt_3_x = this.rect_x ;
		 pt_3_y = this.rect_y + this.rect_h; 
	}




	
	systemCanvasContext.beginPath();
	systemCanvasContext.moveTo(pt_1_x, pt_1_y);
	systemCanvasContext.lineTo(pt_2_x, pt_2_y);
	systemCanvasContext.lineTo(pt_3_x, pt_3_y);
	systemCanvasContext.lineTo(pt_1_x, pt_1_y);
	systemCanvasContext.closePath();
	systemCanvasContext.strokeStyle = this.line_color;
	
	systemCanvasContext.lineJoin = "round";
	systemCanvasContext.lineWidth = this.line_width;
	
	if(this.is_filled)
	{
		systemCanvasContext.fillStyle = this.line_color;
		systemCanvasContext.fill();
	}
	systemCanvasContext.stroke();
	
	systemCanvasContext.restore();
	
	if(!this.is_selected)
		return;
	systemCanvasContext.save();
	systemCanvasContext.strokeStyle = "#64cb23";
	systemCanvasContext.strokeRect(this.rect_x, this.rect_y, this.rect_w, this.rect_h);
	systemCanvasContext.restore();
};