
function UndoManager()
{
	this.undo_stack = new Array();
	this.redo_stack = new Array();
	this.parent_canvas_model = null;
};

UndoManager.prototype.setCanvasModel = function(canvas)
{
	this.parent_canvas_model = canvas;
};

UndoManager.prototype.addToUndoStack = function(item)
{
	for(var i = 0; i < this.undo_stack.length; ++i)
	{
		if(item == this.undo_stack[i])
			return;
	}
	this.undo_stack.push(item);
	this.redo_stack.length = 0;
};

UndoManager.prototype.undo = function()
{
	if(this.undo_stack.length == 0)
		return;
	var temp = this.undo_stack.pop();
	temp.undo();
	this.redo_stack.push(temp);
};

UndoManager.prototype.redo = function()
{
	if(this.redo_stack.length == 0)
		return;
	var temp = this.redo_stack.pop();
	temp.redo();
	this.undo_stack.push(temp);
};

UndoManager.prototype.clearStack = function()
{
	this.undo_stack.length = 0;
	this.redo_stack.length = 0;
}

UndoManager.prototype.getUndoStackLen = function()
{
	return this.undo_stack.length;
}

UndoManager.prototype.getRedoStackLen = function()
{
	return this.redo_stack.length;
}

UndoManager.prototype.getLastItemType = function()
{
	if(this.undo_stack.length != 0)
	{
		return this.undo_stack[this.undo_stack.length - 1].undo_type;
	}
}