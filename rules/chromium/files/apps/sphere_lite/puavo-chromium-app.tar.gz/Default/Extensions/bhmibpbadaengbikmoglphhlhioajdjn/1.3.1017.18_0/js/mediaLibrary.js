// JavaScript Document
var gdocs = parent.gDocs;
var myNoteImpl = parent.myNoteImpl;
var fs = myNoteImpl.getFileSystem();
var imageCount = 0;
var aryLength = 0;
var myNoteImgArray = new Array();
var isAllSelect = "false";
var totalPage = 0;
var nowPage = 0;
var uploadCount = 0;
var fileArr = [];
var fileArrLen = 0;

var dataStatus = 'picture';
var panelStatus = "leave";
var saveStatus = "leave";

var isClickDel = false;

var pictureBtn = document.getElementById("pictureBtn");
var videoBtn = document.getElementById("videoBtn");

var saveBtn = document.getElementById("saveBtn");

var save_ok_btnText = document.getElementById("save_ok_btnText");

var noInternet_ok_btnText = document.getElementById("noInternet_ok_btnText");

var localBtn = document.getElementById("localBtn");
var uploadBtn = document.getElementById("uploadBtn");

var progressBar = document.getElementById('upload_progressbar');
var percent = document.getElementById('progress_percent_label');
var progress_dialog = document.getElementById('progress_dialog');

var select_ok_btnText = document.getElementById("select_ok_btnText");

var confirm_yes_btnText = document.getElementById("confirm_yes_btnText");
var confirm_no_btnText = document.getElementById("confirm_no_btnText");

var progress_ok_btnText = document.getElementById("progress_ok_btnText");

var gUploadText = document.getElementById("gUploadText");
var gCancelText = document.getElementById("gCancelText");

var selectAllBtn = document.getElementById("selectAllBtn");

var deleteBtn = document.getElementById("deleteBtn");

var backBtn = document.getElementById("backBtn");
var nextBtn = document.getElementById("nextBtn");

var _dirEntry = "";

var newEntries = "";

var saveTimeOut = "";

function errorHandler(e)
{
	var msg = '';
	switch (e.name) {
		case FileError.QUOTA_EXCEEDED_ERR:
			msg = 'QUOTA_EXCEEDED_ERR';
		break;
		case FileError.NOT_FOUND_ERR:
			msg = 'NOT_FOUND_ERR';
		break;
		case FileError.SECURITY_ERR:
			msg = 'SECURITY_ERR';
		break;
		case FileError.INVALID_MODIFICATION_ERR:
			msg = 'INVALID_MODIFICATION_ERR';
		break;
		case FileError.INVALID_STATE_ERR:
			msg = 'INVALID_STATE_ERR';
		break;
		default:
			msg = 'Unknown Error';
		break;
	};
}

function myNoteAddDir(userId)
{
	if(!fs)
	{
		return;
	}
	fs.root.getDirectory(userId, {create: true}, function(dirEntry){
		console.log("addDir OK!");
	}, errorHandler);
}

function myNoteImage(name, iSrc)
{
	var str = name;
	var res = str.replace("/", "");
	var res1 = res.replace("/", "");
	var res2 = res1.replace(".", "");
	var imgId = "a" + res2;
	this.id = "";
	this.src = iSrc;
	this.name = name;
	this.unitId = imgId;
	this.isSelect = "false";
	this.width = 0;
	this.height = 0;
}

function addItem(item)
{
	myNoteImgArray.push(item);
}

function getImgWidth(imgSrc)
{
	var newImg = new Image();
	newImg.src = imgSrc;
	curWidth = newImg.width;
	return curWidth;
}

function getImgHeight(imgSrc)
{
	var newImg = new Image();
	newImg.src = imgSrc;
	curHeight = newImg.height;
	return curHeight;
}

function addObj(name, iSrc)
{
	obj = new myNoteImage(name, iSrc);
	if(name.indexOf('.jpg') != -1)
	{
		obj.width = getImgWidth(iSrc);
		obj.height = getImgHeight(iSrc);
	}
	addItem(obj);
}

function checkSelectAnyImage()
{
	var _allImages = myNoteImgArray;
	var trueCount = 0;

	for(var i=0;i<_allImages.length;i++)
	{
		if(_allImages[i].isSelect == "true")
		{
			trueCount++;
		}
	}
	
	if(trueCount == _allImages.length)
	{
		isAllSelect = "true";
		$("#selectAllBtn").attr('src', '../img/btn_select_all_pressed.png');
		$("#selectAllBtn").attr('isSelect', 'true');
		document.getElementById("selectAllBtn").title = "Unselect all";
	}
	else
	{
		isAllSelect = "false";
		$("#selectAllBtn").attr('src', '../img/btn_select_all_normal.png');
		$("#selectAllBtn").attr('isSelect', 'false');
		document.getElementById("selectAllBtn").title = "Select all";
	}
}

//var imgCount = 0;
function imgSelect(id)
{
	var allImages = myNoteImgArray;
	for(var i=0;i<allImages.length;i++)
	{
		if(allImages[i].unitId == id)
		{
			var pos = i % 16;
			if(allImages[i].isSelect == "true")
			{
				//--imgCount;
				if(isAllSelect == 'true')
				{
					$("#selectAllBtn").attr('src', '../img/btn_select_all_normal.png');
					$("#selectAllBtn").attr('isSelect', 'false');
				}
				$("#container_" + pos).css({'border': ''});
				$("#container_" + pos).find('.checkMarkDiv').css('display', 'none');
				if (isClickDel) {
					$("#container_" + pos).find('.playMark').attr('src', '');
					$("#container_" + pos).find('.playMarkDiv').css('display', 'none');
				}
				allImages[i].isSelect = "false";
				var selectImages = selectPic();
				if(selectImages == 0)
				{
					$("#deleteBtn").attr('src', '../img/btn_clearall_disabled.png');
				}
			}
			else
			{
				if(dataStatus == 'video')
				{
					//Merging...
					if(allImages[i].name != parent.fileName)
					{
						//++imgCount;
						$("#container_" + pos).css({'border': '2px solid #FF8200'});
						$("#container_" + pos).find('.checkMarkDiv').css('display', 'block');
						allImages[i].isSelect = "true";
						$("#deleteBtn").attr('src', '../img/btn_clearall_normal.png');
					}
				}
				else
				{
					//++imgCount;
					$("#container_" + pos).css({'border': '2px solid #FF8200'});
					$("#container_" + pos).find('.checkMarkDiv').css('display', 'block');
					allImages[i].isSelect = "true";
					$("#deleteBtn").attr('src', '../img/btn_clearall_normal.png');
				}
			}
		}
	}
	/*if(imgCount == allImages.length)
	{
		isAllSelect = "true";
		$("#selectAllBtn").attr('src', '../img/btn_select_all_pressed.png');
		$("#selectAllBtn").attr('isSelect', 'true');
	}
	else
	{
		isAllSelect = "false";
		$("#selectAllBtn").attr('src', '../img/btn_select_all_normal.png');
		$("#selectAllBtn").attr('isSelect', 'false');
	}*/
	checkSelectAnyImage();
}

function imgClickEvent(numberOfImg)
{
	for(var i = 0; i < numberOfImg; i++)
	{
		document.getElementById("container_"+i).onclick = function(){
			var objectId = parseInt(this.id.substring(10)) + 16 * nowPage;
			if(typeof(objectId) !== 'undefined')
			{
				imgSelect(myNoteImgArray[objectId].unitId);
			}
		};
		document.getElementById("container_"+i).ondblclick = function(){
			var objectId = parseInt(this.id.substring(10)) + 16 * nowPage;
			var source = myNoteImgArray[objectId];
			if(typeof(source) !== 'undefined')
			{
				if(source.name.indexOf(".jpg") != -1)
				{
					parent.showMediaLibraryImg(source.src);
				}
				if(source.name.indexOf(".mkv") != -1)
				{
					//Merging...
					if(source.name != parent.fileName)
					{
						parent.showMediaLibraryVideo(source.src);
					}
				}
			}
		};
		document.getElementById("container_"+i).onmouseover = function(){
			var objectId = parseInt(this.id.substring(10)) + 16 * nowPage;
			var source = myNoteImgArray[objectId];
			if(typeof(source) !== 'undefined')
			{
				if(dataStatus == 'video')
				{
					//Merging...
					if(source.name == parent.fileName)
					{
						$("#" + this.id).css({'border': '2px solid #595959'});
					}
				}
			}
		};
	}
}

function loadPic()
{
	totalPage = Math.floor(myNoteImgArray.length / 16);
	firstPageLastPos = ((myNoteImgArray.length) % 16);
	if(totalPage > 0)
	{
		firstPageNumberOfImg = 16;
	}
	else
	{
		firstPageNumberOfImg = firstPageLastPos;
	}
	if((firstPageLastPos == 0) && (totalPage > 0))
	{
		totalPage -=1;
	}
	for(var i = 0; i < firstPageNumberOfImg; i++)
	{
		var src = myNoteImgArray[i].src;
		var name = myNoteImgArray[i].name;
		var unitId = myNoteImgArray[i].unitId;
		var id = i % 16;
		var pos = (i % 16) + 1;
		if(name.indexOf('.jpg') != -1)
		{
			document.getElementById('image_' + pos).onload = function(){
				if(this.width > this.height)
				{
					document.getElementById(this.id).className = "imageWidthCenter";
					centerMe(document.getElementById(this.id), 0, 0);
				}
				else
				{
					$('#' + this.id).css({'max-width': '', 'max-height': '', 'width': '', 'height': '', 'margin': ''});
					document.getElementById(this.id).className = "imageHeightCenter";
				}
			}
			$("#container_" + id).find('.playMark').attr('src', '');
			$("#container_" + id).find('.playMarkDiv').css('display', 'none');
			document.getElementById('image_' + pos).src = src;
			document.getElementById('image_' + pos).unitId = unitId;
			myNoteImgArray[i].id = "image_" + pos;
		}
		if(name.indexOf('.mkv') != -1)
		{
			document.getElementById('video_' + pos).src = src;
			document.getElementById('video_' + pos).unitId = unitId;
			myNoteImgArray[i].id = "video_" + pos;
			//Merging...
			if(name != parent.fileName)
			{
				$("#container_" + id).find('.playMark').attr('src', '../img/icon_play.png');
			}
			else
			{
				$("#container_" + id).find('.playMark').attr('src', '../img/icon_change.png');
			}
			$("#container_" + id).find('.playMarkDiv').css('display', 'block');
		}
		$("#imageName_" + pos).text(name);
		$("#container_" + id).css('display', 'inline-block');
		$("#container_" + pos).css({'border': ''});
		$("#container_" + pos).find('.checkMarkDiv').css('display', 'none');
	}

	nowPage = 0;
	if(totalPage > 0)
	{
		$("#nextBtn").attr('src', '../img/btn_right_normal.png');
	}
	document.getElementById('pageList').value = (nowPage + 1) + " / " + (totalPage + 1);
	imgClickEvent(firstPageNumberOfImg);
}

function initBtnStatus()
{
	$("#saveBtn").attr('src', '../img/btn_save_normal.png');
	$("#selectAllBtn").attr('src', '../img/btn_select_all_normal.png');
}

function readImg(name, imgName)
{
	var checkImgExist = false;
	fs.root.getFile(imgName, {}, function(fileEntry){
		// Get a File object representing the file,
		// then use FileReader to read its contents.
		fileEntry.file(function(file){
			var url = window.URL.createObjectURL(file);
			for(var j = 0; j < myNoteImgArray.length ; j++)
			{
				if(name == myNoteImgArray[j].name)
				{
					checkImgExist = true;
				}
			}
			if(!checkImgExist)
			{
				addObj(name, url);
			}
			checkImgExist = false;
			imageCount = imageCount + 1;
			if(imageCount == aryLength)
			{
				//resort
				myNoteImgArray.sort(function(a, b){
					return b.name.localeCompare(a.name);
				});
				loadPic();
				initBtnStatus();
			}
			/*var reader = new FileReader();
			reader.onloadend = function(e){
				for(var j = 0; j < myNoteImgArray.length ; j++)
				{
					if(name == myNoteImgArray[j].name)
					{
						checkImgExist = true;
					}
				}
				if(!checkImgExist)
				{
					addObj(name, this.result);
				}

				// read DONE
				if(reader.readyState == 2)
				{
					checkImgExist = false;
					imageCount = imageCount + 1;
					if(imageCount == aryLength)
					{
						//resort
						myNoteImgArray.sort(function(a, b){
							return b.name.localeCompare(a.name);
						});
						loadPic();
						initBtnStatus();
					}
				}
			};
			reader.readAsDataURL(file);*/
		}, errorHandler);
	}, errorHandler);
}

function addPicFromFilesystemToArray(name, iSrc)
{
	readImg(name, iSrc);
}

function toArray(list)
{
	return Array.prototype.slice.call(list || [], 0);
}

function continueReadFiles(_dirReader, _entries)
{
	if(_entries.length == 0)
	{
		console.log(newEntries.length);
		var aryName = new Array();
		var aryfullPath = new Array();
		if(dataStatus == 'picture')
		{
			for(var count=0;count<newEntries.length;++count)
			{
				if(newEntries[count].name.indexOf('.jpg') != -1)
				{
					++aryLength;
				}
			}
		}
		else if(dataStatus == 'video')
		{
			for(var count=0;count<newEntries.length;++count)
			{
				if(newEntries[count].name.indexOf('.mkv') != -1)
				{
					++aryLength;
				}
			}
		}
		//aryLength = entries.length;
		for(var i = 0; i < newEntries.length; i++)
		{
			var entry = newEntries[i];
			if(entry.isDirectory)
			{
				//console.log('Directory: ' + entry.fullPath);
			}
			else if(entry.isFile)
			{
				//console.log('File: ' + entry.fullPath);
				if(dataStatus == 'picture')
				{
					if(entry.name.indexOf('.jpg') != -1)
					{
						aryName.push(entry.name);
						aryfullPath.push(entry.fullPath);
					}
				}
				else if(dataStatus == 'video')
				{
					if(entry.name.indexOf('.mkv') != -1)
					{
						aryName.push(entry.name);
						aryfullPath.push(entry.fullPath);
					}
				}
			}
		}
		for(var i = 0;i < aryName.length; i++)
		{
			addPicFromFilesystemToArray(aryName[i], aryfullPath[i]);
		}
	}
	else
	{
		_dirReader.readEntries(function(entries){
			newEntries = newEntries.concat(toArray(entries));
			continueReadFiles(_dirReader, entries);
		});
	}
}

function readDir(dir)
{
	//var aryName = new Array();
	//var aryfullPath = new Array();
	fs.root.getDirectory(dir, {}, function(dirEntry){
		var dirReader = dirEntry.createReader();
		dirReader.readEntries(function(entries){
			newEntries = entries;
			continueReadFiles(dirReader, entries);
			/*if(dataStatus == 'picture')
			{
				for(var count=0;count<entries.length;++count)
				{
					if(entries[count].name.indexOf('.jpg') != -1)
					{
						++aryLength;
					}
				}
			}
			else if(dataStatus == 'video')
			{
				for(var count=0;count<entries.length;++count)
				{
					if(entries[count].name.indexOf('.mkv') != -1)
					{
						++aryLength;
					}
				}
			}
			//aryLength = entries.length;
			for(var i = 0; i < entries.length; i++)
			{
				var entry = entries[i];
				if(entry.isDirectory)
				{
					//console.log('Directory: ' + entry.fullPath);
				}
				else if(entry.isFile)
		    	{
					//console.log('File: ' + entry.fullPath);
					if(dataStatus == 'picture')
					{
						if(entry.name.indexOf('.jpg') != -1)
						{
							aryName.push(entry.name);
							aryfullPath.push(entry.fullPath);
						}
					}
					else if(dataStatus == 'video')
					{
						if(entry.name.indexOf('.mkv') != -1)
						{
							aryName.push(entry.name);
							aryfullPath.push(entry.fullPath);
						}
					}
				}
			}
			for(var i = 0;i < aryName.length; i++)
			{
				addPicFromFilesystemToArray(aryName[i], aryfullPath[i]);
			}*/
		}, errorHandler);
	}, errorHandler);
}

function mynoteUserLogin()
{
	myNoteAddDir("sphereLiteUser");
	readDir("sphereLiteUser");
	//myNoteAddDir("/tmp");
	//readDir("/tmp");
}

function selectPic()
{
	var allImages = myNoteImgArray;
	var selectImages = [];
	for(var i=0;i<allImages.length;i++)
	{
		if(allImages[i].isSelect == "true")
		{
			selectImages.push(allImages[i]);
		}
	}
	return selectImages;
}

function removeFile(name)
{
	fs.root.getFile("sphereLiteUser" + "/" + name, {create: false}, function(fileEntry){
		fileEntry.remove(function(){
			console.log('File removed.'+ name);
		}, errorHandler );
	}, errorHandler );
}

function removeItem(i)
{
	myNoteImgArray.splice(i, 1);
}

function changeToPage(num)
{
	totalPage = Math.floor(myNoteImgArray.length / 16);
	lastPos = (myNoteImgArray.length % 16);
	if((lastPos == 0) && (totalPage > 0))
	{
		totalPage -=1;
		if(nowPage > totalPage)
		{
			nowPage = totalPage;
			num = totalPage;
			console.log("nowPage::" + nowPage);

		}
	}
	for(var i = 16 * num; i < 16 * (num +1); i++)
	{
		if(myNoteImgArray[i])
		{
			var id = i % 16;
			var pos = (i % 16) + 1;
			if((num == totalPage) && (pos > lastPos) && (lastPos > 0))
			{
				document.getElementById('image_' + pos).src = "";
				document.getElementById('image_' + pos).unitId = "";
				document.getElementById('image_' + pos).className = "";
				document.getElementById('video_' + pos).src = "";
				document.getElementById('video_' + pos).unitId = "";
				$("#imageName_"+pos).text("");
				$("#container_" + id).css('display', 'none');
			}
			else
			{
				var src = myNoteImgArray[i].src;
				var unitId = myNoteImgArray[i].unitId;
				var name = myNoteImgArray[i].name;
				if(name.indexOf('.jpg') != -1)
				{
					document.getElementById('image_' + pos).onload = function(){
						if(this.width > this.height)
						{
							document.getElementById(this.id).className = "imageWidthCenter";
							centerMe(document.getElementById(this.id), 0, 0);
						}
						else
						{
							$('#' + this.id).css({'max-width': '', 'max-height': '', 'width': '', 'height': '', 'margin': ''});
							document.getElementById(this.id).className = "imageHeightCenter";
						}
					}
					document.getElementById('image_' + pos).src = src;
					document.getElementById('image_' + pos).unitId = unitId;
					document.getElementById('image_' + pos).className = "";
					myNoteImgArray[i].id = "image_" + pos;
				}
				if(name.indexOf('.mkv') != -1)
				{
					document.getElementById('video_' + pos).src = src;
					//Merging...
					if(name != parent.fileName)
					{
						$("#container_" + id).find('.playMark').attr('src', '../img/icon_play.png');
					}
					else
					{
						$("#container_" + id).find('.playMark').attr('src', '../img/icon_change.png');
					}
					$("#container_" + id).find('.playMarkDiv').css('display', 'block');
					document.getElementById('video_' + pos).unitId = unitId;
					myNoteImgArray[i].id = "video_" + pos;
				}
				$("#imageName_" + pos).text(name);
				$("#container_" + id).css('display', 'inline-block');
			}
		}
		else
		{
			var id = i % 16;
			var pos = (i % 16) + 1;
			document.getElementById('image_' + pos).src = "";
			document.getElementById('image_' + pos).unitId = "";
			document.getElementById('image_' + pos).className = "";
			document.getElementById('video_' + pos).src = "";
			document.getElementById('video_' + pos).unitId = "";
			$("#imageName_"+pos).text("");
			$("#container_" + id).css('display', 'none');
		}
	}
	$("#selectAllBtn").attr('src', '../img/btn_select_all_normal.png');
	$("#selectAllBtn").attr('isSelect', 'false');
	unSelectAll();
	if(num == 0)
	{
		$("#backBtn").attr('src', '../img/btn_left_disabled.png');
		$("#nextBtn").attr('src', '../img/btn_right_disabled.png');
	}
	document.getElementById('pageList').value = (nowPage + 1) + " / " + (totalPage + 1);
}

function deleteImg()
{
	$("#deleteDlg").css('display', 'none');
	$("#modalDialog_mask").css('display', 'none');
	var selectImages = selectPic();
	for(var i=0;i<selectImages.length;i++)
	{
		for(var j=0;j<myNoteImgArray.length;j++)
		{
			if(myNoteImgArray[j].unitId == selectImages[i].unitId)
			{
				isClickDel = true;
				myNoteImgArray[j].isSelect = "true";
				imgSelect(myNoteImgArray[j].unitId);
				myNoteImgArray[j].isSelect = "false";
				removeFile(myNoteImgArray[j].name);
				removeItem(j);
				isClickDel = false;
			}
		}
	}
	if(isAllSelect == "true")
	{
		isAllSelect = "false";
	}
	changeToPage(nowPage);
}

function uploadFile(_length, _progressVal)
{
	fs.root.getFile("sphereLiteUser" + "/" + fileArr[0].name, {}, function(fileEntry){
		fileEntry.file(function(file){
			var reader = new FileReader();
			reader.onloadend = function(e){
				result = gdocs.upload(file, _length, _progressVal, function(){
					fileArr.shift();
					if(fileArr.length == 0)
					{
						$("#progressBarDiv").css('display', 'none');
						progressBar.value = 0;
						$("#uploadSuccessDiv").css('display', 'block');
						fileArr = [];
						fileArrLen = 0;
					}
					else
					{
						uploadFile(fileArrLen, progressBar.value);
					}
				}, false);
			};
			reader.readAsText(file);
		}, errorHandler);
	}, errorHandler);
}

function uploadGoogleDrive()
{
	if(!fs)
	{
		return;
	}
	var selectImages = selectPic();
	var count = 0;
	for(var i = 0; i < selectImages.length; i++)
	{
		for(var j = 0;j < myNoteImgArray.length; j++)
		{
			if(myNoteImgArray[j].unitId == selectImages[i].unitId)
			{
				fileArr.push(myNoteImgArray[j]);
			}
	    }
	}
	fileArrLen = fileArr.length;
	uploadFile(fileArrLen, 0);
	//if(isAllSelect == "true")
	//{
	//    isAllSelect = "false";
	//}
}

function googleAuthorize()
{
	$(".loginDiv").css('display', 'none');
	$("#progressBarDiv").css('display', 'block');
	if (!gdocs.accessToken)
	{
		gdocs.auth(true, function()
		{
			uploadGoogleDrive();
		});
	}
	else
	{
		uploadGoogleDrive();
	}
	if(isAllSelect == "true")
	{
		isAllSelect = "false";
    }
}

function requestAccountListener()
{
	var obj = JSON.parse(this.responseText);
	if(typeof(obj.error) !== 'undefined')
	{
		if(obj.error.code == 401)
		{
			signIn();
		}
	}
	else
	{
		console.log("obj.name: " + obj.name);
		$("#userInfo_label").text(obj.name);
		$("#modalDialog_mask").css('display', 'block');
		$(".loginDiv").css('display', 'block');
	}
}

function signIn()
{
	gdocs.auth(true, function(){
		var request = new XMLHttpRequest();
		request.onload = requestAccountListener;
		request.open('GET', 'https://www.googleapis.com/oauth2/v1/userinfo?alt=json&access_token='+gdocs.accessToken+'', true);
		request.send();
	});
}

function doCheckInterNet()
{
	var selectImages = selectPic();
	if(selectImages.length == 0)
	{
		$("#saveBtn").attr('src', '../img/btn_save_normal.png');
		$("#saveBtn").attr('isSelect', 'false');
		$(".saveMenu dd ul").hide();
		$("#modalDialog_mask").css('display', 'block');
		$("#selectDlg").css('display', 'block');
		console.log('No select any item.');
		return;
	}
	
	var status = navigator.onLine ? "online" : "offline";
	if(status == "online")
	{
		console.log("status result = " + status);
		signIn();
	}
	else
	{
		console.log("status result = " + status);
		$("#modalDialog_mask").css('display', 'block');
		$("#noInternetDiv").css('display', 'block');
	}
	$("#saveBtn").attr('src', '../img/btn_save_normal.png');
	$("#saveBtn").attr('isSelect', 'false');
	$(".saveMenu dd ul").hide();
}

function unSelectAll()
{
	if(myNoteImgArray.length == 0)
	{
	    return;
	}
	num = nowPage;
	for(var i = 16 * num; i < 16 * (num +1); i++)
	{
	    var pos = (i % 16) + 1;
		if(myNoteImgArray[i])
		{
		    myNoteImgArray[i].isSelect = "true";
			imgSelect(myNoteImgArray[i].unitId);
		}
	}
	isAllSelect = "false";
	document.getElementById("selectAllBtn").title = "Select all";
}

function selectAll()
{
	if(myNoteImgArray.length == 0)
	{
		return;
	}
	num = nowPage;
	totalPage = Math.floor(myNoteImgArray.length / 16);
	lastPos = (myNoteImgArray.length % 16);
	if((lastPos == 0) && (totalPage > 0))
	{
		totalPage -=1;
	}

	if(isAllSelect == "false")
	{
		for(var i = 16 * num; i < 16 * (num +1); i++)
		{
			var pos = (i % 16) + 1;
			if((num == totalPage) && (pos > lastPos) && (lastPos > 0))
			{

			}
			else
			{
				myNoteImgArray[i].isSelect = "false";
				imgSelect(myNoteImgArray[i].unitId);
			}
		}
		isAllSelect = "true";
		$("#selectAllBtn").attr('src', '../img/btn_select_all_pressed.png');
		$("#selectAllBtn").attr('isSelect', 'true');
		document.getElementById("selectAllBtn").title = "Unselect all";
	}
	else
	{
		unSelectAll();
		$("#selectAllBtn").attr('src', '../img/btn_select_all_hover.png');
		$("#selectAllBtn").attr('isSelect', 'false');
	}
}

function centerMe(obj, marginWidth, marginHeight)
{
	var parentWidth = obj.parentNode.clientWidth;
	var parentHeight = obj.parentNode.clientHeight;
	
	obj.style.maxWidth = parentWidth - marginWidth + 'px';
	obj.style.maxHeight = parentHeight - marginHeight + 'px';
	
	obj.style.width = 'auto';
	obj.style.height = 'auto';
	if(obj.height < parentHeight && obj.width < parentWidth)
	{
		if(obj.height / obj.width < parentHeight / parentWidth)
		{
			obj.style.width = parentWidth + 'px';
		}
		else
		{
			obj.style.height = parentHeight + 'px';
		}
	}
	obj.style.margin = Math.floor((parentHeight - marginHeight - obj.clientHeight) / 2) + 'px' + ' ' + Math.floor((parentWidth - marginWidth - obj.clientWidth) / 2) + 'px';
}

function onResize()
{
	var userAgent = navigator.userAgent;
	var _clientWidth = 0;
	var _clientHeight = 0;
	if(userAgent.indexOf("CrOS") != -1)
	{
		_clientWidth = parent.document.body.clientWidth;
		_clientHeight = parent.document.body.clientHeight;
	}
	else
	{
		_clientWidth = window.outerWidth;
		_clientHeight = window.outerHeight;
	}
	
	if(_clientWidth == screen.availWidth && _clientHeight == screen.availHeight)
	{
		parent.isMaximum = true;
	}
	else
	{
		parent.isMaximum = false;
	}
	var width = originalWidth + (_clientWidth - originalWidth - 100);
	var height = originalHeight + (_clientHeight - originalHeight - 120);
	$(".pictureDiv").width(width);
	$(".pictureDiv").height(height);
	$("#pictureBtn").width(width / 2);
	$("#videoBtn").css({'left': width / 2});
	$("#videoBtn").width(width / 2);
	$("#pageDiv").css({'left': (width - $("#pageDiv").width()) / 2});
	$("#selectDlg").css({'left': 'calc(50% - '+$("#selectDlg").outerWidth() / 2+'px)', 'top': 'calc(45% - '+$("#selectDlg").outerHeight() / 2+'px)'});
	for(var i = 16 * nowPage; i < 16 * (nowPage + 1); i++)
	{
		var id = i % 16;
		var pos = (i % 16) + 1;
		if($('#image_' + pos).hasClass("imageWidthCenter"))
		{
			centerMe(document.getElementById('image_' + pos), 0, 0);
		}
	}
	if(parent.isMaximum)
	{
		parent.document.getElementById("scaleWindowBtn").title = "Minimize";
		parent.mainIframe.style.left = "0px";
		parent.mainIframe.style.width = "100%";
		parent.mainIframeTmp.style.left = "0px";
		parent.mainIframeTmp.style.width = "100%";
		var screenWidth = originalWidth + (_clientWidth - originalWidth);
		$(".pictureDiv").width(screenWidth);
		$("#pictureBtn").width(screenWidth / 2);
		$("#videoBtn").css({'left': screenWidth / 2});
		$("#videoBtn").width(screenWidth / 2);
		$("#pageDiv").css({'left': (screenWidth - $("#pageDiv").width()) / 2});
	}
	else
	{
		parent.document.getElementById("scaleWindowBtn").title = "Fullscreen";
		parent.mainIframe.style.left = "100px";
		parent.mainIframe.style.width = "calc(100% - 100px)";
		parent.mainIframeTmp.style.left = "100px";
		parent.mainIframeTmp.style.width = "calc(100% - 100px)";
	}
}

function hideLoginDiv()
{
	$(".loginDiv").css('display', 'none');
	$("#modalDialog_mask").css('display', 'none');
	$("#userInfo_label").text("");
	//gdocs.revokeAuthToken(function() {});
}

function goNextPage()
{
	if(nowPage < totalPage)
	{
		nowPage += 1;
		changeToPage(nowPage);
		if(nowPage == totalPage)
		{
			$("#backBtn").attr('src', '../img/btn_left_normal.png');
			$("#nextBtn").attr('src', '../img/btn_right_disabled.png');
		}
		console.log("goNExtpage nowPage = ", nowPage);
	}
}

function goBackPage()
{
	if(nowPage > 0)
	{
		nowPage -= 1;
		changeToPage(nowPage);
		if(nowPage == 0)
		{
			$("#backBtn").attr('src', '../img/btn_left_disabled.png');
			$("#nextBtn").attr('src', '../img/btn_right_normal.png');
		}
		console.log("goBackPage nowPage = ", nowPage);
	}
}

function hideSelectDlg()
{
	$("#selectDlg").css('display', 'none');
	$("#modalDialog_mask").css('display', 'none');
}

function hideUploadSuccessDiv()
{
	$("#uploadSuccessDiv").css('display', 'none');
	$("#modalDialog_mask").css('display', 'none');
}

function hideSaveSuccessDiv()
{
	$("#saveSuccessDiv").css('display', 'none');
	$("#modalDialog_mask").css('display', 'none');
}

function hideNoInternetDiv()
{
	$("#noInternetDiv").css('display', 'none');
	$("#modalDialog_mask").css('display', 'none');
}

function confirmDelete()
{
	var selectImages = selectPic();
	$("#modalDialog_mask").css('display', 'block');
	if(selectImages.length == 0)
	{
		$("#selectDlg").css('display', 'block');
		return;
	}
	$("#deleteDlg").css('display', 'block');
}

function hideDelete()
{
	$("#modalDialog_mask").css('display', 'none');
	$("#deleteDlg").css('display', 'none');
}

function clearAllData()
{
	totalPage = Math.floor(myNoteImgArray.length / 16);
	firstPageLastPos = ((myNoteImgArray.length) % 16);
	if(totalPage > 0)
	{
		firstPageNumberOfImg = 16;
	}
	else
	{
		firstPageNumberOfImg = firstPageLastPos;
	}
	if((firstPageLastPos == 0) && (totalPage > 0))
	{
		totalPage -=1;
	}
	for(var i = 0; i < firstPageNumberOfImg; i++)
	{
		var id = i % 16;
		var pos = (i % 16) + 1;
		document.getElementById('image_' + pos).src = "";
		document.getElementById('image_' + pos).unitId = "";
		document.getElementById('image_' + pos).className = "";
		document.getElementById('video_' + pos).src = "";
		document.getElementById('video_' + pos).unitId = "";
		$("#imageName_"+pos).text("");
		$("#container_" + id).find('.playMark').attr('src', '');
		$("#container_" + id).find('.playMarkDiv').css('display', 'none');
		$("#container_" + id).css('display', 'none');
	}

	nowPage = 0;
	totalPage = 0;
	$("#backBtn").attr('src', '../img/btn_left_disabled.png');
	$("#nextBtn").attr('src', '../img/btn_right_disabled.png');
	document.getElementById('pageList').value = (nowPage + 1) + " / " + (totalPage + 1);
}

function changeMediaLibraryData()
{
	if(this.id == 'pictureBtn')
	{
		dataStatus = 'picture';
		$("#videoBtn").attr('isSelect', 'false');
		$("#videoLeft").attr('src', '../img/bg_top_mid.png');
		$("#videoMid").attr('src', '../img/bg_top_mid.png');
		$("#videoRight").attr('src', '../img/bg_top_right.png');
		$("#videoImg").attr('src', '../img/btn_video_normal.png');
		
		$(this).attr('isSelect', 'true');
		$("#pictureLeft").attr('src', '../img/bg_pic_btn_pressed_left.png');
		$("#pictureMid").attr('src', '../img/bg_pic_btn_pressed_mid.png');
		$("#pictureRight").attr('src', '../img/bg_pic_btn_pressed_right.png');
		$("#pictureImg").attr('src', '../img/btn_pic_pressed.png');
	}
	if(this.id == 'videoBtn')
	{
		dataStatus = 'video'
		$("#pictureBtn").attr('isSelect', 'false');
		$("#pictureLeft").attr('src', '../img/bg_top_left.png');
		$("#pictureMid").attr('src', '../img/bg_top_mid.png');
		$("#pictureRight").attr('src', '../img/bg_top_mid.png');
		$("#pictureImg").attr('src', '../img/btn_pic_normal.png');
		
		$(this).attr('isSelect', 'true');
		$("#videoLeft").attr('src', '../img/bg_video_btn_pressed_left.png');
		$("#videoMid").attr('src', '../img/bg_pic_btn_pressed_mid.png');
		$("#videoRight").attr('src', '../img/bg_video_btn_pressed_right.png');
		$("#videoImg").attr('src', '../img/btn_video_pressed.png');
	}
	$("#selectAllBtn").attr('src', '../img/btn_select_all_normal.png');
	$("#selectAllBtn").attr('isSelect', 'false');
	unSelectAll();
	clearAllData();
	myNoteImgArray = new Array();
	trueCount = 0;
	isAllSelect = "false";
	imageCount = 0;
	aryLength = 0;
	readDir("sphereLiteUser");
}

function saveMenu()
{
	$(".saveMenu dd ul").hide();
	$(this).attr('src', '../img/btn_save_pressed.png');
	$(this).attr('isSelect', 'true');
	$("#saveDiv").slideToggle('fast');
	checkSavePanel("saveMenu");
}

function fileToArrayBuffer()
{
	if(fileArr.length == 0)
	{
		$("#modalDialog_mask").css('display', 'block');
		$("#saveSuccessDiv").css('display', 'block');
		_dirEntry = null;
		fileArr = [];
		fileArrLen = 0;
		document.body.style.cursor = "default";
		parent.document.body.style.cursor = "default";
		return;
	}
	document.body.style.cursor = "wait";
	parent.document.body.style.cursor = "wait";
	fs.root.getFile("sphereLiteUser" + "/" + fileArr[0].name, {}, function(fileEntry){
		fileEntry.copyTo(_dirEntry, fileArr[0].name, function(){
			delete fileEntry;
			fileEntry = null;
			fileArr.shift();
			fileToArrayBuffer();
		});
	}, errorHandler);
}

function saveLocal()
{
	var selectImages = selectPic();
	if(selectImages.length == 0)
	{
		$("#saveBtn").attr('src', '../img/btn_save_normal.png');
		$("#saveBtn").attr('isSelect', 'false');
		$(".saveMenu dd ul").hide();
		$("#modalDialog_mask").css('display', 'block');
		$("#selectDlg").css('display', 'block');
		console.log('No select any item.');
		return;
	}
	chrome.fileSystem.chooseEntry({type: 'openDirectory'}, function(dirEntry){
		if(!fs)
		{
			return;
		}
		if (chrome.runtime.lastError) {
			document.body.style.cursor = "default";
			parent.document.body.style.cursor = "default";
			return;
		}
		_dirEntry = dirEntry;
		for(var i = 0; i < selectImages.length; i++)
		{
			for(var j = 0;j < myNoteImgArray.length; j++)
			{
				if(myNoteImgArray[j].unitId == selectImages[i].unitId)
				{
					fileArr.push(myNoteImgArray[j]);
				}
			}
		}
		fileArrLen = fileArr.length;
		fileToArrayBuffer();
		//if(isAllSelect == "true")
		//{
		//	isAllSelect = "false";
		//}
	});
	$("#saveBtn").attr('src', '../img/btn_save_normal.png');
	$("#saveBtn").attr('isSelect', 'false');
	$(".saveMenu dd ul").hide();
}

function checkSavePanel(id)
{
	if(saveTimeOut)
	{
		clearTimeout(saveTimeOut);
	}
	saveTimeOut = setTimeout(function(){
		if(panelStatus == "leave")
		{
			if(saveStatus == "leave")
			{
				$("#saveBtn").attr('src', '../img/btn_save_normal.png');
			}
			else
			{
				$("#saveBtn").attr('src', '../img/btn_save_hover.png');
			}
			$("#saveBtn").attr('isSelect', 'false');
			$("."+id+" dd ul").hide();
		}
	}, 3000);
}

function allBtnEvent()
{
	$("#pictureBtn").hover(function(){
		var isSelect = $(this).attr('isSelect');
		if(isSelect == 'false')
		{
			$("#pictureLeft").attr('src', '../img/bg_pic_btn_hover_left.png');
			$("#pictureMid").attr('src', '../img/bg_pic_btn_hover_mid.png');
			$("#pictureRight").attr('src', '../img/bg_pic_btn_hover_right.png');
			$("#pictureImg").attr('src', '../img/btn_pic_hover.png');
		}
	}, function(){
		var isSelect = $(this).attr('isSelect');
		if(isSelect == 'false')
		{
			$("#pictureLeft").attr('src', '../img/bg_top_left.png');
			$("#pictureMid").attr('src', '../img/bg_top_mid.png');
			$("#pictureRight").attr('src', '../img/bg_top_mid.png');
			$("#pictureImg").attr('src', '../img/btn_pic_normal.png');
		}
	});
	
	$("#pictureBtn").mousedown(function(e){
		if(e.which != 1)
		{
			return;
		}
		$("#pictureLeft").attr('src', '../img/bg_pic_btn_pressed_left.png');
		$("#pictureMid").attr('src', '../img/bg_pic_btn_pressed_mid.png');
		$("#pictureRight").attr('src', '../img/bg_pic_btn_pressed_right.png');
		$("#pictureImg").attr('src', '../img/btn_pic_pressed.png');
	}).mouseup(function(e){
		if(e.which != 1)
		{
			return;
		}
		$("#pictureLeft").attr('src', '../img/bg_pic_btn_hover_left.png');
		$("#pictureMid").attr('src', '../img/bg_pic_btn_hover_mid.png');
		$("#pictureRight").attr('src', '../img/bg_pic_btn_hover_right.png');
		$("#pictureImg").attr('src', '../img/btn_pic_hover.png');
	});
	
	$("#videoBtn").hover(function(){
		var isSelect = $(this).attr('isSelect');
		if(isSelect == 'false')
		{
			$("#videoLeft").attr('src', '../img/bg_video_btn_hover_left.png');
			$("#videoMid").attr('src', '../img/bg_pic_btn_hover_mid.png');
			$("#videoRight").attr('src', '../img/bg_video_btn_hover_right.png');
			$("#videoImg").attr('src', '../img/btn_video_hover.png');
		}
	}, function(){
		var isSelect = $(this).attr('isSelect');
		if(isSelect == 'false')
		{
			$("#videoLeft").attr('src', '../img/bg_top_mid.png');
			$("#videoMid").attr('src', '../img/bg_top_mid.png');
			$("#videoRight").attr('src', '../img/bg_top_right.png');
			$("#videoImg").attr('src', '../img/btn_video_normal.png');
		}
	});
	
	$("#videoBtn").mousedown(function(e){
		if(e.which != 1)
		{
			return;
		}
		$("#videoLeft").attr('src', '../img/bg_video_btn_pressed_left.png');
		$("#videoMid").attr('src', '../img/bg_pic_btn_pressed_mid.png');
		$("#videoRight").attr('src', '../img/bg_video_btn_pressed_right.png');
		$("#videoImg").attr('src', '../img/btn_video_pressed.png');
	}).mouseup(function(e){
		if(e.which != 1)
		{
			return;
		}
		$("#videoLeft").attr('src', '../img/bg_video_btn_hover_left.png');
		$("#videoMid").attr('src', '../img/bg_pic_btn_hover_mid.png');
		$("#videoRight").attr('src', '../img/bg_video_btn_hover_right.png');
		$("#videoImg").attr('src', '../img/btn_video_hover.png');
	});
	
	$("#saveDiv").hover(function(){
		panelStatus = "hover";
	}, function(){
		panelStatus = "leave";
		checkSavePanel("saveMenu");
	});
	
	$("#save_ok_btnText").hover(function(){
		$(this).css('color', '#FFFFFF');
		$("#save_ok_btn").attr('src', '../img/btn_dialog_hover.png');
	}, function(){
		$(this).css('color', '#CCCCCC');
		$("#save_ok_btn").attr('src', '../img/btn_dialog_normal.png');
	});
	
	$("#save_ok_btnText").mousedown(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).css('color', '#FF8200');
		$("#save_ok_btn").attr('src', '../img/btn_dialog_pressed.png');
	}).mouseup(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).css('color', '#FFFFFF');
		$("#save_ok_btn").attr('src', '../img/btn_dialog_hover.png');
	});
	
	$("#noInternet_ok_btnText").hover(function(){
		$(this).css('color', '#FFFFFF');
		$("#noInternet_ok_btn").attr('src', '../img/btn_dialog_hover.png');
	}, function(){
		$(this).css('color', '#CCCCCC');
		$("#noInternet_ok_btn").attr('src', '../img/btn_dialog_normal.png');
	});
	
	$("#noInternet_ok_btnText").mousedown(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).css('color', '#FF8200');
		$("#noInternet_ok_btn").attr('src', '../img/btn_dialog_pressed.png');
	}).mouseup(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).css('color', '#FFFFFF');
		$("#noInternet_ok_btn").attr('src', '../img/btn_dialog_hover.png');
	});
	
	$("#saveBtn").hover(function(){
		if(myNoteImgArray.length == 0)
		{
			return;
		}
		saveStatus = "hover";
		var isSelect = $(this).attr('isSelect');
		if(isSelect == "false")
		{
			$(this).attr('src', '../img/btn_save_hover.png');
		}
	}, function(){
		if(myNoteImgArray.length == 0)
		{
			return;
		}
		saveStatus = "leave";
		var isSelect = $(this).attr('isSelect');
		if(isSelect == "false")
		{
			$(this).attr('src', '../img/btn_save_normal.png');
		}
	});
	
	$("#saveBtn").mousedown(function(e){
		if(e.which != 1)
		{
			return;
		}
		if(myNoteImgArray.length == 0)
		{
			return;
		}
		$(this).attr('src', '../img/btn_save_pressed.png');
	}).mouseup(function(e){
		if(e.which != 1)
		{
			return;
		}
		if(myNoteImgArray.length == 0)
		{
			return;
		}
		$(this).attr('src', '../img/btn_save_hover.png');
	});
	
	$("#selectAllBtn").hover(function(){
		if(myNoteImgArray.length == 0)
		{
			return;
		}
		var isSelect = $(this).attr('isSelect');
		if(isSelect == "false")
		{
			$(this).attr('src', '../img/btn_select_all_hover.png');
		}
	}, function(){
		if(myNoteImgArray.length == 0)
		{
			return;
		}
		var isSelect = $(this).attr('isSelect');
		if(isSelect == "false")
		{
			$(this).attr('src', '../img/btn_select_all_normal.png');
		}
	});
	
	$("#selectAllBtn").mousedown(function(e){
		if(e.which != 1)
		{
			return;
		}
		if(myNoteImgArray.length == 0)
		{
			return;
		}
		$(this).attr('src', '../img/btn_select_all_pressed.png');
	}).mouseup(function(e){
		if(e.which != 1)
		{
			return;
		}
		if(myNoteImgArray.length == 0)
		{
			return;
		}
		$(this).attr('src', '../img/btn_select_all_hover.png');
	});
	
	$("#deleteBtn").hover(function(){
		if(myNoteImgArray.length == 0)
		{
			return;
		}
		var selectImages = selectPic();
		if(selectImages == 0)
		{
			return;
		}
		$(this).attr('src', '../img/btn_clearall_hover.png');
	}, function(){
		if(myNoteImgArray.length == 0)
		{
			return;
		}
		var selectImages = selectPic();
		if(selectImages == 0)
		{
			return;
		}
		$(this).attr('src', '../img/btn_clearall_normal.png');
	});
	
	$("#deleteBtn").mousedown(function(e){
		if(e.which != 1)
		{
			return;
		}
		if(myNoteImgArray.length == 0)
		{
			return;
		}
		var selectImages = selectPic();
		if(selectImages == 0)
		{
			return;
		}
		$(this).attr('src', '../img/btn_clearall_pressed.png');
	}).mouseup(function(e){
		if(e.which != 1)
		{
			return;
		}
		if(myNoteImgArray.length == 0)
		{
			return;
		}
		var selectImages = selectPic();
		if(selectImages == 0)
		{
			return;
		}
		$(this).attr('src', '../img/btn_clearall_hover.png');
	});
	
	$("#localBtn").hover(function(){
		$(this).attr('src', '../img/btn_file_hover.png');
	}, function(){
		$(this).attr('src', '../img/btn_file_normal.png');
	});
	
	$("#localBtn").mousedown(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).attr('src', '../img/btn_file_pressed.png');
	}).mouseup(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).attr('src', '../img/btn_file_hover.png');
	});
	
	$("#uploadBtn").hover(function(){
		$(this).attr('src', '../img/btn_google_drive_hover.png');
	}, function(){
		$(this).attr('src', '../img/btn_google_drive_normal.png');
	});
	
	$("#uploadBtn").mousedown(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).attr('src', '../img/btn_google_drive_pressed.png');
	}).mouseup(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).attr('src', '../img/btn_google_drive_hover.png');
	});
	
	$("#backBtn").hover(function(){
		if(nowPage == 0)
		{
			return;
		}
		$(this).attr('src', '../img/btn_left_hover.png');
	}, function(){
		if(nowPage == 0)
		{
			return;
		}
		$(this).attr('src', '../img/btn_left_normal.png');
	});
	
	$("#backBtn").mousedown(function(e){
		if(e.which != 1)
		{
			return;
		}
		if(nowPage == 0)
		{
			return;
		}
		$(this).attr('src', '../img/btn_left_pressed.png');
	}).mouseup(function(e){
		if(e.which != 1)
		{
			return;
		}
		if(nowPage == 0)
		{
			return;
		}
		$(this).attr('src', '../img/btn_left_hover.png');
	});
	
	$("#nextBtn").hover(function(){
		if(nowPage == totalPage)
		{
			return;
		}
		$(this).attr('src', '../img/btn_right_hover.png');
	}, function(){
		if(nowPage == totalPage)
		{
			return;
		}
		$(this).attr('src', '../img/btn_right_normal.png');
	});
	
	$("#nextBtn").mousedown(function(e){
		if(e.which != 1)
		{
			return;
		}
		if(nowPage == totalPage)
		{
			return;
		}
		$(this).attr('src', '../img/btn_right_pressed.png');
	}).mouseup(function(e){
		if(e.which != 1)
		{
			return;
		}
		if(nowPage == totalPage)
		{
			return;
		}
		$(this).attr('src', '../img/btn_right_hover.png');
	});
	
	$("#gUploadText").hover(function(){
		$(this).css('color', '#FFFFFF');
		$("#gUpload").attr('src', '../img/btn_dialog_hover.png');
	}, function(){
		$(this).css('color', '#CCCCCC');
		$("#gUpload").attr('src', '../img/btn_dialog_normal.png');
	});
	
	$("#gUploadText").mousedown(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).css('color', '#FF8200');
		$("#gUpload").attr('src', '../img/btn_dialog_pressed.png');
	}).mouseup(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).css('color', '#FFFFFF');
		$("#gUpload").attr('src', '../img/btn_dialog_hover.png');
	});
	
	$("#gCancelText").hover(function(){
		$(this).css('color', '#FFFFFF');
		$("#gCancel").attr('src', '../img/btn_dialog_hover.png');
	}, function(){
		$(this).css('color', '#CCCCCC');
		$("#gCancel").attr('src', '../img/btn_dialog_normal.png');
	});
	
	$("#gCancelText").mousedown(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).css('color', '#FF8200');
		$("#gCancel").attr('src', '../img/btn_dialog_pressed.png');
	}).mouseup(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).css('color', '#FFFFFF');
		$("#gCancel").attr('src', '../img/btn_dialog_hover.png');
	});
	
	$("#progress_ok_btnText").hover(function(){
		$(this).css('color', '#FFFFFF');
		$("#progress_ok_btn").attr('src', '../img/btn_dialog_hover.png');
	}, function(){
		$(this).css('color', '#CCCCCC');
		$("#progress_ok_btn").attr('src', '../img/btn_dialog_normal.png');
	});
	
	$("#progress_ok_btnText").mousedown(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).css('color', '#FF8200');
		$("#progress_ok_btn").attr('src', '../img/btn_dialog_pressed.png');
	}).mouseup(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).css('color', '#FFFFFF');
		$("#progress_ok_btn").attr('src', '../img/btn_dialog_hover.png');
	});
	
	$("#confirm_yes_btnText").hover(function(){
		$(this).css('color', '#FFFFFF');
		$("#confirm_yes_btn").attr('src', '../img/btn_dialog_hover.png');
	}, function(){
		$(this).css('color', '#CCCCCC');
		$("#confirm_yes_btn").attr('src', '../img/btn_dialog_normal.png');
	});
	
	$("#confirm_yes_btnText").mousedown(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).css('color', '#FF8200');
		$("#confirm_yes_btn").attr('src', '../img/btn_dialog_pressed.png');
	}).mouseup(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).css('color', '#FFFFFF');
		$("#confirm_yes_btn").attr('src', '../img/btn_dialog_hover.png');
	});
	
	$("#confirm_no_btnText").hover(function(){
		$(this).css('color', '#FFFFFF');
		$("#confirm_no_btn").attr('src', '../img/btn_dialog_hover.png');
	}, function(){
		$(this).css('color', '#CCCCCC');
		$("#confirm_no_btn").attr('src', '../img/btn_dialog_normal.png');
	});
	
	$("#confirm_no_btnText").mousedown(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).css('color', '#FF8200');
		$("#confirm_no_btn").attr('src', '../img/btn_dialog_pressed.png');
	}).mouseup(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).css('color', '#FFFFFF');
		$("#confirm_no_btn").attr('src', '../img/btn_dialog_hover.png');
	});
	
	$("#select_ok_btnText").hover(function(){
		$(this).css('color', '#FFFFFF');
		$("#confirm_no_btn").attr('src', '../img/btn_dialog_hover.png');
	}, function(){
		$(this).css('color', '#CCCCCC');
		$("#confirm_no_btn").attr('src', '../img/btn_dialog_normal.png');
	});
	
	$("#select_ok_btnText").mousedown(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).css('color', '#FF8200');
		$("#confirm_no_btn").attr('src', '../img/btn_dialog_pressed.png');
	}).mouseup(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).css('color', '#FFFFFF');
		$("#confirm_no_btn").attr('src', '../img/btn_dialog_hover.png');
	});
}

$(document).ready(function(){
	$(".loginDiv").on('dblclick', function(e){
		e.stopPropagation();
	});
	
	$("#selectDlg").on('dblclick', function(e){
		e.stopPropagation();
	});
	
	$("#deleteDlg").on('dblclick', function(e){
		e.stopPropagation();
	});
	
	$("#progressBarDiv").on('dblclick', function(e){
		e.stopPropagation();
	});
	
	$("#uploadSuccessDiv").on('dblclick', function(e){
		e.stopPropagation();
	});
	
	$("#saveSuccessDiv").on('dblclick', function(e){
		e.stopPropagation();
	});
	
	$("#noInternetDiv").on('dblclick', function(e){
		e.stopPropagation();
	});
	
	$(document).bind('click', function(e){
		var $clicked = $(e.target);
		if(!$clicked.parents().hasClass("saveMenu"))
		{
			$("#saveBtn").attr('src', '../img/btn_save_normal.png');
			$("#saveBtn").attr('isSelect', 'false');
			$(".saveMenu dd ul").hide();
		}
	});
	allBtnEvent();
});

function startInit()
{
	if(fs == 0)
	{
		console.log("fs == 0");
		fs = myNoteImpl.getFileSystem();
		window.setTimeout(startInit, 1000);
		return;
	}
	pictureBtn.onclick = changeMediaLibraryData;
	videoBtn.onclick = changeMediaLibraryData;
	saveBtn.onclick = saveMenu;
	localBtn.onclick = saveLocal;
	uploadBtn.onclick = doCheckInterNet;
	select_ok_btnText.onclick = hideSelectDlg;
	progress_ok_btnText.onclick = hideUploadSuccessDiv;
	save_ok_btnText.onclick = hideSaveSuccessDiv;
	noInternet_ok_btnText.onclick = hideNoInternetDiv;
	gUploadText.onclick = googleAuthorize;
	gCancelText.onclick = hideLoginDiv;
	selectAllBtn.onclick = selectAll;
	deleteBtn.onclick = confirmDelete;
	confirm_yes_btnText.onclick = deleteImg;
	confirm_no_btnText.onclick = hideDelete;
	backBtn.onclick = goBackPage;
	nextBtn.onclick = goNextPage;
	
	originalWidth = $(".pictureDiv").width();
	originalHeight = $(".pictureDiv").height();
	
	onResize();
	$(window).resize(onResize);
	
	mynoteUserLogin();
}

window.onload = startInit;