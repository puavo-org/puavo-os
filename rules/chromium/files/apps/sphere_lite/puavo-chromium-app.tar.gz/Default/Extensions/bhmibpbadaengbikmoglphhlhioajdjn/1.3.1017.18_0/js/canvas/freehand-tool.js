var lenThreshold = 25.0;
var angleThreshold = Math.cos(Math.PI * 5.0 / 180.0);


function FreehandTool(editor)
{
	//ft_m_canvas_editor = ft_constructor_p_canvas_editor;
	this.canvasEditor = editor;
	this.debug_name = "Freehand tool";
	this.is_painting = false;
	this.new_freehand_graphic = null;
	this.line_width = 3;
	this.line_color = "#FF0000";
	this.last_draw_pt_x = 0;
	this.last_draw_pt_y = 0;
	this.last_real_pt_x = 0;
	this.last_real_pt_y = 0;
	this.isHighlighter = false;
	this.curX = 0;
	this.curY = 0;
	this.preX = 0;
	this.preY = 0;
	this.startDraw = 0;
	this.arrow_type = 0;
	this.dash_line = false;
};

FreehandTool.prototype.getName = function()
{
	return this.debug_name;
};

FreehandTool.prototype.setLineWidth = function(width)
{
	this.line_width = width;
};

FreehandTool.prototype.getLineWidth = function()
{
	return this.line_width;
};

FreehandTool.prototype.setLineColor = function(color)
{
	this.line_color = color;
};

FreehandTool.prototype.getLineColor = function()
{
	return this.line_color;
};

function calcSquaredDistance(p1_x, p1_y, p2_x, p2_y)
{
    var dx = p1_x - p2_x;
    var dy = p1_y - p2_y;
    return (dx * dx + dy * dy);
}

FreehandTool.prototype.startSmooth = function(x, y, is_last_pt)
{
	var new_draw_pt_x = (x + this.last_real_pt_x) * 0.5;
	var new_draw_pt_y = (y + this.last_real_pt_y) * 0.5;
	
	var mid_pt_x = (this.last_draw_pt_x + (this.last_real_pt_x * 2.0) + new_draw_pt_x) * 0.25;
	var mid_pt_y = (this.last_draw_pt_y + (this.last_real_pt_y * 2.0) + new_draw_pt_y) * 0.25;
	
	var ax = mid_pt_x - this.last_draw_pt_x;
	var ay = mid_pt_y - this.last_draw_pt_y;
    
	var bx = new_draw_pt_x - mid_pt_x;
	var by = new_draw_pt_y - mid_pt_y;
	
	var dot = ax * bx + ay * by;
	var aDis = Math.abs(Math.sqrt(calcSquaredDistance(mid_pt_x, mid_pt_y, this.last_draw_pt_x, this.last_draw_pt_y)));
	var bDis = Math.abs(Math.sqrt(calcSquaredDistance(mid_pt_x, mid_pt_y, this.last_real_pt_x, this.last_real_pt_y)));
	var angle = dot / (aDis * bDis);
    
    var midAdded = false;
	
    if (calcSquaredDistance(this.last_draw_pt_x, this.last_draw_pt_y, new_draw_pt_x, new_draw_pt_y) > lenThreshold ||  // the length of line D1D2 > 5 pixels
        Math.abs(angle) < angleThreshold)  // the angle > +-5 degrees; represents an obvious turn of the path
    {
    	this.new_freehand_graphic.addPoint(mid_pt_x, mid_pt_y);
        midAdded = true;
    }
    this.new_freehand_graphic.addPoint(new_draw_pt_x, new_draw_pt_y);
    // curPoint = the last point of the entire path
    if (is_last_pt)
    {
    	this.new_freehand_graphic.addPoint(x, y);
    }
    
    this.last_draw_pt_x = new_draw_pt_x;
    this.last_draw_pt_y = new_draw_pt_y;
    this.last_real_pt_x = x;
    this.last_real_pt_y = y;
};

FreehandTool.prototype.annoToolAnnotationStart = function(x, y)
{
	this.is_painting = true;
	this.last_draw_pt_x = x;
	this.last_draw_pt_y = y;
	this.last_real_pt_x = x;
	this.last_real_pt_y = y;
	if(this.isHighlighter)
	{
	    this.new_freehand_graphic = new HighlighterGraphic();
	}
	else
	{
	    this.new_freehand_graphic = new FreehandGraphic();
	}
	//this.new_freehand_graphic = new FreehandGraphic();
	//this.new_freehand_graphic.setHighlighter(this.isHighlighter);	
	this.new_freehand_graphic.setLineWidth(this.line_width);
	this.new_freehand_graphic.setLineColor(this.line_color);
	this.new_freehand_graphic.setArrowType(this.arrow_type);
	this.new_freehand_graphic.setDashLine(this.dash_line);

	systemCanvasContext.strokeStyle = this.line_color;
	systemCanvasContext.lineWidth = this.line_width;
	this.new_freehand_graphic.addPoint(x, y);
	this.currX = x;
	this.currY = y;
	this.prevX = x;
	this.prevY = y;
	systemCanvasContext.beginPath();
};

FreehandTool.prototype.annoToolAnnotationMove = function(x, y)
{
	if(this.is_painting == false)
		return;
	this.prevX = this.currX;
	this.prevY = this.currY;
	this.currX = x;
	this.currY = y;
    this.draw(this.prevX, this.prevY,this.currX,this.currY);
	this.startSmooth(x, y, false);
	//this.new_freehand_graphic.addPoint(x, y);	
	//this.canvasEditor.askViewToRedraw();
};

FreehandTool.prototype.draw = function(prevX, prevY,currX,currY)
{
    this.startDraw = this.startDraw +1;
	if(this.startDraw == 1)
	{
	    systemCanvasContext.moveTo(prevX, prevY);
	}
	systemCanvasContext.lineJoin = 'round';
    systemCanvasContext.lineTo(currX, currY);
	systemCanvasContext.stroke();
    systemCanvasContext.save();
};

FreehandTool.prototype.annoToolAnnotationStop = function(x, y)
{
    systemCanvasContext.closePath();
	this.startDraw = 0;
	this.is_painting = false;
	this.startSmooth(x, y, true);
	//this.new_freehand_graphic.addPoint(x, y);
	this.canvasEditor.addGraphicToActiveCanvas(this.new_freehand_graphic);	
	this.new_freehand_graphic.isEditing = false;
	this.new_freehand_graphic = null;
	this.canvasEditor.askViewToRedraw();	
};

FreehandTool.prototype.render = function()
{
	if(!this.is_painting)
	{
		return;
	}
	this.new_freehand_graphic.render();	
};

FreehandTool.prototype.setHighlighter = function(yesNo)
{
    this.isHighlighter = yesNo;	
}

FreehandTool.prototype.setArrowType = function(type)
{
	this.arrow_type = type;
}

FreehandTool.prototype.getArrowType = function()
{
	return this.arrow_type;
}

FreehandTool.prototype.setDashLine = function(TorF)
{
	this.dash_line = TorF;
}

FreehandTool.prototype.getDashLine = function(TorF)
{
	return this.dash_line;
}