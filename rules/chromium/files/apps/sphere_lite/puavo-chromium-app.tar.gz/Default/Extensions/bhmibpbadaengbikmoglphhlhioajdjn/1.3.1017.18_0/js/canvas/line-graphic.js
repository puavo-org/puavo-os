// lg for Line graphic prefix

function LineGraphic()
{
	this.rect_x = 0;
	this.rect_y = 0;
	this.rect_w = 0;
	this.rect_h = 0;
	this.parent_canvas_model = null;
	this.start_pt_x = 0;
	this.start_pt_y = 0;
	this.end_pt_x = 0;
	this.end_pt_y = 0;
	this.is_selected = false;
	this.line_width = 3;
	this.rect_is_calc = false;
	this.line_color = "#000000";
	// this.line_color_r = 255;
	// this.line_color_g = 155;
	// this.line_color_b = 55;
	// this.line_color_a = 1;
	this.zorderIndex = -1;
	this.dash_line = false;
	this.arrow_type = 2; // 0: no arrow 1: single arrow 2: double arrow 
};

LineGraphic.prototype.getType = function()
{
	return "LineGraphic";
};

LineGraphic.prototype.setLineWidth = function(width)
{
	this.line_width = width;
};

LineGraphic.prototype.setLineColor = function(color)
{
	this.line_color = color;
	// this.line_color_r = r;
	// this.line_color_g = g;
	// this.line_color_b = b;
	// this.line_color_a = a;
};

LineGraphic.prototype.setParentCanvasModel = function(canvas_model)
{
	this.parent_canvas_model = canvas_model;
	if(!this.rect_is_calc)
	{
		this.calcGraphicRect();
		this.calcPointsToGraphicCoor();
		this.rect_is_calc = true;
	}
};

LineGraphic.prototype.setSelected = function(selected)
{
	this.is_selected = selected;
};

LineGraphic.prototype.isSelected = function()
{
	return this.is_selected;
};

LineGraphic.prototype.move = function(dx , dy)
{
	this.rect_x += dx;
	this.rect_y += dy;
};

LineGraphic.prototype.setStartPoint = function(x, y)
{
	this.start_pt_x = x;
	this.start_pt_y = y;
};

LineGraphic.prototype.setEndPoint = function(x, y)
{
	this.end_pt_x = x;
	this.end_pt_y = y;
};

LineGraphic.prototype.calcIsSelected = function(x, y, w, h)
{
	var gLeft = this.rect_x;
	var gRight = this.rect_x + this.rect_w;
	var gTop = this.rect_y;
	var gBottom = this.rect_y + this.rect_h;
	var l = x;
	var r = x + w;
	var t = y;
	var b = y + h;
	if(b < gTop || r < gLeft|| l > gRight || t > gBottom)
		return false;
	return true;
};

LineGraphic.prototype.calcGraphicRect = function()
{
	this.rect_x = this.start_pt_x;
	this.rect_w = this.end_pt_x - this.start_pt_x;
	if(this.end_pt_x < this.start_pt_x)
	{
		this.rect_x = this.end_pt_x;
		this.rect_w = this.start_pt_x - this.rect_x;
	}
	this.rect_y = this.start_pt_y;
	this.rect_h = this.end_pt_y - this.start_pt_y;
	if(this.end_pt_y < this.start_pt_y)
	{
		this.rect_y = this.end_pt_y;
		this.rect_h = this.start_pt_y - this.rect_y;
	}
};

LineGraphic.prototype.calcPointsToGraphicCoor = function()
{
	this.start_pt_x -= this.rect_x;
	this.start_pt_y -= this.rect_y;
	this.end_pt_x -= this.rect_x;
	this.end_pt_y -= this.rect_y;
};

LineGraphic.prototype.eraseTest = function(ax, ay, bx, by)
{
	ax -= this.rect_x;
	ay -= this.rect_y;
	bx -= this.rect_x;
	by -= this.rect_y;
	return isIntersected(this.start_pt_x, this.start_pt_y, this.end_pt_x, this.end_pt_y, ax, ay, bx, by);
};

LineGraphic.prototype.hitTest = function(x, y)
{
	var gLeft = this.rect_x;
	var gRight = this.rect_x + this.rect_w;
	var gTop = this.rect_y;
	var gBottom = this.rect_y + this.rect_h;
	if(x > gRight || x < gLeft || y > gBottom || y < gTop)
	{
		return false;
	}
	return true;
};

LineGraphic.prototype.setZorderIndex = function(index)
{
	this.zorderIndex = index;
}

LineGraphic.prototype.getZorderIndex = function(index)
{
	return this.zorderIndex;
}

LineGraphic.prototype.setArrowType = function(type)
{
	this.arrow_type = type;
}
LineGraphic.prototype.setDashLine = function(TorF)
{
	this.dash_line = TorF;
}

LineGraphic.prototype.render = function()
{
	systemCanvasContext.save();
	systemCanvasContext.translate(this.rect_x, this.rect_y);
		
	systemCanvasContext.beginPath();
	if(this.dash_line === true){
		var dashObj = [this.line_width*5,this.line_width*3];
		this.drawDashLine(this.start_pt_x,this.start_pt_y,this.end_pt_x, this.end_pt_y,dashObj);
	}
	else
	{	
		systemCanvasContext.moveTo(this.start_pt_x , this.start_pt_y);
		systemCanvasContext.lineTo(this.end_pt_x, this.end_pt_y);
		systemCanvasContext.closePath();
		systemCanvasContext.strokeStyle = this.line_color;
		systemCanvasContext.lineJoin = "round";
		systemCanvasContext.lineWidth = this.line_width;
		systemCanvasContext.stroke();
	}

	switch(this.arrow_type){
		case 0:
			break;
		case 2:	
			this.drawArrow(this.end_pt_x, this.end_pt_y,this.start_pt_x,this.start_pt_y,this.line_color);
		case 1:
			this.drawArrow(this.start_pt_x,this.start_pt_y,this.end_pt_x, this.end_pt_y,this.line_color);
			break;
	}

	systemCanvasContext.restore();
	
	if(!this.is_selected)
		return;
	systemCanvasContext.save();
	systemCanvasContext.strokeStyle = "#64cb23";
	systemCanvasContext.strokeRect(this.rect_x, this.rect_y, this.rect_w, this.rect_h);
	systemCanvasContext.restore();
};

LineGraphic.prototype.arrowPoint = function(x1,y1,x2,y2){
	var multipleNum = 0;
	if(this.line_width == 3)
	{
		multipleNum = 5;
	}
	else if(this.line_width == 6)
	{
		multipleNum = 7.5;
	}
	else if(this.line_width == 9)
	{
		multipleNum = 10;
	}
	
	var width = Math.abs(x1-x2); 
    var height = Math.abs(y1-y2); 
    var length = Math.sqrt(width*width + height*height); 
    var degreeoffset = 30/180*Math.PI; 
    var degree = 0; 
    var xl = 0; // x left
    var yl = 0; // y left
    var xr = 0; 
    var yr = 0; 
    var arrowLength = this.line_width * 10 / 3; 
    var returnObj = {};
    
    if(x1-x2 <0 && y1-y2>=0) {
		degree = Math.asin(height/length);
		y2 = y2 - multipleNum*degree;
		x2 = x2 + multipleNum*Math.acos(height/length);
		xl = x2 - arrowLength * Math.cos(degree - degreeoffset); 
		yl = y2 + arrowLength * Math.sin(degree - degreeoffset); 
		xr = x2 - arrowLength * Math.sin(90/180 * Math.PI - degree - degreeoffset); 
		yr = y2 + arrowLength * Math.cos(90/180 * Math.PI - degree - degreeoffset); 

    } else if(x1-x2 >=0 && y1-y2<0){
		degree = Math.acos(height/length);
		y2 = y2 + multipleNum*Math.asin(height/length);
		x2 = x2 - multipleNum*degree; 
		xl = x2 + arrowLength * Math.sin(degree - degreeoffset); 
		yl = y2 - arrowLength * Math.cos(degree - degreeoffset); 
		xr = x2 + arrowLength * Math.cos(90/180 * Math.PI - degree - degreeoffset); 
		yr = y2 - arrowLength * Math.sin(90/180 * Math.PI - degree - degreeoffset); 
    } else if(x1-x2>=0 && y1-y2>=0) { 
	    degree = Math.asin(height/length);
	    y2 = y2 - multipleNum*degree;
		x2 = x2 - multipleNum*Math.acos(height/length);
		xl = x2 + arrowLength * Math.cos(degree - degreeoffset); 
		yl = y2 + arrowLength * Math.sin(degree - degreeoffset); 
		xr = x2 + arrowLength * Math.sin(90/180 * Math.PI - degree - degreeoffset); 
		yr = y2 + arrowLength *Math.cos(90/180 * Math.PI - degree - degreeoffset); 
	} else if(x1-x2<0 && y1-y2<0) { 
	    degree = Math.asin(height/length); 
	    y2 = y2 + multipleNum*degree;
		x2 = x2 + multipleNum*Math.acos(height/length);
		xl = x2 - arrowLength * Math.cos(degree - degreeoffset); 
		yl = y2 - arrowLength * Math.sin(degree - degreeoffset); 
		xr = x2 - arrowLength * Math.sin(90/180 * Math.PI - degree - degreeoffset); 
		yr = y2 - arrowLength * Math.cos(90/180 * Math.PI - degree - degreeoffset); 
    } 
	returnObj = {xl,yl,x2,y2,xr,yr};

    return returnObj;
}

LineGraphic.prototype.drawArrow = function(start_pt_x,start_pt_y,end_pt_x,end_pt_y,color){
	var arrow = this.arrowPoint(start_pt_x,start_pt_y,end_pt_x,end_pt_y);
	systemCanvasContext.moveTo(arrow.x2, arrow.y2);
	systemCanvasContext.lineTo(arrow.xl , arrow.yl);
	systemCanvasContext.lineTo(arrow.xr, arrow.yr);	
	systemCanvasContext.closePath();
	systemCanvasContext.fillStyle = color;
	systemCanvasContext.lineJoin = "round";
	systemCanvasContext.fill();
	//systemCanvasContext.restore();
}

LineGraphic.prototype.drawDashLine = function(x,y,x2,y2,dashObj)
{
	var dx = (x2 - x), dy = (y2 - y);
	var slope = dx ? dy / dx : 1e15;
	var draw_length = Math.sqrt(dx * dx + dy * dy);

	var startValue = dashObj;

	while(draw_length > 0){
		if(draw_length >= dashObj[0] && dashObj[0] > 0)
		{
			x = (dashObj[0] * x2 + (draw_length-dashObj[0]) * x)/draw_length;
			y = (dashObj[0] * y2 + (draw_length-dashObj[0]) * y)/draw_length;
			systemCanvasContext.lineTo(x,y);
			draw_length = draw_length - dashObj[0];
			dashObj[0] = 0 ;
		}	
		else if(draw_length < dashObj[0] && dashObj[0] > 0)
		{
			dashObj[0] = dashObj[0] - draw_length;
			systemCanvasContext.lineTo(x2, y2);
			draw_length = 0;
		}
		else if(draw_length >= dashObj[1] && dashObj[1] > 0)
		{		
			x = (dashObj[1] * x2 + (draw_length - dashObj[1]) * x)/draw_length;
			y = (dashObj[1] * y2 + (draw_length - dashObj[1]) * y)/draw_length;
			draw_length = draw_length - dashObj[1];
			systemCanvasContext.moveTo(x,y);
			dashObj[0] = this.line_width *5;
			dashObj[1] = this.line_width *3;
		}
		else if(draw_length < dashObj[1] && dashObj[1] > 0)
		{			
			dashObj[1] = dashObj[1] - draw_length;
			draw_length = 0;
		}
		systemCanvasContext.strokeStyle = this.line_color;
		systemCanvasContext.lineJoin = "round";
		systemCanvasContext.lineCap = "round";
		systemCanvasContext.lineWidth = this.line_width;
		systemCanvasContext.stroke();	
	}
}