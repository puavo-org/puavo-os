var canvasEditor;
var canvasView;
var systemCanvas;

function startCanvas(width, height)
{
	canvasView = new CanvasView(width, height);
    canvasEditor = new CanvasEditor("Canvas Editor");
	var canvasModel = new CanvasModel();
	canvasEditor.initialize();
	canvasEditor.setActiveCanvasModel(canvasModel);
};

function switchToFreehandTool()
{
	canvasEditor.switchToFreehandTool();	
};

function switchToLineTool()
{
	canvasEditor.switchToLineTool();	
};

function switchToSelectionTool()
{
	canvasEditor.switchToSelectionTool();	
};