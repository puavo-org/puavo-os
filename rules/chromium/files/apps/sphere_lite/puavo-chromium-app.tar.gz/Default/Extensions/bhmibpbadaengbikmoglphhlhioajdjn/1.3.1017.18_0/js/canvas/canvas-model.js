// cm for canvas model prefix

function CanvasModel(editor)
{
	this.all_graphics = new Array();
	this.name = "Canvas Model";
	this.undo_manager = new UndoManager();
	this.maxZorderIndex = -1;
	this.canvasEditor = editor;
};

CanvasModel.prototype.init = function()
{
	this.undo_manager.setCanvasModel(this);
};

CanvasModel.prototype.undo = function()
{
	this.undo_manager.undo();
	this.canvasEditor.askViewToRedraw();
};

CanvasModel.prototype.redo = function()
{
	this.undo_manager.redo();
	this.canvasEditor.askViewToRedraw();
};

CanvasModel.prototype.addToUndoStack = function(item)
{
	this.undo_manager.addToUndoStack(item);
};

CanvasModel.prototype.clearStack = function()
{
	this.undo_manager.clearStack();
};

CanvasModel.prototype.getName = function()
{
	return this.name;
};

CanvasModel.prototype.getAllGraphics = function()
{
	return this.all_graphics;
};

CanvasModel.prototype.addGraphic = function(graphic, add_to_undo_stack)
{
	this.all_graphics.push(graphic);
	graphic.setParentCanvasModel(this);
	
	if(add_to_undo_stack)
	{
		++this.maxZorderIndex;
		graphic.setZorderIndex(this.maxZorderIndex);
		var undoItem = new UndoItem();
		undoItem.setGraphicCanvas(this);
		undoItem.setType("ADD");
		undoItem.setGraphic(graphic);
		this.undo_manager.addToUndoStack(undoItem);
	}
	this.sortingCanvasObjects();
	
	//////////for debug////////
//	if(this.all_graphics.length > 2)
//		canvasEditor.switchToEraserTool();
};

CanvasModel.prototype.clearAll = function(add_to_undo_stack)
{
	if(add_to_undo_stack)
	{
		var undoItem = new UndoItem();
		undoItem.setGraphicCanvas(this);
		undoItem.setType("REMOVE");
		var index = 0;
		for(index; index < this.all_graphics.length; ++index)
		{
			undoItem.setGraphic(this.all_graphics[index]);
		};
		this.undo_manager.addToUndoStack(undoItem);
	}
	
	this.all_graphics.length = 0;
};

CanvasModel.prototype.removeGraphic = function(graphic, add_to_undo_stack)
{
	graphic.setParentCanvasModel(null);
	this.all_graphics.splice(this.all_graphics.indexOf(graphic), 1);
	
	if(add_to_undo_stack)
	{
		var undoItem = new UndoItem();
		undoItem.setGraphicCanvas(this);
		undoItem.setType("REMOVE");
		undoItem.setGraphic(graphic);
		this.undo_manager.addToUndoStack(undoItem);
	}
};

CanvasModel.prototype.sortingCanvasObjects = function()
{
	for(var i = this.all_graphics.length -1; i > 0; --i)
	{
		for(var j = 0; j < i; ++j)
		{
			if(this.all_graphics[j + 1].getZorderIndex() < this.all_graphics[j].getZorderIndex())
			{
				this.swap(j + 1, j);
			}
		}
	}
};

CanvasModel.prototype.swap = function(x, y)
{
	var tmp = this.all_graphics[x];
	this.all_graphics[x] = this.all_graphics[y];
	this.all_graphics[y] = tmp;
}

CanvasModel.prototype.render = function()
{
	var index = 0;
	for(index; index < this.all_graphics.length; ++index)
	{
		this.all_graphics[index].render();
	};
};