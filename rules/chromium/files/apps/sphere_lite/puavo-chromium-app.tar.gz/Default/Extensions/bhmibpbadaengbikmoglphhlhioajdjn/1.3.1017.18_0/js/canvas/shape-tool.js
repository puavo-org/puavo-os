

function ShapeTool(editor)
{
	this.debug_name = "Shape Tool";
	this.is_painting = false;
	this.new_shape;
	this.current_shape_type = "Triangle";
	this.line_width = 3;
	this.is_filled = true;
	this.line_color = "#FF0000";
	// this.line_color_r = 255;
	// this.line_color_g = 155;
	// this.line_color_b = 55;
	// this.line_color_a = 1;
	this.canvasEditor = editor;
};

ShapeTool.prototype.getName = function()
{
	return this.debug_name;
};

ShapeTool.prototype.setShapeType = function(shape_type)
{
	this.current_shape_type = shape_type;
};

ShapeTool.prototype.setLineWidth = function(width)
{
	this.line_width = width;
};

ShapeTool.prototype.setFilled = function(filled)
{
	this.is_filled = filled;
};

ShapeTool.prototype.setLineColor = function(color)
{
	this.line_color = color;
	// this.line_color_r = r;
	// this.line_color_g = g;
	// this.line_color_b = b;
	// this.line_color_a = a;
};

ShapeTool.prototype.getLineColor = function()
{
	return this.line_color;
}

ShapeTool.prototype.annoToolAnnotationStart = function(x, y)
{
	this.is_painting = true;
	if(this.current_shape_type == "Circle")
		this.new_shape = new CircleGraphic();
	else if(this.current_shape_type == "Ellipse")
		this.new_shape = new EllipseGraphic();
	else if(this.current_shape_type == "Rectangle")
		this.new_shape = new RectangleGraphic();
	else if(this.current_shape_type == "Triangle")
		this.new_shape = new TriangleGraphic();
	else
		return;
	this.new_shape.setLineWidth(this.line_width);
	this.new_shape.setFilled(this.is_filled);
	this.new_shape.setLineColor(this.line_color);
	this.new_shape.setStartPoint(x, y);
};

ShapeTool.prototype.annoToolAnnotationMove = function(x, y)
{
	if(this.is_painting == false)
		return;
	this.new_shape.setEndPoint(x, y);
	this.canvasEditor.askViewToRedraw();
};

ShapeTool.prototype.annoToolAnnotationStop = function(x, y)
{
	if(this.is_painting == false)
		return;
	this.new_shape.setEndPoint(x, y);
	this.canvasEditor.askViewToRedraw();
	this.is_painting = false;
	this.canvasEditor.addGraphicToActiveCanvas(this.new_shape);
	this.new_shape = null;
	this.canvasEditor.askViewToRedraw();
};

ShapeTool.prototype.render = function()
{
	if(!this.is_painting)
	{
		return;
	}
	this.new_shape.render();
};
