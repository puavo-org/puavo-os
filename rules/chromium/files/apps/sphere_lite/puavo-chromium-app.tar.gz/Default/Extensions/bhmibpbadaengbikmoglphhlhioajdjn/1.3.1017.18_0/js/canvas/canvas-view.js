/**
 *
 */

// CV for parameter prefix

var systemCanvasContext;
var canvas_view_width;
var canvas_view_height;
///////////////////////////////////////////////////////
var colorPurple = "#cb3594";

var bg_image;
var cv_m_mouse_down = false;
var corner_mouse_down = false;
var cv_m_touch_down = false;
var corner_touch_down = false;

///////////////////////////////////////////////////////
function CanvasView(width, height)
{
	canvas_view_width = width;
	canvas_view_height = height;
	// Create the canvas (Neccessary for IE because it doesn't know what a canvas element is)
	var canvasDiv = document.getElementById('canvasDiv');
	systemCanvas = document.createElement('canvas');
	systemCanvas.setAttribute('width', canvas_view_width);
	systemCanvas.setAttribute('height', canvas_view_height);
	systemCanvas.setAttribute('id', 'canvas');

	systemCanvas.style.position = "absolute";
	systemCanvas.style.top = "0px";
	systemCanvas.style.left = "0px";

	this.left = 0;
	this.top = 0;

	canvasDiv.appendChild(systemCanvas);
	if(typeof G_vmlCanvasManager != 'undefined')
	{
		systemCanvas = G_vmlCanvasManager.initElement(canvas);
	}
	systemCanvasContext = systemCanvas.getContext("2d"); // Grab the 2d canvas context

	if(parent.bgImage == null)
	{
	    bg_image = new Image();
      bg_image.src = "../img/transparent.png";
		  parent.bgFlag = 0;
	}
	else
	{
	    bg_image = parent.bgImage;
      if(bg_image.src.match('transparent'))
      {
          parent.bgFlag = 0;
      }
      else
      {
          parent.bgFlag = 1;
      }
	}
	bg_image.onload = function()
	{
		systemCanvasContext.drawImage(bg_image, 0, 0, canvas_view_width, canvas_view_height);
	};
	//bg_image.src = "transparent.png";
	// use parent member to record background image
	parent.bgImage = bg_image;
	// Note: The above code is a workaround for IE 8 and lower. Otherwise we could have used:
	//     context = document.getElementById('canvas').getContext("2d");
	// Add mouse events
	// ----------------
	$('#canvas').on({
		'mousedown': function(e){
			if(e.which != 1)
			{
				return;
			}
			var mouseX = e.offsetX ;
			var mouseY = e.offsetY ;

			mouseX *= systemCanvas.width/$('#canvas').width();
			mouseY *= systemCanvas.height/$('#canvas').height();

			if(canvasEditor.cornerTest(mouseX, mouseY) == "nw-resize")
			{
				document.getElementById("canvasDiv").style.cursor = "nw-resize";
				corner_mouse_down = true;
			}
			else if(canvasEditor.cornerTest(mouseX, mouseY) == "ne-resize")
			{
				document.getElementById("canvasDiv").style.cursor = "ne-resize";
				corner_mouse_down = true;
			}
			else
			{
				document.getElementById("canvasDiv").style.cursor = "auto";
			}

			if(canvasEditor != null)
				canvasEditor.annotationStart(mouseX, mouseY);
			cv_m_mouse_down = true;
		},
		'mousemove': function(e){
			var mouseX = e.offsetX ;
			var mouseY = e.offsetY ;

			mouseX *= systemCanvas.width/$('#canvas').width();
			mouseY *= systemCanvas.height/$('#canvas').height();

			if(canvasEditor.cornerTest(mouseX, mouseY) == "nw-resize")
			{
				document.getElementById("canvasDiv").style.cursor = "nw-resize";
			}
			else if(canvasEditor.cornerTest(mouseX, mouseY) == "ne-resize")
			{
				document.getElementById("canvasDiv").style.cursor = "ne-resize";
			}
			else
			{
				if(!corner_mouse_down)
				{
					document.getElementById("canvasDiv").style.cursor = "auto";
				}
			}

			if(cv_m_mouse_down == false)
				return;
			if(canvasEditor != null)
				canvasEditor.annotationMove(mouseX, mouseY);
		},
		'mouseup': function(e){
			if(e.which != 1)
			{
				return;
			}
			var mouseX = e.offsetX ;
			var mouseY = e.offsetY ;

			mouseX *= systemCanvas.width/$('#canvas').width();
			mouseY *= systemCanvas.height/$('#canvas').height();

			corner_mouse_down = false;
			document.getElementById("canvasDiv").style.cursor = "auto";
			cv_m_mouse_down = false;
			if(canvasEditor != null)
				canvasEditor.annotationStop(mouseX, mouseY);
				if(typeof(canvasEditor.getLastItemType()) !== 'undefined')
				{
					parent.mainContent.contentWindow.setUndoRedoUI();
				}
		},
		'mouseleave': function(e){
			if(cv_m_mouse_down)
			{
				var mouseX = e.offsetX;
				var mouseY = e.offsetY;

				mouseX *= systemCanvas.width/$('#canvas').width();
				mouseY *= systemCanvas.height/$('#canvas').height();

				if(canvasEditor != null)
					canvasEditor.annotationStop(mouseX, mouseY);
					if(typeof(canvasEditor.getLastItemType()) !== 'undefined')
					{
						parent.mainContent.contentWindow.setUndoRedoUI();
					}
			}
			cv_m_mouse_down = false;
		},
		'touchstart': function(e){
			var element = document.getElementById('canvas');
			var rect = element.getBoundingClientRect();
			var mouseX = 0;
			var mouseY = 0;

			if (rotate == 90 || rotate == -270) {
				if (ceil == -1) {
					if (mirror == -1) {
						var mouseXtmp = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseX = Math.round(rect.height / scale) - mouseXtmp;
						mouseY = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
					} else {
						mouseX = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseY = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
					}
				} else {
					if (mirror == -1) {
						var mouseXtmp = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseX = Math.round(rect.height / scale) - mouseXtmp;
						var mouseYtmp = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseY = Math.round(rect.width / scale) - mouseYtmp;
					} else {
						mouseX = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						var mouseYtmp = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseY = Math.round(rect.width / scale) - mouseYtmp;
					}
				}
			} else if (rotate == 180 || rotate == -180) {
				if (ceil == -1) {
					if (mirror == -1) {
						mouseX = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseY = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
					} else {
						var mouseXtmp = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseX = Math.round(rect.width / scale) - mouseXtmp;
						mouseY = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
					}
				} else {
					if (mirror == -1) {
						mouseX = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						var mouseYtmp = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseY = Math.round(rect.height / scale) - mouseYtmp;
					} else {
						var mouseXtmp = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseX = Math.round(rect.width / scale) - mouseXtmp;
						var mouseYtmp = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseY = Math.round(rect.height / scale) - mouseYtmp;
					}
				}
			} else if (rotate == -90 || rotate == 270) {
				if (ceil == -1) {
					if (mirror == -1) {
						mouseX = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						var mouseYtmp = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseY = Math.round(rect.width / scale) - mouseYtmp;
					} else {
						var mouseXtmp = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseX = Math.round(rect.height / scale) - mouseXtmp;
						var mouseYtmp = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseY = Math.round(rect.width / scale) - mouseYtmp;
					}
				} else {
					if (mirror == -1) {
						mouseX = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseY = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
					} else {
						var mouseXtmp = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseX = Math.round(rect.height / scale) - mouseXtmp;
						mouseY = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
					}
				}
			} else {
				if (ceil == -1) {
					if (mirror == -1) {
						var mouseXtmp = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseX = Math.round(rect.width / scale) - mouseXtmp;
						var mouseYtmp = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseY = Math.round(rect.height / scale) - mouseYtmp;
					} else {
						mouseX = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						var mouseYtmp = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseY = Math.round(rect.height / scale) - mouseYtmp;
					}
				} else {
					if (mirror == -1) {
						var mouseXtmp = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseX = Math.round(rect.width / scale) - mouseXtmp;
						mouseY = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
					} else {
						mouseX = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseY = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
					}
				}
			}

			mouseX *= systemCanvas.width/$('#canvas').width();
			mouseY *= systemCanvas.height/$('#canvas').height();

			if(canvasEditor.cornerTest(mouseX, mouseY) == "nw-resize")
			{
				document.getElementById("canvasDiv").style.cursor = "nw-resize";
				corner_touch_down = true;
			}
			else if(canvasEditor.cornerTest(mouseX, mouseY) == "ne-resize")
			{
				document.getElementById("canvasDiv").style.cursor = "ne-resize";
				corner_touch_down = true;
			}
			else
			{
				document.getElementById("canvasDiv").style.cursor = "auto";
			}

			if(canvasEditor != null)
				canvasEditor.annotationStart(mouseX, mouseY);
			cv_m_touch_down = true;
		},
		'touchmove': function(e){
			var element = document.getElementById('canvas');
			var rect = element.getBoundingClientRect();
			var mouseX = 0;
			var mouseY = 0;

			if (rotate == 90 || rotate == -270) {
				if (ceil == -1) {
					if (mirror == -1) {
						var mouseXtmp = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseX = Math.round(rect.height / scale) - mouseXtmp;
						mouseY = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
					} else {
						mouseX = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseY = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
					}
				} else {
					if (mirror == -1) {
						var mouseXtmp = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseX = Math.round(rect.height / scale) - mouseXtmp;
						var mouseYtmp = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseY = Math.round(rect.width / scale) - mouseYtmp;
					} else {
						mouseX = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						var mouseYtmp = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseY = Math.round(rect.width / scale) - mouseYtmp;
					}
				}
			} else if (rotate == 180 || rotate == -180) {
				if (ceil == -1) {
					if (mirror == -1) {
						mouseX = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseY = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
					} else {
						var mouseXtmp = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseX = Math.round(rect.width / scale) - mouseXtmp;
						mouseY = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
					}
				} else {
					if (mirror == -1) {
						mouseX = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						var mouseYtmp = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseY = Math.round(rect.height / scale) - mouseYtmp;
					} else {
						var mouseXtmp = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseX = Math.round(rect.width / scale) - mouseXtmp;
						var mouseYtmp = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseY = Math.round(rect.height / scale) - mouseYtmp;
					}
				}
			} else if (rotate == -90 || rotate == 270) {
				if (ceil == -1) {
					if (mirror == -1) {
						mouseX = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						var mouseYtmp = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseY = Math.round(rect.width / scale) - mouseYtmp;
					} else {
						var mouseXtmp = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseX = Math.round(rect.height / scale) - mouseXtmp;
						var mouseYtmp = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseY = Math.round(rect.width / scale) - mouseYtmp;
					}
				} else {
					if (mirror == -1) {
						mouseX = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseY = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
					} else {
						var mouseXtmp = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseX = Math.round(rect.height / scale) - mouseXtmp;
						mouseY = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
					}
				}
			} else {
				if (ceil == -1) {
					if (mirror == -1) {
						var mouseXtmp = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseX = Math.round(rect.width / scale) - mouseXtmp;
						var mouseYtmp = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseY = Math.round(rect.height / scale) - mouseYtmp;
					} else {
						mouseX = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						var mouseYtmp = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseY = Math.round(rect.height / scale) - mouseYtmp;
					}
				} else {
					if (mirror == -1) {
						var mouseXtmp = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseX = Math.round(rect.width / scale) - mouseXtmp;
						mouseY = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
					} else {
						mouseX = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseY = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
					}
				}
			}

			mouseX *= systemCanvas.width/$('#canvas').width();
			mouseY *= systemCanvas.height/$('#canvas').height();

			if(canvasEditor.cornerTest(mouseX, mouseY) == "nw-resize")
			{
				document.getElementById("canvasDiv").style.cursor = "nw-resize";
			}
			else if(canvasEditor.cornerTest(mouseX, mouseY) == "ne-resize")
			{
				document.getElementById("canvasDiv").style.cursor = "ne-resize";
			}
			else
			{
				if(!corner_touch_down)
				{
					document.getElementById("canvasDiv").style.cursor = "auto";
				}
			}

			if(cv_m_touch_down == false)
				return;
			if(canvasEditor != null)
				canvasEditor.annotationMove(mouseX, mouseY);
		},
		'touchend': function(e){
			var element = document.getElementById('canvas');
			var rect = element.getBoundingClientRect();
			var mouseX = 0;
			var mouseY = 0;

			if (rotate == 90 || rotate == -270) {
				if (ceil == -1) {
					if (mirror == -1) {
						var mouseXtmp = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseX = Math.round(rect.height / scale) - mouseXtmp;
						mouseY = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
					} else {
						mouseX = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseY = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
					}
				} else {
					if (mirror == -1) {
						var mouseXtmp = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseX = Math.round(rect.height / scale) - mouseXtmp;
						var mouseYtmp = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseY = Math.round(rect.width / scale) - mouseYtmp;
					} else {
						mouseX = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						var mouseYtmp = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseY = Math.round(rect.width / scale) - mouseYtmp;
					}
				}
			} else if (rotate == 180 || rotate == -180) {
				if (ceil == -1) {
					if (mirror == -1) {
						mouseX = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseY = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
					} else {
						var mouseXtmp = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseX = Math.round(rect.width / scale) - mouseXtmp;
						mouseY = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
					}
				} else {
					if (mirror == -1) {
						mouseX = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						var mouseYtmp = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseY = Math.round(rect.height / scale) - mouseYtmp;
					} else {
						var mouseXtmp = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseX = Math.round(rect.width / scale) - mouseXtmp;
						var mouseYtmp = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseY = Math.round(rect.height / scale) - mouseYtmp;
					}
				}
			} else if (rotate == -90 || rotate == 270) {
				if (ceil == -1) {
					if (mirror == -1) {
						mouseX = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						var mouseYtmp = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseY = Math.round(rect.width / scale) - mouseYtmp;
					} else {
						var mouseXtmp = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseX = Math.round(rect.height / scale) - mouseXtmp;
						var mouseYtmp = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseY = Math.round(rect.width / scale) - mouseYtmp;
					}
				} else {
					if (mirror == -1) {
						mouseX = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseY = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
					} else {
						var mouseXtmp = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseX = Math.round(rect.height / scale) - mouseXtmp;
						mouseY = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
					}
				}
			} else {
				if (ceil == -1) {
					if (mirror == -1) {
						var mouseXtmp = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseX = Math.round(rect.width / scale) - mouseXtmp;
						var mouseYtmp = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseY = Math.round(rect.height / scale) - mouseYtmp;
					} else {
						mouseX = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						var mouseYtmp = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
						mouseY = Math.round(rect.height / scale) - mouseYtmp;
					}
				} else {
					if (mirror == -1) {
						var mouseXtmp = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseX = Math.round(rect.width / scale) - mouseXtmp;
						mouseY = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
					} else {
						mouseX = Math.round((e.originalEvent.changedTouches[0].pageX - rect.left) / scale);
						mouseY = Math.round((e.originalEvent.changedTouches[0].pageY - rect.top) / scale);
					}
				}
			}
			
			mouseX *= systemCanvas.width/$('#canvas').width();
			mouseY *= systemCanvas.height/$('#canvas').height();

			corner_touch_down = false;
			document.getElementById("canvasDiv").style.cursor = "auto";
			cv_m_touch_down = false;
			if(canvasEditor != null)
				canvasEditor.annotationStop(mouseX, mouseY);
				if(typeof(canvasEditor.getLastItemType()) !== 'undefined')
				{
					parent.mainContent.contentWindow.setUndoRedoUI();
				}
		}
	});

	this.systemCanvasContext = systemCanvasContext;
	this.systemCanvas = systemCanvas;
};

var canvasEditor;

CanvasView.prototype.setEditor = function(editor)
{
    canvasEditor = editor
}

CanvasView.prototype.hasCustomBackground = function()
{
    if(parent.bgFlag == 0)
	{
	    return false;
	}
	else
	{
	    return true;
	}
}

CanvasView.prototype.reset = function()
{
    parent.bgFlag = 0;
    parent.bgImage = null;
};

CanvasView.prototype.setBackground = function(url)
{
    parent.bgFlag = 1;
	bg_image = new Image();
	bg_image.onload = function ()
	{
		systemCanvas.width = systemCanvas.width;
    systemCanvasContext.fillStyle = "#000000";
    systemCanvasContext.fillRect(0, 0, canvas_view_width, canvas_view_height);
    if(canvas_view_width > bg_image.width && canvas_view_height > bg_image.height)
    {
        if((bg_image.width / bg_image.height) > (canvas_view_width / canvas_view_height))
        {
            if(bg_image.width > bg_image.height)
            {
                var scale = canvas_view_width / bg_image.width;
                bg_image.width = canvas_view_width;
                bg_image.height = bg_image.height * scale;
                var imageX = (canvas_view_width - bg_image.width) / 2;
                var imageY = (canvas_view_height - bg_image.height) / 2;
                systemCanvasContext.drawImage(bg_image, imageX, imageY, bg_image.width, bg_image.height);
            }
            else
            {
                var scale = canvas_view_height / bg_image.height;
                bg_image.width = bg_image.width * scale;
                bg_image.height = canvas_view_height;
                var imageX = (canvas_view_width - bg_image.width) / 2;
                var imageY = (canvas_view_height - bg_image.height) / 2;
                systemCanvasContext.drawImage(bg_image, imageX, imageY, bg_image.width, bg_image.height);
            }
        }
        else
        {
            var scale = bg_image.width / bg_image.height;
            bg_image.width = canvas_view_height * scale;
            bg_image.height = canvas_view_height;
            var imageX = (canvas_view_width - bg_image.width) / 2;
            var imageY = (canvas_view_height - bg_image.height) / 2;
            systemCanvasContext.drawImage(bg_image, imageX, imageY, bg_image.width, bg_image.height);
        }
		}
    else if(canvas_view_width > bg_image.width && canvas_view_height < bg_image.height)
    {
        var scale = 1 / (bg_image.height / canvas_view_height);
        bg_image.height = canvas_view_height;
        bg_image.width = bg_image.width * scale;
        var imageX = (canvas_view_width - bg_image.width) / 2;
        var imageY = (canvas_view_height - bg_image.height) / 2;
        systemCanvasContext.drawImage(bg_image, imageX, imageY, bg_image.width, bg_image.height);
    }
    else if(canvas_view_width < bg_image.width && canvas_view_height > bg_image.height)
    {
        var scale = 1 / (bg_image.width / canvas_view_width);
        bg_image.height = canvas_view_height * scale;
        bg_image.width = canvas_view_width;
        var imageX = (canvas_view_width - bg_image.width) / 2;
        var imageY = (canvas_view_height - bg_image.height) / 2;
        systemCanvasContext.drawImage(bg_image, imageX, imageY, bg_image.width, bg_image.height);
    }
    else
    {
        var scale = 1 / (bg_image.height / canvas_view_height);
        bg_image.height = canvas_view_height;
        bg_image.width = bg_image.width * scale;
        var imageX = (canvas_view_width - bg_image.width) / 2;
        var imageY = (canvas_view_height - bg_image.height) / 2;
        systemCanvasContext.drawImage(bg_image, imageX, imageY, bg_image.width, bg_image.height);
    }
    canvasEditor.render();
	};
	bg_image.src = url;
	parent.bgImage = bg_image;
};

CanvasView.prototype.moveTo = function(x, y)
{
	systemCanvas.style.position = "absolute";
	systemCanvas.style.top = y + "px";
	systemCanvas.style.left = x + "px";
	this.left = x;
	this.top = y;
};

CanvasView.prototype.getTop = function()
{
	return this.top;
};

CanvasView.prototype.getLeft = function()
{
	return this.left;
};

CanvasView.prototype.redraw = function()
{
	systemCanvas.width = systemCanvas.width;
  var srcStr = bg_image.src;
  var curBgFlag = 0;
  //if(srcStr.match('bg_whiteboard_green') != null || srcStr.match('bg_whiteboard_white') != null)
	if(srcStr.match('transparent') != null)
  {
      curBgFlag = 0;
  }
  else
  {
      curBgFlag = 1;
  }
  if(parent.bgFlag || curBgFlag)
  {
      systemCanvasContext.fillStyle = "#000000";
      systemCanvasContext.fillRect(0, 0, canvas_view_width, canvas_view_height);
      if(canvas_view_width > bg_image.width && canvas_view_height > bg_image.height)
      {
          var scale = bg_image.width / bg_image.height;
          bg_image.width = canvas_view_height * scale;
          bg_image.height = canvas_view_height;
          var imageX = (canvas_view_width - bg_image.width) / 2;
          var imageY = (canvas_view_height - bg_image.height) / 2;
          systemCanvasContext.drawImage(bg_image, imageX, imageY, bg_image.width, bg_image.height);
  		}
      else
      {
          var imageX = (canvas_view_width - bg_image.width) / 2;
          var imageY = (canvas_view_height - bg_image.height) / 2;
          systemCanvasContext.drawImage(bg_image, imageX, imageY, bg_image.width, bg_image.height);
      }
	}
  else
  {
      systemCanvasContext.drawImage(bg_image, 0, 0, canvas_view_width, canvas_view_height);
  }
  if(canvasEditor)
  canvasEditor.render();
};

CanvasView.prototype.removeBackground = function()
{
    parent.bgFlag = 0;
    bg_image = new Image();
	bg_image.onload = function()
	{
	    systemCanvas.width = systemCanvas.width;
		systemCanvasContext.drawImage(bg_image, 0, 0, canvas_view_width, canvas_view_height);
		if(canvasEditor)
		canvasEditor.render();
	};
	bg_image.src = "transparent.png";
	// use parent member to record background image
	parent.bgImage = bg_image;
}

CanvasView.prototype.setWhiteboardBackground = function()
{
    parent.bgFlag = 0;
    bg_image = new Image();
	bg_image.onload = function()
	{
	    systemCanvas.width = systemCanvas.width;
		systemCanvasContext.drawImage(bg_image, 0, 0, canvas_view_width, canvas_view_height);
		if(canvasEditor)
		canvasEditor.render();
	};
	bg_image.src = "transparent.png";
	// use parent member to record background image
	parent.bgImage = bg_image;
}
/*
function rotatePosition(mx,my){
	switch(rotate){
		case 0:
			x = mx;
			y = my;
			break;
		case -270: case 90 :
			x = my + ($('#canvas').width() - $('#canvas').height())/2 ;
			y = -mx + $('#canvas').width() - ($('#canvas').width() - $('#canvas').height())/2 ;
			break;
		case 180:
			x = -mx;
			y = -my;
			x += $('#canvas').width();
			y += $('#canvas').height();
			break;
		case 270:case -90: 
			x = -my + $('#canvas').width() - ($('#canvas').width() - $('#canvas').height())/2 ;
			y = mx - ($('#canvas').width() - $('#canvas').height()) / 2;
			break;	
	}
	var result = {x,y};

	return result;
}
*/
