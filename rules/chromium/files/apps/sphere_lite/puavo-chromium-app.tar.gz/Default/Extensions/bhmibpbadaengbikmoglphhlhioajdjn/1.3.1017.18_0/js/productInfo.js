// JavaScript Document
var originalHeight = 0;

function onResize()
{
	var userAgent = navigator.userAgent;
	var _clientWidth = 0;
	var _clientHeight = 0;
	if(userAgent.indexOf("CrOS") != -1)
	{
		_clientWidth = parent.document.body.clientWidth;
		_clientHeight = parent.document.body.clientHeight;
	}
	else
	{
		_clientWidth = window.outerWidth;
		_clientHeight = window.outerHeight;
	}
	
	if(_clientWidth == screen.availWidth && _clientHeight == screen.availHeight)
	{
		parent.isMaximum = true;
	}
	else
	{
		parent.isMaximum = false;
	}
	var height = originalHeight + (_clientHeight - originalHeight - 34);
	$("#productDiv").height(height);
	if(parent.isMaximum)
	{
		parent.document.getElementById("scaleWindowBtn").title = "Minimize";
		parent.mainIframe.style.left = "0px";
		parent.mainIframe.style.width = "100%";
		parent.mainIframeTmp.style.left = "0px";
		parent.mainIframeTmp.style.width = "100%";
	}
	else
	{
		parent.document.getElementById("scaleWindowBtn").title = "Fullscreen";
		parent.mainIframe.style.left = "100px";
		parent.mainIframe.style.width = "calc(100% - 100px)";
		parent.mainIframeTmp.style.left = "100px";
		parent.mainIframeTmp.style.width = "calc(100% - 100px)";
	}
}

function startInit()
{
	var manifest = chrome.runtime.getManifest();
    var productVersion = $("#productVersion");
    productVersion.html("Version " + manifest.version);
	
	originalHeight = $("#productDiv").height();
	
	$('#webSite a').css('color', '#FF8200');
	$('#webSite a').click(function(){
		window.open("http://www.aver.com");
	});
	
	onResize();
	$(window).resize(onResize);
}

window.onload = startInit;