// JavaScript Document
var myNoteImpl = myNoteImpl;
var isMaximum = false;
var closeBtn = document.getElementById("closeBtn");
var changeMediaLibraryBtn = document.getElementById("changeMediaLibraryBtn");
var scaleWindowBtn = document.getElementById("scaleWindowBtn");

var cameraPreviewBtn = document.getElementById("cameraPreviewBtn");
var mediaLibraryBtn = document.getElementById("mediaLibraryBtn");
var infoBtn = document.getElementById("infoBtn");

var mainIframe = document.getElementById("mainIframe");
var mainIframeTmp = document.getElementById("mainIframeTmp");
var mainContent = document.getElementById("mainContent");
var mainContentTmp = document.getElementById("mainContentTmp");
var mergeIframe = document.getElementById("mergeIframe");
var mergeContent = document.getElementById("mergeContent");
var concatIframe = document.getElementById("concatIframe");
var concatContent = document.getElementById("concatContent");

var closeYesText = document.getElementById("closeYesText");
var closeNoText = document.getElementById("closeNoText");

var originalWidth = 0;
var originalHeigth = 0;
var imgSrc = document.getElementById("imgSrc");
var videoSrc = document.getElementById("videoSrc");

var curIndex = 0;
var now = Date.now;
var time;
var convertTime;
var isMerging = false;
var arrLength = 0;
var convertVal = 0;
var _convertVal = 0;
var totalTime = 0;

var fileName = "";

var micVolume = 100;

var vBlobsArr = "";
var aBlobsArr = "";
var allBlobs = [];

var progress = 0;
var progressTimer = "";

var convertTimer = "";
var concatTimer = "";
var script = null;
var pnacl = null;

function fileNameCache(_fileName)
{
	fileName = _fileName;
}

function prepareConvert()
{
	arrLength = vBlobsArr.length;
	allBlobs = [];
	if(arrLength == 1)
	{
		progress = 1;
	}
	else
	{
		progress = (totalTime / 20) + 1;
	}
	curIndex = 0;
	convertTime = now();
	convertStreams(vBlobsArr[0], aBlobsArr[0]);
}

function sendRecordTime(_minCount, _secCount)
{
	totalTime = _minCount * 60 + _secCount;
}

function addZero(value)
{
	if(value < 10)
	{
		value = "0" + value;
	}
	return value;
}

function getVideoFileName()
{
	var date = new Date();
	var fileName = addZero(date.getFullYear()) + '-' + addZero(date.getMonth() + 1) + '-' + addZero(date.getDate()) + '-' + addZero(date.getHours()) + '-' + addZero(date.getMinutes()) + '-' + addZero(date.getSeconds()) + '.mkv';
	return fileName;
}

function PostBlob(blob)
{
	var content=new Blob([blob], {type: 'video/mp4'});
	var date = new Date();
	var fileName = addZero(date.getFullYear()) + '-' + addZero(date.getMonth() + 1) + '-' + addZero(date.getDate()) + '-' + addZero(date.getHours()) + '-' + addZero(date.getMinutes()) + '-' + addZero(date.getSeconds()) + '.mkv';
	var accepts = [{extensions: ['mp4']}];
	chrome.fileSystem.chooseEntry({type: 'saveFile', accepts: accepts, suggestedName: fileName}, function(writableFileEntry) {
		writableFileEntry.createWriter(function(writer) {
			writer.onerror = function(e) {
				console.log('write error');
			};
			writer.onwriteend = function(e) {
				console.log('write complete');
			};
			writer.write(content);
			}, function(e) {
				console.log('write error');
			});
	});
	vBlobsArr = "";
	aBlobsArr = "";
	allBlobs = [];
}

function clearPNaCl()
{
	if(script != null)
	{
		script.src = "";
		script.remove();
		pnacl = null;
		delete script;
		script = null;
	}
	if(convertTimer)
	{
		clearTimeout(convertTimer);
	}
	if(concatTimer)
	{
		clearTimeout(concatTimer);
	}
}

function convertStreams(vBlob, aBlob)
{
	if(vBlobsArr.length != 0 && aBlobsArr.length != 0)
	{
		vBlobsArr.shift();
		aBlobsArr.shift();
	}
	
	myNoteImpl.addVideo("/tmp", "vBlob.webm", vBlob, function() {
		delete vBlob;
		vBlob = null;
		
		myNoteImpl.addVideo("/tmp", "aBlob.wav", aBlob, function() {
			delete aBlob;
			aBlob = null;
	
			script = document.createElement('embed');
			script.id = 'pnacl';
			script.width = 0;
			script.height = 0;
			script.src = 'ffmpeg.nmf';
			script.type = 'application/x-pnacl';
			script.setAttribute('ps_stdout', 'dev/tty');
			script.setAttribute('ps_stderr', 'dev/tty');
			script.setAttribute('ps_tty_prefix', '');
			script.setAttribute('arg0', 'ffmpeg');
			script.setAttribute('arg1', '-y');
			/*document.write("<embed id='pnacl' width='0' height='0'");
			document.write("ps_stdout='dev/tty'");
			document.write("ps_stderr='dev/tty'");
			document.write("ps_tty_prefix= ''");
			document.write("arg0='ffmpeg'");
			document.write("arg1='-y'");*/
			
			var n = 2;
			var out_file = 'a.out';
			
			var args = '-i vBlob.webm -i aBlob.wav -vcodec copy -acodec copy -ac 1 output'+curIndex+'.mkv'; //sphereLiteUser
			console.log((new Date ()).toLocaleTimeString() + ' ' + args);
			curIndex++;
			//var args = window.location.search.substr(1);
			//args = decodeURIComponent(args);
			args.split('"').forEach(function(t, i) {
				t = t.trim();
				if ((i % 2) === 1) {
				script.setAttribute("arg"+n, t);
				//document.write("arg"+n+"='"+t+"'");
				out_file = t;
				n++;
				} else {
					t = t.replace(/\s+/g, ' ');
				t.split(" ").forEach(function(x,j,ao) {
					x = x.trim();
					if(j==(ao.length-1)) {
					if(x=='/dev/null') x = 'dev_null';
					}
					script.setAttribute("arg"+n, x);
					//document.write("arg"+n+"='"+x+"'");
					out_file = x;
					n++;
				});
				}
			});
			//document.write("></embed>");
			
			//var pnacl = document.getElementById("pnacl");
			pnacl = script;
			
			function updateStatus(msg) {
				console.log((new Date ()).toLocaleTimeString() + ' ' + msg);
				if(msg == 'Success!')
				{
					convertVal = _convertVal + (100 / progress);
					if(convertVal >= 100)
					{
						convertVal = 100;
					}
					mainContent.contentWindow.setProgressValue(convertVal);
					_convertVal = convertVal;
				}
			}

			function eventStatus(status) {
				return function () {
				updateStatus(status);
				}
			}

			function eventProgress(event) {
				var loadPercent = 0.0;
				var loadPercentString;
				if (event.lengthComputable && event.total > 0) {
				loadPercent = event.loaded / event.total * 100.0;
				loadPercentString = Math.round(loadPercent) + '%';
				updateStatus('Loading...' + loadPercentString);
				} else {
				updateStatus('Loading...');
				}
			}	

			function eventRunning() {
				updateStatus("Running");
				time = now();
			}
			pnacl.addEventListener('loadstart', eventStatus("Load Start"));
			pnacl.addEventListener('progress', eventProgress);
			pnacl.addEventListener('load', eventStatus("load"));
			pnacl.addEventListener('error', eventStatus("error"+pnacl.lastError));
			pnacl.addEventListener('abort', eventStatus("abort"+pnacl.lastError));
			pnacl.addEventListener('loadend', eventRunning);
			pnacl.addEventListener('message', function (ev) {
				if(ev.data.match(/^Libavutil has been linked to a broken llrint/)) return;
				if(ev.data.match(/^frame=/) || ev.data.match(/^size=/)) {
				var ti = ev.data.match(/time=..:..:../);
				//if(document.cform.ctext.value != ti) document.cform.ctext.value = ti;
				//console.log((new Date ()).toLocaleTimeString() + ' ' + ti);
				}
				//if((ev.data.match(/^frame=/) || ev.data.match(/^size=/))&& disable_stats) return;
				//if(ev.data.match(/^[ ,\n,\r]*$/)  && disable_stats) return;
				//var output = document.getElementById("output");
				//output.textContent += ev.data;
				console.log((new Date ()).toLocaleTimeString() + ' ' + ev.data);
			});

			pnacl.addEventListener('crash', function () {
				myNoteImpl.deleteVideo("/tmp", "vBlob.webm");
				myNoteImpl.deleteVideo("/tmp", "aBlob.wav");
				
				var totalTime = now() - time - 1000;
				if(totalTime<0) totalTime += 1000;
				totalTime = Math.round(totalTime/1000);
				if(pnacl.exitStatus == 0) {
				//var output = document.getElementById("output");
				//output.textContent += 'Finished processing (took ' + totalTime + 's)'
				updateStatus('Finished processing (took ' + totalTime + 's)');		
				updateStatus('Success!');
						//var downlink = document.createElement('a');
					//downlink.href = "filesystem:http://"+location.host+"/persistent/sphereLiteUser/"+out_file;
						//downlink.download = out_file;
						//downlink.innerHTML = "<button>Download</button>";
					//objDownload.appendChild(downlink);
					//var objDownload = document.getElementById('download');
					
					if(vBlobsArr.length != 0 && aBlobsArr.length != 0)
					{
						script.src = "";
						script.remove();
						pnacl = null;
						delete script;
						script = null;
						
						console.log((new Date ()).toLocaleTimeString() + ' ' + curIndex + '/' + vBlobsArr.length);
						if(curIndex % 8 != 0)
						{
							convertTimer = setTimeout(function(){
								convertStreams(vBlobsArr[0], aBlobsArr[0]);
								if(convertTimer)
								{
									clearTimeout(convertTimer);
								}
							}, 10);
						}
						else
						{
							convertTimer = setTimeout(function(){
								convertStreams(vBlobsArr[0], aBlobsArr[0]);
								if(convertTimer)
								{
									clearTimeout(convertTimer);
								}
							}, 9000);
						}
					}
					else
					{
						script.src = "";
						script.remove();
						pnacl = null;
						delete script;
						script = null;
						
						//mainContent.contentWindow.clearProgressValue();
						//mainContent.contentWindow.removeFile("video.webm");
						//mainContent.contentWindow.removeFile("audio.wav");
						
				//		PostBlob(allBlobs[0]);
				//		PostBlob(blob);
				//		myNoteImpl.addVideo("sphereLiteUser", fileName, blob);
						//isMerging = false;
						//convertVal = 0;
						//_convertVal = 0;
						delete vBlobsArr;
						vBlobsArr = null;
						delete aBlobsArr;
						aBlobsArr = null;
						
						concatTimer = setTimeout(function(){
							concatVideo();
							if(concatTimer)
							{
								clearTimeout(concatTimer);
							}
						}, 9000);
						//allBlobs = [];
					}
				} else {
					updateStatus("Exit code:"+pnacl.exitStatus);
					script.src = "";
					script.remove();
					pnacl = null;
					delete script;
					script = null;
				}
			});
			
			document.getElementsByTagName("body")[0].appendChild(script);
	
		});
	});
}

var outputLength = 0;
function concatVideo()
{
	console.log('!!! Prepare concatVideo() !!!');
	
	var listData = "";
	for(var i = 0 ; i < curIndex ; i++)
	{
		listData = listData + "file 'output" + i + ".mkv'\n";
	}
			
	myNoteImpl.addVideo("/tmp", "file.txt", new Blob([listData]), function() {
			script = document.createElement('embed');
			script.id = 'pnacl';
			script.width = 0;
			script.height = 0;
			script.src = 'ffmpeg.nmf';
			script.type = 'application/x-pnacl';
			script.setAttribute('ps_stdout', 'dev/tty');
			script.setAttribute('ps_stderr', 'dev/tty');
			script.setAttribute('ps_tty_prefix', '');
			script.setAttribute('arg0', 'ffmpeg');
			script.setAttribute('arg1', '-y');
			/*document.write("<embed id='pnacl' width='0' height='0'");
			document.write("ps_stdout='dev/tty'");
			document.write("ps_stderr='dev/tty'");
			document.write("ps_tty_prefix= ''");
			document.write("arg0='ffmpeg'");
			document.write("arg1='-y'");*/
			
			var n = 2;
			var out_file = 'a.out';
			var args = '-f concat -i file.txt -c copy '+fileName+''
			console.log((new Date ()).toLocaleTimeString() + ' ' + args);
			curIndex++;
			//var args = window.location.search.substr(1);
			//args = decodeURIComponent(args);
			args.split('"').forEach(function(t, i) {
				t = t.trim();
				if ((i % 2) === 1) {
				script.setAttribute("arg"+n, t);
				//document.write("arg"+n+"='"+t+"'");
				out_file = t;
				n++;
				} else {
					t = t.replace(/\s+/g, ' ');
				t.split(" ").forEach(function(x,j,ao) {
					x = x.trim();
					if(j==(ao.length-1)) {
					if(x=='/dev/null') x = 'dev_null';
					}
					script.setAttribute("arg"+n, x);
					//document.write("arg"+n+"='"+x+"'");
					out_file = x;
					n++;
				});
				}
			});
			//document.write("></embed>");
			
			//var pnacl = document.getElementById("pnacl");
			pnacl = script;
			
			function updateStatus(msg) {
				console.log((new Date ()).toLocaleTimeString() + ' ' + msg);
				if(msg == 'Success!')
				{
					convertVal = _convertVal + (100 / progress);
					if(convertVal >= 100)
					{
						convertVal = 100;
					}
					mainContent.contentWindow.setProgressValue(convertVal);
				}
			}

			function eventStatus(status) {
				return function () {
				updateStatus(status);
				}
			}

			function eventProgress(event) {
				var loadPercent = 0.0;
				var loadPercentString;
				if (event.lengthComputable && event.total > 0) {
				loadPercent = event.loaded / event.total * 100.0;
				loadPercentString = Math.round(loadPercent) + '%';
				updateStatus('Loading...' + loadPercentString);
				} else {
				updateStatus('Loading...');
				}
			}	

			function eventRunning() {
				updateStatus("Running");
				time = now();
			}
			pnacl.addEventListener('loadstart', eventStatus("Load Start"));
			pnacl.addEventListener('progress', eventProgress);
			pnacl.addEventListener('load', eventStatus("load"));
			pnacl.addEventListener('error', eventStatus("error"+pnacl.lastError));
			pnacl.addEventListener('abort', eventStatus("abort"+pnacl.lastError));
			pnacl.addEventListener('loadend', eventRunning);
			pnacl.addEventListener('message', function (ev) {
				if(ev.data.match(/^Libavutil has been linked to a broken llrint/)) return;
				if(ev.data.match(/^frame=/) || ev.data.match(/^size=/)) {
				var ti = ev.data.match(/time=..:..:../);
				//if(document.cform.ctext.value != ti) document.cform.ctext.value = ti;
				//console.log((new Date ()).toLocaleTimeString() + ' ' + ti);
				}
				//if((ev.data.match(/^frame=/) || ev.data.match(/^size=/))&& disable_stats) return;
				//if(ev.data.match(/^[ ,\n,\r]*$/)  && disable_stats) return;
				//var output = document.getElementById("output");
				//output.textContent += ev.data;*/
				console.log((new Date ()).toLocaleTimeString() + ' ' + ev.data);
			});

			pnacl.addEventListener('crash', function () {
				var totalTime = now() - time - 1000;
				if(totalTime<0) totalTime += 1000;
				totalTime = Math.round(totalTime/1000);
				if(pnacl.exitStatus == 0) {
				//var output = document.getElementById("output");
				//output.textContent += 'Finished processing (took ' + totalTime + 's)'
				updateStatus('Finished processing (took ' + totalTime + 's)');		
				updateStatus('Success!');
						//var downlink = document.createElement('a');
					//downlink.href = "filesystem:http://"+location.host+"/persistent/sphereLiteUser/"+out_file;
						//downlink.download = out_file;
						//downlink.innerHTML = "<button>Download</button>";
					//objDownload.appendChild(downlink);
					//var objDownload = document.getElementById('download');
					
					script.src = "";
					script.remove();
					pnacl = null;
					delete script;
					script = null;
					
					myNoteImpl.copyVideo("/tmp", fileName, "/sphereLiteUser", fileName, function()
					{
						myNoteImpl.deleteDirectory("/tmp");
						
						var finalTime = now() - convertTime - 1000;
						if(finalTime<0) finalTime += 1000;
						finalTime = Math.round(finalTime/1000);
						console.log((new Date ()).toLocaleTimeString() + ' finalTime: ' + finalTime + 's');
						progressTimer = setTimeout(function(){
							mainContent.contentWindow.clearProgressValue();
							isMerging = false;
							convertVal = 0;
							_convertVal = 0;
							progress = 0;
							fileName = "";
							if(progressTimer)
							{
								clearTimeout(progressTimer);
							}
						}, 1000);
					});
				} else {
					updateStatus("Exit code:"+pnacl.exitStatus);
					
					script.src = "";
					script.remove();
					pnacl = null;
					delete script;
					script = null;
				}
			});
			
			document.getElementsByTagName("body")[0].appendChild(script);
	});
}

function showMediaLibraryImg(url)
{
	$("#videoDiv").css('display', 'none');
	imgSrc.onload = function()
	{
		if(this.width > this.height)
		{
			$("#imgSrc").css({'width': '100%'});
		}
		else
		{
			$("#imgSrc").css({'height': '100%'});
		}
		$("#imgDiv").css('display', 'block');
		$("#changeMediaLibraryBtn").css('display', 'block');
		$("#mediaDiv").css('display', 'block');
		onResize();
	}
	imgSrc.src = url;
}

function showMediaLibraryVideo(url)
{
	$("#imgDiv").css('display', 'none');
    videoSrc.src = url;
	$("#videoSrc").css({'width': '100%'});
	videoSrc.load();
	$("#videoDiv").css('display', 'block');
	$("#changeMediaLibraryBtn").css('display', 'block');
	$("#mediaDiv").css('display', 'block');
	
//AI 20180705[S]	
    var userAgent = navigator.userAgent;
	console.log(userAgent);
	videoSrc.addEventListener('loadedmetadata', function() 
	{
        if (videoSrc.duration === Infinity) 
		{
		//	videoSrc.currentTime = 1e101;
		    videoSrc.currentTime = 3601;
            videoSrc.ontimeupdate = function() 
			{
				videoSrc.currentTime = 0;
                videoSrc.ontimeupdate = function() 
				{
					delete videoSrc.ontimeupdate;
                //    videoSrc.play();
                };
            };
        }
    });
//AI 20180705[E]	
	
    onResize();
}

function onResize()
{
	var userAgent = navigator.userAgent;
	var _clientWidth = 0;
	var _clientHeight = 0;
	if(userAgent.indexOf("CrOS") != -1)
	{
		_clientWidth = document.body.clientWidth;
		_clientHeight = document.body.clientHeight;
	}
	else
	{
		_clientWidth = window.outerWidth;
		_clientHeight = window.outerHeight;
	}
	
	if(_clientWidth == screen.availWidth && _clientHeight == screen.availHeight)
	{
		isMaximum = true;
	}
	else
	{
		isMaximum = false;
	}
	var width = originalWidth + (_clientWidth - originalWidth);
	var height = originalHeight + (_clientHeight - originalHeight - 34);
	$("#mediaDiv").width(width);
	$("#mediaDiv").height(height);
	$("#imgDiv").width(width);
	$("#imgDiv").height(height);
	$("#imgDivTmp").width(width);
	$("#imgDivTmp").height(height);
	$("#videoDiv").width(width);
	$("#videoDiv").height(height);
	$("#videoDivTmp").width(width);
	$("#videoDivTmp").height(height);
		
	var _left = ($("#imgDiv").width() - $("#imgSrc").width()) / 2;
	var _top = ($("#imgDiv").height() - $("#imgSrc").height()) / 2;
	$("#imgSrc").css({'left': _left, 'top': _top});
	if($("#imgSrc").width() > $("#imgSrc").height())
	{
		if($("#imgSrc").height() >= $("#imgDivTmp").height())
		{
			var _width = $("#imgDivTmp").height() * ($("#imgSrc").width() / $("#imgSrc").height());
			$("#imgDivTmp").width(_width);
			var _left = ($("#imgDiv").width() - $("#imgDivTmp").width()) / 2;
			var _top = ($("#imgDiv").height() - $("#imgDivTmp").height()) / 2;
			$("#imgSrc").css({'left': _left, 'top': _top});
		}
	}
	
	var _videoLeft = ($("#videoDiv").width() - $("#videoSrc").width()) / 2;
	var _height = $("#videoSrc").width() / ($("#videoDiv").width() / $("#videoDiv").height());
	$("#videoSrc").height(_height);
	var _videoTop = ($("#videoDiv").height() - $("#videoSrc").height()) / 2;
	$("#videoSrc").css({'left': _videoLeft, 'top': _videoTop});
	if($("#videoSrc").width() > $("#videoSrc").height())
	{
		if($("#videoSrc").height() >= $("#videoDivTmp").height())
		{
			var _width = $("#videoDivTmp").height() * ($("#videoSrc").width() / $("#videoSrc").height());
			$("#videoDivTmp").width(_width);
			var _left = ($("#videoDiv").width() - $("#videoDivTmp").width()) / 2;
			var _top = ($("#videoDiv").height() - $("#videoDivTmp").height()) / 2;
			$("#videoSrc").css({'left': _left, 'top': _top});
		}
	}
	
	if(isMaximum)
	{
		$(".titleText").css({'left': 0});
		$("#closeDiv").css({'left': 'calc(50% - 150px)'});
		$("#scaleWindowBtn").attr('src', '../img/btn_shrinkscreen_normal.png');
	}
	else
	{
		$(".titleText").css({'left': 50});
		$("#closeDiv").css({'left': 'calc(55% - 150px)'});
		$("#scaleWindowBtn").attr('src', '../img/btn_fullscreen_normal.png');
	}
}

function closeApp()
{
	chrome.power.releaseKeepAwake();
	chrome.app.window.current().close();
}

function hideMediaDiv()
{
	if(imgSrc.src != "")
	{
		$("#changeMediaLibraryBtn").css('display', 'none');
		$("#mediaDiv").css('display', 'none');
		$("#imgSrc").css({'width': '', 'height': ''});
		imgSrc.src = "";
	}
	if(videoSrc.src != "")
	{
		videoSrc.pause();
		videoSrc.src = "";
	}
}

function scaleWindow()
{
	if(!isMaximum)
	{
		isMaximum = true;
		chrome.app.window.current().maximize();
		$("#scaleWindowBtn").attr('src', '../img/btn_shrinkscreen_normal.png');
		document.getElementById("scaleWindowBtn").title = "Minimize";
	}
	else
	{
		isMaximum = false;
		chrome.app.window.current().restore();
		$("#scaleWindowBtn").attr('src', '../img/btn_fullscreen_normal.png');
		document.getElementById("scaleWindowBtn").title = "Fullscreen";
	}
}

function changePage()
{
	if(this.id == "cameraPreviewBtn")
	{
		$(this).attr('src', '../img/btn_rec_mode_pressed.png');
		$($(this)).attr('isSelect', 'true');
		
		$("#mediaLibraryBtn").attr('src', '../img/btn_playback_normal.png');
		$("#infoBtn").attr('src', '../img/btn_info_normal.png');
		
		$("#mediaLibraryBtn").attr('isSelect', 'false');
		$("#infoBtn").attr('isSelect', 'false');
		if($("#mainIframeTmp").css('display') == 'block')
		{
			$("#mainIframeTmp").css('display', 'none');
			mainContentTmp.src = "";
			$("#mainIframe").css('display', 'block');
		}
	}
	if(this.id == "mediaLibraryBtn")
	{
		$(this).attr('src', '../img/btn_playback_pressed.png');
		$($(this)).attr('isSelect', 'true');
		
		$("#cameraPreviewBtn").attr('src', '../img/btn_rec_mode_normal.png');
		$("#infoBtn").attr('src', '../img/btn_info_normal.png');
		
		$("#cameraPreviewBtn").attr('isSelect', 'false');
		$("#infoBtn").attr('isSelect', 'false');
		if($("#mainIframe").css('display') == 'block')
		{
			if(mainContentTmp.src.indexOf("mediaLibrary") == -1)
			{
				mainContentTmp.src = "html/mediaLibrary.html";
			}
			$("#mainIframe").css('display', 'none');
			$("#mainIframeTmp").css('display', 'block');
		}
		else
		{
			if(mainContentTmp.src.indexOf("mediaLibrary") != -1)
			{
				return;
			}
			mainContentTmp.src = "html/mediaLibrary.html";
		}
	}
	if(this.id == "infoBtn")
	{
		$(this).attr('src', '../img/btn_info_pressed.png');
		$($(this)).attr('isSelect', 'true');
		
		$("#cameraPreviewBtn").attr('src', '../img/btn_rec_mode_normal.png');
		$("#mediaLibraryBtn").attr('src', '../img/btn_playback_normal.png');
		
		$("#cameraPreviewBtn").attr('isSelect', 'false');
		$("#mediaLibraryBtn").attr('isSelect', 'false');
		if($("#mainIframe").css('display') == 'block')
		{
			if(mainContentTmp.src.indexOf("productInfo") == -1)
			{
				mainContentTmp.src = "html/productInfo.html";
			}
			$("#mainIframe").css('display', 'none');
			$("#mainIframeTmp").css('display', 'block');
		}
		else
		{
			if(mainContentTmp.src.indexOf("productInfo") != -1)
			{
				return;
			}
			mainContentTmp.src = "html/productInfo.html";
		}
	}
}

function fullscreenCameraVideo()
{
	if(videoSrc.requestFullscreen)
	{
		videoSrc.requestFullscreen();
	}
	else if(videoSrc.msRequestFullscreen)
	{
		videoSrc.msRequestFullscreen();
	}
	else if(videoSrc.mozRequestFullScreen)
	{
		videoSrc.mozRequestFullScreen();
	}
	else if(videoSrc.webkitRequestFullscreen)
	{
		videoSrc.webkitRequestFullscreen();
		document.webkitFullScreen = false;
	}
}

function setMic(vol)
{
	micVolume = vol;
}

function showCloseDlg()
{
	$("#modalDialog_mask").css('display', 'block');
	$("#closeDiv").css('display', 'block');
}

function hideCloseDlg()
{
	$("#modalDialog_mask").css('display', 'none');
	$("#closeDiv").css('display', 'none');
}

function init()
{
	closeBtn.onclick = showCloseDlg;
	closeYesText.onclick = closeApp;
	closeNoText.onclick = hideCloseDlg;
	changeMediaLibraryBtn.onclick = hideMediaDiv;
	scaleWindowBtn.onclick = scaleWindow;
	cameraPreviewBtn.onclick = changePage;
	mediaLibraryBtn.onclick = changePage;
	infoBtn.onclick = changePage;
	
	originalWidth = $("#mediaDiv").width();
	originalHeight = $("#mediaDiv").height();
	
	document.addEventListener("dblclick", function(e)
	{
		if(document.webkitFullScreen)
		{
			document.webkitCancelFullScreen();
			document.webkitFullScreen = false;
		}
		else
		{
			fullscreenCameraVideo();
		}
	}, false);
	
	onResize();
	$(window).resize(onResize);
}

$(document).ready(function(){
	$(".selectDiv").on('dblclick', function(e){
		e.stopPropagation();
	});
	
	$("#modalDialog_mask").on('dblclick', function(e){
		e.stopPropagation();
	});
	
	$("#closeDiv").on('dblclick', function(e){
		e.stopPropagation();
	});
	
	$("#mediaDiv").on('dblclick', function(e){
		e.stopPropagation();
	});
	
	$("#cameraPreviewBtn").hover(function(){
		var isSelect = $(this).attr('isSelect');
		if(isSelect == 'false')
		{
			$(this).attr('src', '../img/btn_rec_mode_hover.png');
		}
	}, function(){
		var isSelect = $(this).attr('isSelect');
		if(isSelect == 'false')
		{
			$(this).attr('src', '../img/btn_rec_mode_normal.png');
		}
	});
	$("#cameraPreviewBtn").mousedown(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).attr('src', '../img/btn_rec_mode_pressed.png');
	}).mouseup(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).attr('src', '../img/btn_rec_mode_hover.png');
	});
	
	$("#mediaLibraryBtn").hover(function(){
		var isSelect = $(this).attr('isSelect');
		if(isSelect == 'false')
		{
			$(this).attr('src', '../img/btn_playback_hover.png');
		}
	}, function(){
		var isSelect = $(this).attr('isSelect');
		if(isSelect == 'false')
		{
			$(this).attr('src', '../img/btn_playback_normal.png');
		}
	});
	$("#mediaLibraryBtn").mousedown(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).attr('src', '../img/btn_playback_pressed.png');
	}).mouseup(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).attr('src', '../img/btn_playback_hover.png');
	});
	
	$("#infoBtn").hover(function(){
		var isSelect = $(this).attr('isSelect');
		if(isSelect == 'false')
		{
			$(this).attr('src', '../img/btn_info_hover.png');
		}
	}, function(){
		var isSelect = $(this).attr('isSelect');
		if(isSelect == 'false')
		{
			$(this).attr('src', '../img/btn_info_normal.png');
		}
	});
	$("#infoBtn").mousedown(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).attr('src', '../img/btn_info_pressed.png');
	}).mouseup(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).attr('src', '../img/btn_info_hover.png');
	});
	
	$("#closeBtn").hover(function(){
		$(this).attr('src', '../img/btn_x_hover.png');
	}, function(){
		$(this).attr('src', '../img/btn_x_normal.png');
	});
	$("#closeBtn").mousedown(function(e){
		$(this).attr('src', '../img/btn_x_pressed.png');
	}).mouseup(function(){
    	$(this).attr('src', '../img/btn_x_hover.png');
    });
	
	$("#closeYesText").hover(function(){
		$(this).css('color', '#FFFFFF');
		$("#confirm_no_btn").attr('src', '../img/btn_dialog_hover.png');
	}, function(){
		$(this).css('color', '#CCCCCC');
		$("#confirm_no_btn").attr('src', '../img/btn_dialog_normal.png');
	});
	
	$("#closeYesText").mousedown(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).css('color', '#FF8200');
		$("#confirm_no_btn").attr('src', '../img/btn_dialog_pressed.png');
	}).mouseup(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).css('color', '#FFFFFF');
		$("#confirm_no_btn").attr('src', '../img/btn_dialog_hover.png');
	});
	
	$("#closeNoText").hover(function(){
		$(this).css('color', '#FFFFFF');
		$("#confirm_no_btn").attr('src', '../img/btn_dialog_hover.png');
	}, function(){
		$(this).css('color', '#CCCCCC');
		$("#confirm_no_btn").attr('src', '../img/btn_dialog_normal.png');
	});
	
	$("#closeNoText").mousedown(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).css('color', '#FF8200');
		$("#confirm_no_btn").attr('src', '../img/btn_dialog_pressed.png');
	}).mouseup(function(e){
		if(e.which != 1)
		{
			return;
		}
		$(this).css('color', '#FFFFFF');
		$("#confirm_no_btn").attr('src', '../img/btn_dialog_hover.png');
	});
	
	$("#changeMediaLibraryBtn").hover(function(){
		$(this).attr('src', '../img/btn_back_hover.png');
	}, function(){
		$(this).attr('src', '../img/btn_back_normal.png');
	});
	$("#changeMediaLibraryBtn").mousedown(function(){
		$(this).attr('src', '../img/btn_back_pressed.png');
	}).mouseup(function(){
    	$(this).attr('src', '../img/btn_back_hover.png');
    });
	
	$("#scaleWindowBtn").hover(function(){
		if(!isMaximum)
		{
			$(this).attr('src', '../img/btn_fullscreen_hover.png');
		}
		else
		{
			$(this).attr('src', '../img/btn_shrinkscreen_hover.png');
		}
	}, function(){
		if(!isMaximum)
		{
			$(this).attr('src', '../img/btn_fullscreen_normal.png');
		}
		else
		{
			$(this).attr('src', '../img/btn_shrinkscreen_normal.png');
		}
	});
	$("#scaleWindowBtn").mousedown(function(){
		if(!isMaximum)
		{
			$(this).attr('src', '../img/btn_fullscreen_pressed.png');
		}
		else
		{
			$(this).attr('src', '../img/btn_shrinkscreen_pressed.png');
		}
	}).mouseup(function(){
		if(!isMaximum)
		{
			$(this).attr('src', '../img/btn_fullscreen_hover.png');
		}
		else
		{
			$(this).attr('src', '../img/btn_shrinkscreen_hover.png');
		}
	});
});

function onMaximize()
{
    mainIframe.style.left = 0;
	mainIframeTmp.style.left = 0;
}

function onRestore()
{
	if(!isMaximum)
	{
		mainIframe.style.left = 100;
		mainIframeTmp.style.left = 100;
	}
}

function onGetDevices()
{
    console.debug("Device get");
}

function onDeviceAdd()
{
    console.debug("Device add");
}

function onDeviceRemove()
{
	console.debug("Device remove");
}

window.onload = init;

chrome.app.window.current().onMaximized.addListener(onMaximize);

chrome.app.window.current().onRestored.addListener(onRestore);

chrome.usb.getDevices({}, onGetDevices);

chrome.usb.onDeviceAdded.addListener(onDeviceAdd);

chrome.usb.onDeviceRemoved.addListener(onDeviceRemove);

