chrome.app.runtime.onLaunched.addListener(function() {
	chrome.power.requestKeepAwake("display");
	chrome.app.window.create("main.html", {
		bounds: 
		{
			width: 900,
			height: 720
		},
		minWidth: 740,
		minHeight: 600,
		frame: 'none'
	});
});