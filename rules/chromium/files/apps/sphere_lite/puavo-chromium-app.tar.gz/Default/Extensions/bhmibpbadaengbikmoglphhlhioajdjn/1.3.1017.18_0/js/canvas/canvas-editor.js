var systemCanvasContext;
var canvasEditor;

function CanvasEditor(name, canvasView)
{
    this.canvasView = canvasView;
    systemCanvasContext = canvasView.systemCanvasContext;
	this.debug_name = name;
	this.freehand_tool = new FreehandTool(this);
	this.line_tool = new LineTool(this);
	this.selection_tool = new SelectionTool(this);
	this.shape_tool = new ShapeTool(this);
	this.eraser_tool = new EraserTool(this);
	this.highlighter_tool = new FreehandTool(this);
	this.highlighter_tool.setHighlighter(true);
	this.text_tool = new TextTool(this, canvasView);
	this.current_tool = this.selection_tool;

	this.active_canvas_model = null;
	this.highlighter_tool.setLineWidth(3);
	//this.highlighter_tool.setLineColor(255, 155, 55, 1);
	this.highlighter_tool.setHighlighter(true);
	//this.shape_tool.setLineColor(255, 155, 55, 1);
	canvasEditor = this;

	//this.line_width = 
};

CanvasEditor.prototype.initialize = function()
{
//	this.freehand_tool = new FreehandTool();
//	this.line_tool = new LineTool();
//	this.selection_tool = new SelectionTool();
//	this.shape_tool = new ShapeTool();
//	this.current_tool = ce_m_freehand_tool;
};

CanvasEditor.prototype.getName = function()
{
	return this.debug_name;
};

CanvasEditor.prototype.setActiveCanvasModel = function(canvas_model)
{
	this.active_canvas_model = canvas_model;
};

CanvasEditor.prototype.getActiveCanvasModel = function()
{
	return this.active_canvas_model;
};

CanvasEditor.prototype.switchToFreehandTool = function()
{
	if(this.current_tool == this.selection_tool)
	{
		this.current_tool.deselectAllGraphics();
	}
	if(this.current_tool == this.text_tool)
	{
		this.current_tool.forceCloseTextEditor();
	}
	this.current_tool = this.freehand_tool;
};

CanvasEditor.prototype.switchToHighlighterTool = function()
{
	if(this.current_tool == this.selection_tool)
	{
		this.current_tool.deselectAllGraphics();
	}
	if(this.current_tool == this.text_tool)
	{
		this.current_tool.forceCloseTextEditor();
	}
	this.current_tool = this.highlighter_tool;
};

CanvasEditor.prototype.setFreehandToolWidth = function(width)
{
	this.freehand_tool.setLineWidth(width);
};

CanvasEditor.prototype.setFreehandToolColor = function(color)
{
	this.freehand_tool.setLineColor(color);
};

CanvasEditor.prototype.setHighlighterToolWidth = function(width)
{
	this.highlighter_tool.setLineWidth(width);
};

CanvasEditor.prototype.setHighlighterToolColor = function(color)
{
	this.highlighter_tool.setLineColor(color);
};

CanvasEditor.prototype.switchToLineTool = function()
{
	if(this.current_tool == this.selection_tool)
	{
		this.current_tool.deselectAllGraphics();
	}
	if(this.current_tool == this.text_tool)
	{
		this.current_tool.forceCloseTextEditor();
	}
	this.current_tool = this.line_tool;
};

CanvasEditor.prototype.setLineToolWidth = function(width)
{
	this.line_tool.setLineWidth(width);
};

CanvasEditor.prototype.setLineToolColor = function(color)
{
	this.line_tool.setLineColor(color);
};

CanvasEditor.prototype.switchToSelectionTool = function()
{
	if(this.current_tool == this.text_tool)
	{
		this.current_tool.forceCloseTextEditor();
	}
	this.current_tool = this.selection_tool;
};

CanvasEditor.prototype.switchToTextTool = function()
{
	if(this.current_tool == this.selection_tool)
	{
		this.current_tool.deselectAllGraphics();
	}
	this.current_tool = this.text_tool;
};

CanvasEditor.prototype.setTextToolColor = function(color)
{
	this.text_tool.setTextColor(color);
};

CanvasEditor.prototype.setTextToolFontSize = function(size)
{
	this.text_tool.setTextFontSize(size);
};
CanvasEditor.prototype.setTextToolItalic = function(TorF)
{
	this.text_tool.setItalic(TorF);
}
CanvasEditor.prototype.setTextToolBold = function(TorF)
{
	this.text_tool.setBold(TorF);
}
CanvasEditor.prototype.setTextToolUnderLine = function(TorF)
{
	this.text_tool.setUnderLine(TorF);
}

CanvasEditor.prototype.switchToShapeTool = function()
{
	if(this.current_tool == this.selection_tool)
	{
		this.current_tool.deselectAllGraphics();
	}
	if(this.current_tool == this.text_tool)
	{
		this.current_tool.forceCloseTextEditor();
	}
	this.current_tool = this.shape_tool;
};

CanvasEditor.prototype.setShapeToolWidth = function(width)
{
	this.shape_tool.setLineWidth(width);
};

CanvasEditor.prototype.setShapeToolColor = function(color)
{
	this.shape_tool.setLineColor(color);
};

CanvasEditor.prototype.setShapeFilled = function(filled)
{
	this.shape_tool.setFilled(filled);
};

CanvasEditor.prototype.setShapeType = function(shape)
{
	this.shape_tool.setShapeType(shape);
};

CanvasEditor.prototype.switchToEraserTool = function()
{
	if(this.current_tool == this.selection_tool)
	{
		this.current_tool.deselectAllGraphics();
	}
	if(this.current_tool == this.text_tool)
	{
		this.current_tool.forceCloseTextEditor();
	}
	this.current_tool = this.eraser_tool;
};

CanvasEditor.prototype.setCurToolNull = function()
{
	this.current_tool = null;
}

CanvasEditor.prototype.getUndoStackLen = function()
{
	var undoStackLen = this.active_canvas_model.undo_manager.getUndoStackLen();
	return undoStackLen;
}

CanvasEditor.prototype.getRedoStackLen = function()
{
	var redoStackLen = this.active_canvas_model.undo_manager.getRedoStackLen();
	return redoStackLen;
}

CanvasEditor.prototype.getLastItemType = function()
{
	var lastType = this.active_canvas_model.undo_manager.getLastItemType();
	return lastType;
}

CanvasEditor.prototype.forceCloseTextEditor = function()
{
	if(this.current_tool == this.text_tool)
	{
		this.current_tool.forceCloseTextEditor();
	}
}

CanvasEditor.prototype.addGraphicToActiveCanvas = function(graphic)
{
	if(this.active_canvas_model == null)
		return;
	this.active_canvas_model.addGraphic(graphic, true);
};

CanvasEditor.prototype.removeGraphicFromActiveCanvas = function(graphic)
{
	if(this.active_canvas_model == null)
		return;
	this.active_canvas_model.removeGraphic(graphic, true);
};

CanvasEditor.prototype.annotationStart = function(x, y)
{
	if(this.current_tool != null)
		this.current_tool.annoToolAnnotationStart(x, y);
};

CanvasEditor.prototype.annotationMove = function(x, y)
{
	if(this.current_tool != null)
		this.current_tool.annoToolAnnotationMove(x, y);
};

CanvasEditor.prototype.annotationStop = function(x, y)
{
	if(this.current_tool != null)
		this.current_tool.annoToolAnnotationStop(x, y);
};

CanvasEditor.prototype.insertImage = function(url)
{
	if(this.current_tool == this.selection_tool)
	{
		this.current_tool.deselectAllGraphics();
	}
	var scaleWidth = 0;
	var scaleHeight = 0;
	var image = new Image();
	image.onload = function()
	{
		if(image.width > systemCanvasContext.canvas.width || image.height > systemCanvasContext.canvas.height)
		{
			var wRatio =  Math.ceil((systemCanvasContext.canvas.width / image.width) * 100) / 100;
			var hRatio =  Math.ceil((systemCanvasContext.canvas.height / image.height) * 100) / 100;
			if(wRatio > hRatio)
			{
				scaleWidth = Math.round(image.width * hRatio);
				scaleHeight = Math.round(image.height * hRatio);
				image.width = scaleWidth * 0.8;
				image.height = scaleHeight * 0.8;
			}
			else
			{
				scaleWidth = Math.round(image.width * wRatio);
				scaleHeight = Math.round(image.height * wRatio);
				image.width = scaleWidth * 0.8;
				image.height = scaleHeight * 0.8;
			}
		}
		var image_graphic = new ImageGraphic(image);
		canvasEditor.addGraphicToActiveCanvas(image_graphic);
		canvasEditor.askViewToRedraw();
	};
	image.src = url;
};

CanvasEditor.prototype.render = function()
{
	if(this.active_canvas_model != null)
		this.active_canvas_model.render();
	if(this.current_tool != null)
		this.current_tool.render();
};

CanvasEditor.prototype.askViewToRedraw = function()
{
	this.canvasView.redraw();
};

CanvasEditor.prototype.deleteSelect = function()
{
	this.selection_tool.deleteSelect();
};

CanvasEditor.prototype.cornerTest = function(x, y)
{
	return this.selection_tool.cornerTest(x, y);
};

CanvasEditor.prototype.getCurrentTool = function(){
	return this.current_tool;
};

CanvasEditor.prototype.setLineToolArrowType = function(type)
{
	this.line_tool.arrow_type = type;
}
CanvasEditor.prototype.setLineToolDash = function(TorF)
{
	this.line_tool.dash_line = TorF;
}
CanvasEditor.prototype.setFreehandToolArrowType = function(type)
{
	this.freehand_tool.arrow_type = type;
}
CanvasEditor.prototype.setFreehandToolDash = function(TorF)
{
	this.freehand_tool.dash_line = TorF;
}
CanvasEditor.prototype.setHighlighterToolArrowType = function(type)
{
	this.line_tool.arrow_type = type;
}
CanvasEditor.prototype.setHighlighterToolDash = function(TorF)
{
	this.line_tool.dash_line = TorF;
}
CanvasEditor.prototype.setTextToolFontFamily = function(font)
{
	this.text_tool.setTextFontFamily(font)
}