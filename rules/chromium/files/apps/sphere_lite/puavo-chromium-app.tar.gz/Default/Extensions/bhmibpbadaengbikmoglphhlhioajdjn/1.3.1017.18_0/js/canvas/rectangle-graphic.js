
function RectangleGraphic()
{
	this.rect_x = 0;
	this.rect_y = 0;
	this.rect_w = 0;
	this.rect_h = 0;
	this.parent_canvas_model = null;
	this.start_pt_x = 0;
	this.start_pt_y = 0;
	this.end_pt_x = 0;
	this.end_pt_y = 0;
	this.is_selected = false;
	this.line_width = 3;
	this.line_color;
	// this.line_color_r = 255;
	// this.line_color_g = 155;
	// this.line_color_b = 55;
	// this.line_color_a = 1;
	this.is_filled = false;
	this.zorderIndex = -1;
};

RectangleGraphic.prototype.getType = function()
{
	return "RectangleGraphic";
};

RectangleGraphic.prototype.setFilled = function(filled)
{
	this.is_filled = filled;
};

RectangleGraphic.prototype.setLineWidth = function(width)
{
	this.line_width = width;
};

RectangleGraphic.prototype.setLineColor = function(color)
{
	this.line_color = color;
	// this.line_color_r = r;
	// this.line_color_g = g;
	// this.line_color_b = b;
	// this.line_color_a = a;
};

RectangleGraphic.prototype.setParentCanvasModel = function(canvas_model)
{
	this.parent_canvas_model = canvas_model;
	this.calcGraphicRect();
};

RectangleGraphic.prototype.setSelected = function(selected)
{
	this.is_selected = selected;
};

RectangleGraphic.prototype.isSelected = function()
{
	return this.is_selected;
};

RectangleGraphic.prototype.move = function(dx , dy)
{
	this.rect_x += dx;
	this.rect_y += dy;
};

RectangleGraphic.prototype.setStartPoint = function(x, y)
{
	this.start_pt_x = x;
	this.start_pt_y = y;
};

RectangleGraphic.prototype.setEndPoint = function(x, y)
{
	this.end_pt_x = x;
	this.end_pt_y = y;
	this.calcGraphicRect();
};

RectangleGraphic.prototype.calcIsSelected = function(x, y, w, h)
{
	var gLeft = this.rect_x;
	var gRight = this.rect_x + this.rect_w;
	var gTop = this.rect_y;
	var gBottom = this.rect_y + this.rect_h;
	var l = x;
	var r = x + w;
	var t = y;
	var b = y + h;
	if(b < gTop || r < gLeft|| l > gRight || t > gBottom)
		return false;
	return true;
};

RectangleGraphic.prototype.calcGraphicRect = function()
{
	this.rect_x = this.start_pt_x;
	this.rect_w = this.end_pt_x - this.start_pt_x;
	if(this.end_pt_x < this.start_pt_x)
	{
		this.rect_x = this.end_pt_x;
		this.rect_w = this.start_pt_x - this.rect_x;
	}
	this.rect_y = this.start_pt_y;
	this.rect_h = this.end_pt_y - this.start_pt_y;
	if(this.end_pt_y < this.start_pt_y)
	{
		this.rect_y = this.end_pt_y;
		this.rect_h = this.start_pt_y - this.rect_y;
	}
};

RectangleGraphic.prototype.hitTest = function(x, y)
{
	var gLeft = this.rect_x;
	var gRight = this.rect_x + this.rect_w;
	var gTop = this.rect_y;
	var gBottom = this.rect_y + this.rect_h;
	if(x > gRight || x < gLeft || y > gBottom || y < gTop)
	{
		return false;
	}
	return true;
};

RectangleGraphic.prototype.eraseTest = function(ax, ay, bx, by)
{
//	ax -= this.rect_x;
//	ay -= this.rect_y;
//	bx -= this.rect_x;
//	by -= this.rect_y;
	
	var gLeft = this.rect_x;
	var gRight = this.rect_x + this.rect_w;
	var gTop = this.rect_y;
	var gBottom = this.rect_y + this.rect_h;
	
	var doErase = false;
	doErase |= isIntersected(gLeft, gTop, gRight, gTop, ax, ay, bx, by);
	doErase |= isIntersected(gLeft, gTop, gLeft, gBottom, ax, ay, bx, by);
	doErase |= isIntersected(gRight, gTop, gRight, gBottom, ax, ay, bx, by);
	doErase |= isIntersected(gLeft, gBottom, gRight, gBottom, ax, ay, bx, by);

	return doErase;
};

RectangleGraphic.prototype.setZorderIndex = function(index)
{
	this.zorderIndex = index;
}

RectangleGraphic.prototype.getZorderIndex = function(index)
{
	return this.zorderIndex;
}

RectangleGraphic.prototype.render = function()
{
	systemCanvasContext.save();
	
	systemCanvasContext.lineWidth = this.line_width;
	systemCanvasContext.strokeStyle = this.line_color;
	systemCanvasContext.strokeRect(this.rect_x, this.rect_y, this.rect_w, this.rect_h);
	if(this.is_filled)
	{
		systemCanvasContext.beginPath();
		systemCanvasContext.rect(this.rect_x, this.rect_y, this.rect_w, this.rect_h);
		systemCanvasContext.fillStyle = this.line_color;
		systemCanvasContext.fill();
		systemCanvasContext.closePath();
	}
	systemCanvasContext.restore();
	if(!this.is_selected)
		return;
	systemCanvasContext.save();
	systemCanvasContext.strokeStyle = "#64cb23";
	systemCanvasContext.strokeRect(this.rect_x, this.rect_y, this.rect_w, this.rect_h);
	systemCanvasContext.restore();
};