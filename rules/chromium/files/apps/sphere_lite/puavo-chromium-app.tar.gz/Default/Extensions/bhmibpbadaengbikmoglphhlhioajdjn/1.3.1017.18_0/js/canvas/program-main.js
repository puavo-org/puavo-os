var canvasEditor;
var canvasView;
var systemCanvas;

$(document).ready(function () 
{
	new startCanvas();
});

function startCanvas()
{
	canvasView = new CanvasView(900, 600);
    canvasEditor = new CanvasEditor("Canvas Editor");
	var canvasModel = new CanvasModel();
	canvasModel.init();
	canvasEditor.initialize();
	canvasEditor.setActiveCanvasModel(canvasModel);
};