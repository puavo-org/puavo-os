var canvasEditor;
var canvasView;
var systemCanvas;
var canvasModel;

function startCanvas(_canvasView, width, height, x, y)
{
    // creating CanvasView in child but creating CanvasEditor and CanvasModel in parent
	// for when leave view, child object will destroy, so let parent to keep to CanvasEditor and CanvasModel object.
	//canvasView = new CanvasView(width, height);
	canvasView = _canvasView;
	canvasView.moveTo(x, y);
    canvasEditor = new CanvasEditor("Canvas Editor", canvasView);
	if(canvasModel == null)
	{
	    canvasModel = new CanvasModel(canvasEditor);
	}
	//canvasModel = parent.canvasModel;
	//canvasEditor.initialize();
	canvasEditor.setActiveCanvasModel(canvasModel);
	canvasView.setEditor(canvasEditor);
	systemCanvas = canvasView.systemCanvas;
};

function releaseCanvas()
{
    canvasView.reset();
	clearCanvas();
	systemCanvas = null;
	canvasView = null;
	canvasEditor = null;
	canvasModel = null;
};

function getCanvasImage(type)
{
    if(type == null)
	{
	    type = "jpeg";
	}
    if(type == "jpeg" || type == "JPEG" || type == "jpg" || type == "JPG")
	{
	    return systemCanvas.toDataURL("image/jpeg");
	}
	else if(type == "png" || type == "PNG")
	{
	    return systemCanvas.toDataURL("image/png");
	}
	else
	{
	    console.error("invalid image type");
	    return null
	}
};

function moveCanvasView(x, y)
{
	canvasView.moveTo(x, y);
};

function setBackground(url)
{
	canvasView.setBackground(url);
};

function switchToFreehandTool()
{
	canvasEditor.switchToFreehandTool();
};

function setFreehandToolLineWidth(width)
{
	canvasEditor.setFreehandToolWidth(width);
};

function setFreehandToolLineColor(color)
{
	canvasEditor.setFreehandToolColor(color);
};

function switchToLineTool()
{
	canvasEditor.switchToLineTool();
};

function switchToTextTool()
{
	canvasEditor.switchToTextTool();
};

function setTextToolColor(color)
{
	canvasEditor.setTextToolColor(color);
};

function setTextToolFontSize(size)
{
	canvasEditor.setTextToolFontSize(size);
};

function setLineToolLineWidth(width)
{
	canvasEditor.setLineToolWidth(width);
};

function setLineToolLineColor(color)
{
	canvasEditor.setLineToolColor(color);
};

function switchToSelectionTool()
{
	canvasEditor.switchToSelectionTool();
};

function switchToEraserTool()
{
	canvasEditor.switchToEraserTool();
};

function switchToHighlighterTool()
{
	canvasEditor.switchToHighlighterTool();
};

function setHighlighterColor(color)
{
	canvasEditor.setHighlighterToolColor(color);
};

function setHighlighterToolLineWidth(width)
{
	canvasEditor.setHighlighterToolWidth(width);
};

function switchToShapeTool()
{
	canvasEditor.switchToShapeTool();
};

function setShapeToolLineWidth(width)
{
	canvasEditor.setShapeToolWidth(width);
};

function setShapeToolLineColor(color)
{
	canvasEditor.setShapeToolColor(color);
};

function setShapeToolFilled(filled)
{
	canvasEditor.setShapeFilled(filled);
};

function setShapeToolType(shape)
{
	//plz set shape type as string "Circle" "Rectangle" "Triangle"
	canvasEditor.setShapeType(shape);
};

function insertImage(url)
{
	canvasEditor.insertImage(url);
};

function clearCanvas()
{
	canvasEditor.getActiveCanvasModel().clearAll(true);
	canvasEditor.askViewToRedraw();
};

function callundo()
{
	canvasEditor.getActiveCanvasModel().undo();
	canvasEditor.askViewToRedraw();
};

function callredo()
{
	canvasEditor.getActiveCanvasModel().redo();
	canvasEditor.askViewToRedraw();
};

function setCurToolNull()
{
	canvasEditor.setCurToolNull();
}

function getUndoStackLen()
{
	if(canvasEditor != null)
	{
		var undoStackLen = canvasEditor.getUndoStackLen();
		return undoStackLen;
	}
}

function getRedoStackLen()
{
	if(canvasEditor != null)
	{
		var redoStackLen = canvasEditor.getRedoStackLen();
		return redoStackLen;
	}
}

function getLastItemType()
{
	if(canvasEditor != null)
	{
		var lastType = canvasEditor.getLastItemType();
		return lastType;
	}
}

function forceCloseTextEditor()
{
	if(canvasEditor != null)
	{
		if(canvasEditor.getCurrentTool() != null)
		{
			var debug_name = canvasEditor.getCurrentTool().debug_name;
			if(typeof(debug_name) !== 'undefined' && debug_name == 'text tool')
			{
				canvasEditor.forceCloseTextEditor();
			}
		}
	}
}

function clearStack()
{
	canvasEditor.getActiveCanvasModel().clearStack();
};

function isExistImage()
{
	if(canvasModel.getAllGraphics().length == 0 && canvasView.hasCustomBackground() == false)
	{
	    return false;
	}
    else
	{
	    return true;
	}
}

function removeBackground()
{
	canvasView.removeBackground();
};

function setWhiteboardBackground()
{
	canvasView.setWhiteboardBackground();
};
function deleteSelect()
{
    canvasEditor.deleteSelect();
};

function getCurrentTool()
{
	if(canvasEditor != null)
	{
		return canvasEditor.getCurrentTool();
	}
}

function setArrow(type)
{
	if(getCurrentTool )
	canvasEditor.setLineToolArrowType(type);
}

function setLineDash(TorF)
{
	canvasEditor.setLineToolDash(TorF);
}

function setHighlighterArrow(type)
{
	canvasEditor.setHighlighterToolArrowType(type);
}

function setHightlighterDash(TorF)
{
	canvasEditor.setHightlighterDash(TorF);
}

function setFreehandArrow(type)
{
	canvasEditor.setFreehandToolArrowType(type);
}

function setFreehandDash(TorF)
{
	canvasEditor.setFreehandToolDash(TorF);
}

function setTextToolFontFamily(font)
{
	canvasEditor.setTextToolFontFamily(font);
}

function setTextToolItalic(TorF)
{
	canvasEditor.setTextToolItalic(TorF);
}

function setTextToolBold(TorF)
{
	canvasEditor.setTextToolBold(TorF);
}

function setTextToolUnderLine(TorF)
{
	canvasEditor.setTextToolUnderLine(TorF);
}