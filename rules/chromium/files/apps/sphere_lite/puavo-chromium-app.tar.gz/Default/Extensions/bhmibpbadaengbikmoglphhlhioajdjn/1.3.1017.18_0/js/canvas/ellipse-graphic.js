
function EllipseGraphic()
{
	this.rect_x = 0;
	this.rect_y = 0;
	this.rect_w = 0;
	this.rect_h = 0;
	this.parent_canvas_model = null;
	this.start_pt_x = 0;
	this.start_pt_y = 0;
	this.end_pt_x = 0;
	this.end_pt_y = 0;
	this.is_selected = false;
	this.line_width = 3;
	this.line_color = "#FF0000";
	// this.line_color_r = 255;
	// this.line_color_g = 155;
	// this.line_color_b = 55;
	// this.line_color_a = 1;
	this.is_filled = false;
	this.zorderIndex = -1;
};

EllipseGraphic.prototype.getType = function()
{
	return "EllipseGraphic";
};

EllipseGraphic.prototype.setFilled = function(filled)
{
	this.is_filled = filled;
};

EllipseGraphic.prototype.setParentCanvasModel = function(canvas_model)
{
	this.parent_canvas_model = canvas_model;
	this.calcGraphicRect();
};

EllipseGraphic.prototype.setLineWidth = function(width)
{
	this.line_width = width;
};

EllipseGraphic.prototype.setLineColor = function(color)
{
	this.line_color = color;
	// this.line_color_r = r;
	// this.line_color_g = g;
	// this.line_color_b = b;
	// this.line_color_a = a;
};

EllipseGraphic.prototype.setSelected = function(selected)
{
	this.is_selected = selected;
};

EllipseGraphic.prototype.isSelected = function()
{
	return this.is_selected;
};

EllipseGraphic.prototype.move = function(dx , dy)
{
	this.rect_x += dx;
	this.rect_y += dy;
};

EllipseGraphic.prototype.setStartPoint = function(x, y)
{
	this.start_pt_x = x;
	this.start_pt_y = y;
};

EllipseGraphic.prototype.setEndPoint = function(x, y)
{
	this.end_pt_x = x;
	this.end_pt_y = y;
	this.calcGraphicRect();
};

EllipseGraphic.prototype.calcIsSelected = function(x, y, w, h)
{
	var gLeft = this.rect_x;
	var gRight = this.rect_x + this.rect_w;
	var gTop = this.rect_y;
	var gBottom = this.rect_y + this.rect_h;
	var l = x;
	var r = x + w;
	var t = y;
	var b = y + h;
	if(b < gTop || r < gLeft|| l > gRight || t > gBottom)
		return false;
	return true;
};

EllipseGraphic.prototype.eraseTest = function(ax, ay, bx, by)
{
	var a = this.rect_w / 2;
	var b = this.rect_h / 2;
	ax -= (this.rect_x + a);
	ay -= (this.rect_y + b);
	bx -= (this.rect_x + a);
	by -= (this.rect_y + b);


//	var cx = this.rect_x + a;
//	var cy = this.rect_y + b;
	var ares = (ax * ax) / (a * a) + (ay * ay) / (b * b);
	var bres = (bx * bx) / (a * a) + (by * by) / (b * b);
	//console.log(ares);
	if((ares > 1 && bres <= 1) || (ares <= 1 && bres > 1))
	{
		return true;
	}
	return false;
};

EllipseGraphic.prototype.calcGraphicRect = function()
{
	this.rect_x = this.start_pt_x;
	this.rect_y = this.start_pt_y;

	if(this.end_pt_x < this.start_pt_x)
	{
		this.rect_x = this.end_pt_x;
		this.rect_w = this.start_pt_x - this.rect_x;
	}else
	{
		this.rect_w = this.end_pt_x - this.start_pt_x;
	}

	if(this.end_pt_y < this.start_pt_y)
	{
		this.rect_y = this.end_pt_y;
		this.rect_h = this.start_pt_y - this.rect_y;
	}else
	{
		this.rect_h = this.end_pt_y - this.start_pt_y;

	}
};

EllipseGraphic.prototype.hitTest = function(x, y)
{
	var gLeft = this.rect_x;
	var gRight = this.rect_x + this.rect_w;
	var gTop = this.rect_y;
	var gBottom = this.rect_y + this.rect_h;
	if(x > gRight || x < gLeft || y > gBottom || y < gTop)
	{
		return false;
	}
	return true;
};

EllipseGraphic.prototype.setZorderIndex = function(index)
{
	this.zorderIndex = index;
}

EllipseGraphic.prototype.getZorderIndex = function(index)
{
	return this.zorderIndex;
}

EllipseGraphic.prototype.render = function()
{
	systemCanvasContext.save();
	var radius;
	if(this.rect_h < this.rect_w)
	{
		radius = this.rect_w / 2;
	}else{
		radius = this.rect_h / 2;
	}

	systemCanvasContext.beginPath();
	systemCanvasContext.lineWidth = this.line_width;

	// if(this.rect_w < this.rect_h)
	// {
	// 	systemCanvasContext.scale(this.rect_w/this.rect_h, 1);
	// }
	// else if (this.rect_w > this.rect_h)
	// {
	// 	systemCanvasContext.scale(1, this.rect_h/this.rect_w);		
	// }
	// else
	// {
	// 	systemCanvasContext.scale(1, 1);
	// }

	systemCanvasContext.ellipse(this.rect_x + this.rect_w / 2, this.rect_y + this.rect_h / 2, 
		this.rect_w / 2, this.rect_h / 2,0,  0, 2 * Math.PI);
	systemCanvasContext.closePath();
	systemCanvasContext.strokeStyle = this.line_color;
	if(this.is_filled)
	{
		systemCanvasContext.fillStyle = this.line_color;
		systemCanvasContext.fill();
	}
	systemCanvasContext.stroke();

	systemCanvasContext.restore();

	if(!this.is_selected)
		return;
	systemCanvasContext.save();
	systemCanvasContext.strokeStyle = "#64cb23";
	systemCanvasContext.strokeRect(this.rect_x, this.rect_y, this.rect_w, this.rect_h);
	systemCanvasContext.restore();
};
