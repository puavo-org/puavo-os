

function ImageGraphic(image)
{
	this.rect_x = 0;
	this.rect_y = 0;
	this.rect_w = 0;
	this.rect_h = 0;
	this.centerX = 0;
	this.centerY = 0;
	this.parent_canvas_model = null;
	this.image = image;
	this.is_selected = false;
	this.rect_is_calc = false;
	this.zorderIndex = -1;
};

ImageGraphic.prototype.getType = function()
{
	return "ImageGraphic";
};

ImageGraphic.prototype.setParentCanvasModel = function(canvas_model)
{
	this.parent_canvas_model = canvas_model;
	if(!this.rect_is_calc)
	{
		this.calcGraphicRect();
		this.rect_is_calc = true;
	}
};

ImageGraphic.prototype.setSelected = function(selected)
{
	this.is_selected = selected;
};

ImageGraphic.prototype.isSelected = function()
{
	return this.is_selected;
};

ImageGraphic.prototype.move = function(dx , dy)
{
	this.rect_x += dx;
	this.rect_y += dy;
	this.centerX =  this.rect_x + (this.rect_w / 2);
	this.centerY =  this.rect_y + (this.rect_h / 2);
};

ImageGraphic.prototype.moveToCenter = function()
{
	if(this.centerX == 0 && this.centerY == 0)
	{
		this.centerX =  this.rect_x + (this.rect_w / 2);
		this.centerY =  this.rect_y + (this.rect_h / 2);
	}
	this.rect_x =  this.centerX - (this.rect_w / 2);
	this.rect_y =  this.centerY - (this.rect_h / 2);
};

ImageGraphic.prototype.setStartPoint = function(x, y)
{
	this.start_pt_x = x;
	this.start_pt_y = y;
};

ImageGraphic.prototype.setEndPoint = function(x, y)
{
	this.end_pt_x = x;
	this.end_pt_y = y;
};

ImageGraphic.prototype.calcIsSelected = function(x, y, w, h)
{
	var gLeft = this.rect_x;
	var gRight = this.rect_x + this.rect_w;
	var gTop = this.rect_y;
	var gBottom = this.rect_y + this.rect_h;
	var l = x;
	var r = x + w;
	var t = y;
	var b = y + h;
	if(b < gTop || r < gLeft|| l > gRight || t > gBottom)
		return false;
	return true;
};

ImageGraphic.prototype.calcGraphicRect = function()
{
	this.rect_x = 0;
	this.rect_y = 0;
	this.rect_w = this.image.width;
	this.rect_h = this.image.height;
};

ImageGraphic.prototype.eraseTest = function(ax, ay, bx, by)
{
	return this.hitTest(bx, by);
};

ImageGraphic.prototype.hitTest = function(x, y)
{
	var gLeft = this.rect_x;
	var gRight = this.rect_x + this.rect_w;
	var gTop = this.rect_y;
	var gBottom = this.rect_y + this.rect_h;
	if(x > gRight || x < gLeft || y > gBottom || y < gTop)
	{
		return false;
	}
	return true;
};

ImageGraphic.prototype.scale = function(px , py, cx, cy, from)
{
    var ratio = this.rect_w / this.rect_h;
	this.moveToCenter();
	if(Math.abs(this.centerX - cx) == 0 ||  Math.abs(this.centerY - cy) == 0)
	{
		return;
	}
	if((cx < px && cy < py) || (cx > px && cy <py))
	{
		if(this.rect_w > this.rect_h)
		{
			this.rect_w = Math.abs(this.centerX - cx)*2;
			this.rect_h = Math.abs((this.centerX - cx)*2 / ratio);
		}
		else
		{
			this.rect_w = Math.abs(this.centerY - cy) * 2 * ratio;
			this.rect_h = Math.abs(this.centerY - cy) * 2;
		}
	}
	else if((cx > px && cy > py) || cx < px && cy > py)
	{
		if(this.rect_w > this.rect_h)
		{
			this.rect_w = Math.abs(this.centerX - cx)*2;
			this.rect_h = Math.abs((this.centerX - cx)*2 / ratio);
		}
		else
		{
			this.rect_w = Math.abs(this.centerY - cy) * 2 * ratio;
			this.rect_h = Math.abs(this.centerY - cy) * 2;
		}
	}	
};

ImageGraphic.prototype.setZorderIndex = function(index)
{
	this.zorderIndex = index;
}

ImageGraphic.prototype.getZorderIndex = function(index)
{
	return this.zorderIndex;
}

ImageGraphic.prototype.render = function()
{
	systemCanvasContext.save();
	systemCanvasContext.drawImage(this.image, this.rect_x, this.rect_y, this.rect_w, this.rect_h);
	systemCanvasContext.restore();
	
	if(!this.is_selected)
		return;
	systemCanvasContext.save();
	systemCanvasContext.strokeStyle = "#64cb23";
	systemCanvasContext.strokeRect(this.rect_x, this.rect_y, this.rect_w, this.rect_h);
	systemCanvasContext.restore();
};