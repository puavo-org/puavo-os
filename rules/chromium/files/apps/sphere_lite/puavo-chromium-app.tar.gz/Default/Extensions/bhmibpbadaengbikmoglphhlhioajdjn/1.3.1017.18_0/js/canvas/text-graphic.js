// lg for Line graphic prefix

function TextGraphic()
{
	this.rect_x = 0;
	this.rect_y = 0;
	this.rect_w = 0;
	this.rect_h = 0;
	this.parent_canvas_model = null;
	
	this.is_selected = false;
	this.text_point_size = 20;
	this.rect_is_calc = false;
	this.text = null;
	this.line_color = "#FF0000";
	this.zorderIndex = -1;
	this.fontFamily = '';

	this.italic = "";
	this.bold = '';
	this.underLine = false;
	this.angle = rotate;
	this.mirror = mirror;
	this.ceil = ceil;
	this.nowSize  = $('#canvas').width();
};

TextGraphic.prototype.getType = function()
{
	return "TextGraphic";
}

TextGraphic.prototype.setFontSize = function(size)
{
	this.text_point_size = size;
};

TextGraphic.prototype.setTextFontFamily = function(fontFamily)
{
	this.fontFamily = fontFamily;
}

TextGraphic.prototype.setLineColor = function(color)
{
	this.line_color = color;
};

TextGraphic.prototype.setTextPosition = function(x, y)
{
	this.rect_x = x;
	this.rect_y = y;
};

TextGraphic.prototype.setText = function(string)
{
	this.text = string;
};

TextGraphic.prototype.setItalic = function(TorF)
{
	if (TorF === true)
		this.italic = "italic";
	else
		this.italic = "";
}

TextGraphic.prototype.setBold = function(TorF)
{
	if (TorF === true)
		this.bold = "bold";
	else
		this.bold = "";
}

TextGraphic.prototype.setUnderLine = function(TorF)
{
	this.underLine = TorF;
}

TextGraphic.prototype.setParentCanvasModel = function(canvas_model)
{
	this.parent_canvas_model = canvas_model;
	if(!this.rect_is_calc)
	{
		this.calcGraphicRect();
		this.calcPointsToGraphicCoor();
		this.rect_is_calc = true;
	}
};

TextGraphic.prototype.setSelected = function(selected)
{
	this.is_selected = selected;
};

TextGraphic.prototype.isSelected = function()
{
	return this.is_selected;
};

TextGraphic.prototype.move = function(dx , dy)
{
	this.rect_x += dx;
	this.rect_y += dy;
};

TextGraphic.prototype.setStartPoint = function(x, y)
{
	this.start_pt_x = x;
	this.start_pt_y = y;
};

TextGraphic.prototype.calcIsSelected = function(x, y, w, h)
{
	var gLeft = this.rect_x;
	var gRight = this.rect_x + this.rect_w;
	var gTop = this.rect_y;
	var gBottom = this.rect_y + this.rect_h;
	var l = x;
	var r = x + w;
	var t = y;
	var b = y + h;
	if(b < gTop || r < gLeft|| l > gRight || t > gBottom)
		return false;
	return true;
};

TextGraphic.prototype.calcGraphicRect = function()
{
	systemCanvasContext.save();
	systemCanvasContext.font = this.italic + " " + this.bold +' '+this.text_point_size + 'px '+this.fontFamily;
	systemCanvasContext.textBaseline = "Top";
	systemCanvasContext.fillStyle = this.text_color;
	var metrics = systemCanvasContext.measureText(this.text);
    this.rect_w = metrics.width;
	this.rect_h = parseInt(this.text_point_size, 10);
	systemCanvasContext.restore();
};

TextGraphic.prototype.calcPointsToGraphicCoor = function()
{
};

TextGraphic.prototype.eraseTest = function(ax, ay, bx, by)
{
//	ax -= this.rect_x;
//	ay -= this.rect_y;
//	bx -= this.rect_x;
//	by -= this.rect_y;
	
	var gLeft = this.rect_x;
	var gRight = this.rect_x + this.rect_w;
	var gTop = this.rect_y;
	var gBottom = this.rect_y + this.rect_h;
	
	var doErase = false;
	doErase |= isIntersected(gLeft, gTop, gRight, gTop, ax, ay, bx, by);
	doErase |= isIntersected(gLeft, gTop, gLeft, gBottom, ax, ay, bx, by);
	doErase |= isIntersected(gRight, gTop, gRight, gBottom, ax, ay, bx, by);
	doErase |= isIntersected(gLeft, gBottom, gRight, gBottom, ax, ay, bx, by);

	return doErase;
};

TextGraphic.prototype.hitTest = function(x, y)
{
	var gLeft = this.rect_x;
	var gRight = this.rect_x + this.rect_w;
	var gTop = this.rect_y;
	var gBottom = this.rect_y + this.rect_h;
	if(x > gRight || x < gLeft || y > gBottom || y < gTop)
	{
		return false;
	}
	return true;
};

TextGraphic.prototype.setZorderIndex = function(index)
{
	this.zorderIndex = index;
}

TextGraphic.prototype.getZorderIndex = function(index)
{
	return this.zorderIndex;
}

TextGraphic.prototype.render = function()
{
	systemCanvasContext.save();
	systemCanvasContext.font = this.italic + " " + this.bold +' '+this.text_point_size+ 'px '+this.fontFamily;
	systemCanvasContext.textBaseline = "top";
	systemCanvasContext.fillStyle = this.line_color;
	systemCanvasContext.translate(this.rect_x, this.rect_y);
	
	if (this.mirror == -1 && this.ceil == 1) {
		systemCanvasContext.scale(-1, 1);
	} else if (this.mirror == 1 && this.ceil == -1) {
		systemCanvasContext.scale(1, -1);
	} else if (this.mirror == -1 && this.ceil == -1) {
		systemCanvasContext.scale(-1, -1);
	} else {
		systemCanvasContext.scale(1, 1);
	}
	
	if (this.angle == 0 || this.angle == 180 || this.angle == -180) {
		systemCanvasContext.rotate((this.angle) / 180 * Math.PI);
	} else {
		systemCanvasContext.rotate((this.angle - 180) / 180 * Math.PI);
	}
	
	if(this.text.indexOf('\n') != -1)
	{
		var splitTmp = this.text.split('\n');
		for(var i=0;i<splitTmp.length;++i)
		{
			systemCanvasContext.fillText(splitTmp[i] , 0, 0 + (i * this.text_point_size));
			var metrics = systemCanvasContext.measureText(splitTmp[i]);
			if(this.underLine === true)
			{
				systemCanvasContext.strokeStyle = this.line_color;
				systemCanvasContext.lineWidth = this.text_point_size/10;
				systemCanvasContext.beginPath();
				systemCanvasContext.moveTo(0, ((i+1) *  parseInt(this.text_point_size, 10)));
				systemCanvasContext.lineTo(metrics.width, ((i+1) *  parseInt(this.text_point_size, 10)));
				systemCanvasContext.closePath();
				systemCanvasContext.stroke();
			}
		}
		
	}
	else
	{
		//systemCanvasContext.fillText(this.text , this.rect_x, this.rect_y);
		systemCanvasContext.fillText(this.text , 0, 0);
		if(this.underLine === true)
			{
				var metrics = systemCanvasContext.measureText(this.text);
				systemCanvasContext.strokeStyle = this.line_color;
				systemCanvasContext.lineWidth = this.text_point_size/10;
				systemCanvasContext.beginPath();
				systemCanvasContext.moveTo(0,  parseInt(this.text_point_size, 10));
				systemCanvasContext.lineTo(metrics.width, parseInt(this.text_point_size, 10));
				systemCanvasContext.closePath();
				systemCanvasContext.stroke();
			}
	}
	systemCanvasContext.restore();
	
	if(!this.is_selected)
		return;
	systemCanvasContext.save();
	systemCanvasContext.strokeStyle = "#64cb23";
	systemCanvasContext.strokeRect(this.rect_x, this.rect_y, this.rect_w, this.rect_h);
	systemCanvasContext.restore();
};