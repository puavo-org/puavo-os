
function isIntersected(path_1_s_x, path_1_s_y, path_1_e_x, path_1_e_y, path_2_s_x, path_2_s_y, path_2_e_x, path_2_e_y)
{
	var ax = path_1_e_x - path_1_s_x;
	var ay = path_1_e_y - path_1_s_y;
	var bx = path_2_s_x - path_2_e_x;
	var by = path_2_s_y - path_2_e_y;
	
	var cx = path_1_s_x - path_2_s_x;
	var cy = path_1_s_y - path_2_s_y;
	
	var coeff = 1. / (ay * bx - ax * by);
	var a = (by * cx - bx * cy) * coeff;
	var b = (ax * cy - ay * cx) * coeff;
	if ((-(1e-6) < a && a < (1.+(1e-6))) && (-(1e-6) < b && b < (1.+(1e-6))))
	{
		return true;
	}
	return false;
};
