

function TextTool(editor, cView)
{
	//lt_m_canvas_editor = lt_constructor_p_canvas_editor;
	this.is_editing = false;
	this.debug_name = "text tool";
	this.textArea = document.getElementById('text_tool_textarea');
	this.line_color = "#FF0000";
	this.text_font_size = 20;
	this.new_text_graphic = null;
	this.canvasEditor = editor;
	this.canvasView = cView;
	this.fontFamily = 'Arial';
	this.isItalic = false;
	this.isBold = false;
	this.isUnderLine = false;
}

TextTool.prototype.getName = function()
{
	return this.debug_name;
};

TextTool.prototype.setLineColor = function(color)
{
	this.line_color = color;
};

TextTool.prototype.getLineColor = function(color)
{
	return this.line_color;
};

TextTool.prototype.setTextFontSize = function(size)
{
	this.text_font_size = size;
};
TextTool.prototype.setTextFontFamily = function(font)
{
	this.fontFamily = font;
}
TextTool.prototype.setItalic = function(TorF)
{
	this.isItalic = TorF;
}
TextTool.prototype.setBold = function(TorF)
{
	this.isBold = TorF;
}
TextTool.prototype.setUnderLine = function(TorF)
{
	this.isUnderLine = TorF;
}
TextTool.prototype.forceCloseTextEditor = function()
{
	if(this.is_editing)
	{
		this.textArea.style.display = "none";
		this.textArea.rows =1;
		this.is_editing = false;
		this.new_text_graphic.setText(this.textArea.value);
		this.new_text_graphic.setLineColor(this.line_color);
		this.new_text_graphic.setFontSize(this.text_font_size);
		this.new_text_graphic.setTextFontFamily(this.fontFamily);
		this.new_text_graphic.setItalic(this.isItalic);
		this.new_text_graphic.setBold(this.isBold);
		this.new_text_graphic.setUnderLine(this.isUnderLine);
		this.canvasEditor.addGraphicToActiveCanvas(this.new_text_graphic);
		this.textArea.value = null;
		this.new_text_graphic = null;
		this.canvasEditor.askViewToRedraw();
	}
};


TextTool.prototype.annoToolAnnotationStart = function(x, y)
{
	if(this.is_editing)
	{
		this.textArea.style.display = "none";
		this.textArea.rows =1;
		this.is_editing = false;
		this.new_text_graphic.setText(this.textArea.value);
		this.new_text_graphic.setLineColor(this.line_color);
		this.new_text_graphic.setFontSize(this.text_font_size);
		this.new_text_graphic.setTextFontFamily(this.fontFamily);
		this.new_text_graphic.setItalic(this.isItalic);
		this.new_text_graphic.setBold(this.isBold);
		this.new_text_graphic.setUnderLine(this.isUnderLine);
		this.canvasEditor.addGraphicToActiveCanvas(this.new_text_graphic);
		this.textArea.value = null;
		this.new_text_graphic = null;
		this.canvasEditor.askViewToRedraw();
		return;
	}
	this.is_editing = true;

	this.textArea.style.position = "absolute";
	var uiX = 0;
	var uiY = 0;
	
	if (event.constructor.name === "MouseEvent") {
		uiX = event.pageX - 3;
		uiY = event.pageY - 3;
	} else {
		uiX = event.changedTouches[0].pageX - 3;
		uiY = event.changedTouches[0].pageY - 3;
	}
	
	this.new_text_graphic = new TextGraphic();
	this.new_text_graphic.setTextPosition(x, y);
	this.textArea.style.background = "rgba(0,0,0,0.1)";
	this.textArea.style.top = uiY + "px";
	this.textArea.style.left = uiX + "px";
	this.textArea.style.display = "block";
	this.textArea.style.fontSize = this.text_font_size + "px";
	this.textArea.style.fontFamily = this.fontFamily;
	this.textArea.style.color = this.line_color;
};

TextTool.prototype.annoToolAnnotationMove = function(x, y)
{

};

TextTool.prototype.annoToolAnnotationStop = function(x, y)
{
	this.textArea.focus();
};

TextTool.prototype.render = function()
{
	//if(!this.is_painting)
	//{
	//	return;
	//}
	//this.new_line_graphic.render();
};
