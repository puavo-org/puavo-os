
function EraserTool(editor)
{
	this.prev_pt_x = 0;
	this.prev_pt_y = 0;
	this.cur_pt_x = 0;
	this.cur_pt_y = 0;
	this.left = 0;
	this.top = 0;
	this.width = 15;
	this.height = 15;
	this.is_painting = false;
	this.canvasEditor = editor;
};

EraserTool.prototype.annoToolAnnotationStart = function(x, y)
{
	this.prev_pt_x = x;
	this.prev_pt_y = y;
	this.cur_pt_x = x;
	this.cur_pt_y = y;
	this.left = x;
	this.top = y;
	this.is_painting = true;
	this.canvasEditor.askViewToRedraw();
};

EraserTool.prototype.annoToolAnnotationMove = function(x, y)
{
	this.prev_pt_x = this.cur_pt_x;
	this.prev_pt_y = this.cur_pt_y;
	this.cur_pt_x = x;
	this.cur_pt_y = y;
	this.left = x;
	this.top = y;
	var all_graphics = this.canvasEditor.getActiveCanvasModel().getAllGraphics();
	for(var index = all_graphics.length - 1; index >= 0; --index)
	{
		if(all_graphics[index].eraseTest(this.prev_pt_x, this.prev_pt_y, this.cur_pt_x, this.cur_pt_y))
		{
			this.canvasEditor.removeGraphicFromActiveCanvas(all_graphics[index]);
			break;
		}
	}

	this.canvasEditor.askViewToRedraw();
};

EraserTool.prototype.annoToolAnnotationStop = function(x, y)
{
	this.is_painting = false;
	this.canvasEditor.askViewToRedraw();
};

EraserTool.prototype.render = function()
{
	if(this.is_painting == false)
		return;
	
	systemCanvasContext.save();
	systemCanvasContext.strokeStyle = "#64cb23";
	systemCanvasContext.strokeRect(this.left - 7, this.top - 7, this.width, this.height);
	systemCanvasContext.restore();
};