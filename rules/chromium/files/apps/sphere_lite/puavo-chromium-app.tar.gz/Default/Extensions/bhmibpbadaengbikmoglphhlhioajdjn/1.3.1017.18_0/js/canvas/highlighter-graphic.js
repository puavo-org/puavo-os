/*------------------------------------------------------------------------------------------------------------*
 *                                                                                                            *
 * Copyright      2013 AVer Information Inc.                                                                  *
 *                                                                                                            *
 *------------------------------------------------------------------------------------------------------------*
 * PROJECT     :  ClassCast                                                                                   *
 * BINARY NAME :                                                                                              *
 * FILE NAME   :  js/highlighter-graphic.js                                                                        *
 * CREATED BY  :  Ted Wu                                                                                   *
 * CREATED DATE:  1/10/13 (MM/DD/YY)                                                                         *
 *------------------------------------------------------------------------------------------------------------*/

/*!
 * @file
 * @author  Ted Wu <Ted.Wu@aver.com>
 * @version 1.0
 *
 * @section DESCRIPTION
 * fhg for highlighter graphic prefix
 */

function HighlighterGraphic()
{
	FreehandGraphic.call(this);	
	this.debug_name = "HighlighterGraphic";
	this.cachedImg = new Image();
	this.isImageRegenerated = false;
	this.isHasRetangle = false;
};

HighlighterGraphic.prototype = new FreehandGraphic();
HighlighterGraphic.prototype.constructor = HighlighterGraphic;

HighlighterGraphic.prototype.render = function()
{	
	//When editing no render
	if(this.isEditing)
	{
		this.isImageRegenerated = false;
		this.isHasRetangle = false;
		this._render(systemCanvasContext);
	}
	else
	{
		//Create a temp canvas in memory
		if(!(this.isImageRegenerated))
		{
			tmpCanvasContext = document.createElement('canvas');
			tmpCanvasContext.setAttribute('width', window.outerWidth);
			tmpCanvasContext.setAttribute('height', window.outerHeight - 113);
			tmpCanvasContext.style.position = "absolute";
			tmpCanvasContext.style.top = "0px";
			tmpCanvasContext.style.left = "113px";
			tmpCanvas = tmpCanvasContext.getContext("2d");
			this._render(tmpCanvas);
			this.cachedImg.src = tmpCanvasContext.toDataURL("image/png");
			this.isImageRegenerated = true;
		}
		systemCanvasContext.save();

		var t = this.cachedImg;
		if (this.cachedImg.complete){
			systemCanvasContext.globalAlpha = 0.4;
			systemCanvasContext.drawImage(t,0,0);
			systemCanvasContext.restore();
		}else{
			setTimeout(function(){
			systemCanvasContext.globalAlpha = 0.4;
			systemCanvasContext.drawImage(t,0,0);
			systemCanvasContext.restore();
			},1);	
		}

		if(!this.is_selected)
		return;
		systemCanvasContext.save();
		systemCanvasContext.strokeStyle = "#64cb23";
		systemCanvasContext.strokeRect(this.rect_x, this.rect_y, this.rect_w, this.rect_h);
		this.isHasRetangle = true;
		systemCanvasContext.restore();
	}
}