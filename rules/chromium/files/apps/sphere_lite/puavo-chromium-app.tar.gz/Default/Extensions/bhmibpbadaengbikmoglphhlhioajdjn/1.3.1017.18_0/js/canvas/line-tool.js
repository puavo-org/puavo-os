
function LineTool(editor)
{
	//lt_m_canvas_editor = lt_constructor_p_canvas_editor;
	this.is_painting = false;
	this.debug_name = "Line tool";
	this.new_line_graphic = null;
	this.line_color = "#FF0000";
	this.arrow_type = 0;
	this.dash_line = false;
	this.line_width = 3;
	this.canvasEditor = editor;
}

LineTool.prototype.getName = function()
{
	return this.debug_name;
};

LineTool.prototype.setLineWidth = function(width)
{
	this.line_width = width;
};

LineTool.prototype.getLineWidth = function()
{
	return this.line_width;
};

LineTool.prototype.setLineColor = function(color)
{
	this.line_color = color;
};

LineTool.prototype.getLineColor = function()
{
	return this.line_color;
};

LineTool.prototype.setArrowType = function(type)
{
	this.arrow_type = type;
};

LineTool.prototype.getArrowType = function()
{
	return this.arrow_type;
}

LineTool.prototype.setDashLine = function(TorF)
{
	this.dash_line = TorF;
}

LineTool.prototype.getDashLine = function(TorF)
{
	return this.dash_line;
}

LineTool.prototype.annoToolAnnotationStart = function(x, y)
{
	this.is_painting = true;
	this.new_line_graphic = new LineGraphic();
	this.new_line_graphic.setLineWidth(this.line_width);
	this.new_line_graphic.setLineColor(this.line_color);
	this.new_line_graphic.setStartPoint(x, y);
	this.new_line_graphic.setArrowType(this.arrow_type);
	this.new_line_graphic.setDashLine(this.dash_line);
};

LineTool.prototype.annoToolAnnotationMove = function(x, y)
{
	if(this.is_painting == false)
		return;
	this.new_line_graphic.setEndPoint(x, y);
	this.canvasEditor.askViewToRedraw();
};

LineTool.prototype.annoToolAnnotationStop = function(x, y)
{
	this.is_painting = false;
	this.new_line_graphic.setEndPoint(x, y);
	this.canvasEditor.addGraphicToActiveCanvas(this.new_line_graphic);
	this.new_line_graphic = null;
	this.canvasEditor.askViewToRedraw();
};

LineTool.prototype.render = function()
{
	if(!this.is_painting)
	{
		return;
	}
	this.new_line_graphic.render();	
};