// JavaScript Document
var myNoteImpl = parent.myNoteImpl;

var now = Date.now;
var time;
var convertVal = 0;

var progressTimer = "";

var script = null;
var pnacl = null;

function concatVideo(curIndex, convertTime, progress, _convertVal)
{
	parent.mergeContent.onload = null;
	parent.mergeContent.src = "";
	
	console.log('!!! Prepare concatVideo() !!!');
	
	var listData = "";
	for(var i = 0 ; i < curIndex ; i++)
	{
		listData = listData + "file 'output" + i + ".mkv'\n";
	}
			
	myNoteImpl.addVideo("/tmp", "file.txt", new Blob([listData]), function() {
			script = document.createElement('embed');
			script.id = 'pnacl';
			script.width = 0;
			script.height = 0;
			script.src = '../ffmpeg.nmf';
			script.type = 'application/x-pnacl';
			script.setAttribute('ps_stdout', 'dev/tty');
			script.setAttribute('ps_stderr', 'dev/tty');
			script.setAttribute('ps_tty_prefix', '');
			script.setAttribute('arg0', 'ffmpeg');
			script.setAttribute('arg1', '-y');
			/*document.write("<embed id='pnacl' width='0' height='0'");
			document.write("ps_stdout='dev/tty'");
			document.write("ps_stderr='dev/tty'");
			document.write("ps_tty_prefix= ''");
			document.write("arg0='ffmpeg'");
			document.write("arg1='-y'");*/
			
			var n = 2;
			var out_file = 'a.out';
			var args = '-f concat -i file.txt -c copy '+parent.fileName+'';
			console.log((new Date ()).toLocaleTimeString() + ' ' + args);
			//var args = window.location.search.substr(1);
			//args = decodeURIComponent(args);
			args.split('"').forEach(function(t, i) {
				t = t.trim();
				if ((i % 2) === 1) {
				script.setAttribute("arg"+n, t);
				//document.write("arg"+n+"='"+t+"'");
				out_file = t;
				n++;
				} else {
					t = t.replace(/\s+/g, ' ');
				t.split(" ").forEach(function(x,j,ao) {
					x = x.trim();
					if(j==(ao.length-1)) {
					if(x=='/dev/null') x = 'dev_null';
					}
					script.setAttribute("arg"+n, x);
					//document.write("arg"+n+"='"+x+"'");
					out_file = x;
					n++;
				});
				}
			});
			//document.write("></embed>");
			
			//var pnacl = document.getElementById("pnacl");
			pnacl = script;
			
			function updateStatus(msg) {
				console.log((new Date ()).toLocaleTimeString() + ' ' + msg);
				if(msg == 'Success!')
				{
					convertVal = _convertVal + (100 / progress);
					if(convertVal >= 100)
					{
						convertVal = 100;
					}
					parent.mainContent.contentWindow.setProgressValue(convertVal);
				}
			}

			function eventStatus(status) {
				return function () {
				updateStatus(status);
				}
			}

			function eventProgress(event) {
				var loadPercent = 0.0;
				var loadPercentString;
				if (event.lengthComputable && event.total > 0) {
				loadPercent = event.loaded / event.total * 100.0;
				loadPercentString = Math.round(loadPercent) + '%';
				updateStatus('Loading...' + loadPercentString);
				} else {
				updateStatus('Loading...');
				}
			}	

			function eventRunning() {
				updateStatus("Running");
				time = now();
			}
			pnacl.addEventListener('loadstart', eventStatus("Load Start"));
			pnacl.addEventListener('progress', eventProgress);
			pnacl.addEventListener('load', eventStatus("load"));
			pnacl.addEventListener('error', eventStatus("error"+pnacl.lastError));
			pnacl.addEventListener('abort', eventStatus("abort"+pnacl.lastError));
			pnacl.addEventListener('loadend', eventRunning);
			pnacl.addEventListener('message', function (ev) {
				if(ev.data.match(/^Libavutil has been linked to a broken llrint/)) return;
				if(ev.data.match(/^frame=/) || ev.data.match(/^size=/)) {
				var ti = ev.data.match(/time=..:..:../);
				//if(document.cform.ctext.value != ti) document.cform.ctext.value = ti;
				//console.log((new Date ()).toLocaleTimeString() + ' ' + ti);
				}
				//if((ev.data.match(/^frame=/) || ev.data.match(/^size=/))&& disable_stats) return;
				//if(ev.data.match(/^[ ,\n,\r]*$/)  && disable_stats) return;
				//var output = document.getElementById("output");
				//output.textContent += ev.data;*/
				console.log((new Date ()).toLocaleTimeString() + ' ' + ev.data);
			});

			pnacl.addEventListener('crash', function () {
				var totalTime = now() - time - 1000;
				if(totalTime<0) totalTime += 1000;
				totalTime = Math.round(totalTime/1000);
				if(pnacl.exitStatus == 0) {
				//var output = document.getElementById("output");
				//output.textContent += 'Finished processing (took ' + totalTime + 's)'
				updateStatus('Finished processing (took ' + totalTime + 's)');		
				updateStatus('Success!');
						//var downlink = document.createElement('a');
					//downlink.href = "filesystem:http://"+location.host+"/persistent/sphereLiteUser/"+out_file;
						//downlink.download = out_file;
						//downlink.innerHTML = "<button>Download</button>";
					//objDownload.appendChild(downlink);
					//var objDownload = document.getElementById('download');
					
					script.src = "";
					script.remove();
					pnacl = null;
					delete script;
					script = null;
					
					myNoteImpl.copyVideo("/tmp", parent.fileName, "/sphereLiteUser", parent.fileName, function()
					{
						myNoteImpl.deleteDirectory("/tmp");
						
						var finalTime = now() - convertTime - 1000;
						if(finalTime<0) finalTime += 1000;
						finalTime = Math.round(finalTime/1000);
						console.log((new Date ()).toLocaleTimeString() + ' finalTime: ' + finalTime + 's');
						progressTimer = setTimeout(function(){
							parent.mainContent.contentWindow.clearProgressValue();
							parent.isMerging = false;
							convertVal = 0;
							parent._convertVal = 0;
							parent.progress = 0;
							parent.fileName = "";
							if(progressTimer)
							{
								clearTimeout(progressTimer);
							}
							parent.concatContent.onload = null;
							parent.concatContent.src = "";
						}, 1000);
					});
				} else {
					updateStatus("Exit code:"+pnacl.exitStatus);
					
					script.src = "";
					script.remove();
					pnacl = null;
					delete script;
					script = null;
				}
			});
			
			document.getElementsByTagName("body")[0].appendChild(script);
	});
}