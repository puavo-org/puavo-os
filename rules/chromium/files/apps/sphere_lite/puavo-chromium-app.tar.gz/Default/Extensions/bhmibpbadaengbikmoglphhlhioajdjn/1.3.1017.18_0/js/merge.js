// JavaScript Document
var myNoteImpl = parent.myNoteImpl;

var curIndex = 0;
var now = Date.now;
var time;
var convertTime;
var arrLength = 0;
var convertVal = 0;
var _convertVal = 0;
var totalTime = 0;

var micVolume = 100;

var allBlobs = [];

var progress = 0;
var progressTimer = "";

var convertTimer = "";
var concatTimer = "";
var script = null;
var pnacl = null;

function convertStreams(vBlob, aBlob)
{
	if(parent.vBlobsArr.length != 0 && parent.aBlobsArr.length != 0)
	{
		parent.vBlobsArr.shift();
		parent.aBlobsArr.shift();
	}
	
	myNoteImpl.addVideo("/tmp", "vBlob.webm", vBlob, function() {
		delete vBlob;
		vBlob = null;
		
		myNoteImpl.addVideo("/tmp", "aBlob.wav", aBlob, function() {
			delete aBlob;
			aBlob = null;
	
			script = document.createElement('embed');
			script.id = 'pnacl';
			script.width = 0;
			script.height = 0;
			script.src = '../ffmpeg.nmf';
			script.type = 'application/x-pnacl';
			script.setAttribute('ps_stdout', 'dev/tty');
			script.setAttribute('ps_stderr', 'dev/tty');
			script.setAttribute('ps_tty_prefix', '');
			script.setAttribute('arg0', 'ffmpeg');
			script.setAttribute('arg1', '-y');
			/*document.write("<embed id='pnacl' width='0' height='0'");
			document.write("ps_stdout='dev/tty'");
			document.write("ps_stderr='dev/tty'");
			document.write("ps_tty_prefix= ''");
			document.write("arg0='ffmpeg'");
			document.write("arg1='-y'");*/
			
			var n = 2;
			var out_file = 'a.out';
			
			var args = '-i vBlob.webm -i aBlob.wav -vcodec copy -acodec copy -ac 1 output'+curIndex+'.mkv'; //sphereLiteUser
			console.log((new Date ()).toLocaleTimeString() + ' ' + args);
			curIndex++;
			//var args = window.location.search.substr(1);
			//args = decodeURIComponent(args);
			args.split('"').forEach(function(t, i) {
				t = t.trim();
				if ((i % 2) === 1) {
				script.setAttribute("arg"+n, t);
				//document.write("arg"+n+"='"+t+"'");
				out_file = t;
				n++;
				} else {
					t = t.replace(/\s+/g, ' ');
				t.split(" ").forEach(function(x,j,ao) {
					x = x.trim();
					if(j==(ao.length-1)) {
					if(x=='/dev/null') x = 'dev_null';
					}
					script.setAttribute("arg"+n, x);
					//document.write("arg"+n+"='"+x+"'");
					out_file = x;
					n++;
				});
				}
			});
			//document.write("></embed>");
			
			//var pnacl = document.getElementById("pnacl");
			pnacl = script;
			
			function updateStatus(msg) {
				console.log((new Date ()).toLocaleTimeString() + ' ' + msg);
				if(msg == 'Success!')
				{
					convertVal = _convertVal + (100 / progress);
					if(convertVal >= 100)
					{
						convertVal = 100;
					}
					parent.mainContent.contentWindow.setProgressValue(convertVal);
					_convertVal = convertVal;
				}
			}

			function eventStatus(status) {
				return function () {
				updateStatus(status);
				}
			}

			function eventProgress(event) {
				var loadPercent = 0.0;
				var loadPercentString;
				if (event.lengthComputable && event.total > 0) {
				loadPercent = event.loaded / event.total * 100.0;
				loadPercentString = Math.round(loadPercent) + '%';
				updateStatus('Loading...' + loadPercentString);
				} else {
				updateStatus('Loading...');
				}
			}	

			function eventRunning() {
				updateStatus("Running");
				time = now();
			}
			pnacl.addEventListener('loadstart', eventStatus("Load Start"));
			pnacl.addEventListener('progress', eventProgress);
			pnacl.addEventListener('load', eventStatus("load"));
			pnacl.addEventListener('error', eventStatus("error"+pnacl.lastError));
			pnacl.addEventListener('abort', eventStatus("abort"+pnacl.lastError));
			pnacl.addEventListener('loadend', eventRunning);
			pnacl.addEventListener('message', function (ev) {
				if(ev.data.match(/^Libavutil has been linked to a broken llrint/)) return;
				if(ev.data.match(/^frame=/) || ev.data.match(/^size=/)) {
				var ti = ev.data.match(/time=..:..:../);
				//if(document.cform.ctext.value != ti) document.cform.ctext.value = ti;
				//console.log((new Date ()).toLocaleTimeString() + ' ' + ti);
				}
				//if((ev.data.match(/^frame=/) || ev.data.match(/^size=/))&& disable_stats) return;
				//if(ev.data.match(/^[ ,\n,\r]*$/)  && disable_stats) return;
				//var output = document.getElementById("output");
				//output.textContent += ev.data;
				console.log((new Date ()).toLocaleTimeString() + ' ' + ev.data);
			});

			pnacl.addEventListener('crash', function () {
				myNoteImpl.deleteVideo("/tmp", "vBlob.webm");
				myNoteImpl.deleteVideo("/tmp", "aBlob.wav");
				
				var totalTime = now() - time - 1000;
				if(totalTime<0) totalTime += 1000;
				totalTime = Math.round(totalTime/1000);
				if(pnacl.exitStatus == 0) {
				//var output = document.getElementById("output");
				//output.textContent += 'Finished processing (took ' + totalTime + 's)'
				updateStatus('Finished processing (took ' + totalTime + 's)');		
				updateStatus('Success!');
						//var downlink = document.createElement('a');
					//downlink.href = "filesystem:http://"+location.host+"/persistent/sphereLiteUser/"+out_file;
						//downlink.download = out_file;
						//downlink.innerHTML = "<button>Download</button>";
					//objDownload.appendChild(downlink);
					//var objDownload = document.getElementById('download');
					
					if(parent.vBlobsArr.length != 0 && parent.aBlobsArr.length != 0)
					{
						script.src = "";
						script.remove();
						pnacl = null;
						delete script;
						script = null;
						
						console.log((new Date ()).toLocaleTimeString() + ' ' + curIndex + '/' + parent.vBlobsArr.length);
						if(curIndex % 5 != 0)
						{
							convertTimer = setTimeout(function(){
								convertStreams(parent.vBlobsArr[0], parent.aBlobsArr[0]);
								if(convertTimer)
								{
									clearTimeout(convertTimer);
								}
							}, 100);
						}
						else
						{
							convertTimer = setTimeout(function(){
								convertStreams(parent.vBlobsArr[0], parent.aBlobsArr[0]);
								if(convertTimer)
								{
									clearTimeout(convertTimer);
								}
							}, 10000);
						}
					}
					else
					{
						script.src = "";
						script.remove();
						pnacl = null;
						delete script;
						script = null;
						
						//mainContent.contentWindow.clearProgressValue();
						//mainContent.contentWindow.removeFile("video.webm");
						//mainContent.contentWindow.removeFile("audio.wav");
						
				//		PostBlob(allBlobs[0]);
				//		PostBlob(blob);
				//		myNoteImpl.addVideo("sphereLiteUser", fileName, blob);
						//isMerging = false;
						//convertVal = 0;
						//_convertVal = 0;
						delete parent.vBlobsArr;
						parent.vBlobsArr = null;
						delete parent.aBlobsArr;
						parent.aBlobsArr = null;
						
						concatTimer = setTimeout(function(){
							parent.concatContent.onload = function()
							{
								this.contentWindow.concatVideo(curIndex, convertTime, progress, _convertVal);
							}
							parent.concatContent.src = "html/concat.html"
							//concatVideo();
							if(concatTimer)
							{
								clearTimeout(concatTimer);
							}
						}, 10000);
						//allBlobs = [];
					}
				} else {
					updateStatus("Exit code:"+pnacl.exitStatus);
					script.src = "";
					script.remove();
					pnacl = null;
					delete script;
					script = null;
				}
			});
			
			document.getElementsByTagName("body")[0].appendChild(script);
	
		});
	});
}

function prepareConvert()
{
	arrLength = parent.vBlobsArr.length;
	allBlobs = [];
	if(arrLength == 1)
	{
		progress = 1;
	}
	else
	{
		progress = (parent.totalTime / 45) + 1;
	}
	curIndex = 0;
	convertTime = now();
	convertStreams(parent.vBlobsArr[0], parent.aBlobsArr[0]);
}