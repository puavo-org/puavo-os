var selected_graphics = new Array();

function SelectionTool(editor)
{
	this.start_pt_x = 0;
	this.start_pt_y = 0;
	this.end_pt_x = 0;
	this.end_pt_y = 0;
	this.left = 0;
	this.top = 0;
	this.width = 0;
	this.height = 0;
	this.curX = 0;
	this.curY = 0;
	this.preX = 0;
	this.preY = 0;
	this.is_painting = false;
	this.state = "SELECTION";
	this.current_move_undo_item = null;
	this.canvasEditor = editor;
	this.onCorner = false;
};

SelectionTool.prototype.annoToolAnnotationStart = function(x, y)
{
	var clicked_in_selected_graphics = false;
	this.start_pt_x = x;
	this.start_pt_y = y;
	this.end_pt_x = x;
	this.end_pt_y = y;
	this.currX = x;
	this.currY = y;
	this.prevX = x;
	this.prevY = y;
	var index = 0;
	this.state = "SELECTION";
	this.inLeftTopCorner = false;
	this.inRightTopCorner = false;
	this.inLeftDownCorner = false;
	this.inRightDownCorner = false;
	this.onCorner = false;
	
	for(; index < selected_graphics.length; ++index)
	{
		if(selected_graphics[index].hitTest(x, y))
		{
		    this.state = "MOVE";			
		}
	}
	if(this.state != "MOVE")
	{
		var graphics = this.canvasEditor.getActiveCanvasModel().getAllGraphics();
		
		var i = graphics.length - 1;
		for(; i >= 0; --i)
		{
			if(graphics[i].getType() == "ImageGraphic")
			{
				if(graphics[i].hitTest(x, y))
				{
					this.deselectAllGraphics();
					selected_graphics.push(graphics[i]);
					graphics[i].setSelected(true);
					this.state = "MOVE";
					break;
				}
			}
		}
	}
	if(this.state == "MOVE")
	{
		this.current_move_undo_item = new UndoItem();
		this.current_move_undo_item.setType("MOVE");
		this.current_move_undo_item.setGraphicCanvas(this.canvasEditor.getActiveCanvasModel());
		this.current_move_undo_item.startMove();
		index = 0;
		for(; index < selected_graphics.length; ++index)
		{
			this.current_move_undo_item.setGraphic(selected_graphics[index]);
		}
		var i = 0;
		for(; i < selected_graphics.length; ++i)
		{
			if(selected_graphics[i].getType() == "ImageGraphic")
			{
				var iX = selected_graphics[i].rect_x;
				var iY = selected_graphics[i].rect_y;
				var iW = selected_graphics[i].rect_w;
				var iH = selected_graphics[i].rect_h;
				if(Math.abs(x - iX) < 10 && Math.abs(y - iY) < 10 && selected_graphics[i].hitTest(x, y))
				{
					this.onCorner = true;
				}
				else if(Math.abs(x - (iX + iW)) < 10 && (Math.abs(y - iY) < 10) && selected_graphics[i].hitTest(x, y))
				{
					this.onCorner = true;
				}
				else if(Math.abs(x - iX) < 10 && (Math.abs(y - (iY + iH)) < 10) && selected_graphics[i].hitTest(x, y))
				{
					this.onCorner = true;
				}
				else if(Math.abs(x - (iX + iW)) < 10 && (Math.abs(y - (iY + iH)) < 10) && selected_graphics[i].hitTest(x, y))
				{
					this.onCorner = true;
				}
			}
		}
		return;
	}
	
	
	this.calcSelectRect();
	this.deselectAllGraphics();
	this.is_painting = true;
	this.canvasEditor.askViewToRedraw();
};

SelectionTool.prototype.deselectAllGraphics = function()
{
	var index = 0;
	for(; index < selected_graphics.length; ++index)
	{
		selected_graphics[index].setSelected(false);
	}
	selected_graphics.length = 0;
	this.canvasEditor.askViewToRedraw();
};

SelectionTool.prototype.annoToolAnnotationMove = function(x, y)
{
	var dx = x - this.end_pt_x;
	var dy = y - this.end_pt_y;
	this.end_pt_x = x;
	this.end_pt_y = y;
	this.prevX = this.currX;
	this.prevY = this.currY;
	this.currX = x;
	this.currY = y;
	if(this.state == "SELECTION")
	{
		this.calcSelectRect();
		this.selectionTest();
	}
	else if(this.state == "MOVE")
	{
		var index = 0;
		for(; index < selected_graphics.length; ++index)
		{
			if(selected_graphics[index].debug_name == "HighlighterGraphic")
			{
				selected_graphics[index].isEditing = true;
			}
			if(selected_graphics[index].getType() == "ImageGraphic")
			{
				if(this.onCorner)
				{
					selected_graphics[index].scale(this.prevX, this.prevY, this.currX, this.currY);
				}
			}

			if(!this.onCorner)
			{
				selected_graphics[index].move(dx, dy);
			}
		}
		this.current_move_undo_item.updateMovement(dx, dy);
	}
	this.canvasEditor.askViewToRedraw();
};

SelectionTool.prototype.annoToolAnnotationStop = function(x, y)
{
	this.end_pt_x = x;
	this.end_pt_y = y;
	if(this.state == "SELECTION")
	{
		this.calcSelectRect();
		this.selectionTest();
		this.is_painting = false;
	}
	else if(this.state == "MOVE")
	{
		this.current_move_undo_item.endMove();
		this.canvasEditor.getActiveCanvasModel().addToUndoStack(this.current_move_undo_item);
		this.current_move_undo_item = null;
	}
	var index = 0;
	for(; index < selected_graphics.length; ++index)
	{
		selected_graphics[index].isEditing = false;
	}
	this.canvasEditor.askViewToRedraw();
};

SelectionTool.prototype.calcSelectRect = function()
{
	this.left = this.start_pt_x;
	this.width = this.end_pt_x - this.start_pt_x;
	if(this.end_pt_x < this.start_pt_x)
	{
		this.left = this.end_pt_x;
		this.width = this.start_pt_x - this.left;
	}
	this.top = this.start_pt_y;
	this.height = this.end_pt_y - this.start_pt_y;
	if(this.end_pt_y < this.start_pt_y)
	{
		this.top = this.end_pt_y;
		this.height = this.start_pt_y - this.top;
	}
};

SelectionTool.prototype.selectionTest = function()
{
	var graphics = this.canvasEditor.getActiveCanvasModel().getAllGraphics();
	
	var index = graphics.length - 1;
	for(; index >= 0; --index)
	{
		if(graphics[index].calcIsSelected(this.left, this.top, this.width, this.height))
		{
			if(graphics[index].isSelected() == false)
			{
				selected_graphics.push(graphics[index]);
				graphics[index].setSelected(true);
			}
		}
	}
};

SelectionTool.prototype.imageSelected = function(x, y)
{
	var graphics = this.canvasEditor.getActiveCanvasModel().getAllGraphics();
	var index = graphics.length - 1;
	for(; index >= 0; --index)
	{
		if(graphics[index].hitTest(x, y))
		{
			if(graphics[index].isSelected() == false && graphics[index].getType() == "ImageGraphic")
			{
				selected_graphics.push(graphics[index]);
				graphics[index].setSelected(true);
				return true;
			}
		}
	}
};

SelectionTool.prototype.deleteSelect = function()
{
	var all_graphics = this.canvasEditor.getActiveCanvasModel().getAllGraphics();
	for(var index = all_graphics.length - 1; index >= 0; --index)
	{
		if(all_graphics[index].isSelected())
		{
			this.canvasEditor.removeGraphicFromActiveCanvas(all_graphics[index]);
		}
	}
	this.canvasEditor.askViewToRedraw();
}

SelectionTool.prototype.cornerTest = function(x, y)
{
	var i = 0;
	for(; i < selected_graphics.length; ++i)
	{
		if(selected_graphics[i].getType() == "ImageGraphic")
		{
			var iX = selected_graphics[i].rect_x;
			var iY = selected_graphics[i].rect_y;
			var iW = selected_graphics[i].rect_w;
			var iH = selected_graphics[i].rect_h;
			if(Math.abs(x - iX) < 10 && Math.abs(y - iY) < 10 && selected_graphics[i].hitTest(x, y))
			{
				return "nw-resize";
			}
			else if(Math.abs(x - (iX + iW)) < 10 && (Math.abs(y - iY) < 10) && selected_graphics[i].hitTest(x, y))
			{
				return "ne-resize";
			}
			else if(Math.abs(x - iX) < 10 && (Math.abs(y - (iY + iH)) < 10) && selected_graphics[i].hitTest(x, y))
			{
				return "ne-resize";
			}
			else if(Math.abs(x - (iX + iW)) < 10 && (Math.abs(y - (iY + iH)) < 10) && selected_graphics[i].hitTest(x, y))
			{
				return "nw-resize";
			}
		}
	}
	return false;
}

SelectionTool.prototype.render = function()
{
	if(this.is_painting == false)
		return;
	
	systemCanvasContext.save();
	systemCanvasContext.strokeStyle = "#64cb23";
	systemCanvasContext.strokeRect(this.left, this.top, this.width, this.height);
	systemCanvasContext.restore();
};