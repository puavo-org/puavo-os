
function Graphic()
{
	
};

Graphic.prototype.move = function(dx , dy)
{
	
};

Graphic.prototype.setParentCanvasModel = function(gh_set_parent_canvas_model_p_canvas_model)
{
	
};

Graphic.prototype.calcGraphicRect = function()
{

};

Graphic.prototype.hitTest = function(x, y)
{
	
};

Graphic.prototype.calcIsSelected = function(x, y, w, h)
{
	
};

Graphic.prototype.render = function()
{
	
};