
function UndoItem()
{
	this.undo_graphic_list = new Array();
	this.undo_type = "ADD"; // "REMOVE" "MOVE"
	this.graphic_parent_canvas = null;
	this.all_movement_x = 0;
	this.all_movement_y = 0;
	this.is_updateing = false;
};

UndoItem.prototype.setGraphic = function(graphic)
{
	this.undo_graphic_list.push(graphic);
};

UndoItem.prototype.setGraphicCanvas = function(canvas)
{
	this.graphic_parent_canvas = canvas;
};

UndoItem.prototype.setType = function(type)
{
	this.undo_type = type;
};

UndoItem.prototype.updateMovement = function(dx, dy)
{
	if(!this.is_updateing)
		return;
	this.all_movement_x += dx;
	this.all_movement_y += dy;
};

UndoItem.prototype.startMove = function()
{
	this.is_updateing = true;
};

UndoItem.prototype.endMove = function()
{
	this.is_updateing = false;
};

UndoItem.prototype.isStartUpdate = function()
{
	return this.is_updateing;
};

UndoItem.prototype.getType = function()
{
	return this.undo_type;
};

UndoItem.prototype.undo = function()
{
	if(this.undo_type == "ADD")
	{
		var index = 0;
		for(; index < this.undo_graphic_list.length; ++index)
		{
			this.graphic_parent_canvas.removeGraphic(this.undo_graphic_list[index], false);
		}
	}
	else if(this.undo_type == "REMOVE")
	{
		var index = 0;
		for(; index < this.undo_graphic_list.length; ++index)
		{
			this.graphic_parent_canvas.addGraphic(this.undo_graphic_list[index], false);
		}
	}
	else if(this.undo_type == "MOVE")
	{
		var index = 0;
		for(; index < this.undo_graphic_list.length; ++index)
		{
			this.undo_graphic_list[index].move(-this.all_movement_x, -this.all_movement_y);
			if(this.undo_graphic_list[index].debug_name == "HighlighterGraphic")
			{
				this.undo_graphic_list[index].isEditing = true;
				this.undo_graphic_list[index].render();
				this.undo_graphic_list[index].isEditing = false;
				this.undo_graphic_list[index].render();
			}
		}
	}
};

UndoItem.prototype.redo = function()
{
	if(this.undo_type == "ADD")
	{
		var index = 0;
		for(; index < this.undo_graphic_list.length; ++index)
		{
			this.graphic_parent_canvas.addGraphic(this.undo_graphic_list[index], false);
		}
	}
	else if(this.undo_type == "REMOVE")
	{
		var index = 0;
		for(; index < this.undo_graphic_list.length; ++index)
		{
			this.graphic_parent_canvas.removeGraphic(this.undo_graphic_list[index], false);
		}
	}
	else if(this.undo_type == "MOVE")
	{
		var index = 0;
		for(; index < this.undo_graphic_list.length; ++index)
		{
			this.undo_graphic_list[index].move(this.all_movement_x, this.all_movement_y);
			if(this.undo_graphic_list[index].debug_name == "HighlighterGraphic")
			{
				this.undo_graphic_list[index].isEditing = true;
				this.undo_graphic_list[index].render();
				this.undo_graphic_list[index].isEditing = false;
				this.undo_graphic_list[index].render();
			}
		}
	}
};

