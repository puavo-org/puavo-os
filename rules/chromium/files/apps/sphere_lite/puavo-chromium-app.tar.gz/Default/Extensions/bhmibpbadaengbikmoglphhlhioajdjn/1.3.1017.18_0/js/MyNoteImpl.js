/*------------------------------------------------------------------------------------------------------------*
 *                                                                                                            *
 * Copyright      2013 AVer Information Inc.                                                                  *
 *                                                                                                            *
 *------------------------------------------------------------------------------------------------------------*
 * PROJECT     :  ClassCast                                                                                   *
 * BINARY NAME :                                                                                              *
 * FILE NAME   :  intf/MyNoteImpl.js                                                                          *
 * CREATED BY  :  Rock Chen                                                                                   *
 * CREATED DATE:  12/13/13 (MM/DD/YY)                                                                         *
 *------------------------------------------------------------------------------------------------------------*/

/*!
 * @file
 * @author  Rock Chen <Rock.Chen@aver.com>
 * @version 1.0
 *
 * @section DESCRIPTION
 * Interface to represent MyNoteImpl object.
 */

window.requestFileSystem = window.requestFileSystem || window.webkitRequestFileSystem;
navigator.persistentStorage=navigator.persistentStorage||navigator.webkitPersistentStorage;

function MyNoteImpl()
{
    this.fs = 0;
    var me = this;
    navigator.persistentStorage.requestQuota(null, 
	function(grantedBytes)
	{
		this.granted = grantedBytes;
		window.requestFileSystem(PERSISTENT, grantedBytes, function(filesystem) {
		me.fs = filesystem;
		me.fs.root.getDirectory( '/root' , {create: true }, function (dirEntry) {
		console.log( 'You have just created the '  + dirEntry.name + ' directory.' );
		}, function(e){ console.error('getDirectory Error:', e);}); 
		me.fs.root.getDirectory( '/tmp' , {create: true }, function (dirEntry) {
		console.log( 'You have just created the '  + dirEntry.name + ' directory.' );
		}, function(e){ console.error('getDirectory Error:', e);}); 
		}, function(e){ console.error('requestFileSystem Error:', e);});
	}, function(e){ console.error('requestQuota Error:', e);});
};

function dataURItoBlob(dataURI) 
{
    var binary = atob(dataURI.split(',')[1]);
    var array = [];
    for(var i = 0; i < binary.length; i++) 
	{
        array.push(binary.charCodeAt(i));
    }
    return new Blob([new Uint8Array(array)], {type: 'image/jpeg'});
}

MyNoteImpl.prototype.addImage = function(userName, imgName, src)
{
    //averLog.log("MyNoteImpl.addImage(" + userName + ", " + imgName + ", src)  Start");
	this.fs.root.getDirectory ( userName,  { create :  true },  null, function(e){ console.error('getDirectory Error:', e);} );
    this.fs.root.getFile(userName + "/" +imgName, {create:true}, function(fileEntry){
    fileEntry.createWriter(function(fileWriter){
    fileWriter.write(dataURItoBlob(src));
	//averLog.log("MyNoteImpl.addImage() End");
    }, function(e){ console.error('getDirectory Error:', e);});
    }, function(e){ console.error('getDirectory Error:', e);});
};

MyNoteImpl.prototype.copyVideo = function(userName1, imgName1, userName2, imgName2, callback)
{
	this.fs.root.getDirectory(userName1, {create: true}, null, function(e){
		console.error('getDirectory Error:', e);
	});
	this.fs.root.getDirectory(userName2, {create: true}, null, function(e){
		console.error('getDirectory Error:', e);
	});
	var fsRoot = this.fs.root;
	this.fs.root.getFile(userName1 + "/" +imgName1, {create: true}, function(fileEntry){
		fsRoot.getDirectory(userName2, {create: true}, function(dirEntry){
			fileEntry.copyTo(dirEntry);
			if(callback !== undefined)
					callback();
		});
	}, function(e){ console.error('getDirectory Error:', e);});
}

MyNoteImpl.prototype.deleteVideo = function(userName, imgName)
{
	this.fs.root.getFile(userName + "/" +imgName, {create: false}, function(fileEntry){
		fileEntry.remove(function(){			
		}, function(e){ console.error('getDirectory Error:', e);});
	}, function(e){ console.error('getDirectory Error:', e);});
}

MyNoteImpl.prototype.deleteDirectory = function(userName)
{
	this.fs.root.getDirectory(userName, {}, function(dirEntry) {
		 dirEntry.removeRecursively(function() {});
	}, function(e){
		console.error('getDirectory Error:', e);
	});
}

MyNoteImpl.prototype.addVideo = function(userName, imgName, blob, callback)
{
	this.fs.root.getDirectory(userName, {create: true}, null, function(e){
		console.error('getDirectory Error:', e);
	});
	this.fs.root.getFile(userName + "/" +imgName, {create: true}, function(fileEntry){
		fileEntry.createWriter(function(fileWriter){
			fileWriter.onwriteend = function(e) {
				if(callback !== undefined)
					callback();
			}
			fileWriter.write(blob);
		}, function(e){ console.error('getDirectory Error:', e);});
	}, function(e){ console.error('getDirectory Error:', e);});
}

MyNoteImpl.prototype.addVideoTmp = function(userName, imgName, blob)
{
	this.fs.root.getDirectory(userName, {create: false}, null, function(e){
		console.error('getDirectory Error:', e);
	});
	this.fs.root.getFile(userName + "/" +imgName, {create: false}, function(fileEntry){
		fileEntry.createWriter(function(fileWriter){
			console.log("fileWriter.length: " + fileWriter.length);
			fileWriter.seek(fileWriter.length);
			fileWriter.write(blob);
		}, function(e){ console.error('getDirectory Error:', e);});
	}, function(e){ console.error('getDirectory Error:', e);});
}

function creatHeadDir(userName)
{
	//averLog.log("creatHeadDir Start");
    if (!this.fs) 
	{	    
        return;
    }
	this.fs.root.getDirectory ( userName + "_head",  { create :  true },  function ( dirEntry )  
	{ 
	    //averLog.log("creatHeadDir OK");
    }, function(e){ console.error('getDirectory Error:', e);} );         
}

MyNoteImpl.prototype.saveHeadImage = function(userName, src)
{
    //averLog.log("MyNoteImpl.saveHeadImage(" + userName + ", " + src + ") Start");
	creatHeadDir(userName);
	this.fs.root.getDirectory ( userName + "_head/",  { create :  true },  null, function(e){ console.error('getDirectory Error:', e);} );
    this.fs.root.getFile(userName + "_head/headImg.png", {create:true}, function(fileEntry){
    fileEntry.createWriter(function(fileWriter){
    fileWriter.write(dataURItoBlob(src));
	
	//averLog.log("MyNoteImpl.saveHeadImage() End");
    }, function(e){ console.error('getDirectory Error:', e);});
    }, function(e){ console.error('getDirectory Error:', e);});
};

MyNoteImpl.prototype.getHeadImage= function(userName, callback)
{
	creatHeadDir(userName);
	//averLog.log("MyNoteImpl.getHeadImage(" + userName + ") Start");	
    this.fs.root.getFile(userName + "_head/headImg.png", {}, function(fileEntry)
	{
        fileEntry.file(function(file) 
	    {
            var reader = new FileReader();
            reader.onloadend = function(e)
	        {
				if(reader.readyState == 2)
				{
					if(!isFunction(callback))
					{
						return;
					}
					callback(this.result);
				}
            };
            reader.readAsDataURL(file);
        }, function(e){ console.error('getDirectory Error:', e);});
    }, function(e){ console.error('getDirectory Error:', e);});
}

MyNoteImpl.prototype.saveScaleHeadImage = function(userName, src)
{
    //averLog.log("MyNoteImpl.saveHeadImage(" + userName + ", " + src + ") Start");
	creatHeadDir(userName);
	this.fs.root.getDirectory ( userName + "_head/",  { create :  true },  null, function(e){ console.error('getDirectory Error:', e);} );
    this.fs.root.getFile(userName + "_head/scaleHeadImg.png", {create:true}, function(fileEntry){
    fileEntry.createWriter(function(fileWriter){
    fileWriter.write(dataURItoBlob(src));
	
	//averLog.log("MyNoteImpl.saveHeadImage() End");
    }, function(e){ console.error('getDirectory Error:', e);});
    }, function(e){ console.error('getDirectory Error:', e);});
};

MyNoteImpl.prototype.getScaleHeadImage= function(userName, callback)
{
	creatHeadDir(userName);
	//averLog.log("MyNoteImpl.getHeadImage(" + userName + ") Start");	
    this.fs.root.getFile(userName + "_head/scaleHeadImg.png", {}, function(fileEntry)
	{
        fileEntry.file(function(file) 
	    {
            var reader = new FileReader();
            reader.onloadend = function(e)
	        {
				if(reader.readyState == 2)
				{
					if(!isFunction(callback))
					{
						return;
					}
					callback(this.result);
				}
            };
            reader.readAsDataURL(file);
        }, function(e){ console.error('getDirectory Error:', e);});
    }, function(e){ console.error('getDirectory Error:', e);});
}

MyNoteImpl.prototype.getFileSystem = function()
{
    return this.fs;
};

var myNoteImpl = new MyNoteImpl();